/* КК · Монтаж — шрифты компьютера и Adobe Fonts. Премьер не отдаёт скриптам список шрифтов, поэтому читаем сами файлы:
   шаблону нужно PostScript-имя, панели — семейство, начертание и есть ли кириллица (субтитры русские). */
window.KKFonts = (function () {
  var FACE = /\.(ttf|otf|ttc|otc)$/i, CACHE = 1;   // версия кэша: поменять, если в нём появятся новые поля
  function dirs() {
    var os = require("os"), path = require("path"), h = os.homedir(), e = process.env;
    if (process.platform === "win32") return [path.join(e.WINDIR || "C:\\Windows", "Fonts"), path.join(e.LOCALAPPDATA || "", "Microsoft", "Windows", "Fonts"), path.join(e.APPDATA || "", "Adobe", "CoreSync", "plugins", "livetype"), path.join(e.CommonProgramFiles || "C:\\Program Files\\Common Files", "Adobe", "Fonts")];
    return [path.join(h, "Library", "Fonts"), "/Library/Fonts", "/System/Library/Fonts", path.join(h, "Library", "Application Support", "Adobe", "CoreSync", "plugins", "livetype"), path.join(h, "Library", "Application Support", "Adobe", "Fonts"), "/Library/Application Support/Adobe/Fonts"];
  }
  // шрифты Adobe лежат в скрытых папках и часто без расширения — там берём все файлы, а что это шрифт, решит заголовок
  function walk(dir, any, out, depth) {
    var fs = require("fs"), path = require("path"), l; try { l = fs.readdirSync(dir); } catch (e) { return; }
    l.forEach(function (n) { var p = path.join(dir, n), s; try { s = fs.statSync(p); } catch (e) { return; }
      if (s.isDirectory()) { if (depth < 4) walk(p, any, out, depth + 1); } else if (any || FACE.test(n)) out.push({ p: p, m: +s.mtime, z: s.size }); });
  }
  function rd(fd, pos, len) { var b = Buffer.alloc(len); require("fs").readSync(fd, b, 0, len, pos); return b; }
  function tables(fd, off) { var n = rd(fd, off + 4, 2).readUInt16BE(0), d = rd(fd, off + 12, n * 16), t = {};
    for (var i = 0; i < n; i++) t[d.toString("latin1", i * 16, i * 16 + 4)] = { o: d.readUInt32BE(i * 16 + 8), l: d.readUInt32BE(i * 16 + 12) };
    return t; }
  function names(fd, tb) {
    var b = rd(fd, tb.o, Math.min(tb.l, 4e6)), n = b.readUInt16BE(2), so = b.readUInt16BE(4), best = {}, res = {};
    for (var i = 0; i < n; i++) { var r = 6 + i * 12; if (r + 12 > b.length) break;
      var pid = b.readUInt16BE(r), lang = b.readUInt16BE(r + 4), id = b.readUInt16BE(r + 6), len = b.readUInt16BE(r + 8), o = so + b.readUInt16BE(r + 10);
      if ([1, 2, 6, 16, 17].indexOf(id) < 0 || o + len > b.length || (pid !== 0 && pid !== 1 && pid !== 3)) continue;
      var score = pid === 3 ? (lang === 0x409 ? 4 : 2) : pid === 1 && lang === 0 ? 3 : 1; if (best[id] >= score) continue; best[id] = score;
      if (pid === 1) res[id] = b.toString("latin1", o, o + len); else { var u = Buffer.from(b.slice(o, o + len)); u.swap16 && len % 2 === 0 && u.swap16(); res[id] = u.toString("utf16le"); }
    }
    return res;
  }
  // есть ли символ в шрифте: смотрим таблицу cmap (форматы 4 и 12 — почти все шрифты)
  function cmapHas(b, o, c) {
    var f = b.readUInt16BE(o), i;
    if (f === 12) { var g = b.readUInt32BE(o + 12); for (i = 0; i < g; i++) { var p = o + 16 + i * 12; if (c >= b.readUInt32BE(p) && c <= b.readUInt32BE(p + 4)) return true; } return false; }
    if (f !== 4) return false;
    var sc = b.readUInt16BE(o + 6) / 2, E = o + 14, S = E + sc * 2 + 2, D = S + sc * 2, R = D + sc * 2;
    for (i = 0; i < sc; i++) { if (b.readUInt16BE(E + i * 2) < c) continue; if (b.readUInt16BE(S + i * 2) > c) return false;
      var ro = b.readUInt16BE(R + i * 2); if (!ro) return ((c + b.readUInt16BE(D + i * 2)) & 0xffff) !== 0;
      return b.readUInt16BE(R + i * 2 + ro + (c - b.readUInt16BE(S + i * 2)) * 2) !== 0; }
    return false;
  }
  function hasCyr(fd, tb) {
    var b = rd(fd, tb.o, Math.min(tb.l, 4e6)), n = b.readUInt16BE(2), pick = -1, rank = 0;
    for (var i = 0; i < n; i++) { var r = 4 + i * 8, pid = b.readUInt16BE(r), eid = b.readUInt16BE(r + 2), k = pid === 3 && eid === 10 ? 4 : pid === 0 && eid >= 4 ? 3 : pid === 3 && eid === 1 ? 2 : pid === 0 ? 1 : 0; if (k > rank) { rank = k; pick = b.readUInt32BE(r + 4); } }
    return pick >= 0 && cmapHas(b, pick, 0x416) && cmapHas(b, pick, 0x436);   // и заглавная, и строчная: есть шрифты только с заглавной кириллицей
  }
  function face(fd, off) {
    var t = tables(fd, off); if (!t.name || !t.cmap) return null;
    var nm = names(fd, t.name), ps = nm[6], fam = nm[16] || nm[1]; if (!ps || !fam || fam.charAt(0) === "." || ps.charAt(0) === ".") return null;
    var w = 400, it = 0; if (t["OS/2"]) { try { var o2 = rd(fd, t["OS/2"].o, 64); w = o2.readUInt16BE(4); it = o2.readUInt16BE(62) & 1; } catch (e) {} }
    var cyr = false; try { cyr = hasCyr(fd, t.cmap); } catch (e) {}
    return { p: ps, n: fam, s: nm[17] || nm[2] || "Regular", w: w, i: it, c: cyr ? 1 : 0 };
  }
  function parse(file) {
    var fs = require("fs"), fd, out = [];
    try { fd = fs.openSync(file, "r"); var tag = rd(fd, 0, 4).toString("latin1");
      if (tag === "ttcf") { var n = Math.min(rd(fd, 8, 4).readUInt32BE(0), 64), o = rd(fd, 12, n * 4); for (var i = 0; i < n; i++) { var f = face(fd, o.readUInt32BE(i * 4)); if (f) out.push(f); } }
      else if (tag === "OTTO" || tag === "true" || tag === "\x00\x01\x00\x00") { var g = face(fd, 0); if (g) out.push(g); }
    } catch (e) {} if (fd !== undefined) try { fs.closeSync(fd); } catch (e) {}
    return out;
  }
  function group(cache) {
    var byPs = {}, fams = {}, path = Object.keys(cache);
    path.forEach(function (p) { cache[p].f.forEach(function (x) { if (!byPs[x.p]) { byPs[x.p] = 1; var F = fams[x.n] || (fams[x.n] = { n: x.n, c: 0, file: p, faces: [] }); if (x.c) F.c = 1; F.faces.push({ p: x.p, s: x.s, w: x.w, i: x.i, file: p }); } }); });
    return Object.keys(fams).map(function (k) { var F = fams[k]; F.faces.sort(function (a, b) { return a.i - b.i || a.w - b.w || (a.s < b.s ? -1 : 1); });
      var R = F.faces.slice().sort(function (a, b) { return a.i - b.i || Math.abs(a.w - 400) - Math.abs(b.w - 400) || b.w - a.w; })[0]; F.reg = R; F.file = R.file; return F; })
      .sort(function (a, b) { return a.n.localeCompare(b.n, "ru"); });
  }
  // список — пачками, чтобы панель не замирала; разбираем только новые файлы, остальное из кэша
  function scan(done) {
    var fs = require("fs"), path = require("path"), os = require("os"), cf = path.join(os.homedir(), ".kodkreatora", "fonts.json"), old = {}, files = [], next = {};
    try { var j = JSON.parse(fs.readFileSync(cf, "utf8")); if (j.v === CACHE) old = j.f; } catch (e) {}
    dirs().forEach(function (d) { walk(d, /livetype/.test(d), files, 0); });
    var i = 0;
    (function step() {
      var end = Math.min(i + 40, files.length);
      for (; i < end; i++) { var x = files[i], o = old[x.p]; next[x.p] = o && o.m === x.m && o.z === x.z ? o : { m: x.m, z: x.z, f: parse(x.p) }; }
      if (i < files.length) return setTimeout(step, 0);
      try { fs.mkdirSync(path.dirname(cf), { recursive: true }); fs.writeFileSync(cf, JSON.stringify({ v: CACHE, f: next })); } catch (e) {}
      done(group(next));
    })();
  }
  function url(file) { var p = String(file).replace(/\\/g, "/"); return "file://" + (p.charAt(0) === "/" ? "" : "/") + encodeURI(p).replace(/#/g, "%23").replace(/\?/g, "%3F"); }
  return { scan: scan, url: url };
})();

#!/bin/bash
# Установка плагинов КОД КРЕАТОРА для Premiere Pro (Mac)
cd "$(dirname "$0")"
EXT="$HOME/Library/Application Support/Adobe/CEP/extensions"
mkdir -p "$EXT"
for P in kk-montazh kk-animacia; do
  [ -d "$P" ] || continue
  rm -rf "$EXT/$P"; cp -R "$P" "$EXT/$P"
done
xattr -dr com.apple.quarantine "$EXT/kk-montazh" "$EXT/kk-animacia" 2>/dev/null
# разрешаем Премьеру загружать плагины не из Adobe Exchange (все версии 2019–2026)
for v in 9 10 11 12 13; do defaults write com.adobe.CSXS.$v PlayerDebugMode 1; done
mkdir -p "$HOME/Library/Fonts"; cp fonts/*.ttf "$HOME/Library/Fonts/" 2>/dev/null
echo ""
echo "  Готово! Плагины КОД КРЕАТОРА установлены."
echo "  Перезапусти Premiere Pro → Окно → Расширения → «КК · Монтаж» и «КК · Анимация»."
echo ""
read -n 1 -s -r -p "  Нажми любую клавишу, чтобы закрыть окно"

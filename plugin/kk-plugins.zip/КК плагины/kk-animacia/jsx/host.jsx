/* КК · Анимация — часть внутри Premiere Pro (ExtendScript, ES3: без let/const и стрелок).
   Скрипты Премьера не умеют задавать кривые плавности ключей, поэтому анимации «запекаются»:
   плагин сам считает промежуточные ключи по кривой (как это делают коммерческие плагины).
   Каждая функция возвращает строку: "ok|сообщение" или "err|сообщение". */

var KK_TICKS = 254016000000;

/* ---------- кривые ---------- */
var KK_EASE = {
  linear: function (t) { return t; },
  outCubic: function (t) { return 1 - Math.pow(1 - t, 3); },
  inCubic: function (t) { return t * t * t; },
  inOutCubic: function (t) { return t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; },
  outExpo: function (t) { return t === 1 ? 1 : 1 - Math.pow(2, -10 * t); },
  outQuint: function (t) { return 1 - Math.pow(1 - t, 5); },
  outBack: function (t) { var c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
  outElastic: function (t) { if (t === 0 || t === 1) return t; return Math.pow(2, -10 * t) * Math.sin((t * 10 - .75) * (2 * Math.PI / 3)) + 1; },
  outBounce: function (t) {
    var n = 7.5625, d = 2.75;
    if (t < 1 / d) return n * t * t;
    if (t < 2 / d) { t -= 1.5 / d; return n * t * t + .75; }
    if (t < 2.5 / d) { t -= 2.25 / d; return n * t * t + .9375; }
    t -= 2.625 / d; return n * t * t + .984375;
  }
};

/* ---------- помощники ---------- */
function kkSeq() { return app.project.activeSequence; }
function kkFps(seq) { return KK_TICKS / Number(seq.timebase); }
function kkSel() {
  var seq = kkSeq(); if (!seq) return [];
  var s = seq.getSelection(), out = [];
  for (var i = 0; i < s.length; i++) if (s[i].mediaType === "Video") out.push(s[i]);
  return out;
}
function kkComp(item, match) {
  for (var i = 0; i < item.components.numItems; i++) if (item.components[i].matchName === match) return item.components[i];
  return null;
}
function kkLerp(a, b, e) {
  if (a instanceof Array) { var r = []; for (var i = 0; i < a.length; i++) r.push(a[i] + (b[i] - a[i]) * e); return r; }
  return a + (b - a) * e;
}
/* клип: время начала/конца в «времени исходника» — так Премьер считает ключи */
function kkSpan(item) {
  var inS = item.inPoint.seconds, len = item.end.seconds - item.start.seconds;
  return { a: inS, b: inS + len, len: len };
}
function kkBase(prop, t) {
  return prop.isTimeVarying() ? prop.getValueAtTime(t) : prop.getValue();
}
/* ставит ряд ключей: f(k) -> значение, на кадрах t0..t1 */
function kkBake(prop, t0, t1, fps, f) {
  if (!prop.isTimeVarying()) prop.setTimeVarying(true);
  var n = Math.max(2, Math.round((t1 - t0) * fps));
  for (var k = 0; k <= n; k++) {
    var t = t0 + (t1 - t0) * k / n;
    prop.addKey(t);
    prop.setValueAtKey(t, f(k / n), k === n);
  }
}

var KK_FX = {
  stab: ["Warp Stabilizer", "Стабилизатор деформации"],
  transform: ["Transform", "Преобразовать"]
};
function kkQeItem(item) {
  // ищем по времени начала и имени: порядковый номер сбивают переходы и пустоты на дорожке
  app.enableQE();
  var qs = qe.project.getActiveSequence(), seq = kkSeq(), st = item.start.seconds, en = item.end.seconds;
  for (var v = 0; v < seq.videoTracks.numTracks; v++) {
    var tr = seq.videoTracks[v], here = false;
    for (var c = 0; c < tr.clips.numItems; c++) if (tr.clips[c].nodeId === item.nodeId) here = true;
    if (!here) continue;
    var qt = qs.getVideoTrackAt(v), best = null;
    for (var q = 0; q < qt.numItems; q++) {
      var qi = qt.getItemAt(q); if (!qi || qi.type === "Empty") continue;
      var s0 = -1, e0 = -1; try { s0 = qi.start.secs; e0 = qi.end.secs; } catch (e) { continue; }
      if (Math.abs(s0 - st) < 0.02 && Math.abs(e0 - en) < 0.02) { if (qi.name === item.name) return qi; best = best || qi; }
    }
    if (best) return best;
  }
  return null;
}
// Премьер отдаёт названия эффектов то полностью, то сокращённо («Волнообр. деформ-ия», «Стабил-тор деформ.»),
// а getVideoEffectByName «находит» что угодно — поэтому сверяем со списком с учётом сокращений
function kkFxMatch(listName, want) {
  var a = String(listName).toLowerCase().replace(/\s*\(.*$/, "").split(/\s+/), b = String(want).toLowerCase().split(/\s+/);
  if (a.length !== b.length) return false;
  for (var i = 0; i < a.length; i++) {
    var w = a[i], t = b[i];
    if (w === t) continue;
    var cut = w.search(/[.\-]/);                                   // «деформ-ия» → «деформ», «Волнообр.» → «волнообр»
    if (cut > 1) { var pre = w.slice(0, cut), suf = w.slice(cut + 1).replace(/\./g, "");
      if (t.indexOf(pre) === 0 && (!suf || t.slice(-suf.length) === suf)) continue; }
    return false;
  }
  return true;
}
function kkFx(names) {
  app.enableQE();
  var list = qe.project.getVideoEffectList();
  var j, i, pass;
  for (pass = 0; pass < 3; pass++)            // 0 — точное имя, 1 — сокращение, 2 — устаревшая версия «(пред.)»
    for (i = 0; i < names.length; i++) for (j = 0; j < list.length; j++) {
      var L = String(list[j]), legacy = /\(пред|\(legacy/i.test(L);
      if (pass === 0 ? L === names[i] : pass === 1 ? (!legacy && kkFxMatch(L, names[i])) : kkFxMatch(L, names[i]))
        return qe.project.getVideoEffectByName(L);
    }
  return null;
}

function kkSrcSize(item) {
  try { var m = item.projectItem.getProjectMetadata(); var r = /VideoInfo>(\d+) x (\d+)/.exec(m); if (r) return [+r[1], +r[2]]; } catch (e) {}
  return null;
}

/* ---------- КК · Анимация ---------- */
var KK_FXA = { post: ["Posterize Time", "Время постеризации"], wave: ["Wave Warp", "Волнообразная деформация"] };
/* какой эффект добавился: Премьер ставит некоторые эффекты (стабилизатор) всегда в конец, поэтому «последний» не годится */
function kkAddedComp(item, before) {
  var cnt = {}, i;
  for (i = 0; i < before.length; i++) cnt[before[i]] = (cnt[before[i]] || 0) + 1;
  var seen = {};
  for (i = 0; i < item.components.numItems; i++) { var m = item.components[i].matchName; seen[m] = (seen[m] || 0) + 1; }
  for (i = item.components.numItems - 1; i >= 0; i--) { var mm = item.components[i].matchName; if ((seen[mm] || 0) > (cnt[mm] || 0)) return item.components[i]; }
  return null;
}
function kkMatchNames(item) { var a = []; for (var i = 0; i < item.components.numItems; i++) a.push(item.components[i].matchName); return a; }
function kkAddFx(item, names) {
  var fx = kkFx(names); if (!fx) return null;
  var qi = kkQeItem(item); if (!qi) return null;
  var before = kkMatchNames(item);
  qi.addVideoEffect(fx);
  return kkAddedComp(item, before);
}
/* «через кадр»: fps 12 (на двойках) | 8 (на тройках) */
function ka_steps(fps) {
  try {
    var items = kkSel(); if (!items.length) return "err|Выдели клип";
    for (var i = 0; i < items.length; i++) { if (!kkQeItem(items[i])) return "err|Не нашла клип — выдели его на таймлайне ещё раз"; var c = kkAddFx(items[i], KK_FXA.post); if (!c) return "err|Нет эффекта «Время постеризации» в этой версии"; c.properties[0].setValue(Number(fps) || 12, true); }
    return "ok|Анимация теперь " + (fps || 12) + " к/с — эффект stop-motion";
  } catch (e) { return "err|" + e.toString(); }
}
/* рисованная тряска контура */
function ka_boil(power) {
  try {
    var items = kkSel(); if (!items.length) return "err|Выдели клип";
    var pw = Number(power) || 1;
    for (var i = 0; i < items.length; i++) {
      if (!kkQeItem(items[i])) return "err|Не нашла клип — выдели его на таймлайне ещё раз"; var c = kkAddFx(items[i], KK_FXA.wave); if (!c) return "err|Нет эффекта «Волнообразная деформация» в этой версии";
      var vals = { 1: 2 * pw, 2: 40, 3: 0.6 }; // высота, ширина, скорость волны
      for (var k in vals) try { c.properties[Number(k)].setValue(vals[k], true); } catch (e2) {}
      var p = kkAddFx(items[i], KK_FXA.post); if (p) p.properties[0].setValue(8, true);
    }
    return "ok|Контур «дышит», как нарисованный";
  } catch (e) { return "err|" + e.toString(); }
}
/* циклы на весь клип: sway (качание) | float (парение) | pulse (пульс) | spin (вращение) | blink (мигание) ; period — секунды */
function ka_loop(kind, period, amount) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var items = kkSel(); if (!items.length) return "err|Выдели клип";
    var fps = kkFps(seq), T = Number(period) || 1.5, A = Number(amount) || 1, U = Math.min(seq.frameSizeHorizontal, seq.frameSizeVertical) / 1080;
    for (var i = 0; i < items.length; i++) {
      var it = items[i], sp = kkSpan(it), mo = kkComp(it, "AE.ADBE Motion"), op = kkComp(it, "AE.ADBE Opacity");
      var pos = mo.properties[0], sc = mo.properties[1], rot = mo.properties[4];
      var P = kkBase(pos, sp.a), S = kkBase(sc, sp.a), R = kkBase(rot, sp.a), H = seq.frameSizeVertical;
      var w = function (x) { return 2 * Math.PI * x * sp.len / T; };
      var f = Math.min(fps, 15); // для циклов хватает 15 ключей в секунду — меньше нагрузка
      if (kind === "sway") kkBake(rot, sp.a, sp.b, f, function (x) { return R + 8 * A * Math.sin(w(x)); });
      else if (kind === "float") kkBake(pos, sp.a, sp.b, f, function (x) { return [P[0], P[1] + 18 * A * U / H * Math.sin(w(x))]; });
      else if (kind === "pulse") kkBake(sc, sp.a, sp.b, f, function (x) { return S * (1 + 0.06 * A * (0.5 + 0.5 * Math.sin(w(x)))); });
      else if (kind === "spin") { rot.setTimeVarying(true); rot.addKey(sp.a); rot.setValueAtKey(sp.a, R, false); rot.addKey(sp.b); rot.setValueAtKey(sp.b, R + 360 * A * sp.len / T, true); }
      else if (kind === "blink") { if (!op) return "err|Нет непрозрачности"; var O = kkBase(op.properties[0], sp.a);
        kkBake(op.properties[0], sp.a, sp.b, fps, function (x) { return Math.sin(w(x)) > -0.3 ? O : 0; }); }
      else return "err|Неизвестный цикл";
    }
    return "ok|Цикл на весь клип готов";
  } catch (e) { return "err|" + e.toString(); }
}
/* появление лесенкой: выделенные клипы выскакивают по очереди (сверху вниз по дорожкам, слева направо) */
function ka_stagger(step, dur) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var items = kkSel(); if (items.length < 2) return "err|Выдели 2 и больше клипов";
    var fps = kkFps(seq), st = Number(step) || 0.12, d = Number(dur) || 0.35;
    items.sort(function (a, b) { return a.start.seconds - b.start.seconds; });
    for (var i = 0; i < items.length; i++) {
      var it = items[i], sp = kkSpan(it), mo = kkComp(it, "AE.ADBE Motion"), op = kkComp(it, "AE.ADBE Opacity"), sc = mo.properties[1];
      var t0 = sp.a + i * st, t1 = Math.min(sp.b, t0 + d), S = kkBase(sc, t1), O = op ? kkBase(op.properties[0], t1) : 100;
      if (i * st > 0) kkBake(sc, sp.a, t0, fps, function () { return 0; });
      kkBake(sc, t0, t1, fps, function (x) { return S * KK_EASE.outBack(x); });
      if (op) kkBake(op.properties[0], t0, t1, fps, function (x) { return O * Math.min(1, x * 3); });
    }
    return "ok|Лесенка готова, объектов: " + items.length;
  } catch (e) { return "err|" + e.toString(); }
}
/* прыжок со сжатием и растяжением: объект подпрыгивает, на земле сплющивается */
function ka_jump(height, times) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var items = kkSel(); if (!items.length) return "err|Выдели клип";
    var fps = kkFps(seq), U = Math.min(seq.frameSizeHorizontal, seq.frameSizeVertical) / 1080, H = seq.frameSizeVertical, N = Number(times) || 2, h = (Number(height) || 220) * U / H;
    for (var i = 0; i < items.length; i++) {
      var it = items[i], sp = kkSpan(it), mo = kkComp(it, "AE.ADBE Motion"), pos = mo.properties[0];
      var P = kkBase(pos, sp.a), S = kkBase(mo.properties[1], sp.a);
      mo.properties[3].setValue(false, true); // неравномерный масштаб
      var sh = mo.properties[1], sw = mo.properties[2];
      var L = Math.min(sp.len, N * 0.7);
      var ph = function (x) { var y = (x * N) % 1; return y; };
      kkBake(pos, sp.a, sp.a + L, fps, function (x) { var y = ph(x); return [P[0], P[1] - h * 4 * y * (1 - y)]; });
      kkBake(sh, sp.a, sp.a + L, fps, function (x) { var y = ph(x), g = Math.max(0, 1 - Math.min(y, 1 - y) * 8); return S * (1 + 0.12 * (Math.abs(0.5 - y) < 0.35 ? 0.4 : 0) - 0.22 * g); });
      kkBake(sw, sp.a, sp.a + L, fps, function (x) { var y = ph(x), g = Math.max(0, 1 - Math.min(y, 1 - y) * 8); return S * (1 - 0.06 * (Math.abs(0.5 - y) < 0.35 ? 0.4 : 0) + 0.22 * g); });
    }
    return "ok|Прыжок готов, повторов: " + N;
  } catch (e) { return "err|" + e.toString(); }
}
/* движение по дуге: из текущего места в сторону (dir: left|right|up|down) по красивой дуге */
function ka_arc(dir, dist) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var items = kkSel(); if (!items.length) return "err|Выдели клип";
    var fps = kkFps(seq), W = seq.frameSizeHorizontal, H = seq.frameSizeVertical, U = Math.min(W, H) / 1080, D = (Number(dist) || 400) * U;
    var vx = dir === "left" ? -D : dir === "right" ? D : 0, vy = dir === "up" ? -D : dir === "down" ? D : 0;
    // контрольная точка дуги: перпендикулярно движению, для горизонтали — вверх
    var cx = vx / 2 + (vx ? 0 : D * 0.35), cy = vy / 2 - (vx ? D * 0.35 : 0);
    for (var i = 0; i < items.length; i++) {
      var it = items[i], sp = kkSpan(it), pos = kkComp(it, "AE.ADBE Motion").properties[0], P = kkBase(pos, sp.a), len = Math.min(sp.len, 1.2);
      var px = P[0] * W, py = P[1] * H;
      kkBake(pos, sp.a, sp.a + len, fps, function (x) { var t = KK_EASE.inOutCubic(x), u = 1 - t;
        return [(px + 2 * u * t * cx + t * t * vx) / W, (py + 2 * u * t * cy + t * t * vy) / H]; });
    }
    return "ok|Движение по дуге готово";
  } catch (e) { return "err|" + e.toString(); }
}
function kk_ping() { return "ok|" + app.version + "|" + (app.project ? app.project.name : ""); }

var KA_DIR = "";
try { KA_DIR = (new File($.fileName)).parent.parent.fsName; } catch (e) {}
function kaLoadPresets() { try { var f = new File(KA_DIR + "/jsx/presets.jsx"); if (f.exists) $.evalFile(f); return typeof ka_lists === "function"; } catch (e) { return false; } }
function ka_setDir(d) { if (d) KA_DIR = d; var ok = kaLoadPresets(); return "ok|" + KA_DIR + "|" + (ok ? "presets" : "no-presets"); }
if (KA_DIR) kaLoadPresets();

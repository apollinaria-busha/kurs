/* КК · Анимация — пресеты v2 (~50 механик). ES3. Сдвиги в «пикселях 1080p». */
function kaCtx() {
  var seq = kkSeq(); if (!seq) return { err: "err|Открой секвенцию" };
  var items = kkSel(); if (!items.length) return { err: "err|Выдели клип" };
  var W = seq.frameSizeHorizontal, H = seq.frameSizeVertical;
  return { seq: seq, items: items, fps: kkFps(seq), W: W, H: H, U: Math.min(W, H) / 1080 };
}
function kaRnd(i) { var x = Math.sin(i * 12.9898 + 78.233) * 43758.5453; return x - Math.floor(x); }

/* ---------- циклы на весь клип ---------- */
var KA_LOOPS = {
  sway: "Качание", pendulum: "Маятник", "float": "Парение", hover: "Парение с наклоном", pulse: "Пульс", heartbeat: "Сердцебиение", breathe: "Дыхание",
  zoomPulse: "Удар в бит", spin: "Вращение", roll: "Катится", wobble: "Покачивание", jelly: "Желе", flip: "Переворот по кругу", tilt: "Наклоны",
  hop: "Прыжки на месте", orbit: "Орбита", figure8: "Восьмёрка", wiggle: "Хаотичное дрожание", blink: "Мигание", shakeLoop: "Тряска"
};
function ka_loop2(id, period, amount) {
  try {
    var c = kaCtx(); if (c.err) return c.err;
    var T = Number(period) || 1.5, A = Number(amount) || 1;
    for (var i = 0; i < c.items.length; i++) {
      var it = c.items[i], sp = kkSpan(it), mo = kkComp(it, "AE.ADBE Motion"), op = kkComp(it, "AE.ADBE Opacity");
      var pos = mo.properties[0], sc = mo.properties[1], scw = mo.properties[2], uni = mo.properties[3], rot = mo.properties[4];
      var P = kkBase(pos, sp.a), S = kkBase(sc, sp.a), R = kkBase(rot, sp.a), f = Math.min(c.fps, 15);
      var ph = function (x) { return x * sp.len / T; }, s2 = function (x) { return Math.sin(ph(x) * Math.PI * 2); };
      var dx = function (px) { return px * c.U / c.W * A; }, dy = function (px) { return px * c.U / c.H * A; };
      if (id === "sway") kkBake(rot, sp.a, sp.b, f, function (x) { return R + 8 * A * s2(x); });
      else if (id === "pendulum") kkBake(rot, sp.a, sp.b, f, function (x) { return R + 30 * A * s2(x); });
      else if (id === "float") kkBake(pos, sp.a, sp.b, f, function (x) { return [P[0], P[1] + dy(18) * s2(x)]; });
      else if (id === "hover") { kkBake(pos, sp.a, sp.b, f, function (x) { return [P[0], P[1] + dy(16) * s2(x)]; }); kkBake(rot, sp.a, sp.b, f, function (x) { return R + 4 * A * Math.cos(ph(x) * Math.PI * 2); }); }
      else if (id === "pulse") kkBake(sc, sp.a, sp.b, f, function (x) { return S * (1 + .06 * A * (.5 + .5 * s2(x))); });
      else if (id === "heartbeat") kkBake(sc, sp.a, sp.b, c.fps, function (x) { var t = ph(x) % 1; return S * (1 + .1 * A * (Math.exp(-Math.pow((t - .1) / .04, 2)) + .7 * Math.exp(-Math.pow((t - .28) / .04, 2)))); });
      else if (id === "breathe") kkBake(sc, sp.a, sp.b, f, function (x) { return S * (1 + .03 * A * s2(x)); });
      else if (id === "zoomPulse") kkBake(sc, sp.a, sp.b, c.fps, function (x) { var t = ph(x) % 1; return S * (1 + .08 * A * Math.exp(-t * 9)); });
      else if (id === "spin") { rot.setTimeVarying(true); rot.addKey(sp.a); rot.setValueAtKey(sp.a, R, false); rot.addKey(sp.b); rot.setValueAtKey(sp.b, R + 360 * A * sp.len / T, true); }
      else if (id === "roll") { kkBake(rot, sp.a, sp.b, f, function (x) { return R + 360 * A * ph(x); }); kkBake(pos, sp.a, sp.b, f, function (x) { return [P[0] + dx(120) * s2(x / 2), P[1]]; }); }
      else if (id === "wobble") { kkBake(rot, sp.a, sp.b, f, function (x) { return R + 6 * A * s2(x); }); kkBake(sc, sp.a, sp.b, f, function (x) { return S * (1 + .04 * A * Math.cos(ph(x) * Math.PI * 4)); }); }
      else if (id === "jelly") { uni.setValue(false, true); var SW = kkBase(scw, sp.a);
        kkBake(scw, sp.a, sp.b, f, function (x) { return SW * (1 + .08 * A * s2(x)); }); kkBake(sc, sp.a, sp.b, f, function (x) { return S * (1 - .08 * A * s2(x)); }); }
      else if (id === "flip") { uni.setValue(false, true); var SW2 = kkBase(scw, sp.a); kkBake(scw, sp.a, sp.b, c.fps, function (x) { return SW2 * Math.cos(ph(x) * Math.PI * 2); }); }
      else if (id === "tilt") kkBake(rot, sp.a, sp.b, c.fps, function (x) { return R + (Math.floor(ph(x) * 2) % 2 ? 6 : -6) * A; });
      else if (id === "hop") kkBake(pos, sp.a, sp.b, c.fps, function (x) { var t = ph(x) % 1; return [P[0], P[1] - dy(80) * 4 * t * (1 - t)]; });
      else if (id === "orbit") kkBake(pos, sp.a, sp.b, f, function (x) { var a = ph(x) * Math.PI * 2; return [P[0] + dx(60) * Math.cos(a), P[1] + dy(60) * Math.sin(a)]; });
      else if (id === "figure8") kkBake(pos, sp.a, sp.b, f, function (x) { var a = ph(x) * Math.PI * 2; return [P[0] + dx(80) * Math.sin(a), P[1] + dy(40) * Math.sin(2 * a)]; });
      else if (id === "wiggle") kkBake(pos, sp.a, sp.b, Math.min(c.fps, 12), function (x) { var k = Math.floor(x * sp.len * 12); return [P[0] + dx(14) * (kaRnd(k) - .5) * 2, P[1] + dy(14) * (kaRnd(k + 99) - .5) * 2]; });
      else if (id === "blink") { if (!op) return "err|Нет непрозрачности"; var O = kkBase(op.properties[0], sp.a); kkBake(op.properties[0], sp.a, sp.b, c.fps, function (x) { return s2(x) > -0.3 ? O : 0; }); }
      else if (id === "shakeLoop") kkBake(pos, sp.a, sp.b, c.fps, function (x) { var k = Math.floor(x * sp.len * c.fps); return [P[0] + dx(6) * (kaRnd(k) - .5) * 2, P[1] + dy(6) * (kaRnd(k + 7) - .5) * 2]; });
      else return "err|Неизвестный цикл";
    }
    return "ok|«" + KA_LOOPS[id] + "» на весь клип";
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- появления ---------- */
var KA_IN = {
  flyL: "Вылет слева с перелётом", flyR: "Вылет справа с перелётом", flyU: "Вылет сверху", flyD: "Вылет снизу", spiral: "По спирали", boomerang: "Бумеранг",
  zoomThrough: "Сквозь экран", unfold: "Раскрыться", dropSquash: "Упасть и сплющиться", riseSlow: "Медленно всплыть",
  cropL: "Шторка слева", cropR: "Шторка справа", cropU: "Шторка сверху", cropD: "Шторка снизу", popCascade: "Каскад (несколько клипов)", jump1: "Один прыжок"
};
function ka_in2(id, dur) {
  try {
    var c = kaCtx(); if (c.err) return c.err; var D = Number(dur) || 0.6;
    if (id === "popCascade") return ka_stagger(0.08, 0.3);
    if (id === "jump1") return ka_jump(220, 1);
    for (var i = 0; i < c.items.length; i++) {
      var it = c.items[i], sp = kkSpan(it), d = Math.min(D, sp.len), t0 = sp.a, t1 = sp.a + d, mo = kkComp(it, "AE.ADBE Motion"), op = kkComp(it, "AE.ADBE Opacity");
      var pos = mo.properties[0], sc = mo.properties[1], scw = mo.properties[2], uni = mo.properties[3], rot = mo.properties[4];
      var P = kkBase(pos, t1), S = kkBase(sc, t1), R = kkBase(rot, t1), O = op ? kkBase(op.properties[0], t1) : 100;
      var X = function (px) { return px * c.U / c.W; }, Y = function (px) { return px * c.U / c.H; }, back = KK_EASE.outBack, o3 = KK_EASE.outCubic;
      var fadeIn = function () { if (op) kkBake(op.properties[0], t0, t0 + d * .4, c.fps, function (x) { return O * x; }); };
      if (id === "flyL" || id === "flyR") { var s = id === "flyL" ? -1 : 1; kkBake(pos, t0, t1, c.fps, function (x) { return [P[0] + s * X(700) * (1 - back(x)), P[1]]; }); }
      else if (id === "flyU" || id === "flyD") { var s2 = id === "flyU" ? -1 : 1; kkBake(pos, t0, t1, c.fps, function (x) { return [P[0], P[1] + s2 * Y(900) * (1 - back(x))]; }); }
      else if (id === "spiral") { kkBake(pos, t0, t1, c.fps, function (x) { var k = 1 - o3(x), a = x * Math.PI * 3; return [P[0] + X(300) * k * Math.cos(a), P[1] + Y(300) * k * Math.sin(a)]; });
        kkBake(sc, t0, t1, c.fps, function (x) { return S * o3(x); }); kkBake(rot, t0, t1, c.fps, function (x) { return R - 360 * (1 - o3(x)); }); }
      else if (id === "boomerang") kkBake(pos, t0, t1, c.fps, function (x) { var k = x < .6 ? KK_EASE.inOutCubic(x / .6) : 1 - .25 * Math.sin((x - .6) / .4 * Math.PI); return [P[0] - X(500) * (1 - Math.min(1, k)), P[1] - Y(120) * Math.sin(x * Math.PI)]; });
      else if (id === "zoomThrough") { kkBake(sc, t0, t1, c.fps, function (x) { return S * (6 - 5 * o3(x)); }); fadeIn(); }
      else if (id === "unfold") { uni.setValue(false, true); kkBake(sc, t0, t1, c.fps, function (x) { return S * back(x); }); }
      else if (id === "dropSquash") { uni.setValue(false, true); var SW = kkBase(scw, t1);
        kkBake(pos, t0, t0 + d * .6, c.fps, function (x) { return [P[0], P[1] - Y(600) * (1 - x * x)]; });
        kkBake(sc, t0 + d * .6, t1, c.fps, function (x) { return S * (1 - .3 * Math.sin(x * Math.PI)); }); kkBake(scw, t0 + d * .6, t1, c.fps, function (x) { return SW * (1 + .3 * Math.sin(x * Math.PI)); }); }
      else if (id === "riseSlow") { kkBake(pos, t0, t0 + d * 2, c.fps, function (x) { return [P[0], P[1] + Y(150) * (1 - KK_EASE.outQuint(x))]; }); fadeIn(); }
      else if (/^crop/.test(id)) { var idx = { cropL: 9, cropR: 7, cropU: 10, cropD: 8 }[id]; // «Кадрировать справа» уменьшается — объект открывается слева направо и т. п.
        var cp = mo.properties[idx]; if (!cp) return "err|В этой версии нет кадрирования в «Движении»"; kkBake(cp, t0, t1, c.fps, function (x) { return 100 * (1 - KK_EASE.outQuint(x)); }); }
      else return "err|Неизвестное появление";
    }
    return "ok|«" + KA_IN[id] + "» готово";
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- покадровое ---------- */
var KA_STEPS = { s12: "Через кадр (12 к/с)", s8: "На тройках (8 к/с)", s6: "Рывками (6 к/с)", boil1: "Тряска контура", boil2: "Сильная тряска контура", handheld: "Ручная камера (рывки)", flicker: "Мерцание старой плёнки", stutter: "Заикание (4 к/с)" };
function ka_steps2(id) {
  try {
    if (id === "s12") return ka_steps(12); if (id === "s8") return ka_steps(8); if (id === "s6") return ka_steps(6); if (id === "stutter") return ka_steps(4);
    if (id === "boil1") return ka_boil(1); if (id === "boil2") return ka_boil(2);
    var c = kaCtx(); if (c.err) return c.err;
    for (var i = 0; i < c.items.length; i++) {
      var it = c.items[i], sp = kkSpan(it), mo = kkComp(it, "AE.ADBE Motion"), op = kkComp(it, "AE.ADBE Opacity"), P = kkBase(mo.properties[0], sp.a), S = kkBase(mo.properties[1], sp.a);
      if (id === "handheld") { mo.properties[1].setValue(S * 1.04, true); kkBake(mo.properties[0], sp.a, sp.b, 8, function (x) { var k = Math.floor(x * sp.len * 8); return [P[0] + 6 * c.U / c.W * (kaRnd(k) - .5) * 2, P[1] + 6 * c.U / c.H * (kaRnd(k + 3) - .5) * 2]; }); }
      else if (id === "flicker" && op) { var O = kkBase(op.properties[0], sp.a); kkBake(op.properties[0], sp.a, sp.b, 12, function (x) { return O * (.82 + .18 * kaRnd(Math.floor(x * sp.len * 12))); }); }
    }
    return "ok|«" + KA_STEPS[id] + "» готово";
  } catch (e) { return "err|" + e.toString(); }
}

/* ---------- пути ---------- */
var KA_PATHS = { arcL: "По дуге влево", arcR: "По дуге вправо", arcU: "По дуге вверх", arcD: "По дуге вниз", zigzag: "Зигзаг", wavePath: "Волной через кадр", bounceAcross: "Прыжками через кадр", circleIn: "По кругу к центру" };
function ka_path(id) {
  try {
    if (/^arc/.test(id)) return ka_arc({ arcL: "left", arcR: "right", arcU: "up", arcD: "down" }[id], 400);
    var c = kaCtx(); if (c.err) return c.err;
    for (var i = 0; i < c.items.length; i++) {
      var it = c.items[i], sp = kkSpan(it), pos = kkComp(it, "AE.ADBE Motion").properties[0], P = kkBase(pos, sp.a), L = Math.min(sp.len, 2.5);
      var X = function (px) { return px * c.U / c.W; }, Y = function (px) { return px * c.U / c.H; };
      if (id === "zigzag") kkBake(pos, sp.a, sp.a + L, c.fps, function (x) { var t = x * 4, f = t - Math.floor(t), up = Math.floor(t) % 2; return [P[0] - X(400) + X(800) * x, P[1] + Y(120) * (up ? 1 - 2 * f : -1 + 2 * f)]; });
      else if (id === "wavePath") kkBake(pos, sp.a, sp.a + L, c.fps, function (x) { return [P[0] - X(450) + X(900) * KK_EASE.inOutCubic(x), P[1] + Y(100) * Math.sin(x * Math.PI * 4)]; });
      else if (id === "bounceAcross") kkBake(pos, sp.a, sp.a + L, c.fps, function (x) { var t = (x * 3) % 1; return [P[0] - X(450) + X(900) * x, P[1] - Y(250) * 4 * t * (1 - t)]; });
      else if (id === "circleIn") kkBake(pos, sp.a, sp.a + L, c.fps, function (x) { var k = 1 - KK_EASE.outCubic(x), a = x * Math.PI * 2; return [P[0] + X(350) * k * Math.cos(a), P[1] + Y(350) * k * Math.sin(a)]; });
      else return "err|Неизвестный путь";
    }
    return "ok|«" + KA_PATHS[id] + "» готово";
  } catch (e) { return "err|" + e.toString(); }
}
function ka_lists() {
  var o = [], g = [["Покадрово", KA_STEPS, "ka_steps2"], ["Циклы", KA_LOOPS, "ka_loop2"], ["Появление", KA_IN, "ka_in2"], ["Пути", KA_PATHS, "ka_path"]];
  for (var i = 0; i < g.length; i++) { var a = []; for (var k in g[i][1]) a.push(k + "=" + g[i][1][k]); o.push(g[i][0] + ">" + g[i][2] + ">" + a.join(",")); }
  return o.join("|");
}

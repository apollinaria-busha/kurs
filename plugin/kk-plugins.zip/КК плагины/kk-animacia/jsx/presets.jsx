/* КК · Анимация — пресеты v3 (по 50 механик на вкладку). ES3. Сдвиги в «пикселях 1080p». */
function kaCtx() {
  var seq = kkSeq(); if (!seq) return { err: "err|Открой секвенцию" };
  var items = kkSel(); if (!items.length) return { err: "err|Выдели клип" };
  var W = seq.frameSizeHorizontal, H = seq.frameSizeVertical;
  return { seq: seq, items: items, fps: kkFps(seq), W: W, H: H, U: Math.min(W, H) / 1080 };
}
function kaRnd(i) { var x = Math.sin(i * 12.9898 + 78.233) * 43758.5453; return x - Math.floor(x); }

/* ---------- циклы на весь клип ---------- */
var KA_LOOPS = {
  sway: "Качание", pendulum: "Маятник", "float": "Парение", hover: "Парение с наклоном", pulse: "Пульс", heartbeat: "Сердцебиение", breathe: "Дыхание",
  zoomPulse: "Удар в бит", spin: "Вращение", roll: "Катится", wobble: "Покачивание", jelly: "Желе", flip: "Переворот по кругу", tilt: "Наклоны",
  hop: "Прыжки на месте", orbit: "Орбита", figure8: "Восьмёрка", wiggle: "Хаотичное дрожание", blink: "Мигание", shakeLoop: "Тряска"
};
function ka_loop2(id, period, amount) {
  if (KA_L3[id]) return kaRun3(KA_L3, id, "loop", period, amount);
  try {
    var c = kaCtx(); if (c.err) return c.err;
    var T = Number(period) || 1.5, A = Number(amount) || 1;
    for (var i = 0; i < c.items.length; i++) {
      var it = c.items[i], sp = kkSpan(it), mo = kkComp(it, "AE.ADBE Motion"), op = kkComp(it, "AE.ADBE Opacity");
      var pos = mo.properties[0], sc = mo.properties[1], scw = mo.properties[2], uni = mo.properties[3], rot = mo.properties[4];
      var P = kkBase(pos, sp.a), S = kkBase(sc, sp.a), R = kkBase(rot, sp.a), f = Math.min(c.fps, 15);
      var ph = function (x) { return x * sp.len / T; }, s2 = function (x) { return Math.sin(ph(x) * Math.PI * 2); };
      var dx = function (px) { return px * c.U / c.W * A; }, dy = function (px) { return px * c.U / c.H * A; };
      if (id === "sway") kkBake(rot, sp.a, sp.b, f, function (x) { return R + 8 * A * s2(x); });
      else if (id === "pendulum") kkBake(rot, sp.a, sp.b, f, function (x) { return R + 30 * A * s2(x); });
      else if (id === "float") kkBake(pos, sp.a, sp.b, f, function (x) { return [P[0], P[1] + dy(18) * s2(x)]; });
      else if (id === "hover") { kkBake(pos, sp.a, sp.b, f, function (x) { return [P[0], P[1] + dy(16) * s2(x)]; }); kkBake(rot, sp.a, sp.b, f, function (x) { return R + 4 * A * Math.cos(ph(x) * Math.PI * 2); }); }
      else if (id === "pulse") kkBake(sc, sp.a, sp.b, f, function (x) { return S * (1 + .06 * A * (.5 + .5 * s2(x))); });
      else if (id === "heartbeat") kkBake(sc, sp.a, sp.b, c.fps, function (x) { var t = ph(x) % 1; return S * (1 + .1 * A * (Math.exp(-Math.pow((t - .1) / .04, 2)) + .7 * Math.exp(-Math.pow((t - .28) / .04, 2)))); });
      else if (id === "breathe") kkBake(sc, sp.a, sp.b, f, function (x) { return S * (1 + .03 * A * s2(x)); });
      else if (id === "zoomPulse") kkBake(sc, sp.a, sp.b, c.fps, function (x) { var t = ph(x) % 1; return S * (1 + .08 * A * Math.exp(-t * 9)); });
      else if (id === "spin") { rot.setTimeVarying(true); rot.addKey(sp.a); rot.setValueAtKey(sp.a, R, false); rot.addKey(sp.b); rot.setValueAtKey(sp.b, R + 360 * A * sp.len / T, true); }
      else if (id === "roll") { kkBake(rot, sp.a, sp.b, f, function (x) { return R + 360 * A * ph(x); }); kkBake(pos, sp.a, sp.b, f, function (x) { return [P[0] + dx(120) * s2(x / 2), P[1]]; }); }
      else if (id === "wobble") { kkBake(rot, sp.a, sp.b, f, function (x) { return R + 6 * A * s2(x); }); kkBake(sc, sp.a, sp.b, f, function (x) { return S * (1 + .04 * A * Math.cos(ph(x) * Math.PI * 4)); }); }
      else if (id === "jelly") { uni.setValue(false, true); var SW = kkBase(scw, sp.a);
        kkBake(scw, sp.a, sp.b, f, function (x) { return SW * (1 + .08 * A * s2(x)); }); kkBake(sc, sp.a, sp.b, f, function (x) { return S * (1 - .08 * A * s2(x)); }); }
      else if (id === "flip") { uni.setValue(false, true); var SW2 = kkBase(scw, sp.a); kkBake(scw, sp.a, sp.b, c.fps, function (x) { return SW2 * Math.cos(ph(x) * Math.PI * 2); }); }
      else if (id === "tilt") kkBake(rot, sp.a, sp.b, c.fps, function (x) { return R + (Math.floor(ph(x) * 2) % 2 ? 6 : -6) * A; });
      else if (id === "hop") kkBake(pos, sp.a, sp.b, c.fps, function (x) { var t = ph(x) % 1; return [P[0], P[1] - dy(80) * 4 * t * (1 - t)]; });
      else if (id === "orbit") kkBake(pos, sp.a, sp.b, f, function (x) { var a = ph(x) * Math.PI * 2; return [P[0] + dx(60) * Math.cos(a), P[1] + dy(60) * Math.sin(a)]; });
      else if (id === "figure8") kkBake(pos, sp.a, sp.b, f, function (x) { var a = ph(x) * Math.PI * 2; return [P[0] + dx(80) * Math.sin(a), P[1] + dy(40) * Math.sin(2 * a)]; });
      else if (id === "wiggle") kkBake(pos, sp.a, sp.b, Math.min(c.fps, 12), function (x) { var k = Math.floor(x * sp.len * 12); return [P[0] + dx(14) * (kaRnd(k) - .5) * 2, P[1] + dy(14) * (kaRnd(k + 99) - .5) * 2]; });
      else if (id === "blink") { if (!op) return "err|Нет непрозрачности"; var O = kkBase(op.properties[0], sp.a); kkBake(op.properties[0], sp.a, sp.b, c.fps, function (x) { return s2(x) > -0.3 ? O : 0; }); }
      else if (id === "shakeLoop") kkBake(pos, sp.a, sp.b, c.fps, function (x) { var k = Math.floor(x * sp.len * c.fps); return [P[0] + dx(6) * (kaRnd(k) - .5) * 2, P[1] + dy(6) * (kaRnd(k + 7) - .5) * 2]; });
      else return "err|Неизвестный цикл";
    }
    return "ok|«" + KA_LOOPS[id] + "» на весь клип";
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- появления ---------- */
var KA_IN = {
  flyL: "Вылет слева с перелётом", flyR: "Вылет справа с перелётом", flyU: "Вылет сверху", flyD: "Вылет снизу", spiral: "По спирали", boomerang: "Бумеранг",
  zoomThrough: "Сквозь экран", unfold: "Раскрыться", dropSquash: "Упасть и сплющиться", riseSlow: "Медленно всплыть",
  cropL: "Шторка слева", cropR: "Шторка справа", cropU: "Шторка сверху", cropD: "Шторка снизу", popCascade: "Каскад (несколько клипов)", jump1: "Один прыжок"
};
function ka_in2(id, dur) {
  if (KA_I3[id]) return kaRun3(KA_I3, id, "in", dur);
  try {
    var c = kaCtx(); if (c.err) return c.err; var D = Number(dur) || 0.6;
    if (id === "popCascade") return ka_stagger(0.08, 0.3);
    if (id === "jump1") return ka_jump(220, 1);
    for (var i = 0; i < c.items.length; i++) {
      var it = c.items[i], sp = kkSpan(it), d = Math.min(D, sp.len), t0 = sp.a, t1 = sp.a + d, mo = kkComp(it, "AE.ADBE Motion"), op = kkComp(it, "AE.ADBE Opacity");
      var pos = mo.properties[0], sc = mo.properties[1], scw = mo.properties[2], uni = mo.properties[3], rot = mo.properties[4];
      var P = kkBase(pos, t1), S = kkBase(sc, t1), R = kkBase(rot, t1), O = op ? kkBase(op.properties[0], t1) : 100;
      var X = function (px) { return px * c.U / c.W; }, Y = function (px) { return px * c.U / c.H; }, back = KK_EASE.outBack, o3 = KK_EASE.outCubic;
      var fadeIn = function () { if (op) kkBake(op.properties[0], t0, t0 + d * .4, c.fps, function (x) { return O * x; }); };
      if (id === "flyL" || id === "flyR") { var s = id === "flyL" ? -1 : 1; kkBake(pos, t0, t1, c.fps, function (x) { return [P[0] + s * X(700) * (1 - back(x)), P[1]]; }); }
      else if (id === "flyU" || id === "flyD") { var s2 = id === "flyU" ? -1 : 1; kkBake(pos, t0, t1, c.fps, function (x) { return [P[0], P[1] + s2 * Y(900) * (1 - back(x))]; }); }
      else if (id === "spiral") { kkBake(pos, t0, t1, c.fps, function (x) { var k = 1 - o3(x), a = x * Math.PI * 3; return [P[0] + X(300) * k * Math.cos(a), P[1] + Y(300) * k * Math.sin(a)]; });
        kkBake(sc, t0, t1, c.fps, function (x) { return S * o3(x); }); kkBake(rot, t0, t1, c.fps, function (x) { return R - 360 * (1 - o3(x)); }); }
      else if (id === "boomerang") kkBake(pos, t0, t1, c.fps, function (x) { var k = x < .6 ? KK_EASE.inOutCubic(x / .6) : 1 - .25 * Math.sin((x - .6) / .4 * Math.PI); return [P[0] - X(500) * (1 - Math.min(1, k)), P[1] - Y(120) * Math.sin(x * Math.PI)]; });
      else if (id === "zoomThrough") { kkBake(sc, t0, t1, c.fps, function (x) { return S * (6 - 5 * o3(x)); }); fadeIn(); }
      else if (id === "unfold") { uni.setValue(false, true); kkBake(sc, t0, t1, c.fps, function (x) { return S * back(x); }); }
      else if (id === "dropSquash") { uni.setValue(false, true); var SW = kkBase(scw, t1);
        kkBake(pos, t0, t0 + d * .6, c.fps, function (x) { return [P[0], P[1] - Y(600) * (1 - x * x)]; });
        kkBake(sc, t0 + d * .6, t1, c.fps, function (x) { return S * (1 - .3 * Math.sin(x * Math.PI)); }); kkBake(scw, t0 + d * .6, t1, c.fps, function (x) { return SW * (1 + .3 * Math.sin(x * Math.PI)); }); }
      else if (id === "riseSlow") { kkBake(pos, t0, t0 + d * 2, c.fps, function (x) { return [P[0], P[1] + Y(150) * (1 - KK_EASE.outQuint(x))]; }); fadeIn(); }
      else if (/^crop/.test(id)) { var idx = { cropL: 9, cropR: 7, cropU: 10, cropD: 8 }[id]; // «Кадрировать справа» уменьшается — объект открывается слева направо и т. п.
        var cp = mo.properties[idx]; if (!cp) return "err|В этой версии нет кадрирования в «Движении»"; kkBake(cp, t0, t1, c.fps, function (x) { return 100 * (1 - KK_EASE.outQuint(x)); }); }
      else return "err|Неизвестное появление";
    }
    return "ok|«" + KA_IN[id] + "» готово";
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- покадровое ---------- */
var KA_STEPS = { s12: "Через кадр (12 к/с)", s8: "На тройках (8 к/с)", s6: "Рывками (6 к/с)", boil1: "Тряска контура", boil2: "Сильная тряска контура", handheld: "Ручная камера (рывки)", flicker: "Мерцание старой плёнки", stutter: "Заикание (4 к/с)" };
function ka_steps2(id) {
  if (KA_S3[id]) return kaRun3(KA_S3, id, "steps");
  try {
    if (id === "s12") return ka_steps(12); if (id === "s8") return ka_steps(8); if (id === "s6") return ka_steps(6); if (id === "stutter") return ka_steps(4);
    if (id === "boil1") return ka_boil(1); if (id === "boil2") return ka_boil(2);
    var c = kaCtx(); if (c.err) return c.err;
    for (var i = 0; i < c.items.length; i++) {
      var it = c.items[i], sp = kkSpan(it), mo = kkComp(it, "AE.ADBE Motion"), op = kkComp(it, "AE.ADBE Opacity"), P = kkBase(mo.properties[0], sp.a), S = kkBase(mo.properties[1], sp.a);
      if (id === "handheld") { mo.properties[1].setValue(S * 1.04, true); kkBake(mo.properties[0], sp.a, sp.b, 8, function (x) { var k = Math.floor(x * sp.len * 8); return [P[0] + 6 * c.U / c.W * (kaRnd(k) - .5) * 2, P[1] + 6 * c.U / c.H * (kaRnd(k + 3) - .5) * 2]; }); }
      else if (id === "flicker" && op) { var O = kkBase(op.properties[0], sp.a); kkBake(op.properties[0], sp.a, sp.b, 12, function (x) { return O * (.82 + .18 * kaRnd(Math.floor(x * sp.len * 12))); }); }
    }
    return "ok|«" + KA_STEPS[id] + "» готово";
  } catch (e) { return "err|" + e.toString(); }
}

/* ---------- пути ---------- */
var KA_PATHS = { arcL: "По дуге влево", arcR: "По дуге вправо", arcU: "По дуге вверх", arcD: "По дуге вниз", zigzag: "Зигзаг", wavePath: "Волной через кадр", bounceAcross: "Прыжками через кадр", circleIn: "По кругу к центру" };
function ka_path(id) {
  if (KA_P3[id]) return kaRun3(KA_P3, id, "path");
  try {
    if (/^arc/.test(id)) return ka_arc({ arcL: "left", arcR: "right", arcU: "up", arcD: "down" }[id], 400);
    var c = kaCtx(); if (c.err) return c.err;
    for (var i = 0; i < c.items.length; i++) {
      var it = c.items[i], sp = kkSpan(it), pos = kkComp(it, "AE.ADBE Motion").properties[0], P = kkBase(pos, sp.a), L = Math.min(sp.len, 2.5);
      var X = function (px) { return px * c.U / c.W; }, Y = function (px) { return px * c.U / c.H; };
      if (id === "zigzag") kkBake(pos, sp.a, sp.a + L, c.fps, function (x) { var t = x * 4, f = t - Math.floor(t), up = Math.floor(t) % 2; return [P[0] - X(400) + X(800) * x, P[1] + Y(120) * (up ? 1 - 2 * f : -1 + 2 * f)]; });
      else if (id === "wavePath") kkBake(pos, sp.a, sp.a + L, c.fps, function (x) { return [P[0] - X(450) + X(900) * KK_EASE.inOutCubic(x), P[1] + Y(100) * Math.sin(x * Math.PI * 4)]; });
      else if (id === "bounceAcross") kkBake(pos, sp.a, sp.a + L, c.fps, function (x) { var t = (x * 3) % 1; return [P[0] - X(450) + X(900) * x, P[1] - Y(250) * 4 * t * (1 - t)]; });
      else if (id === "circleIn") kkBake(pos, sp.a, sp.a + L, c.fps, function (x) { var k = 1 - KK_EASE.outCubic(x), a = x * Math.PI * 2; return [P[0] + X(350) * k * Math.cos(a), P[1] + Y(350) * k * Math.sin(a)]; });
      else return "err|Неизвестный путь";
    }
    return "ok|«" + KA_PATHS[id] + "» готово";
  } catch (e) { return "err|" + e.toString(); }
}
/* для панели: "Группа>функция>id=Название~уровень~превью,..." — порядок из KA_ORDER, всё, что не попало в порядок, — в конец */
function ka_lists() {
  var o = [], g = [["Покадрово", KA_STEPS, KA_S3, "ka_steps2"], ["Циклы", KA_LOOPS, KA_L3, "ka_loop2"], ["Появление", KA_IN, KA_I3, "ka_in2"], ["Пути", KA_PATHS, KA_P3, "ka_path"]];
  for (var i = 0; i < g.length; i++) {
    var a = [], seen = {}, ord = String(KA_ORDER[g[i][0]] || "").split(" "), j, id;
    for (j = 0; j < ord.length; j++) { var p = ord[j].split(":"); id = p[0];
      var nm = g[i][1][id] || (g[i][2][id] ? g[i][2][id][0] : ""); if (!nm || seen[id]) continue; seen[id] = 1; a.push(id + "=" + nm + "~" + (p[1] || "d") + "~" + (p[2] || "")); }
    for (id in g[i][1]) if (!seen[id]) { seen[id] = 1; a.push(id + "=" + g[i][1][id] + "~d~"); }
    for (id in g[i][2]) if (!seen[id]) { seen[id] = 1; a.push(id + "=" + g[i][2][id][0] + "~d~"); }
    o.push(g[i][0] + ">" + g[i][3] + ">" + a.join(","));
  }
  return o.join("|");
}

/* ================= v3: по 50 механик на вкладку =================
   Новые механики лежат в таблицах KA_S3 / KA_L3 / KA_I3 / KA_P3: id → [название, функция(k)].
   Порядок карточек и уровень (c — спокойно, d — динамично, b — дерзко) задаёт KA_ORDER внизу. */
var KA_FXN = {
  post: ["Posterize Time", "Время постеризации"], wave: ["Wave Warp", "Волнообразная деформация"],
  turb: ["Turbulent Displace", "Вихр. смещение", "Вихревое смещение", "Турбулентное смещение"], noise: ["Noise", "Шум"],
  gblur: ["Gaussian Blur", "Размытие по Гауссу"], dblur: ["Directional Blur", "Направленное размытие"],
  mosaic: ["Mosaic", "Мозаика"], invert: ["Invert", "Обратить", "Инвертировать", "Инвертирование"],
  bw: ["Black & White", "Черное и белое", "Чёрное и белое", "Черно-белое", "Чёрно-белое", "Черно-белый", "Чёрно-белый"],
  bright: ["Brightness & Contrast", "Яркость и контрастность", "Яркость и контраст"],
  echo: ["Echo", "Эхо"], offset: ["Offset", "Смещение"], transform: ["Transform", "Преобразовать", "Преобразование"]
};
var KA_FXRU = { post: "Время постеризации", wave: "Волнообразная деформация", turb: "Турбулентное смещение", noise: "Шум", gblur: "Размытие по Гауссу",
  dblur: "Направленное размытие", mosaic: "Мозаика", invert: "Инвертировать", bright: "Яркость и контрастность", echo: "Эхо", offset: "Смещение", transform: "Преобразовать" };
function kaKey(p, t, v, ui) { if (!p.isTimeVarying()) p.setTimeVarying(true); p.addKey(t); p.setValueAtKey(t, v, !!ui); }
/* ступеньки: значение держится до следующего шага, переход — за 1 кадр (настоящее «покадрово», без плавного перетекания) */
function kaHold(prop, t0, t1, rate, fps, f) {
  if (!prop) return;
  var n = Math.max(1, Math.round((t1 - t0) * rate)), dt = (t1 - t0) / n, eps = Math.min(1 / fps, dt / 2), j;
  for (j = 0; j < n; j++) {
    var a = t0 + j * dt, v = f(j, j / n);
    kaKey(prop, a, v);
    if (dt - eps > 0.0001) kaKey(prop, a + dt - eps, v);
  }
  kaKey(prop, t1, f(n, 1), true);
}
/* короткие события: в моменты times значение на несколько кадров меняется (frames), потом возвращается */
function kaEv(prop, a, b, fps, times, frames, mk) {
  if (!prop) return;
  var base = mk(null), fr = 1 / fps, i, j, m = frames.length;
  kaKey(prop, a, base);
  for (i = 0; i < times.length; i++) {
    var te = times[i]; if (te + (m + 1) * fr >= b) break;
    kaKey(prop, te, base);
    for (j = 0; j < m; j++) kaKey(prop, te + (j + 1) * fr, mk(frames[j], i));
    kaKey(prop, te + (m + 1) * fr, base);
  }
  kaKey(prop, b, base, true);
}
function kaTimes(a, b, avg, seed, first) { var o = [], t = a + (first === undefined ? avg * .5 : first), i = 0; while (t < b && i < 400) { o.push(t); t += avg * (.6 + .8 * kaRnd(seed + i * 7)); i++; } return o; }
function kaEvery(a, b, every, off) { var o = [], t = a + (off || 0); while (t < b && o.length < 400) { o.push(t); t += every; } return o; }
/* пружина как в iOS: 0 → 1 с затухающими колебаниями; z — затухание (0..1), w — жёсткость */
function kaSpring(t, z, w) {
  if (t <= 0) return 0; if (t >= 1) return 1;
  var wd = w * Math.sqrt(1 - z * z);
  return 1 - Math.exp(-z * w * t) * (Math.cos(wd * t) + z * w / wd * Math.sin(wd * t));
}
function kaDamp(t, cyc, dec) { return Math.exp(-dec * t) * Math.sin(t * cyc * Math.PI * 2); }
function kaClamp(x) { return x < 0 ? 0 : x > 1 ? 1 : x; }
function kaTri(s) { var f = s - Math.floor(s); return f < .25 ? f * 4 : f < .75 ? 2 - f * 4 : f * 4 - 4; } // 0 → 1 → -1 → 0
function kaSine(t) { return .5 - .5 * Math.cos(Math.PI * t); }
/* вращение вокруг «гвоздика» q (в px от центра): сдвиг, который надо добавить к позиции */
function kaPin(th, qx, qy) { var a = th * Math.PI / 180, c = Math.cos(a), s = Math.sin(a); return [qx - (qx * c - qy * s), qy - (qx * s + qy * c)]; }
function kaNoise(x, seed) { var i = Math.floor(x), f = x - i, u = (1 - Math.cos(f * Math.PI)) / 2; return (kaRnd(i + seed) * (1 - u) + kaRnd(i + 1 + seed) * u) * 2 - 1; }
/* параметр эффекта: по названию (RU/EN, в нижнем регистре), иначе — по номеру */
function kaPrm(comp, names, idx) {
  if (!comp) return null;
  var n = comp.properties.numItems, i, j;
  for (i = 0; i < n; i++) { var d = ""; try { d = String(comp.properties[i].displayName).toLowerCase(); } catch (e) {}
    for (j = 0; j < names.length; j++) if (d === names[j]) return comp.properties[i]; }
  return idx < n ? comp.properties[idx] : null;
}
function kaSet(p, v) { try { if (p) p.setValue(v, true); } catch (e) {} }
function kaFx(k, key) { try { return kkAddFx(k.it, KA_FXN[key]); } catch (e) { return null; } }
function kaNeed(k, key) { var fx = kaFx(k, key); if (!fx) throw "Нет эффекта «" + KA_FXRU[key] + "» в этой версии Premiere (или клип не найден — выдели его ещё раз)"; return fx; }
function kaAng(fn, x, k) { var h = .004, p0 = fn(Math.max(0, x - h), k), p1 = fn(Math.min(1, x + h), k), dx = p1[0] - p0[0], dy = p1[1] - p0[1];
  return dx * dx + dy * dy < 1e-6 ? null : Math.atan2(dy, dx) * 180 / Math.PI; }
/* контекст клипа: базовые значения, единицы «px в 1080p», помощники */
function kaK(c, it, tb, A) {
  var sp = kkSpan(it), mo = kkComp(it, "AE.ADBE Motion"), op = kkComp(it, "AE.ADBE Opacity");
  var k = { c: c, it: it, sp: sp, a: sp.a, b: sp.b, L: sp.len, mo: mo, op: op, fps: c.fps, A: A || 1, fw: c.W / c.U, fh: c.H / c.U,
    pos: mo.properties[0], sc: mo.properties[1], scw: mo.properties[2], uni: mo.properties[3], rot: mo.properties[4], opa: op ? op.properties[0] : null };
  var t = tb === undefined ? sp.a : tb;
  k.P = kkBase(k.pos, t); k.S = kkBase(k.sc, t); k.SW = kkBase(k.scw, t); k.R = kkBase(k.rot, t); k.O = k.opa ? kkBase(k.opa, t) : 100;
  k.X = function (px) { return px * c.U / c.W; }; k.Y = function (px) { return px * c.U / c.H; };
  k.at = function (dx, dy) { return [k.P[0] + k.X(dx), k.P[1] + k.Y(dy)]; };
  k.split = function () { var u = true; try { u = k.uni.getValue(); } catch (e) {}
    if (u) { k.uni.setValue(false, true); if (!k.scw.isTimeVarying()) k.scw.setValue(k.S, true); k.SW = k.S; } };
  k.bake = function (prop, t0, t1, f, rate) { if (prop) kkBake(prop, t0, t1, rate || k.fps, f); };
  k.hold = function (prop, t0, t1, rate, f) { kaHold(prop, t0, t1, rate, k.fps, f); };
  k.fade = function (t0, t1) { if (k.opa) kkBake(k.opa, t0, t1, k.fps, function (x) { return k.O * x; }); };
  k.pin = function (t0, t1, f, qx, qy, rate) { // f(x) → угол; объект качается вокруг точки (qx, qy)
    kkBake(k.rot, t0, t1, rate || k.fps, function (x) { return k.R + f(x); });
    kkBake(k.pos, t0, t1, rate || k.fps, function (x) { var o = kaPin(f(x), qx, qy); return k.at(o[0], o[1]); }); };
  k.path = function (fn, orient, t0, t1) { // fn(x, k) → [dx, dy] в px; orient — поворачивать по направлению движения
    t0 = t0 === undefined ? k.a : t0; t1 = t1 === undefined ? k.a + Math.min(k.L, 2.5) : t1;
    kkBake(k.pos, t0, t1, k.fps, function (x) { var p = fn(x, k); return k.at(p[0], p[1]); });
    if (orient) { var prev = kaAng(fn, 0, k), acc = 0; if (prev === null) prev = 0;
      kkBake(k.rot, t0, t1, k.fps, function (x) { var an = kaAng(fn, x, k); if (an === null) return k.R + acc; var dl = an - prev;
        while (dl > 180) dl -= 360; while (dl < -180) dl += 360; acc += dl; prev = an; return k.R + acc; }); }
  };
  return k;
}
function kaErr(e) { return "err|" + (typeof e === "string" ? e : e.toString() + (e.line ? " (строка " + e.line + ")" : "")); }

/* ---------- покадрово: +42 ---------- */
var KA_S3 = {
  liveRate: ["Живая частота", function (k) { var p = kaPrm(kaNeed(k, "post"), ["frame rate", "частота кадров"], 0);
    try { k.hold(p, k.a, k.b, 2, function (j) { return 6 + Math.round(kaRnd(j * 3 + 1) * 6); }); } catch (e) { kaSet(p, 8); } }],
  redraw: ["Перерисовка", function (k) {
    k.hold(k.pos, k.a, k.b, 8, function (j) { return k.at(6 * (kaRnd(j) - .5), 6 * (kaRnd(j + 50) - .5)); });
    k.hold(k.rot, k.a, k.b, 8, function (j) { return k.R + 1.2 * (kaRnd(j + 90) - .5); }); }],
  cutout: ["Бумажная вырезка", function (k) { k.hold(k.rot, k.a, k.b, 6, function (j) { return k.R + 5 * (kaRnd(j + 11) - .5); }); }],
  clay: ["Пластилин", function (k) { k.split();
    k.hold(k.sc, k.a, k.b, 12, function (j) { return k.S * (1 + .06 * (kaRnd(j + 3) - .5)); });
    k.hold(k.scw, k.a, k.b, 12, function (j) { return k.SW * (1 + .06 * (kaRnd(j + 33) - .5)); }); }],
  grain: ["Плёночное зерно", function (k) { kaSet(kaPrm(kaNeed(k, "noise"), ["amount of noise", "величина шума", "количество шума", "шум"], 0), 14); }],
  marker: ["Маркерный контур", function (k) { var fx = kaNeed(k, "turb");
    kaSet(kaPrm(fx, ["amount", "количество", "величина"], 1), 8); kaSet(kaPrm(fx, ["size", "размер"], 2), 14);
    k.hold(kaPrm(fx, ["evolution", "эволюция"], 5), k.a, k.b, 8, function (j) { return j * 97; }); }],
  fadeSteps: ["Проявление ступеньками", function (k) { if (!k.opa) return "err|Нет непрозрачности";
    k.hold(k.opa, k.a, k.a + Math.min(k.L, .8), 6, function (j, x) { return k.O * x; }); }],
  focusSteps: ["Наводка резкости", function (k) { var p = kaPrm(kaNeed(k, "gblur"), ["blurriness", "размытость", "размытие"], 0);
    k.hold(p, k.a, k.a + Math.min(k.L, .8), 6, function (j, x) { return 40 * (1 - x); }); }],
  creep: ["Сдвиг по кадрам", function (k) { k.hold(k.pos, k.a, k.b, 8, function (j, x) { return k.at(-60 + 120 * x + 3 * (kaRnd(j) - .5), 3 * (kaRnd(j + 5) - .5)); }); }],
  walk: ["Шагает", function (k) {
    k.hold(k.pos, k.a, k.b, 6, function (j) { return k.at(0, j % 2 ? 0 : -10); });
    k.hold(k.rot, k.a, k.b, 6, function (j) { return k.R + (j % 4 === 0 ? -3 : j % 4 === 2 ? 3 : 0); }); }],
  tick: ["Секундная стрелка", function (k) { k.hold(k.rot, k.a, k.b, 2, function (j) { return k.R + 6 * j; }); }],
  eyeBlink: ["Моргает", function (k) { k.split();
    kaEv(k.sc, k.a, k.b, k.fps, kaTimes(k.a, k.b, 2.2, 3, .8), [.45, .08, .45], function (f) { return f === null ? k.S : k.S * f; }); }],
  tap: ["Стук в бит", function (k) { kaEv(k.pos, k.a, k.b, k.fps, kaEvery(k.a, k.b, .5, .25), [14, 7, 2], function (f) { return f === null ? k.P : k.at(0, f); }); }],
  growSteps: ["Вырастает покадрово", function (k) { k.hold(k.sc, k.a, k.a + Math.min(k.L, .7), 8, function (j, x) { return x >= 1 ? k.S : k.S * x * (1 + .06 * (kaRnd(j) - .5)); }); }],
  poses: ["Смена поз", function (k) {
    k.hold(k.pos, k.a, k.b, 2, function (j) { return k.at(36 * (kaRnd(j + 1) - .5), 36 * (kaRnd(j + 41) - .5)); });
    k.hold(k.rot, k.a, k.b, 2, function (j) { return k.R + 12 * (kaRnd(j + 81) - .5); });
    k.hold(k.sc, k.a, k.b, 2, function (j) { return k.S * (1 + .1 * (kaRnd(j + 121) - .5)); }); }],
  hopSteps: ["Прыжки покадрово", function (k) { k.hold(k.pos, k.a, k.b, 8, function (j, x) { var t = x * k.L / .75, u = t - Math.floor(t); return k.at(0, -110 * 4 * u * (1 - u)); }); }],
  punchSteps: ["Наезд ступеньками", function (k) { var lv = [1, 1.1, 1.2, 1.32]; k.hold(k.sc, k.a, k.b, 4 / k.L, function (j) { return k.S * lv[Math.min(j, 3)]; }); }],
  oldFilm: ["Старое кино", function (k) { var po = kaFx(k, "post"); if (po) kaSet(kaPrm(po, ["frame rate", "частота кадров"], 0), 12); var bw = kaFx(k, "bw");
    k.hold(k.pos, k.a, k.b, 12, function (j) { return k.at(1.4 * (kaRnd(j) - .5), 4 * (kaRnd(j + 7) - .5)); });
    if (k.opa) k.hold(k.opa, k.a, k.b, 12, function (j) { return k.O * (.86 + .14 * kaRnd(j + 13)); });
    if (!bw) return "ok|«Старое кино» готово (без ч/б — эффекта нет в этой версии)"; }],
  ghost: ["Призрак", function (k) { if (!k.opa) return "err|Нет непрозрачности";
    k.hold(k.opa, k.a, k.b, 15, function (j) { return j % 2 ? k.O * .45 : k.O; });
    k.hold(k.pos, k.a, k.b, 15, function (j) { return j % 2 ? k.at(5, 0) : k.P; }); }],
  lag: ["Подвисания", function (k) { var p = kaPrm(kaNeed(k, "post"), ["frame rate", "частота кадров"], 0), full = Math.round(k.fps);
    try { k.hold(p, k.a, k.b, 2.5, function (j) { return kaRnd(j * 5 + 2) < .28 ? 2 : full; }); } catch (e) { kaSet(p, 6); } }],
  typewriter: ["Печатная машинка", function (k) { var cp = k.mo.properties[9]; if (!cp) return "err|В этой версии нет кадрирования в «Движении»";
    k.hold(cp, k.a, k.a + Math.min(k.L, 1.2), 10, function (j, x) { return 100 * (1 - x); }); }],
  eq: ["Эквалайзер", function (k) { k.split(); k.hold(k.sc, k.a, k.b, 8, function (j) { return k.S * (.6 + .55 * kaRnd(j * 3 + 4)); }); }],
  shutter: ["Щелчок затвора", function (k) { var f1 = 1 / k.fps, t = k.a + 2 * f1;
    if (k.opa) { kaKey(k.opa, k.a, 0); kaKey(k.opa, t, 0); kaKey(k.opa, t + f1, k.O, true); }
    k.bake(k.sc, t, t + .25, function (x) { return k.S * (1.08 - .08 * KK_EASE.outCubic(x)); });
    var br = kaFx(k, "bright"); if (br) k.bake(kaPrm(br, ["brightness", "яркость"], 0), t, t + .2, function (x) { return 80 * (1 - x); }); }],
  vhs: ["VHS-дрожание", function (k) {
    k.hold(k.pos, k.a, k.b, 15, function (j) { return k.at(kaRnd(j * 7 + 1) > .94 ? 18 : 3 * (kaRnd(j) - .5), 0); });
    var nz = kaFx(k, "noise"); if (nz) kaSet(kaPrm(nz, ["amount of noise", "величина шума", "количество шума", "шум"], 0), 8); }],
  trail: ["Шлейф кадров", function (k) { var fx = kaNeed(k, "echo");
    kaSet(kaPrm(fx, ["echo time (seconds)", "echo time", "время эха (секунды)", "время эха (с)", "время эха"], 0), -0.06);
    kaSet(kaPrm(fx, ["number of echoes", "количество эхо", "число эхо", "количество эха", "количество отражений"], 1), 4);
    kaSet(kaPrm(fx, ["starting intensity", "начальная интенсивность"], 2), 1); kaSet(kaPrm(fx, ["decay", "затухание", "ослабление"], 3), .6);
    var po = kaFx(k, "post"); if (po) kaSet(kaPrm(po, ["frame rate", "частота кадров"], 0), 12); }],
  nervous: ["Нервная дрожь", function (k) {
    k.hold(k.rot, k.a, k.b, 15, function (j) { return k.R + 3 * (kaRnd(j + 2) - .5); });
    k.hold(k.sc, k.a, k.b, 15, function (j) { return k.S * (1 + .02 * (kaRnd(j + 9) - .5)); }); }],
  buzz: ["Вибро-звонок", function (k) { var tm = kaEvery(k.a, k.b, 1.3, .3), fr = [7, -7, 7, -7, 6, -6, 4, -4, 2, -2];
    kaEv(k.pos, k.a, k.b, k.fps, tm, fr, function (f) { return f === null ? k.P : k.at(f, 0); });
    kaEv(k.rot, k.a, k.b, k.fps, tm, fr, function (f) { return f === null ? k.R : k.R + f * .3; }); }],
  smear: ["Смазанный кадр", function (k) { k.split(); var tm = kaEvery(k.a, k.b, .8, .4);
    kaEv(k.scw, k.a, k.b, k.fps, tm, [1.55, 1.15], function (f) { return f === null ? k.SW : k.SW * f; });
    kaEv(k.sc, k.a, k.b, k.fps, tm, [.85, .96], function (f) { return f === null ? k.S : k.S * f; });
    kaEv(k.pos, k.a, k.b, k.fps, tm, [26, 8], function (f) { return f === null ? k.P : k.at(f, 0); }); }],
  neon: ["Неон моргает", function (k) { if (!k.opa) return "err|Нет непрозрачности";
    kaEv(k.opa, k.a, k.b, k.fps, kaTimes(k.a, k.b, 2.2, 9, .6), [0, 1, 0, 0, 1, .3, 1, 0], function (f) { return f === null ? k.O : k.O * f; }); }],
  strobe: ["Стробоскоп", function (k) { if (!k.opa) return "err|Нет непрозрачности";
    k.hold(k.opa, k.a, k.b, 8, function (j, x) { return x >= 1 || j % 2 === 0 ? k.O : 0; }); }],
  glitch: ["Глитч-рывки", function (k) { k.split(); var tm = kaTimes(k.a, k.b, 1, 13, .4);
    kaEv(k.pos, k.a, k.b, k.fps, tm, [34, -20, 10], function (f) { return f === null ? k.P : k.at(f, 0); });
    kaEv(k.scw, k.a, k.b, k.fps, tm, [1.25, .9, 1.05], function (f) { return f === null ? k.SW : k.SW * f; }); }],
  pixGlitch: ["Пиксельный сбой", function (k) { var fx = kaNeed(k, "mosaic"), tm = kaTimes(k.a, k.b, 1.4, 21, .5);
    kaEv(kaPrm(fx, ["horizontal blocks", "горизонтальные блоки", "блоки по горизонтали"], 0), k.a, k.b, k.fps, tm, [14, 40, 90], function (f) { return f === null ? 4000 : f; });
    kaEv(kaPrm(fx, ["vertical blocks", "вертикальные блоки", "блоки по вертикали"], 1), k.a, k.b, k.fps, tm, [24, 70, 160], function (f) { return f === null ? 4000 : f; }); }],
  wrapGlitch: ["Сдвиг с переносом", function (k) { var p = kaPrm(kaNeed(k, "offset"), ["shift center to", "сместить центр в", "перенести центр в", "сдвинуть центр в", "сместить центр"], 0);
    var B = kkBase(p, k.a), m = B[0] > 2 ? k.c.W : 1;
    kaEv(p, k.a, k.b, k.fps, kaTimes(k.a, k.b, 1.5, 61, .5), [.18, -.09, .03], function (f) { return f === null ? B : [B[0] + f * m, B[1]]; }); }],
  invert: ["Негатив-вспышки", function (k) { var p = kaPrm(kaNeed(k, "invert"), ["blend with original", "смешать с оригиналом", "смешивание с оригиналом", "смешать с исходным", "наложение на оригинал"], 1);
    kaEv(p, k.a, k.b, k.fps, kaTimes(k.a, k.b, 1.6, 31, .5), [0, 0, 100, 0], function (f) { return f === null ? 100 : f; }); }],
  lightning: ["Молния", function (k) { var p = kaPrm(kaNeed(k, "bright"), ["brightness", "яркость"], 0), tm = kaTimes(k.a, k.b, 2.8, 41, .6);
    kaEv(p, k.a, k.b, k.fps, tm, [90, 10, 70, 25], function (f) { return f === null ? 0 : f; });
    kaEv(k.pos, k.a, k.b, k.fps, tm, [10, -8, 5, -2], function (f) { return f === null ? k.P : k.at(f * .6, f); }); }],
  filmSlip: ["Плёнка соскочила", function (k) { kaEv(k.pos, k.a, k.b, k.fps, kaTimes(k.a, k.b, 2.6, 51, .8), [-320, -170, -60, -10], function (f) { return f === null ? k.P : k.at(0, f); }); }],
  impact: ["Встряска в начале", function (k) { var e = k.a + Math.min(k.L, .6);
    k.hold(k.pos, k.a, e, 15, function (j, x) { var g = (1 - x) * (1 - x) * 56; return x >= 1 ? k.P : k.at(g * (kaRnd(j) - .5), g * (kaRnd(j + 17) - .5)); });
    k.hold(k.rot, k.a, e, 15, function (j, x) { return k.R + 8 * (1 - x) * (kaRnd(j + 29) - .5); }); }],
  teleport: ["Телепорт", function (k) { var s = [[0, 0], [-200, -60], [190, 40], [-60, 120], [150, -110]];
    k.hold(k.pos, k.a, k.b, 1 / .6, function (j) { var q = s[j % 5]; return k.at(q[0], q[1]); }); }],
  zoomGlitch: ["Зум-сбой", function (k) { var lv = [1.14, .92, 1.25, 1.06];
    k.hold(k.sc, k.a, k.b, 5, function (j) { return kaRnd(j * 3 + 7) < .55 ? k.S : k.S * lv[Math.floor(kaRnd(j + 3) * 4)]; }); }],
  blurBeat: ["Расфокус в бит", function (k) { var p = kaPrm(kaNeed(k, "gblur"), ["blurriness", "размытость", "размытие"], 0);
    kaEv(p, k.a, k.b, k.fps, kaEvery(k.a, k.b, .5, .25), [16, 8, 3], function (f) { return f === null ? 0 : f; }); }],
  melt: ["Плавится", function (k) { var fx = kaNeed(k, "turb");
    kaSet(kaPrm(fx, ["amount", "количество", "величина"], 1), 45); kaSet(kaPrm(fx, ["size", "размер"], 2), 70);
    k.hold(kaPrm(fx, ["evolution", "эволюция"], 5), k.a, k.b, 8, function (j) { return j * 25; }); }],
  crumble: ["Рассыпается", function (k) { var fx = kaNeed(k, "mosaic"), e0 = k.b - Math.min(k.L, .7);
    var hb = kaPrm(fx, ["horizontal blocks", "горизонтальные блоки", "блоки по горизонтали"], 0), vb = kaPrm(fx, ["vertical blocks", "вертикальные блоки", "блоки по вертикали"], 1);
    if (e0 > k.a) { kaKey(hb, k.a, 4000); kaKey(vb, k.a, 4000); }
    k.hold(hb, e0, k.b, 8, function (j) { return Math.max(6, Math.round(4000 * Math.pow(.42, j + 1))); });
    k.hold(vb, e0, k.b, 8, function (j) { return Math.max(10, Math.round(4000 * Math.pow(.45, j + 1))); });
    if (k.opa) k.hold(k.opa, e0, k.b, 8, function (j, x) { return k.O * (1 - x * x); }); }]
};

/* ---------- циклы: +30. k.ph(x) — сколько периодов прошло, k.u(x) — доля текущего периода ---------- */
function kaLoopK(k, T) {
  k.T = T; k.ph = function (x) { return x * k.L / T; }; k.u = function (x) { var p = k.ph(x); return p - Math.floor(p); };
  k.f = Math.min(k.fps, 15); k.lb = function (prop, f, full) { kkBake(prop, k.a, k.b, full ? k.fps : k.f, f); };
  return k;
}
var KA_L3 = {
  pinSwing: ["Качели на гвоздике", function (k) { var A = k.A; k.pin(k.a, k.b, function (x) { return 12 * A * Math.sin(k.ph(x) * Math.PI * 2); }, 0, -300, k.f); }],
  zeroG: ["Невесомость", function (k) { var A = k.A;
    k.lb(k.pos, function (x) { var t = k.ph(x); return k.at(40 * A * kaNoise(t * .8, 5), 30 * A * kaNoise(t * .8, 55)); });
    k.lb(k.rot, function (x) { return k.R + 20 * A * k.ph(x) + 6 * A * kaNoise(k.ph(x) * .6, 77); }); }],
  lookAround: ["Оглядывается", function (k) { var A = k.A, ps = [0, -12, 0, 12, 0];
    var v = function (x) { var q = k.u(x) * 4, s = Math.floor(q), f = q - s; return ps[s] + (ps[s + 1] - ps[s]) * kaSpring(Math.min(1, f * 2.5), .45, 16); };
    k.lb(k.rot, function (x) { return k.R + A * v(x); }, true); k.lb(k.pos, function (x) { return k.at(.5 * A * v(x), 0); }, true); }],
  nod: ["Кивает", function (k) { var A = k.A;
    var d = function (x) { var u = k.u(x); return u < .4 ? Math.pow(Math.sin(u / .4 * Math.PI * 2), 2) : 0; };
    k.lb(k.pos, function (x) { return k.at(0, 14 * A * d(x)); }, true); k.lb(k.rot, function (x) { return k.R + 3 * A * d(x); }, true); }],
  noNo: ["Мотает головой", function (k) { var A = k.A;
    var d = function (x) { var u = k.u(x); return u < .45 ? Math.sin(u / .45 * Math.PI * 6) * (1 - u / .45) : 0; };
    k.lb(k.rot, function (x) { return k.R + 8 * A * d(x); }, true); k.lb(k.pos, function (x) { return k.at(10 * A * d(x), 0); }, true); }],
  tada: ["Та-да!", function (k) { var A = k.A;
    k.lb(k.sc, function (x) { var u = k.u(x); return u < .5 ? k.S * (1 + .1 * A * Math.sin(Math.PI * u / .5)) : k.S; }, true);
    k.lb(k.rot, function (x) { var u = k.u(x), s = u / .5; return u < .5 ? k.R + 6 * A * Math.sin(s * Math.PI * 8) * Math.sin(Math.PI * s) : k.R; }, true); }],
  rubberBand: ["Резинка", function (k) { var A = k.A; k.split();
    var e = function (x) { var u = k.u(x), s = u / .5; return u < .5 ? Math.exp(-5 * s) * Math.sin(s * Math.PI * 6) : 0; };
    k.lb(k.scw, function (x) { return k.SW * (1 + .22 * A * e(x)); }, true); k.lb(k.sc, function (x) { return k.S * (1 - .22 * A * e(x)); }, true); }],
  hose: ["Резиновый шланг", function (k) { var A = k.A, fx = kaNeed(k, "transform"), sk = kaPrm(fx, ["skew", "наклон", "перекос", "скос"], 5);
    k.lb(sk, function (x) { return 18 * A * Math.sin(k.ph(x) * Math.PI * 2); });
    k.lb(k.rot, function (x) { return k.R - 4 * A * Math.sin(k.ph(x) * Math.PI * 2); }); }],
  flag: ["Флаг на ветру", function (k) { var fx = kaNeed(k, "wave");
    kaSet(kaPrm(fx, ["wave height", "высота волны"], 1), Math.round(18 * k.A)); kaSet(kaPrm(fx, ["wave width", "ширина волны"], 2), 220);
    kaSet(kaPrm(fx, ["wave speed", "скорость волны"], 4), Math.round(10 / k.T) / 10); }],
  ball: ["Мячик", function (k) { var A = k.A; k.split();
    var c = function (x) { var u = k.u(x); return Math.max(0, 1 - Math.min(u, 1 - u) / .12); }, st = function (x) { return Math.abs(1 - 2 * k.u(x)) * (1 - c(x)); };
    k.lb(k.pos, function (x) { var u = k.u(x); return k.at(0, -110 * A * 4 * u * (1 - u)); }, true);
    k.lb(k.sc, function (x) { return k.S * (1 - .25 * A * c(x) + .1 * A * st(x)); }, true);
    k.lb(k.scw, function (x) { return k.SW * (1 + .25 * A * c(x) - .07 * A * st(x)); }, true); }],
  boing: ["Пружинка", function (k) { var A = k.A;
    k.lb(k.sc, function (x) { var u = k.u(x); if (u < .25) return k.S * (1 - .18 * A * kaSine(u / .25)); var s = (u - .25) / .75; return k.S * (1 - .18 * A * Math.exp(-5 * s) * Math.cos(s * Math.PI * 4)); }, true);
    k.lb(k.pos, function (x) { var u = k.u(x); if (u < .25) return k.at(0, 10 * A * kaSine(u / .25)); var s = (u - .25) / .75; return k.at(0, -60 * A * Math.exp(-4 * s) * Math.sin(s * Math.PI * 3) + 10 * A * Math.exp(-8 * s)); }, true); }],
  carousel: ["Карусель 3D", function (k) { var A = k.A, an = function (x) { return k.ph(x) * Math.PI * 2; };
    k.lb(k.pos, function (x) { return k.at(120 * A * Math.sin(an(x)), 15 * A * Math.cos(an(x))); });
    k.lb(k.sc, function (x) { return k.S * (1 + .15 * A * Math.cos(an(x))); }); }],
  spiralLoop: ["Спираль туда-обратно", function (k) { var A = k.A;
    k.lb(k.pos, function (x) { var t = k.ph(x), r = 70 * A * (.5 - .5 * Math.cos(Math.PI * t)), a = t * Math.PI * 4; return k.at(r * Math.cos(a), r * Math.sin(a)); }); }],
  metronome: ["Метроном", function (k) { var A = k.A; k.pin(k.a, k.b, function (x) { return 20 * A * (2 / Math.PI) * Math.asin(Math.sin(k.ph(x) * Math.PI * 2)); }, 0, 300); }],
  dance: ["Танцует", function (k) { var A = k.A, s = function (x) { return Math.sin(k.ph(x) * Math.PI * 2); };
    k.lb(k.pos, function (x) { return k.at(25 * A * s(x), -18 * A * Math.abs(s(x))); }, true);
    k.lb(k.rot, function (x) { return k.R + 6 * A * s(x); }, true); }],
  peek: ["Выглядывает", function (k) { var A = k.A;
    k.lb(k.pos, function (x) { var u = k.u(x), y = 0;
      if (u >= .3 && u < .55) y = KK_EASE.inOutCubic((u - .3) / .25); else if (u >= .55 && u < .7) y = 1; else if (u >= .7) y = 1 - kaSpring((u - .7) / .3, .4, 16);
      return k.at(0, 140 * A * y); }, true); }],
  tapSpring: ["Нажатие кнопки", function (k) { var A = k.A;
    k.lb(k.sc, function (x) { var u = k.u(x); if (u >= .6) return k.S; var s = u / .6;
      return k.S * (s < .15 ? 1 - .08 * A * KK_EASE.outCubic(s / .15) : 1 - .08 * A * (1 - kaSpring((s - .15) / .85, .35, 20))); }, true); }],
  spinPause: ["Вращение с паузами", function (k) { var A = k.A;
    k.lb(k.rot, function (x) { var p = k.ph(x), u = p - Math.floor(p); return k.R + 360 * A * (Math.floor(p) + kaSpring(Math.min(1, u / .6), .55, 14)); }, true); }],
  coin: ["Монетка", function (k) { var A = k.A; k.split();
    k.lb(k.pos, function (x) { var u = k.u(x), s = u / .5; return k.at(0, u < .5 ? -120 * A * 4 * s * (1 - s) : 0); }, true);
    k.lb(k.scw, function (x) { var u = k.u(x); return u < .5 ? k.SW * Math.abs(Math.cos(Math.PI * 4 * u / .5)) : k.SW; }, true); }],
  pingPong: ["Пинг-понг", function (k) { var A = k.A; k.split();
    var xx = function (x) { var u = k.u(x); return u < .5 ? -1 + 4 * u : 3 - 4 * u; }, sq = function (x) { return Math.max(0, (Math.abs(xx(x)) - .9) / .1); };
    k.lb(k.pos, function (x) { return k.at(200 * A * xx(x), 0); }, true);
    k.lb(k.scw, function (x) { return k.SW * (1 - .25 * sq(x)); }, true); k.lb(k.sc, function (x) { return k.S * (1 + .2 * sq(x)); }, true); }],
  sparkle: ["Звёздочка мерцает", function (k) { var A = k.A, tm = kaTimes(0, k.L, k.T, 71, k.T * .3);
    var w = function (x) { var t = x * k.L, i; for (i = 0; i < tm.length; i++) { var s = (t - tm[i]) / .35; if (s >= 0 && s <= 1) return Math.sin(Math.PI * s); } return 0; };
    k.bake(k.sc, k.a, k.b, function (x) { return k.S * (1 + .25 * A * w(x)); }, 15); k.bake(k.rot, k.a, k.b, function (x) { return k.R + 20 * A * w(x); }, 15); }],
  gust: ["Порыв ветра", function (k) { var A = k.A;
    var l = function (x) { var u = k.u(x); if (u < .15) return 0; if (u < .35) return KK_EASE.outCubic((u - .15) / .2); return 1 - kaSpring((u - .35) / .65, .3, 22); };
    k.lb(k.rot, function (x) { return k.R + 14 * A * l(x); }, true); k.lb(k.pos, function (x) { return k.at(30 * A * l(x), 0); }, true); }],
  laugh: ["Хохочет", function (k) { var A = k.A;
    var h = function (x) { var u = k.u(x); return u < .6 ? Math.abs(Math.sin(u / .6 * Math.PI * 7)) * (1 - u / .6 * .5) : 0; };
    k.lb(k.pos, function (x) { return k.at(0, -8 * A * h(x)); }, true);
    k.lb(k.rot, function (x) { var u = k.u(x); return k.R + (u < .6 ? 2 * A * Math.sin(u / .6 * Math.PI * 3) : 0); }, true); }],
  newton: ["Шарик Ньютона", function (k) { var A = k.A; k.pin(k.a, k.b, function (x) { return 25 * A * Math.abs(Math.sin(Math.PI * k.ph(x))); }, 0, -300); }],
  skate: ["Скейт", function (k) { var A = k.A;
    k.lb(k.pos, function (x) { return k.at(120 * A * Math.sin(k.ph(x) * Math.PI * 2), 0); });
    k.lb(k.rot, function (x) { return k.R + 8 * A * Math.cos(k.ph(x) * Math.PI * 2); }); }],
  jellyfish: ["Медуза", function (k) { var A = k.A; k.split();
    var c = function (x) { var u = k.u(x); return u < .3 ? Math.sin(Math.PI * u / .3) : 0; };
    k.lb(k.scw, function (x) { return k.SW * (1 - .15 * A * c(x)); }, true); k.lb(k.sc, function (x) { return k.S * (1 + .08 * A * c(x)); }, true);
    k.lb(k.pos, function (x) { var u = k.u(x); return k.at(0, -40 * A * (u < .3 ? KK_EASE.outCubic(u / .3) : 1 - (u - .3) / .7)); }); }],
  loader: ["Загрузка", function (k) { k.hold(k.rot, k.a, k.b, 8 / k.T, function (j) { return k.R + 45 * j; }); }],
  yoyo: ["Йо-йо", function (k) { var A = k.A;
    var y = function (x) { var u = k.u(x); if (u < .35) { var s = u / .35; return s * s; } return 1 - KK_EASE.inOutCubic((u - .35) / .65); };
    k.lb(k.pos, function (x) { return k.at(0, 260 * A * y(x)); }, true); k.lb(k.rot, function (x) { return k.R + 360 * y(x); }, true); }],
  yaw: ["Поворот в 3D", function (k) { var A = k.A; k.split();
    k.lb(k.scw, function (x) { return k.SW * Math.cos(30 * Math.min(A, 2.5) * Math.sin(k.ph(x) * Math.PI * 2) * Math.PI / 180); });
    k.lb(k.pos, function (x) { return k.at(10 * A * Math.sin(k.ph(x) * Math.PI * 2), 0); }); }],
  flap: ["Взмах крыльями", function (k) { var A = k.A; k.split();
    k.lb(k.scw, function (x) { return k.SW * (1 - Math.min(.8, .4 * A) * Math.abs(Math.sin(k.ph(x) * Math.PI * 2))); }, true);
    k.lb(k.pos, function (x) { return k.at(0, -10 * A * Math.sin(k.ph(x) * Math.PI * 2 + 1)); }, true); }]
};

/* ---------- появления: +34. k.e(m) — конец появления длиной m × «длительность» ---------- */
var KA_I3 = {
  iosFade: ["Мягкое проявление", function (k) { var e = k.e(1.2), q = KK_EASE.outQuint;
    k.fade(k.a, k.a + (e - k.a) * .6); k.bake(k.pos, k.a, e, function (x) { return k.at(0, 24 * (1 - q(x))); });
    k.bake(k.sc, k.a, e, function (x) { return k.S * (.96 + .04 * q(x)); }); }],
  blurIn: ["Из размытия", function (k) { var p = kaPrm(kaNeed(k, "gblur"), ["blurriness", "размытость", "размытие"], 0), e = k.e(1);
    k.bake(p, k.a, e, function (x) { return 60 * (1 - KK_EASE.outCubic(x)); }); k.fade(k.a, k.a + (e - k.a) * .6); }],
  springPop: ["Пружинный поп", function (k) { k.bake(k.sc, k.a, k.e(1.6), function (x) { return Math.max(0, k.S * kaSpring(x, .45, 15)); }); }],
  sticker: ["Наклейка", function (k) { var e = k.e(1);
    k.bake(k.sc, k.a, e, function (x) { return k.S * (1.5 - .5 * kaSpring(x, .5, 16)); });
    k.bake(k.rot, k.a, e, function (x) { return k.R - 14 * (1 - KK_EASE.outBack(x)); }); k.fade(k.a, k.a + (e - k.a) * .25); }],
  stamp: ["Штамп", function (k) { var e = k.e(.8), e2 = Math.min(k.b, e + .25);
    k.bake(k.sc, k.a, e, function (x) { return k.S * (3.2 - 2.2 * KK_EASE.inCubic(x)); }); k.fade(k.a, k.a + (e - k.a) * .3);
    if (e2 > e) { k.bake(k.sc, e, e2, function (x) { return k.S * (1 - .06 * Math.sin(Math.PI * x)); });
      k.bake(k.pos, e, e2, function (x) { var g = 10 * (1 - x); return k.at(g * Math.sin(x * 40), g * Math.cos(x * 33)); }); } }],
  swingIn: ["Вывеска на гвоздике", function (k) { var e = k.e(2.2);
    k.pin(k.a, e, function (x) { return 75 * (1 - kaSpring(x, .25, 22)); }, 0, -260); k.fade(k.a, k.a + (e - k.a) * .15); }],
  doorOpen: ["Дверца", function (k) { k.split(); var e = k.e(1.1), q = KK_EASE.outCubic;
    k.bake(k.scw, k.a, e, function (x) { return k.SW * q(x); }); k.bake(k.pos, k.a, e, function (x) { return k.at(-200 * (1 - q(x)), 0); }); }],
  flipDown: ["Откидная табличка", function (k) { k.split(); var e = k.e(1.4), q = KK_EASE.outBounce;
    k.bake(k.sc, k.a, e, function (x) { return k.S * q(x); }); k.bake(k.pos, k.a, e, function (x) { return k.at(0, -150 * (1 - q(x))); }); }],
  rollIn: ["Вкатывается", function (k) { var e = k.e(1.3), q = KK_EASE.outCubic;
    k.bake(k.pos, k.a, e, function (x) { return k.at(-700 * (1 - q(x)), 0); }); k.bake(k.rot, k.a, e, function (x) { return k.R - 540 * (1 - q(x)); }); }],
  bounceIn: ["Отскоки сверху", function (k) { k.bake(k.pos, k.a, k.e(1.6), function (x) { return k.at(0, -800 * (1 - KK_EASE.outBounce(x))); }); }],
  stretchIn: ["Влёт с растяжкой", function (k) { k.split(); var e = k.e(1), q = KK_EASE.outBack;
    var v = function (x) { return Math.min(1, Math.abs(q(Math.min(1, x + .02)) - q(x)) / .02 / 3); };
    k.bake(k.pos, k.a, e, function (x) { return k.at(700 * (1 - q(x)), 0); });
    k.bake(k.scw, k.a, e, function (x) { return k.SW * (1 + .5 * v(x)); }); k.bake(k.sc, k.a, e, function (x) { return k.S * (1 - .2 * v(x)); }); }],
  glitchIn: ["Глитч-появление", function (k) { var e = k.e(1);
    if (k.opa) k.hold(k.opa, k.a, e, 15, function (j, x) { return x >= 1 || kaRnd(j + 3) > .4 ? k.O : 0; });
    k.hold(k.pos, k.a, e, 15, function (j, x) { return x >= 1 ? k.P : k.at(60 * (1 - x) * (kaRnd(j + 9) - .5), 0); }); }],
  lampOn: ["Включается как лампа", function (k) { if (!k.opa) return "err|Нет непрозрачности"; var pat = [0, 1, 0, 0, 1, 0, 1, 1, .4, 1];
    k.hold(k.opa, k.a, k.e(1.5), pat.length / (k.e(1.5) - k.a), function (j) { return k.O * pat[Math.min(j, pat.length - 1)]; }); }],
  bubble: ["Всплывает пузырём", function (k) { var e = k.e(1.6), q = KK_EASE.outCubic;
    k.bake(k.pos, k.a, e, function (x) { return k.at(30 * Math.sin(x * Math.PI * 3) * (1 - x), 500 * (1 - q(x))); });
    k.bake(k.sc, k.a, e, function (x) { return k.S * (.6 + .4 * q(x) + .05 * Math.sin(x * Math.PI * 5) * (1 - x)); }); k.fade(k.a, k.a + (e - k.a) * .2); }],
  leafFall: ["Опускается листиком", function (k) { var e = k.e(2.5);
    k.bake(k.pos, k.a, e, function (x) { return k.at(120 * Math.sin(x * Math.PI * 3) * (1 - x) * (1 - x), -700 * (1 - x) * (1 - x)); });
    k.bake(k.rot, k.a, e, function (x) { return k.R + 20 * Math.cos(x * Math.PI * 3) * (1 - x); }); k.fade(k.a, k.a + (e - k.a) * .2); }],
  pivotIn: ["С поворота из угла", function (k) { var e = k.e(1.2); k.pin(k.a, e, function (x) { return -90 * (1 - KK_EASE.outBack(x)); }, -250, 250); k.fade(k.a, k.a + (e - k.a) * .2); }],
  jack: ["Чёртик из табакерки", function (k) { k.split(); var e = k.e(1.6);
    var v = function (x) { return Math.min(1, Math.abs(kaSpring(Math.min(1, x + .02), .35, 18) - kaSpring(x, .35, 18)) / .02 / 4); };
    k.bake(k.pos, k.a, e, function (x) { return k.at(0, 260 * (1 - kaSpring(x, .35, 18))); });
    k.bake(k.sc, k.a, e, function (x) { return k.S * (1 + .3 * v(x)); }); k.bake(k.scw, k.a, e, function (x) { return k.SW * (1 - .15 * v(x)); }); k.fade(k.a, k.a + (e - k.a) * .1); }],
  curtain: ["Раздвигается из центра", function (k) { var l = k.mo.properties[7], r = k.mo.properties[9]; if (!l || !r) return "err|В этой версии нет кадрирования в «Движении»";
    var e = k.e(1); k.bake(l, k.a, e, function (x) { return 50 * (1 - KK_EASE.outQuint(x)); }); k.bake(r, k.a, e, function (x) { return 50 * (1 - KK_EASE.outQuint(x)); }); }],
  tumble: ["Кувырком сверху", function (k) { var e = k.e(1.4), q = KK_EASE.outBack;
    k.bake(k.pos, k.a, e, function (x) { return k.at(0, -650 * (1 - q(x))); }); k.bake(k.rot, k.a, e, function (x) { return k.R + 180 * (1 - q(x)); }); }],
  whipIn: ["Смаз-влёт", function (k) { var fx = kaNeed(k, "dblur"), e = k.e(.9);
    kaSet(kaPrm(fx, ["direction", "направление"], 0), 90);
    k.bake(kaPrm(fx, ["blur length", "длина размытия"], 1), k.a, e, function (x) { return 120 * (1 - KK_EASE.outCubic(Math.min(1, x * 1.4))); });
    k.bake(k.pos, k.a, e, function (x) { return k.at(-900 * (1 - KK_EASE.outExpo(x)), 0); }); }],
  jellyPop: ["Желейный поп", function (k) { k.split(); var e = k.e(1.8);
    var g = function (x) { return KK_EASE.outCubic(Math.min(1, x * 3)); }, w = function (x) { return Math.exp(-5 * x) * Math.sin(x * Math.PI * 7); };
    k.bake(k.sc, k.a, e, function (x) { return k.S * g(x) * (1 + .25 * w(x)); }); k.bake(k.scw, k.a, e, function (x) { return k.SW * g(x) * (1 - .25 * w(x)); }); }],
  inflate: ["Надувается", function (k) { k.bake(k.sc, k.a, k.e(1.6), function (x) { if (x >= 1) return k.S; var q = x * 3, j = Math.floor(q); return k.S * (j + KK_EASE.outBack(q - j)) / 3; }); }],
  rippleIn: ["Из ряби", function (k) { var fx = kaNeed(k, "wave"), e = k.e(1.5);
    kaSet(kaPrm(fx, ["wave width", "ширина волны"], 2), 80);
    k.bake(kaPrm(fx, ["wave height", "высота волны"], 1), k.a, e, function (x) { return 40 * (1 - KK_EASE.outCubic(x)); }); k.fade(k.a, k.a + (e - k.a) * .4); }],
  coinIn: ["Монетка-разворот", function (k) { k.split(); var e = k.e(1.5);
    k.bake(k.scw, k.a, e, function (x) { return k.SW * Math.abs(Math.cos(6 * Math.PI * (1 - KK_EASE.outCubic(x)))); }); k.fade(k.a, k.a + (e - k.a) * .15); }],
  brake: ["Тормозит с креном", function (k) { var e = k.e(1.6);
    k.bake(k.pos, k.a, e, function (x) { return k.at(x < .6 ? 800 * (1 - KK_EASE.outCubic(x / .6)) : 0, 0); });
    k.bake(k.rot, k.a, e, function (x) { if (x < .6) return k.R + 6 * (1 - x / .6); var q = (x - .6) / .4; return k.R - 10 * Math.exp(-4 * q) * Math.sin(q * Math.PI * 2.5) * (1 - q); }); }],
  flashIn: ["С фотовспышкой", function (k) { var e = k.e(.8), br = kaFx(k, "bright");
    if (br) k.bake(kaPrm(br, ["brightness", "яркость"], 0), k.a, e, function (x) { return 100 * (1 - x); });
    k.bake(k.sc, k.a, e, function (x) { return k.S * (1.08 - .08 * KK_EASE.outCubic(x)); }); k.fade(k.a, Math.min(k.b, k.a + 3 / k.fps)); }],
  markerIn: ["Рисуется маркером", function (k) { var cp = k.mo.properties[9]; if (!cp) return "err|В этой версии нет кадрирования в «Движении»"; var e = k.e(1.5);
    k.hold(cp, k.a, e, 12, function (j, x) { return 100 * (1 - x); });
    var tb = kaFx(k, "turb"); if (tb) { kaSet(kaPrm(tb, ["size", "размер"], 2), 14);
      k.hold(kaPrm(tb, ["amount", "количество", "величина"], 1), k.a, e, 12, function (j, x) { return 25 * (1 - x); });
      k.hold(kaPrm(tb, ["evolution", "эволюция"], 5), k.a, e, 12, function (j) { return j * 97; }); } }],
  pixIn: ["Из пикселей", function (k) { var fx = kaNeed(k, "mosaic"), lv = [4, 8, 16, 32, 64, 4000], e = k.e(1);
    k.hold(kaPrm(fx, ["horizontal blocks", "горизонтальные блоки", "блоки по горизонтали"], 0), k.a, e, 5 / (e - k.a), function (j) { return lv[Math.min(j, 5)]; });
    k.hold(kaPrm(fx, ["vertical blocks", "вертикальные блоки", "блоки по вертикали"], 1), k.a, e, 5 / (e - k.a), function (j) { return j >= 5 ? 4000 : Math.round(lv[j] * 1.78); }); }],
  top: ["Юла", function (k) { var e = k.e(1.8);
    k.bake(k.rot, k.a, e, function (x) { return k.R - 900 * (1 - KK_EASE.outCubic(x)); });
    k.bake(k.sc, k.a, e, function (x) { return k.S * (.3 + .7 * KK_EASE.outBack(Math.min(1, x * 1.5))); });
    k.bake(k.pos, k.a, e, function (x) { return k.at(15 * Math.sin(x * Math.PI * 6) * (1 - x), 0); }); }],
  magnet: ["Притягивается магнитом", function (k) { var e = k.e(.9), e2 = Math.min(k.b, e + .15);
    k.bake(k.pos, k.a, e, function (x) { var q = 1 - KK_EASE.inCubic(x); return k.at(-300 * q, -200 * q); });
    if (e2 > e) k.bake(k.pos, e, e2, function (x) { var g = 6 * (1 - x); return k.at(g * Math.sin(x * 30), g * Math.cos(x * 27)); }); }],
  tvOn: ["Включение ТВ", function (k) { k.split(); var e = k.e(1.2), m = k.a + (e - k.a) * .45;
    k.bake(k.scw, k.a, m, function (x) { return k.SW * 1.05 * KK_EASE.outCubic(x); }); kaKey(k.sc, k.a, k.S * .03);
    k.bake(k.sc, m, e, function (x) { return k.S * (.03 + .97 * KK_EASE.outBack(x)); }); k.bake(k.scw, m, e, function (x) { return k.SW * (1.05 - .05 * x); });
    k.fade(k.a, Math.min(k.b, k.a + 2 / k.fps)); }],
  echoIn: ["Влёт со шлейфом", function (k) { var fx = kaNeed(k, "echo");
    kaSet(kaPrm(fx, ["echo time (seconds)", "echo time", "время эха (секунды)", "время эха (с)", "время эха"], 0), -0.04);
    kaSet(kaPrm(fx, ["number of echoes", "количество эхо", "число эхо", "количество эха", "количество отражений"], 1), 6);
    kaSet(kaPrm(fx, ["decay", "затухание", "ослабление"], 3), .7);
    k.bake(k.pos, k.a, k.e(1.2), function (x) { return k.at(-800 * (1 - KK_EASE.outExpo(x)), 0); }); }],
  spider: ["Спускается на ниточке", function (k) { var e = k.e(2.4);
    k.bake(k.pos, k.a, e, function (x) { return k.at(0, -900 * (1 - kaSpring(x, .3, 20))); });
    k.bake(k.rot, k.a, e, function (x) { return k.R + 8 * Math.exp(-3 * x) * Math.sin(x * Math.PI * 5); }); }],
  shy: ["Стесняшка", function (k) { var e = k.e(2.2);
    k.bake(k.pos, k.a, e, function (x) { var v;
      if (x < .3) v = 500 - 200 * KK_EASE.outCubic(x / .3); else if (x < .45) v = 300 + 150 * KK_EASE.inOutCubic((x - .3) / .15); else v = 450 * (1 - KK_EASE.outBack((x - .45) / .55));
      return k.at(v, 0); }); }]
};

/* ---------- пути: +42. KA_PF — чистая математика: x 0..1 → [dx, dy] в px 1080p (k.fw/k.fh — размер кадра в тех же px) ---------- */
function kaPoly(pts, x, ease) { // по ломаной: на каждом отрезке своя плавность
  var n = pts.length - 1, q = Math.min(n - 1e-9, Math.max(0, x * n)), i = Math.floor(q), f = ease(q - i);
  return [pts[i][0] + (pts[i + 1][0] - pts[i][0]) * f, pts[i][1] + (pts[i + 1][1] - pts[i][1]) * f];
}
var KA_COASTER = null;
function kaCoaster(x) { // скорость как у вагончика: на горке медленно, внизу быстро
  var N = 200, i;
  if (!KA_COASTER) { var tt = [0], y = function (u) { return -160 * Math.cos(u * Math.PI * 3) - 40 * u; }, acc = 0;
    for (i = 1; i <= N; i++) { var u0 = (i - 1) / N, u1 = i / N, dx = 900 / N, dy = y(u1) - y(u0), ds = Math.sqrt(dx * dx + dy * dy);
      var v = Math.sqrt(Math.max(30, 60 + (y((u0 + u1) / 2) - y(0)) * 2)); acc += ds / v; tt.push(acc); }
    for (i = 0; i <= N; i++) tt[i] /= acc; KA_COASTER = { t: tt, y: y }; }
  var T = KA_COASTER.t, lo = 0, hi = N; while (hi - lo > 1) { var m = Math.floor((lo + hi) / 2); if (T[m] <= x) lo = m; else hi = m; }
  var uu = (lo + (x - T[lo]) / Math.max(1e-9, T[hi] - T[lo])) / N; return [-450 + 900 * uu, KA_COASTER.y(uu)];
}
var KA_PF = {
  glide: function (x) { return [-450 + 900 * KK_EASE.inOutCubic(x), 0]; },
  diag: function (x) { var e = KK_EASE.inOutCubic(x); return [-400 + 800 * e, 300 - 600 * e - 80 * Math.sin(Math.PI * e)]; },
  sCurve: function (x) { var t = KK_EASE.inOutCubic(x), u = 1 - t, a = [-450, 200], b = [-100, -450], c = [100, 450], d = [450, -200];
    return [u * u * u * a[0] + 3 * u * u * t * b[0] + 3 * u * t * t * c[0] + t * t * t * d[0], u * u * u * a[1] + 3 * u * u * t * b[1] + 3 * u * t * t * c[1] + t * t * t * d[1]]; },
  loopDeLoop: function (x) { var th = -Math.PI + 2 * Math.PI * x; return [143 * th - 230 * Math.sin(th), -230 * (1 + Math.cos(th)) + 0]; },
  coil: function (x) { var th = x * Math.PI * 8, a = 900 / (Math.PI * 8), b = a * 1.6; return [-450 + a * th - b * Math.sin(th), b * Math.cos(th) - b]; },
  heart: function (x) { var t = kaSine(x) * Math.PI * 2, s = Math.sin(t);
    return [14 * 16 * s * s * s, -14 * (13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t) - 5)]; },
  star: function (x) { var p = [], i; for (i = 0; i <= 10; i++) { var r = i % 2 ? 95 : 230, a = -Math.PI / 2 + i * Math.PI / 5; p.push([r * Math.cos(a), r * Math.sin(a) + 230]); }
    return kaPoly(p, x, KK_EASE.inOutCubic); },
  square: function (x) { return kaPoly([[0, 0], [160, 0], [160, 160], [0, 160], [0, 0]], x, function (f) { return kaSpring(f, .5, 14); }); },
  dvd: function (x, k) { var hw = k.fw * .32, hh = k.fh * .32; return [hw * kaTri(x * 1.3), hh * kaTri(x * 1.7)]; },
  stairs: function (x) { var q = Math.min(3.9999, x * 4), j = Math.floor(q), s = q - j; return [-300 + 150 * (j + s), -180 + 90 * (j + s) - 90 * 4 * s * (1 - s)]; },
  shootingStar: function (x) { var e = KK_EASE.outExpo(x); return [450 - 900 * e, -500 + 800 * e]; },
  rocket: function (x) { if (x < .25) return [4 * Math.sin(x * 300), 3 * Math.cos(x * 270)]; var s = (x - .25) / .75; return [12 * Math.sin(s * 20) * s, -1400 * s * s * s]; },
  plane: function (x) { var e = KK_EASE.outCubic(x); return [-500 * (1 - e), -350 * (1 - e) + 40 * Math.sin(x * Math.PI * 3) * (1 - x)]; },
  swoop: function (x) { var p = x - Math.sin(2 * Math.PI * x) / (2 * Math.PI) * .8; return [-450 + 900 * p, -300 + 600 * Math.sin(Math.PI * p)]; },
  bee: function (x) { return [-450 + 900 * x + 40 * Math.sin(x * Math.PI * 10), 60 * kaNoise(x * 6, 3) + 40 * Math.cos(x * Math.PI * 10)]; },
  tornado: function (x) { var th = x * Math.PI * 8, r = 40 + 160 * x; return [r * Math.sin(th), 300 - 600 * x]; },
  dropRoll: function (x) { if (x < .5) return [-300, -700 * (1 - KK_EASE.outBounce(x / .5))]; return [-300 * (1 - KK_EASE.outCubic((x - .5) / .5)), 0]; },
  pendulum: function (x) { var th = 60 * (1 - x) * (1 - x) * Math.cos(x * Math.PI * 4); return kaPin(th, 0, -400); },
  elevator: function (x) { return kaPoly([[0, 400], [0, 267], [0, 133], [0, 0]], x, function (f) { return f < .5 ? kaSpring(f / .5, .6, 14) : 1; }); },
  knight: function (x) { return x < .55 ? [-150, 300 * (1 - KK_EASE.outBack(x / .55))] : [-150 * (1 - KK_EASE.outBack((x - .55) / .45)), 0]; },
  slalom: function (x) { return [150 * Math.sin(x * Math.PI * 5) * (1 - x * .3), -500 * (1 - x)]; },
  sling: function (x) { return x < .35 ? [-180 * KK_EASE.inOutCubic(x / .35), 0] : [-180 * (1 - KK_EASE.outElastic((x - .35) / .65)), 0]; },
  peek: function (x) { var y; if (x < .3) y = 400 - 280 * KK_EASE.outBack(x / .3); else if (x < .75) y = 120; else y = 120 + 280 * KK_EASE.inCubic((x - .75) / .25); return [0, y]; },
  run: function (x) { return [-450 + 900 * x, -14 * Math.abs(Math.sin(x * Math.PI * 12))]; },
  ufo: function (x) { var p = [[-300, -150], [250, -250], [-100, 100], [0, 0]], q = Math.min(2.9999, x * 3), i = Math.floor(q), f = q - i;
    var m = f < .4 ? kaSpring(f / .4, .5, 14) : 1, h = f < .4 ? 0 : 8 * Math.sin((f - .4) / .6 * Math.PI * 2);
    return [p[i][0] + (p[i + 1][0] - p[i][0]) * m, p[i][1] + (p[i + 1][1] - p[i][1]) * m + h]; },
  bolt: function (x) { return kaPoly([[-40, -520], [60, -300], [-30, -290], [70, -60], [0, 0]], x, function (f) { return KK_EASE.outExpo(Math.min(1, f * 1.4)); }); },
  carriage: function (x) { var q = Math.min(2.9999, x * 3), j = Math.floor(q), f = q - j, y = -240 + 120 * j, end = j === 2 ? 0 : 300;
    if (j < 2 && f > .75) { var r = KK_EASE.inOutCubic((f - .75) / .25); return [300 - 600 * r, y + 120 * r]; }
    return [-300 + (end + 300) * KK_EASE.inOutCubic(Math.min(1, f / (j < 2 ? .75 : 1))), y]; },
  gravity: function (x) { var ph = 110 * Math.PI / 180 * Math.sin(Math.PI * (x - .5)), r = 375 / (1 + 1.5 * Math.cos(ph)); return [r * Math.cos(ph) - 150, r * Math.sin(ph)]; },
  circle: function (x) { var th = 2 * Math.PI * KK_EASE.inOutCubic(x); return [150 * Math.sin(th), 150 * Math.cos(th) - 150]; },
  orbit3d: function (x) { var th = 2 * Math.PI * kaSine(x); return [260 * Math.sin(th), -60 * (1 - Math.cos(th))]; },
  scope: function (x) { var q = Math.min(5.9999, x * 6), j = Math.floor(q), f = q - j;
    var pt = function (i) { if (i >= 6) return [0, 0]; var r = 400 * Math.pow(1 - i / 6, 2), a = kaRnd(i * 13 + 5) * Math.PI * 2; return [r * Math.cos(a), r * Math.sin(a)]; };
    var A0 = pt(j), B0 = pt(j + 1), m = KK_EASE.outCubic(Math.min(1, f / .4)); return [A0[0] + (B0[0] - A0[0]) * m, A0[1] + (B0[1] - A0[1]) * m]; },
  fallOff: function (x) { if (x < .2) return [0, -60 * Math.sin(Math.PI * x / .2)]; var s = (x - .2) / .8; return [80 * s, 1400 * s * s]; },
  dashOff: function (x) { if (x < .3) return [-60 * KK_EASE.inOutCubic(x / .3), 0]; var s = (x - .3) / .7; return [-60 + 1460 * s * s * s, 0]; },
  meander: function (x) { var p = [[-450, 0]], i, cx = -450; for (i = 0; i < 3; i++) { p.push([cx, -150]); cx += 150; p.push([cx, -150]); p.push([cx, 0]); cx += 150; p.push([cx, 0]); }
    return kaPoly(p, x, KK_EASE.inOutCubic); },
  somersault: function (x) { var q = Math.min(1.9999, x * 2), j = Math.floor(q), s = q - j; return [-300 + 300 * (j + s), -220 * 4 * s * (1 - s)]; },
  coaster: function (x) { return kaCoaster(x); },
  raindrop: function (x) { var q = Math.min(4.9999, x * 5), j = Math.floor(q), f = q - j, m = KK_EASE.inOutCubic(Math.min(1, f / .3));
    var pt = function (i) { return i >= 5 ? [0, 0] : [i ? 25 * (kaRnd(i * 7) - .5) * 2 : 0, -500 + 100 * i]; }, A0 = pt(j), B0 = pt(j + 1);
    return [A0[0] + (B0[0] - A0[0]) * m, A0[1] + (B0[1] - A0[1]) * m]; },
  inchworm: function (x) { var q = Math.min(3.9999, x * 4), j = Math.floor(q), f = q - j; return [-400 + 200 * j + 100 * (f < .5 ? KK_EASE.inOutCubic(f / .5) : 1 + KK_EASE.inOutCubic((f - .5) / .5)), 0]; },
  windAway: function (x) { return [1300 * Math.pow(x, 2.2), -400 * Math.pow(x, 1.5) + 40 * Math.sin(x * Math.PI * 6)]; },
  speedRamp: function (x) { var u = 2 * x - 1; return [-600 + 1200 * (.5 + .5 * (.15 * u + .85 * u * u * u)), 0]; },
  toCamera: function (x) { return [0, x < .7 ? -280 * Math.sin(Math.PI * x / .7) : 0]; },
  intoDistance: function (x) { var e = KK_EASE.inOutCubic(x); return [40 * Math.sin(x * Math.PI * 2), -350 * e]; }
};
/* обёртки путей: позиция по KA_PF + своё вращение/масштаб там, где оно — часть идеи */
function kaPB(k, prop, f) { kkBake(prop, k.a, k.a + Math.min(k.L, 2.5), k.fps, f); }
var KA_P3 = {
  glide: ["Плавный проезд", function (k) { k.path(KA_PF.glide); }],
  diag: ["По диагонали", function (k) { k.path(KA_PF.diag); }],
  sCurve: ["S-кривая", function (k) { k.path(KA_PF.sCurve); }],
  circle: ["Ровно по кругу", function (k) { k.path(KA_PF.circle); }],
  orbit3d: ["Облёт в 3D", function (k) { k.path(KA_PF.orbit3d); kaPB(k, k.sc, function (x) { return k.S * (1 - .35 * (1 - Math.cos(2 * Math.PI * kaSine(x))) / 2); }); }],
  heart: ["По сердечку", function (k) { k.path(KA_PF.heart); }],
  star: ["Звёздочкой", function (k) { k.path(KA_PF.star); }],
  square: ["По квадрату", function (k) { k.path(KA_PF.square); }],
  plane: ["Бумажный самолётик", function (k) { k.path(KA_PF.plane, true); }],
  elevator: ["Лифт по этажам", function (k) { k.path(KA_PF.elevator); }],
  pendulum: ["Качнулся и замер", function (k) { k.path(KA_PF.pendulum); kaPB(k, k.rot, function (x) { return k.R + 60 * (1 - x) * (1 - x) * Math.cos(x * Math.PI * 4); }); }],
  carriage: ["Как строки текста", function (k) { k.path(KA_PF.carriage); }],
  intoDistance: ["Уходит вдаль", function (k) { k.path(KA_PF.intoDistance); kaPB(k, k.sc, function (x) { return k.S * (1 - .85 * KK_EASE.inOutCubic(x)); }); }],
  meander: ["Меандр", function (k) { k.path(KA_PF.meander); }],
  stairs: ["По ступенькам", function (k) { k.path(KA_PF.stairs); }],
  knight: ["Ход конём", function (k) { k.path(KA_PF.knight); }],
  slalom: ["Слалом", function (k) { k.path(KA_PF.slalom, true); }],
  swoop: ["Пикирует", function (k) { k.path(KA_PF.swoop, true); }],
  loopDeLoop: ["Мёртвая петля", function (k) { k.path(KA_PF.loopDeLoop, true); }],
  coil: ["Пружиной", function (k) { k.path(KA_PF.coil); }],
  run: ["Пробежка", function (k) { k.path(KA_PF.run); kaPB(k, k.rot, function (x) { return k.R + 6 + 2 * Math.sin(x * Math.PI * 12); }); }],
  inchworm: ["Гусеница", function (k) { k.split(); k.path(KA_PF.inchworm);
    kaPB(k, k.scw, function (x) { var f = x * 4 - Math.floor(Math.min(3.9999, x * 4)); return k.SW * (1 + .35 * Math.sin(Math.PI * f)); });
    kaPB(k, k.sc, function (x) { var f = x * 4 - Math.floor(Math.min(3.9999, x * 4)); return k.S * (1 + .1 * (f > .5 ? Math.sin(Math.PI * (f - .5) * 2) : 0)); }); }],
  somersault: ["Сальто", function (k) { k.path(KA_PF.somersault); kaPB(k, k.rot, function (x) { var q = Math.min(1.9999, x * 2), j = Math.floor(q); return k.R + 360 * (j + kaSine(q - j)); }); }],
  coaster: ["Американские горки", function (k) { k.path(KA_PF.coaster, true); }],
  raindrop: ["Капля по стеклу", function (k) { k.path(KA_PF.raindrop); }],
  gravity: ["Облёт и прочь", function (k) { k.path(KA_PF.gravity, true); }],
  speedRamp: ["Замедление в центре", function (k) { k.path(KA_PF.speedRamp); }],
  toCamera: ["Прыжок к зрителю", function (k) { k.path(KA_PF.toCamera);
    kaPB(k, k.sc, function (x) { return x < .7 ? k.S * (.3 + 1.05 * KK_EASE.inOutCubic(x / .7)) : k.S * (1.35 - .35 * KK_EASE.outBack((x - .7) / .3)); }); }],
  dropRoll: ["Упал и покатился", function (k) { k.path(KA_PF.dropRoll); kaPB(k, k.rot, function (x) { return k.R + (KA_PF.dropRoll(x)[0] + 300) / 100 * 57.3; }); }],
  bee: ["Пчела", function (k) { k.path(KA_PF.bee); }],
  ufo: ["НЛО", function (k) { k.path(KA_PF.ufo);
    kaPB(k, k.rot, function (x) { var f = x * 3 - Math.floor(Math.min(2.9999, x * 3)); return k.R + (f < .4 ? 12 * Math.sin(Math.PI * f / .4) : 0); }); }],
  tornado: ["Смерч", function (k) { k.path(KA_PF.tornado); kaPB(k, k.sc, function (x) { return k.S * (.8 + .4 * (Math.cos(x * Math.PI * 8) + 1) / 2); }); }],
  sling: ["Рогатка", function (k) { k.split(); k.path(KA_PF.sling);
    kaPB(k, k.scw, function (x) { return k.SW * (x < .35 ? 1 - .2 * KK_EASE.inOutCubic(x / .35) : 1 + .25 * Math.exp(-6 * (x - .35)) * Math.cos((x - .35) * 12)); }); }],
  scope: ["Наводится на цель", function (k) { k.path(KA_PF.scope); }],
  dvd: ["Как заставка DVD", function (k) { k.path(KA_PF.dvd); }],
  peek: ["Выглянул и спрятался", function (k) { k.path(KA_PF.peek);
    kaPB(k, k.rot, function (x) { return k.R + (x > .3 && x < .75 ? 10 * Math.sin((x - .3) / .45 * Math.PI * 2) : 0); }); }],
  bolt: ["Молнией", function (k) { k.path(KA_PF.bolt); }],
  shootingStar: ["Падающая звезда", function (k) { var fx = kaFx(k, "echo");
    if (fx) { kaSet(kaPrm(fx, ["echo time (seconds)", "echo time", "время эха (секунды)", "время эха (с)", "время эха"], 0), -0.03);
      kaSet(kaPrm(fx, ["number of echoes", "количество эхо", "число эхо", "количество эха", "количество отражений"], 1), 8); kaSet(kaPrm(fx, ["decay", "затухание", "ослабление"], 3), .75); }
    k.path(KA_PF.shootingStar, true); }],
  rocket: ["Ракета на старт", function (k) { k.path(KA_PF.rocket); }],
  fallOff: ["Падает за кадр", function (k) { k.path(KA_PF.fallOff); kaPB(k, k.rot, function (x) { return k.R + (x < .2 ? 0 : 120 * Math.pow((x - .2) / .8, 2)); }); }],
  dashOff: ["Убегает", function (k) { k.split(); k.path(KA_PF.dashOff);
    kaPB(k, k.scw, function (x) { return k.SW * (x < .3 ? 1 - .15 * KK_EASE.inOutCubic(x / .3) : .85 + .6 * Math.min(1, (x - .3) / .3)); }); }],
  windAway: ["Уносит ветром", function (k) { k.path(KA_PF.windAway); kaPB(k, k.rot, function (x) { return k.R + 540 * x * x + 15 * Math.sin(x * Math.PI * 6); }); }]
};

/* ---------- запуск новых механик ---------- */
function kaInK(k, D) { k.e = function (m) { return k.a + Math.min(D * m, k.L); }; return k; }
function kaRun3(tab, id, mode, p1, p2) {
  try {
    var c = kaCtx(); if (c.err) return c.err;
    var msg = "", i;
    for (i = 0; i < c.items.length; i++) {
      var it = c.items[i], sp = kkSpan(it), k, D = Number(p1) || .6;
      if (mode === "loop") k = kaLoopK(kaK(c, it, sp.a, Number(p2) || 1), Number(p1) || 1.5);
      else if (mode === "in") k = kaInK(kaK(c, it, sp.a + Math.min(D * 2.5, sp.len)), D);
      else k = kaK(c, it, sp.a);
      var r = tab[id][1](k);
      if (typeof r === "string") { if (r.indexOf("err") === 0) return r; msg = r; }
    }
    return msg || "ok|«" + tab[id][0] + "»" + (mode === "loop" ? " на весь клип" : " готово");
  } catch (e) { return kaErr(e); }
}
/* порядок карточек: спокойно → динамично → дерзко. Формат «id:уровень:превью» */
var KA_ORDER = {
  "Покадрово": "s12:c:step s8:c:step boil1:c:shake liveRate:c:step redraw:c:step cutout:c:tick clay:c:jelly grain:c:flick marker:c:shake fadeSteps:c:blink focusSteps:c:blur creep:c:step " +
    "s6:d:step handheld:d:shake flicker:d:flick boil2:d:shake walk:d:sway tick:d:tick eyeBlink:d:squash tap:d:drop growSteps:d:zoom poses:d:step hopSteps:d:drop punchSteps:d:pulse " +
    "oldFilm:d:flick ghost:d:flick lag:d:step typewriter:d:wipe eq:d:squash shutter:d:pop vhs:d:glitch trail:d:slide blurBeat:d:blur " +
    "stutter:b:step nervous:b:shake buzz:b:shake smear:b:glitch neon:b:blink strobe:b:blink glitch:b:glitch pixGlitch:b:glitch wrapGlitch:b:glitch invert:b:blink " +
    "lightning:b:flick filmSlip:b:drop impact:b:shake teleport:b:step zoomGlitch:b:pulse melt:b:jelly crumble:b:exit",
  "Циклы": "breathe:c:pulse float:c:float sway:c:sway hover:c:float pulse:c:pulse zeroG:c:float pinSwing:c:swing carousel:c:orbit yaw:c:flip orbit:c:orbit figure8:c:orbit " +
    "spiralLoop:c:orbit jellyfish:c:jelly lookAround:c:sway flag:c:wave " +
    "heartbeat:d:pulse zoomPulse:d:pulse wobble:d:sway jelly:d:jelly pendulum:d:swing metronome:d:swing tilt:d:sway nod:d:drop noNo:d:shake tada:d:pop rubberBand:d:jelly " +
    "hose:d:wave ball:d:squash boing:d:spring tapSpring:d:spring coin:d:flip hop:d:drop skate:d:sway yoyo:d:drop flap:d:flip sparkle:d:pop newton:d:swing " +
    "spin:b:spin spinPause:b:spin roll:b:spin flip:b:flip loader:b:tick dance:b:sway peek:b:drop pingPong:b:slide gust:b:swing laugh:b:shake wiggle:b:shake blink:b:blink shakeLoop:b:shake",
  "Появление": "iosFade:c:fadeUp riseSlow:c:fadeUp blurIn:c:blur curtain:c:wipe cropL:c:wipe cropR:c:wipe cropU:c:wipe cropD:c:wipe unfold:c:pop springPop:c:spring doorOpen:c:flip " +
    "bubble:c:float leafFall:c:fall spider:c:fall " +
    "sticker:d:pop flyL:d:slide flyR:d:slide flyU:d:drop flyD:d:fadeUp swingIn:d:swing flipDown:d:flip rollIn:d:spin bounceIn:d:drop dropSquash:d:squash jump1:d:drop " +
    "stretchIn:d:slide jellyPop:d:jelly inflate:d:pulse rippleIn:d:wave coinIn:d:flip pivotIn:d:swing tumble:d:spin lampOn:d:blink markerIn:d:wipe pixIn:d:step popCascade:d:pop " +
    "magnet:d:slide shy:d:slide " +
    "spiral:b:spin boomerang:b:slide zoomThrough:b:zoom stamp:b:zoom jack:b:spring whipIn:b:slide glitchIn:b:glitch brake:b:slide flashIn:b:flick top:b:spin tvOn:b:squash echoIn:b:slide",
  "Пути": "glide:c:slide diag:c:slide sCurve:c:zig arcL:c:slide arcR:c:slide arcU:c:drop arcD:c:drop circle:c:orbit orbit3d:c:orbit heart:c:orbit star:c:orbit square:c:orbit " +
    "plane:c:slide elevator:c:drop pendulum:c:swing carriage:c:slide intoDistance:c:exit " +
    "wavePath:d:zig zigzag:d:zig meander:d:zig stairs:d:drop bounceAcross:d:drop knight:d:slide slalom:d:zig swoop:d:drop loopDeLoop:d:orbit coil:d:orbit circleIn:d:orbit " +
    "run:d:drop inchworm:d:jelly somersault:d:spin coaster:d:zig raindrop:d:drop gravity:d:orbit speedRamp:d:slide toCamera:d:zoom dropRoll:d:spin " +
    "bee:b:shake ufo:b:float tornado:b:spin sling:b:slide scope:b:shake dvd:b:zig peek:b:drop bolt:b:zig shootingStar:b:exit rocket:b:exit fallOff:b:exit dashOff:b:exit windAway:b:exit"
};

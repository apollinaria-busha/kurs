@echo off
chcp 65001 >nul
rem Установка плагинов КОД КРЕАТОРА для Premiere Pro (Windows)
cd /d "%~dp0"
set "EXT=%APPDATA%\Adobe\CEP\extensions"
if not exist "%EXT%" mkdir "%EXT%"
for %%P in (kk-montazh kk-animacia kk-motion kk-hity) do (
  if exist "%%P" (
    if exist "%EXT%\%%P" rmdir /s /q "%EXT%\%%P"
    xcopy "%%P" "%EXT%\%%P\" /e /i /y /q >nul
  )
)
for %%V in (9 10 11 12 13) do reg add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul
set "FD=%LOCALAPPDATA%\Microsoft\Windows\Fonts"
if not exist "%FD%" mkdir "%FD%"
for %%F in ("fonts\*.ttf") do (
  copy /y "%%F" "%FD%\" >nul
  reg add "HKCU\Software\Microsoft\Windows NT\CurrentVersion\Fonts" /v "%%~nF (TrueType)" /t REG_SZ /d "%FD%\%%~nxF" /f >nul
)
echo.
echo   Готово! Плагины КОД КРЕАТОРА установлены.
echo   Перезапусти Premiere Pro: Окно - Расширения - КК Монтаж, КК Анимация, КК Моушн и КК Adobe Хиты.
echo.
pause

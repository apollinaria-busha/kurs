/* КК · Хиты — рецепты: луки из нескольких эффектов, легендарные эффекты с анимацией, спрятанные переходы Премьера.
   ES3: без let/const/стрелок. Эффекты и параметры ищутся по русскому и английскому имени (+ запасной индекс),
   поэтому рецепты работают в разных версиях и языках Премьера. Подключается из host.jsx. */

/* ---------- эффекты ---------- */
var KH_FX = {
  procamp: ["ProcAmp"],
  noise: ["Шум (предыд.", "Noise (Legacy)", "Шум", "Noise"],
  blur: ["Размытие по Гауссу", "Gaussian Blur"],
  rgb: ["Разделение RGB", "RGB Split"],
  bw: ["Черное и белое", "Чёрное и белое", "Black & White"],
  tint: ["Оттенок", "Tint"],
  poster: ["Постеризация", "Posterize"],
  postTime: ["Время постеризации", "Posterize Time"],
  mosaic: ["Мозаика", "Mosaic"],
  echo: ["Эхо", "Echo"],
  strobe: ["Проблеск. свет", "Проблесковый свет", "Strobe Light"],
  edges: ["Выделение краев", "Выделение краёв", "Find Edges"],
  brush: ["Мазки кистью", "Brush Strokes"],
  turb: ["Вихр. смещение", "Вихревое смещение", "Turbulent Displace"],
  lightning: ["Молния", "Lightning"],
  flare: ["Блики", "Lens Flare"],
  flares: ["Блики объектива", "Lens Flares"],
  rays: ["Объемные лучи", "Объёмные лучи", "Volumetric Rays"],
  edgeGlow: ["Свечение краев", "Свечение краёв", "Edge Glow"],
  echoGlow: ["Эхо-свечение", "Echo Glow"],
  wonder: ["Чудесное свечение", "Wonder Glow"],
  vrGlow: ["Свечение VR", "VR Glow"],
  glitch: ["Цифровой сбой VR", "VR Digital Glitch"],
  vignette: ["Виньетка", "Vignette"],
  crop: ["Обрезать", "Crop"],
  spher: ["Сферизация", "Spherize"],
  bokeh: ["Размытие боке", "Bokeh Blur"],
  bc: ["Brightness & Contrast", "Яркость и контрастность"],
  rough: ["Шероховатые края", "Roughen Edges"],
  chAb: ["Хроматические аберрации VR", "VR Chromatic Aberrations"],
  dirblur: ["Напр. размыт. (пред.", "Направленное размытие", "Directional Blur"],
  invert: ["Обратить", "Invert"], mirror: ["Зеркало", "Mirror"], rep: ["Репликация", "Replicate"], emboss: ["Цветовое тиснение", "Color Emboss"],
  lum: ["Цвет Lumetri", "Lumetri Color"],
  stroke: ["Обводка", "Stroke"], longShadow: ["Длинная тень", "Long Shadow"], roundCrop: ["Закругленное кадрирование", "Rounded Crop"], clone: ["Клонировать", "Clone"],
  focus: ["Размытие фокусировки", "Focus Blur"], magnify: ["Увеличение", "Magnify"], wiggle: ["Покачивание", "Wiggle"], squeeze: ["Сжатие", "Squeeze"], glint: ["Блик", "Glint"], leaks: ["Утечки света", "Light Leaks"]
};
var KH_P = {
  bright: [["Яркость", "Brightness"], 0], contrast: [["Контрастность", "Контраст", "Contrast"], 1], hue: [["Цветовой тон", "Тон", "Hue"], 2], sat: [["Насыщенность", "Saturation"], 3],
  noiseAmt: [["Количество шума", "Amount of Noise", "Величина"], 0], noiseColor: [["Использовать цветной шум", "Тип шума", "Use Color Noise", "Noise Type"], 1],
  blur: [["Размытость", "Размытие", "Blurriness"], 0],
  rgbAmt: [["Горизонтальное разделение", "Horizontal Split", "Величина", "Amount"], 4],
  tBlack: [["Сопоставить черный с", "Сопоставить чёрный с", "Map Black To"], 0], tWhite: [["Сопоставить белый с", "Map White To"], 1], tAmt: [["Величина оттенка", "Amount to Tint"], 2],
  level: [["Уровень", "Level"], 0], fps: [["Частота кадров", "Frame Rate"], 0],
  mosH: [["Горизонтальные блоки", "Horizontal Blocks"], 0], mosV: [["Вертикальные блоки", "Vertical Blocks"], 1],
  echoT: [["Время эха (секунды)", "Echo Time (seconds)"], 0], echoN: [["Количество кадров эха", "Количество эха", "Number Of Echoes"], 1], echoI: [["Начальная интенсивность", "Starting Intensity"], 2], echoD: [["Затухание", "Decay"], 3], echoOp: [["Оператор эха", "Echo Operator"], 4],
  stCol: [["Цвет проблескового света", "Цвет вспышки", "Strobe Color"], 0], stMix: [["Смешивание с оригиналом", "Смешать с оригиналом", "Blend With Original"], 1], stDur: [["Длительность проблескового света (с)", "Длительность вспышки (с)", "Strobe Duration (secs)"], 2], stPer: [["Период проблескового света (с)", "Период вспышки (с)", "Strobe Period (secs)"], 3],
  edInv: [["Обратить", "Invert"], 0], edMix: [["Смешивание с оригиналом", "Смешать с оригиналом", "Blend With Original"], 1],
  brSize: [["Размер кисти", "Brush Size"], 1], brLen: [["Длина мазка", "Stroke Length"], 2], brDen: [["Плотность мазка", "Stroke Density"], 3], brMix: [["Смешать с оригиналом", "Смешивание с оригиналом", "Blend With Original"], 6],
  tuAmt: [["Величина", "Amount"], 1], tuSize: [["Размер", "Size"], 2], tuEvo: [["Эволюция", "Evolution"], 5],
  lnStart: [["Начальная точка", "Start Point"], 0], lnEnd: [["Конечная точка", "End Point"], 1],
  flCenter: [["Центр бликов", "Центр блика", "Flare Center"], 0], flBright: [["Яркость бликов", "Яркость блика", "Flare Brightness"], 1],
  crT: [["Сверху", "Top"], 1], crB: [["Снизу", "Bottom"], 3],
  dirLen: [["Длина размытия", "Blur Length"], 1], dirAng: [["Направление", "Direction"], 0], rep: [["Количество", "Число", "Count"], 0],
  spR: [["Радиус", "Radius"], 0], bcB: [["Яркость", "Brightness"], 0], bcC: [["Контрастность", "Контраст", "Contrast"], 1]
};
function khHex(h) { var n = parseInt(String(h).replace("#", ""), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
function khSet(comp, key, v) {
  if (!comp) return null; var d = KH_P[key], pr = kkParam(comp, d[0], d[1]); if (!pr) return null;
  try { if (typeof v === "string" && v.charAt(0) === "#") { var c = khHex(v); pr.setColorValue(255, c[0], c[1], c[2], true); } else pr.setValue(v, true); } catch (e) {}
  return pr;
}
function khFx(item, key, params) { var c = kkAddEffect(item, KH_FX[key]); if (!c) return null; if (params) for (var k in params) khSet(c, k, params[k]); return c; }
function khBake(comp, key, t0, t1, fps, f) { if (!comp) return; var d = KH_P[key], pr = kkParam(comp, d[0], d[1]); if (pr) try { kkBake(pr, t0, t1, fps, f); } catch (e) {} }
function khRand(seed) { var s = seed; return function () { s = (s * 1664525 + 1013904223) % 4294967296; return s / 4294967296; }; }
// «дыхание» плёнки: микросдвиг кадра и лёгкое покачивание
function khWeave(item, fps, sp, amp, stepFrames) {
  var t = kkTransform(item, false); if (!t) return;
  t.properties[3].setValue(100 + amp * 400, true);
  var R = khRand(7), n = Math.max(2, Math.round(sp.len * fps / (stepFrames || 1)));
  var pos = t.properties[1]; pos.setTimeVarying(true);
  for (var k = 0; k <= n; k++) { var tt = sp.a + sp.len * k / n; pos.addKey(tt); pos.setValueAtKey(tt, [0.5 + (R() - .5) * amp, 0.5 + (R() - .5) * amp * 1.4], k === n); }
  if (stepFrames) { var rot = t.properties[7]; rot.setTimeVarying(true); for (var j = 0; j <= n; j++) { var t2 = sp.a + sp.len * j / n; rot.addKey(t2); rot.setValueAtKey(t2, (R() - .5) * 1.6, j === n); } }
}

/* ---------- луки: рецепты из нескольких эффектов (на выделенные клипы) ---------- */
var KH_LOOKS = {
  vhs: function (it, sp, fps, W, H) {
    khFx(it, "procamp", { sat: 82, contrast: 92, bright: 4 });
    khFx(it, "blur", { blur: 3 });
    var r = khFx(it, "rgb", { rgbAmt: 6 }); var R = khRand(3);
    khBake(r, "rgbAmt", sp.a, sp.b, fps / 3, function () { return R() > .85 ? 18 + R() * 20 : 4 + R() * 4; });
    khFx(it, "noise", { noiseAmt: 14, noiseColor: true });
    khFx(it, "vignette", null);
    return "VHS 1997: кассетный цвет, смаз, RGB-подёргивания и шум. Добавь сверху текстуру «VHS» из «Текстур».";
  },
  film16: function (it, sp, fps) {
    khFx(it, "procamp", { sat: 86, contrast: 108, bright: -2 });
    khFx(it, "noise", { noiseAmt: 9, noiseColor: false });
    khFx(it, "vignette", null);
    khWeave(it, fps, sp, 0.004, 0);
    return "Плёнка 16 мм: зерно, мягкий контраст, виньетка и «дыхание» кадра. Сверху можно положить текстуру «Пыль».";
  },
  digicam: function (it, sp, fps) {
    khFx(it, "procamp", { sat: 122, contrast: 104, bright: 6 });
    khFx(it, "vrGlow", null);
    khFx(it, "noise", { noiseAmt: 5, noiseColor: true });
    return "Мыльница 2000-х: пересвеченный свет, сочные цвета, лёгкий шум матрицы.";
  },
  dream: function (it, sp, fps) {
    khFx(it, "wonder", null);
    khFx(it, "procamp", { sat: 78, bright: 6, contrast: 94 });
    var b = khFx(it, "blur", { blur: 0 });
    khBake(b, "blur", sp.a, Math.min(sp.b, sp.a + 0.6), fps, function (x) { return 40 * (1 - x) * (1 - x); });
    return "Дримкор: мечтательное свечение, мягкий цвет и выход из размытия.";
  },
  pixel: function (it, sp, fps, W, H) {
    var bw = W >= H ? 96 : 54;
    khFx(it, "mosaic", { mosH: bw, mosV: Math.round(bw * H / W) });
    khFx(it, "poster", { level: 7 });
    khFx(it, "postTime", { fps: 12 });
    return "Пиксель-арт 8-бит: крупные пиксели, мало цветов, 12 кадров в секунду.";
  },
  stopmo: function (it, sp, fps) {
    khFx(it, "postTime", { fps: 8 });
    khWeave(it, fps, sp, 0.006, 3);
    return "Стоп-моушн: 8 кадров в секунду и покачивание, как будто снято покадрово.";
  },
  night: function (it, sp, fps) {
    khFx(it, "bw", null);
    khFx(it, "tint", { tBlack: "#020a02", tWhite: "#a6ff8f", tAmt: 100 });
    khFx(it, "noise", { noiseAmt: 22, noiseColor: false });
    khFx(it, "vignette", null);
    return "Ночное видение: зелёный монохром, шум и виньетка.";
  },
  cctv: function (it, sp, fps) {
    khFx(it, "bw", null);
    khFx(it, "procamp", { contrast: 118 });
    khFx(it, "spher", { spR: 900 });
    khFx(it, "noise", { noiseAmt: 12, noiseColor: false });
    khFx(it, "postTime", { fps: 10 });
    return "Камера наблюдения: ч/б, «рыбий глаз», шум и 10 кадров в секунду.";
  },
  comic: function (it, sp, fps) {
    khFx(it, "poster", { level: 5 });
    khFx(it, "edges", { edInv: false, edMix: 55 });
    khFx(it, "procamp", { sat: 130, contrast: 112 });
    return "Комикс: плоские цвета и чернильный контур.";
  },
  paint: function (it, sp, fps) {
    khFx(it, "brush", { brSize: 3, brLen: 9, brDen: 1.2, brMix: 15 });
    khFx(it, "procamp", { sat: 112 });
    return "Масляная живопись: мазки кисти поверх кадра. Тяжёлый эффект — для коротких планов.";
  },
  duotone: function (it, sp, fps) {
    khFx(it, "bw", null);
    khFx(it, "procamp", { contrast: 125 });
    khFx(it, "tint", { tBlack: "#1d1453", tWhite: "#ff8fb3", tAmt: 100 });
    khFx(it, "noise", { noiseAmt: 6, noiseColor: false });
    return "Дуотон-постер: два цвета вместо всех. Цвета меняются в эффекте «Оттенок».";
  },
  neon: function (it, sp, fps) {
    khFx(it, "edgeGlow", null);
    khFx(it, "procamp", { sat: 130, contrast: 110, bright: -6 });
    return "Неоновый контур: светящиеся края по силуэту.";
  },
  acid: function (it, sp, fps) {
    khFx(it, "strobe", { stCol: "#ff2bd6", stMix: 70, stDur: 0.05, stPer: 0.25 });
    var r = khFx(it, "rgb", { rgbAmt: 0 });
    khBake(r, "rgbAmt", sp.a, sp.b, fps, function (x) { var q = (x * sp.len * 4) % 1; return q < .2 ? 30 * (1 - q / .2) : 0; });
    khFx(it, "procamp", { sat: 140 });
    return "Кислотный стробоскоп: цветные вспышки и RGB-удары 4 раза в секунду (подгони период под бит).";
  },
  trails: function (it, sp, fps) {
    khFx(it, "echo", { echoT: -0.033, echoN: 6, echoI: 1, echoD: 0.72, echoOp: 2 });
    return "Эхо-шлейф: за движением тянутся копии — идеально для танца и спорта.";
  },
  flashback: function (it, sp, fps) {
    khFx(it, "bw", null);
    khFx(it, "noise", { noiseAmt: 10, noiseColor: false });
    khFx(it, "vignette", null);
    var b = khFx(it, "bc", { bcB: 0 });
    khBake(b, "bcB", sp.a, Math.min(sp.b, sp.a + 0.4), fps, function (x) { return 100 * Math.pow(1 - x, 3); });
    return "Флэшбэк: белая вспышка на входе, ч/б, зерно и виньетка.";
  },
  cinema: function (it, sp, fps, W, H) {
    if (W >= H) { var bar = (1 - (W / H) / 2.39) / 2 * 100; khFx(it, "crop", { crT: bar, crB: bar }); }
    khFx(it, "procamp", { sat: 92, contrast: 110, bright: -3 });
    khFx(it, "vignette", null);
    return W >= H ? "Кино 2.39:1: широкоэкранные полосы, плотный контраст, виньетка." : "Кино: плотный контраст и виньетка (полосы 2.39 — только для горизонтали).";
  },
  glitchHit: function (it, sp, fps) {
    var g = khFx(it, "glitch", null);
    var r = khFx(it, "rgb", { rgbAmt: 0 }); var R = khRand(11);
    khBake(r, "rgbAmt", sp.a, sp.b, fps, function () { return R() > .8 ? 10 + R() * 40 : 0; });
    return "Глитч-хит: цифровой сбой и рваные RGB-удары по всему клипу.";
  },
  wobble: function (it, sp, fps) {
    var t = khFx(it, "turb", { tuAmt: 14, tuSize: 120 });
    khBake(t, "tuEvo", sp.a, sp.b, fps / 2, function (x) { return x * sp.len * 90; });
    return "Плывущий сон: кадр мягко «дышит» и плывёт, как в жару или во сне.";
  }
};
function kh_look(id) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var fn = KH_LOOKS[id]; if (!fn) return "err|Нет такого лука";
    var sel = kkSel(); if (!sel.length) return "err|Выдели клип на таймлайне";
    var fps = kkFps(seq), W = seq.frameSizeHorizontal, H = seq.frameSizeVertical, msg = "";
    for (var i = 0; i < sel.length; i++) msg = fn(sel[i], kkSpan(sel[i]), fps, W, H);
    return "ok|" + msg + (sel.length > 1 ? " (клипов: " + sel.length + ")" : "");
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- легенды: один эффект, но настроенный и анимированный ---------- */
var KH_LEGENDS = {
  lightning: function (it, sp, fps) { var c = khFx(it, "lightning", { lnStart: [0.15, 0.1], lnEnd: [0.75, 0.9] }); return "Молния: настоящий эффект из старой школы. Точки начала и конца двигай на мониторе."; },
  flare: function (it, sp, fps) { var c = khFx(it, "flare", { flBright: 110 }); khBake(c, "flCenter", sp.a, sp.b, fps / 2, function (x) { return [0.1 + 0.8 * x, 0.25 + 0.1 * Math.sin(x * 3)]; }); return "Блик-пролёт: классический блик объектива проплывает по кадру."; },
  flares: function (it) { khFx(it, "flares", null); return "Блики объектива: современный многослойный блик. Центр — в настройках эффекта."; },
  rays: function (it) { khFx(it, "rays", null); return "Объёмные лучи: свет «пробивает» кадр, как солнце сквозь листья."; },
  edgeGlow: function (it) { khFx(it, "edgeGlow", null); return "Свечение краёв: неоновый ореол по контуру."; },
  echoGlow: function (it) { khFx(it, "echoGlow", null); return "Эхо-свечение: светящиеся копии вокруг объекта — для текста и логотипов."; },
  wonder: function (it) { khFx(it, "wonder", null); return "Чудесное свечение: мягкий дорогой глоу на светах."; },
  rough: function (it) { khFx(it, "rough", null); return "Рваные края: PNG и текст становятся «вырезанными из бумаги»."; },
  bokeh: function (it, sp, fps) { var c = khFx(it, "bokeh", null); return "Боке: кинематографичное размытие фона кругами света."; },
  chroma: function (it) { khFx(it, "chAb", null); return "Хроматические аберрации: цветная кайма, как у винтажного объектива."; },
  stroke: function (it) { khFx(it, "stroke", null); return "Обводка: контур вокруг PNG, текста или вырезанного человека."; },
  longShadow: function (it) { khFx(it, "longShadow", null); return "Длинная тень: плоская тень как в моушн-дизайне — для текста и PNG."; },
  roundCrop: function (it) { khFx(it, "roundCrop", null); return "Скруглённая рамка: кадр-карточка с закруглёнными углами — для «окна» поверх видео."; },
  clone: function (it) { khFx(it, "clone", null); return "Клоны: копии объекта рядом — для эффекта «размножения»."; },
  focus: function (it) { khFx(it, "focus", null); return "Размытие фокусировки: киношная малая глубина резкости."; },
  magnify: function (it) { khFx(it, "magnify", null); return "Лупа: увеличенный круг на детали. Центр и размер — в настройках эффекта."; },
  wiggle: function (it) { khFx(it, "wiggle", null); return "Покачивание: живое дрожание без ключей."; },
  squeeze: function (it) { khFx(it, "squeeze", null); return "Сжатие: объект сплющивается и пружинит."; },
  glint: function (it) { khFx(it, "glint", null); return "Блик: звёздочка-блеск на светах — бьюти и украшения."; },
  leaks: function (it) { khFx(it, "leaks", null); return "Утечки света: тёплые засветы прямо поверх клипа."; }
};
function kh_legend(id) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var fn = KH_LEGENDS[id]; if (!fn) return "err|Нет такого эффекта";
    var sel = kkSel(); if (!sel.length) return "err|Выдели клип на таймлайне";
    var fps = kkFps(seq), msg = "";
    for (var i = 0; i < sel.length; i++) msg = fn(sel[i], kkSpan(sel[i]), fps);
    return "ok|" + msg;
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- спрятанные переходы Премьера ---------- */
function kh_trlist() {
  try { app.enableQE(); var l = qe.project.getVideoTransitionList(), a = []; for (var i = 0; i < l.length; i++) a.push(String(l[i])); return "ok|" + a.join("\u0001"); }
  catch (e) { return "err|" + e.toString(); }
}
function khTc(frames, fps) { var f = Math.round(frames), r = Math.round(fps), s = Math.floor(f / r), ff = f % r; var p = function (n) { return (n < 10 ? "0" : "") + n; }; return "00;00;" + p(s) + ";" + p(ff); }
function kh_tr(name, frames) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var cut = kkCut(seq); if (!cut) return "err|Поставь плейхед точно на стык двух клипов";
    app.enableQE(); var tr = qe.project.getVideoTransitionByName(name); if (!tr) return "err|В этой версии Премьера нет перехода «" + name + "»";
    var qa = kkQeItem(cut.a); if (!qa) return "err|Не нашла клип слева от стыка";
    var fps = kkFps(seq), tc = khTc(Number(frames) || 15, fps), done = false, err = "";
    try { qa.addTransition(tr, false, tc, "00;00;00;00", 0.5, false, true); done = true; } catch (e1) { err = e1.toString(); }
    if (!done) try { qa.addTransition(tr, false, tc); done = true; } catch (e2) { err = e2.toString(); }
    if (!done) return "err|Премьер не поставил переход: " + err;
    return "ok|«" + name + "» на стыке. Длительность меняй, потянув край перехода";
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- звук на плейхед (саунд-дизайн из пака) ---------- */
function kh_sound(path, offset) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var f = new File(path); if (!f.exists) return "err|Звук не скачался";
    var bin = kkBin("КК · Звуки"), it = kkFindByPath(bin, f.fsName);
    if (!it) { app.project.importFiles([f.fsName], true, bin, false); it = kkFindByPath(bin, f.fsName); }
    if (!it) return "err|Не получилось импортировать звук";
    var t0 = Math.max(0, seq.getPlayerPosition().seconds + (Number(offset) || 0)), d = 1;
    try { d = it.getOutPoint().seconds - it.getInPoint().seconds; } catch (e) {}
    var a = -1;
    for (var k = 0; k < seq.audioTracks.numTracks; k++) { var cl = seq.audioTracks[k].clips, busy = false; for (var i = 0; i < cl.numItems; i++) if (cl[i].start.seconds < t0 + d && cl[i].end.seconds > t0) { busy = true; break; } if (!busy) { a = k; break; } }
    if (a < 0) { app.enableQE(); qe.project.getActiveSequence().addTracks(0, 0, 1, 1, seq.audioTracks.numTracks); a = seq.audioTracks.numTracks - 1; }
    seq.audioTracks[a].overwriteClip(it, t0);
    return "ok|Звук на A" + (a + 1);
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- Lumetri: индексы параметров (26.x) + сверка по имени ---------- */
var KH_LUM = { temp: [14, "Температура"], tint: [15, "Оттенок"], sat: [43, "Насыщенность"], exp: [19, "Экспозиция"], con: [20, "Контрастность"], hl: [21, "Подсветка"], sh: [22, "Тени"],
  wh: [23, "Белые"], bl: [24, "Черные"], fade: [40, "Выцветшая пленка"], sharpen: [41, "Увеличить четкость"], vib: [42, "Красочность"], vig: [110, "Степень"] };
function khLum(item, vals) {
  var c = kkAddEffect(item, KH_FX.lum); if (!c) return null;
  for (var k in vals) { var d = KH_LUM[k]; if (!d) continue; var pr = null;
    if (d[0] < c.properties.numItems) { var p0 = c.properties[d[0]]; if (String(p0.displayName) === d[1] || !/[а-я]/i.test(String(p0.displayName))) pr = p0; }
    if (!pr) for (var i = 0; i < c.properties.numItems; i++) if (String(c.properties[i].displayName) === d[1]) { pr = c.properties[i]; break; }
    if (pr) try { pr.setValue(vals[k], true); } catch (e) {} }
  return c;
}
function khTr(item) { return kkTransform(item, true); }
function khBeat(prop, sp, fps, period, f) { // ключи на каждом кадре: f(доля внутри периода 0..1)
  kkBake(prop, sp.a, sp.b, fps, function (x) { var t = x * sp.len, q = (t % period) / period; return f(q, t); });
}
var KH_FN = {
  rgbBeat: function (it, sp, fps) { var r = khFx(it, "rgb", { rgbAmt: 0 }); khBake(r, "rgbAmt", sp.a, sp.b, fps, function (x) { var q = (x * sp.len % 0.5) / 0.5; return q < 0.25 ? 40 * (1 - q / 0.25) : 0; }); },
  invertBeat: function (it, sp, fps) { var c = khFx(it, "invert", null); if (!c) return; var pr = kkParam(c, ["Смешивание с оригиналом", "Смешать с оригиналом", "Blend With Original"], 1); if (pr) khBeat(pr, sp, fps, 0.5, function (q) { return q < 0.12 ? 0 : 100; }); },
  blurIn: function (it, sp, fps) { var b = khFx(it, "blur", { blur: 0 }); khBake(b, "blur", sp.a, Math.min(sp.b, sp.a + 0.8), fps, function (x) { return 60 * Math.pow(1 - x, 3); }); },
  dolly: function (it, sp, fps) { var t = khTr(it); if (t) kkBake(t.properties[3], sp.a, sp.b, Math.min(fps, 10), function (x) { return 100 + 14 * KK_EASE.inOutCubic(x); }); },
  punch: function (it, sp, fps) { var t = khTr(it); if (t) kkBake(t.properties[3], sp.a, Math.min(sp.b, sp.a + 0.25), fps, function (x) { return 135 - 35 * KK_EASE.outCubic(x); }); },
  heartbeat: function (it, sp, fps) { var t = khTr(it); if (t) khBeat(t.properties[3], sp, fps, 0.9, function (q) { var a = Math.exp(-Math.pow((q - 0.05) / 0.05, 2)), b = Math.exp(-Math.pow((q - 0.25) / 0.05, 2)); return 100 + 9 * a + 6 * b; }); },
  spinHit: function (it, sp, fps) { var t = khTr(it); if (!t) return; t.properties[3].setValue(118, true); khBeat(t.properties[7], sp, fps, 0.5, function (q, tt) { var s = Math.floor(tt / 0.5) % 2 ? 1 : -1; return q < 0.3 ? s * 6 * (1 - q / 0.3) : 0; }); },
  wiggleRot: function (it, sp, fps) { var t = khTr(it); if (!t) return; t.properties[3].setValue(112, true); kkBake(t.properties[7], sp.a, sp.b, Math.min(fps, 15), function (x) { return 3 * Math.sin(x * sp.len * Math.PI * 1.2); }); },
  bounceY: function (it, sp, fps) { var t = khTr(it); if (!t) return; t.properties[3].setValue(110, true); khBeat(t.properties[1], sp, fps, 0.5, function (q) { return [0.5, 0.5 - 0.03 * Math.abs(Math.sin(q * Math.PI)) * (1 - q)]; }); },
  infrared: function (it, sp, fps) { khFx(it, "procamp", { hue: 180, sat: 120 }); khLum(it, { tint: 30, con: 15 }); },
  flareSweep: function (it, sp, fps) { var c = khFx(it, "flare", { flBright: 110 }); khBake(c, "flCenter", sp.a, sp.b, fps / 2, function (x) { return [0.1 + 0.8 * x, 0.25 + 0.1 * Math.sin(x * 3)]; }); }
};
function khStep(it, st, sp, fps, W, H) {
  var k = st[0];
  if (k === "lum") return khLum(it, st[1]);
  if (k === "fx") return khFx(it, st[1], st[2]);
  if (k === "weave") return khWeave(it, fps, sp, st[1], st[2]);
  if (k === "pulse") { var t = khTr(it); if (t) khBeat(t.properties[3], sp, fps, st[1], function (q) { return 100 + st[2] * Math.pow(1 - q, 3); }); return; }
  if (k === "shake") { var t2 = khTr(it); if (!t2) return; t2.properties[3].setValue(100 + st[2] * 400, true); var R = khRand(5);
    khBeat(t2.properties[1], sp, fps, st[1], function (q) { var a = st[2] * Math.pow(1 - q, 2); return [0.5 + (R() - .5) * 2 * a, 0.5 + (R() - .5) * 2 * a]; }); return; }
  if (k === "flash") { var b = khFx(it, "bc", { bcB: 0 }); if (b) { var pr = kkParam(b, KH_P.bcB[0], KH_P.bcB[1]); if (pr) khBeat(pr, sp, fps, st[1], function (q) { return st[2] * Math.pow(Math.max(0, 1 - q / 0.3), 2); }); } return; }
  if (k === "hue") { var p = khFx(it, "procamp", { hue: 0 }); khBake(p, "hue", sp.a, sp.b, fps / 2, function (x) { return (x * sp.len * st[1] * 360) % 360; }); return; }
  if (k === "spikes") { var c = khFx(it, st[1], null); var R2 = khRand(9); khBake(c, st[2], sp.a, sp.b, fps, function () { return R2() > 1 - st[4] / fps * 3 ? st[3] * (0.5 + R2() * 0.5) : 0; }); return; }
  if (k === "fn") { if (KH_LOOKS[st[1]]) return KH_LOOKS[st[1]](it, sp, fps, W, H); if (KH_FN[st[1]]) return KH_FN[st[1]](it, sp, fps, W, H); }
}
var KH_DIR = ""; try { KH_DIR = (new File($.fileName)).parent.fsName; } catch (e) {}
function khCatalog() { if (typeof KH_CATALOG === "undefined") { var f = new File((KH_DIR || (KK_DIR + "/jsx")) + "/catalog.js"); if (f.exists) $.evalFile(f); } return typeof KH_CATALOG === "undefined" ? [] : KH_CATALOG; }
function kh_look2(id) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var C = khCatalog(), L = null; for (var i = 0; i < C.length; i++) if (C[i][0] === id) L = C[i];
    if (!L) return "err|Нет такого лука";
    var sel = kkSel(); if (!sel.length) return "err|Выдели клип на таймлайне";
    var fps = kkFps(seq), W = seq.frameSizeHorizontal, H = seq.frameSizeVertical;
    for (var j = 0; j < sel.length; j++) { var sp = kkSpan(sel[j]); for (var k = 0; k < L[5].length; k++) khStep(sel[j], L[5][k], sp, fps, W, H); }
    return "ok|«" + L[1] + "»: " + L[2] + ". Всё подкручивается в «Элементах управления эффектами»" + (sel.length > 1 ? " (клипов: " + sel.length + ")" : "");
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- легенды After Effects: MOGRT на плейхед ---------- */
function kh_aelegend(id, hex) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var fmt = seq.frameSizeHorizontal >= seq.frameSizeVertical ? "h" : "v";
    var mg = new File(KK_DIR + "/mogrt/legend-" + id + "-" + fmt + ".mogrt"); if (!mg.exists) return "err|Нет шаблона " + id;
    var ph = seq.getPlayerPosition().seconds, v = kkFreeTrack(seq, ph, ph + 5);
    var it = seq.importMGT(mg.fsName, String(Math.round(ph * KK_TICKS)), v, 0);
    if (!it) return "err|Премьер не открыл шаблон. Нужен Premiere Pro 2020 или новее";
    if (hex) try { var c = it.getMGTComponent(), p = c.properties.getParamForDisplayName("Цвет акцента"), n = parseInt(String(hex).replace("#", ""), 16); if (p) p.setColorValue(255, (n >> 16) & 255, (n >> 8) & 255, n & 255, true); } catch (e) {}
    return "ok|Легенда на V" + (v + 1) + ". Текст, цвет и размер — в «Основных графических элементах»";
  } catch (e) { return "err|" + e.toString(); }
}

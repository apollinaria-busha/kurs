/* КК · Хиты — рецепты: луки из нескольких эффектов, легендарные эффекты с анимацией, спрятанные переходы Премьера.
   ES3: без let/const/стрелок. Эффекты и параметры ищутся по русскому и английскому имени (+ запасной индекс),
   поэтому рецепты работают в разных версиях и языках Премьера. Подключается из host.jsx. */

/* ---------- эффекты ---------- */
var KH_FX = {
  procamp: ["ProcAmp"],
  noise: ["Шум (предыд.", "Noise (Legacy)", "Шум", "Noise"],
  blur: ["Размытие по Гауссу", "Gaussian Blur"],
  rgb: ["Разделение RGB", "RGB Split"],
  bw: ["Черное и белое", "Чёрное и белое", "Black & White"],
  tint: ["Оттенок", "Tint"],
  poster: ["Постеризация", "Posterize"],
  postTime: ["Время постеризации", "Posterize Time"],
  mosaic: ["Мозаика", "Mosaic"],
  echo: ["Эхо", "Echo"],
  strobe: ["Проблеск. свет", "Проблесковый свет", "Strobe Light"],
  edges: ["Выделение краев", "Выделение краёв", "Find Edges"],
  brush: ["Мазки кистью", "Brush Strokes"],
  turb: ["Вихр. смещение", "Вихревое смещение", "Turbulent Displace"],
  lightning: ["Молния", "Lightning"],
  flare: ["Блики", "Lens Flare"],
  flares: ["Блики объектива", "Lens Flares"],
  rays: ["Объемные лучи", "Объёмные лучи", "Volumetric Rays"],
  edgeGlow: ["Свечение краев", "Свечение краёв", "Edge Glow"],
  echoGlow: ["Эхо-свечение", "Echo Glow"],
  wonder: ["Чудесное свечение", "Wonder Glow"],
  vrGlow: ["Свечение VR", "VR Glow"],
  glitch: ["Цифровой сбой VR", "VR Digital Glitch"],
  vignette: ["Виньетка", "Vignette"],
  crop: ["Обрезать", "Crop"],
  spher: ["Сферизация", "Spherize"],
  bokeh: ["Размытие боке", "Bokeh Blur"],
  bc: ["Brightness & Contrast", "Яркость и контрастность"],
  rough: ["Шероховатые края", "Roughen Edges"],
  chAb: ["Хроматические аберрации VR", "VR Chromatic Aberrations"],
  dirblur: ["Напр. размыт. (пред.", "Направленное размытие", "Directional Blur"],
  invert: ["Обратить", "Invert"], mirror: ["Зеркало", "Mirror"], rep: ["Репликация", "Replicate"], emboss: ["Цветовое тиснение", "Color Emboss"],
  lum: ["Цвет Lumetri", "Lumetri Color"],
  stroke: ["Обводка", "Stroke"], longShadow: ["Длинная тень", "Long Shadow"], roundCrop: ["Закругленное кадрирование", "Rounded Crop"], clone: ["Клонировать", "Clone"],
  focus: ["Размытие фокусировки", "Focus Blur"], magnify: ["Увеличение", "Magnify"], wiggle: ["Покачивание", "Wiggle"], squeeze: ["Сжатие", "Squeeze"], glint: ["Блик", "Glint"], leaks: ["Утечки света", "Light Leaks"]
};
var KH_P = {
  bright: [["Яркость", "Brightness"], 0], contrast: [["Контрастность", "Контраст", "Contrast"], 1], hue: [["Цветовой тон", "Тон", "Hue"], 2], sat: [["Насыщенность", "Saturation"], 3],
  noiseAmt: [["Количество шума", "Amount of Noise", "Величина"], 0], noiseColor: [["Использовать цветной шум", "Тип шума", "Use Color Noise", "Noise Type"], 1],
  blur: [["Размытость", "Размытие", "Blurriness"], 0],
  rgbAmt: [["Горизонтальное разделение", "Horizontal Split", "Величина", "Amount"], 4],
  tBlack: [["Сопоставить черный с", "Сопоставить чёрный с", "Map Black To"], 0], tWhite: [["Сопоставить белый с", "Map White To"], 1], tAmt: [["Величина оттенка", "Яркость оттенка", "Amount to Tint"], 2],
  level: [["Уровень", "Level"], 0], fps: [["Частота кадров", "Frame Rate"], 0],
  mosH: [["Горизонтальные блоки", "Horizontal Blocks"], 0], mosV: [["Вертикальные блоки", "Vertical Blocks"], 1],
  echoT: [["Время эха (секунды)", "Echo Time (seconds)"], 0], echoN: [["Количество кадров эха", "Количество эха", "Number Of Echoes"], 1], echoI: [["Начальная интенсивность", "Starting Intensity"], 2], echoD: [["Затухание", "Decay"], 3], echoOp: [["Оператор эха", "Echo Operator"], 4],
  stCol: [["Цвет проблескового света", "Цвет вспышки", "Strobe Color"], 0], stMix: [["Смешивание с оригиналом", "Смешать с оригиналом", "Blend With Original"], 1], stDur: [["Длительность проблескового света (с)", "Длительность вспышки (с)", "Strobe Duration (secs)"], 2], stPer: [["Период проблескового света (с)", "Период вспышки (с)", "Strobe Period (secs)"], 3],
  edInv: [["Обратить", "Invert"], 0], edMix: [["Смешивание с оригиналом", "Смешать с оригиналом", "Blend With Original"], 1],
  brSize: [["Размер кисти", "Brush Size"], 1], brLen: [["Длина мазка", "Stroke Length"], 2], brDen: [["Плотность мазка", "Stroke Density"], 3], brMix: [["Смешать с оригиналом", "Смешивание с оригиналом", "Blend With Original"], 6],
  tuAmt: [["Величина", "Amount"], 1], tuSize: [["Размер", "Size"], 2], tuEvo: [["Эволюция", "Evolution"], 5],
  lnStart: [["Начальная точка", "Start Point"], 0], lnEnd: [["Конечная точка", "End Point"], 1],
  flCenter: [["Центр бликов", "Центр блика", "Flare Center"], 0], flBright: [["Яркость бликов", "Яркость блика", "Flare Brightness"], 1],
  crT: [["Сверху", "Top"], 1], crB: [["Снизу", "Bottom"], 3],
  dirLen: [["Длина размытия", "Blur Length"], 1], dirAng: [["Направление", "Direction"], 0], rep: [["Количество", "Число", "Count"], 0],
  spR: [["Радиус", "Radius"], 0], bcB: [["Яркость", "Brightness"], 0], bcC: [["Контрастность", "Контраст", "Contrast"], 1]
};
function khHex(h) { var n = parseInt(String(h).replace("#", ""), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
function khSet(comp, key, v) {
  if (!comp) return null; var d = KH_P[key], pr = kkParam(comp, d[0], d[1]); if (!pr) return null;
  try { if (typeof v === "string" && v.charAt(0) === "#") { var c = khHex(v); pr.setColorValue(255, c[0], c[1], c[2], true); } else pr.setValue(v, true); } catch (e) {}
  return pr;
}
function khFx(item, key, params) { var c = kkAddEffect(item, KH_FX[key]); if (!c) return null; if (params) for (var k in params) khSet(c, k, params[k]); return c; }
function khBake(comp, key, t0, t1, fps, f) { if (!comp) return; var d = KH_P[key], pr = kkParam(comp, d[0], d[1]); if (pr) try { kkBake(pr, t0, t1, fps, f); } catch (e) {} }
function khRand(seed) { var s = seed; return function () { s = (s * 1664525 + 1013904223) % 4294967296; return s / 4294967296; }; }
// «дыхание» плёнки: микросдвиг кадра и лёгкое покачивание
function khWeave(item, fps, sp, amp, stepFrames) {
  var t = kkTransform(item, false); if (!t) return;
  t.properties[3].setValue(100 + amp * 400, true);
  var R = khRand(7), n = Math.max(2, Math.round(sp.len * fps / (stepFrames || 1)));
  var pos = t.properties[1]; pos.setTimeVarying(true);
  for (var k = 0; k <= n; k++) { var tt = sp.a + sp.len * k / n; pos.addKey(tt); pos.setValueAtKey(tt, [0.5 + (R() - .5) * amp, 0.5 + (R() - .5) * amp * 1.4], k === n); }
  if (stepFrames) { var rot = t.properties[7]; rot.setTimeVarying(true); for (var j = 0; j <= n; j++) { var t2 = sp.a + sp.len * j / n; rot.addKey(t2); rot.setValueAtKey(t2, (R() - .5) * 1.6, j === n); } }
}

/* ---------- луки: рецепты из нескольких эффектов (на выделенные клипы) ---------- */
var KH_LOOKS = {
  vhs: function (it, sp, fps, W, H) {
    khFx(it, "procamp", { sat: 82, contrast: 92, bright: 4 });
    khFx(it, "blur", { blur: 3 });
    var r = khFx(it, "rgb", { rgbAmt: 6 }); var R = khRand(3);
    khBake(r, "rgbAmt", sp.a, sp.b, fps / 3, function () { return R() > .85 ? 18 + R() * 20 : 4 + R() * 4; });
    khFx(it, "noise", { noiseAmt: 14, noiseColor: true });
    khFx(it, "vignette", null);
    return "VHS 1997: кассетный цвет, смаз, RGB-подёргивания и шум. Добавь сверху текстуру «VHS» из «Текстур».";
  },
  film16: function (it, sp, fps) {
    khFx(it, "procamp", { sat: 86, contrast: 108, bright: -2 });
    khFx(it, "noise", { noiseAmt: 9, noiseColor: false });
    khFx(it, "vignette", null);
    khWeave(it, fps, sp, 0.004, 0);
    return "Плёнка 16 мм: зерно, мягкий контраст, виньетка и «дыхание» кадра. Сверху можно положить текстуру «Пыль».";
  },
  digicam: function (it, sp, fps) {
    khFx(it, "procamp", { sat: 122, contrast: 104, bright: 6 });
    khFx(it, "vrGlow", null);
    khFx(it, "noise", { noiseAmt: 5, noiseColor: true });
    return "Мыльница 2000-х: пересвеченный свет, сочные цвета, лёгкий шум матрицы.";
  },
  dream: function (it, sp, fps) {
    khFx(it, "wonder", null);
    khFx(it, "procamp", { sat: 78, bright: 6, contrast: 94 });
    var b = khFx(it, "blur", { blur: 0 });
    khBake(b, "blur", sp.a, Math.min(sp.b, sp.a + 0.6), fps, function (x) { return 40 * (1 - x) * (1 - x); });
    return "Дримкор: мечтательное свечение, мягкий цвет и выход из размытия.";
  },
  pixel: function (it, sp, fps, W, H) {
    var bw = W >= H ? 96 : 54;
    khFx(it, "mosaic", { mosH: bw, mosV: Math.round(bw * H / W) });
    khFx(it, "poster", { level: 7 });
    khFx(it, "postTime", { fps: 12 });
    return "Пиксель-арт 8-бит: крупные пиксели, мало цветов, 12 кадров в секунду.";
  },
  stopmo: function (it, sp, fps) {
    khFx(it, "postTime", { fps: 8 });
    khWeave(it, fps, sp, 0.006, 3);
    return "Стоп-моушн: 8 кадров в секунду и покачивание, как будто снято покадрово.";
  },
  night: function (it, sp, fps) {
    khFx(it, "bw", null);
    khFx(it, "tint", { tBlack: "#020a02", tWhite: "#a6ff8f", tAmt: 100 });
    khFx(it, "noise", { noiseAmt: 22, noiseColor: false });
    khFx(it, "vignette", null);
    return "Ночное видение: зелёный монохром, шум и виньетка.";
  },
  cctv: function (it, sp, fps) {
    khFx(it, "bw", null);
    khFx(it, "procamp", { contrast: 118 });
    khFx(it, "spher", { spR: 900 });
    khFx(it, "noise", { noiseAmt: 12, noiseColor: false });
    khFx(it, "postTime", { fps: 10 });
    return "Камера наблюдения: ч/б, «рыбий глаз», шум и 10 кадров в секунду.";
  },
  comic: function (it, sp, fps) {
    khFx(it, "poster", { level: 5 });
    khFx(it, "edges", { edInv: false, edMix: 55 });
    khFx(it, "procamp", { sat: 130, contrast: 112 });
    return "Комикс: плоские цвета и чернильный контур.";
  },
  paint: function (it, sp, fps) {
    khFx(it, "brush", { brSize: 3, brLen: 9, brDen: 1.2, brMix: 15 });
    khFx(it, "procamp", { sat: 112 });
    return "Масляная живопись: мазки кисти поверх кадра. Тяжёлый эффект — для коротких планов.";
  },
  duotone: function (it, sp, fps) {
    khFx(it, "bw", null);
    khFx(it, "procamp", { contrast: 125 });
    khFx(it, "tint", { tBlack: "#1d1453", tWhite: "#ff8fb3", tAmt: 100 });
    khFx(it, "noise", { noiseAmt: 6, noiseColor: false });
    return "Дуотон-постер: два цвета вместо всех. Цвета меняются в эффекте «Оттенок».";
  },
  neon: function (it, sp, fps) {
    khFx(it, "edgeGlow", null);
    khFx(it, "procamp", { sat: 130, contrast: 110, bright: -6 });
    return "Неоновый контур: светящиеся края по силуэту.";
  },
  acid: function (it, sp, fps) {
    khFx(it, "strobe", { stCol: "#ff2bd6", stMix: 70, stDur: 0.05, stPer: 0.25 });
    var r = khFx(it, "rgb", { rgbAmt: 0 });
    khBake(r, "rgbAmt", sp.a, sp.b, fps, function (x) { var q = (x * sp.len * 4) % 1; return q < .2 ? 30 * (1 - q / .2) : 0; });
    khFx(it, "procamp", { sat: 140 });
    return "Кислотный стробоскоп: цветные вспышки и RGB-удары 4 раза в секунду (подгони период под бит).";
  },
  trails: function (it, sp, fps) {
    khFx(it, "echo", { echoT: -0.033, echoN: 6, echoI: 1, echoD: 0.72, echoOp: 2 });
    return "Эхо-шлейф: за движением тянутся копии — идеально для танца и спорта.";
  },
  flashback: function (it, sp, fps) {
    khFx(it, "bw", null);
    khFx(it, "noise", { noiseAmt: 10, noiseColor: false });
    khFx(it, "vignette", null);
    var b = khFx(it, "bc", { bcB: 0 });
    khBake(b, "bcB", sp.a, Math.min(sp.b, sp.a + 0.4), fps, function (x) { return 100 * Math.pow(1 - x, 3); });
    return "Флэшбэк: белая вспышка на входе, ч/б, зерно и виньетка.";
  },
  cinema: function (it, sp, fps, W, H) {
    if (W >= H) { var bar = (1 - (W / H) / 2.39) / 2 * 100; khFx(it, "crop", { crT: bar, crB: bar }); }
    khFx(it, "procamp", { sat: 92, contrast: 110, bright: -3 });
    khFx(it, "vignette", null);
    return W >= H ? "Кино 2.39:1: широкоэкранные полосы, плотный контраст, виньетка." : "Кино: плотный контраст и виньетка (полосы 2.39 — только для горизонтали).";
  },
  glitchHit: function (it, sp, fps) {
    var g = khFx(it, "glitch", null);
    var r = khFx(it, "rgb", { rgbAmt: 0 }); var R = khRand(11);
    khBake(r, "rgbAmt", sp.a, sp.b, fps, function () { return R() > .8 ? 10 + R() * 40 : 0; });
    return "Глитч-хит: цифровой сбой и рваные RGB-удары по всему клипу.";
  },
  wobble: function (it, sp, fps) {
    var t = khFx(it, "turb", { tuAmt: 14, tuSize: 120 });
    khBake(t, "tuEvo", sp.a, sp.b, fps / 2, function (x) { return x * sp.len * 90; });
    return "Плывущий сон: кадр мягко «дышит» и плывёт, как в жару или во сне.";
  }
};
function kh_look(id) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var fn = KH_LOOKS[id]; if (!fn) return "err|Нет такого лука";
    var sel = kkSel(); if (!sel.length) return "err|Выдели клип на таймлайне";
    var fps = kkFps(seq), W = seq.frameSizeHorizontal, H = seq.frameSizeVertical, msg = "";
    for (var i = 0; i < sel.length; i++) msg = fn(sel[i], kkSpan(sel[i]), fps, W, H);
    return "ok|" + msg + (sel.length > 1 ? " (клипов: " + sel.length + ")" : "");
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- легенды: один эффект, но настроенный и анимированный ---------- */
var KH_LEGENDS = {
  lightning: function (it, sp, fps) { var c = khFx(it, "lightning", { lnStart: [0.15, 0.1], lnEnd: [0.75, 0.9] }); return "Молния: настоящий эффект из старой школы. Точки начала и конца двигай на мониторе."; },
  flare: function (it, sp, fps) { var c = khFx(it, "flare", { flBright: 110 }); khBake(c, "flCenter", sp.a, sp.b, fps / 2, function (x) { return [0.1 + 0.8 * x, 0.25 + 0.1 * Math.sin(x * 3)]; }); return "Блик-пролёт: классический блик объектива проплывает по кадру."; },
  flares: function (it) { khFx(it, "flares", null); return "Блики объектива: современный многослойный блик. Центр — в настройках эффекта."; },
  rays: function (it) { khFx(it, "rays", null); return "Объёмные лучи: свет «пробивает» кадр, как солнце сквозь листья."; },
  edgeGlow: function (it) { khFx(it, "edgeGlow", null); return "Свечение краёв: неоновый ореол по контуру."; },
  echoGlow: function (it) { khFx(it, "echoGlow", null); return "Эхо-свечение: светящиеся копии вокруг объекта — для текста и логотипов."; },
  wonder: function (it) { khFx(it, "wonder", null); return "Чудесное свечение: мягкий дорогой глоу на светах."; },
  rough: function (it) { khFx(it, "rough", null); return "Рваные края: PNG и текст становятся «вырезанными из бумаги»."; },
  bokeh: function (it, sp, fps) { var c = khFx(it, "bokeh", null); return "Боке: кинематографичное размытие фона кругами света."; },
  chroma: function (it) { khFx(it, "chAb", null); return "Хроматические аберрации: цветная кайма, как у винтажного объектива."; },
  stroke: function (it) { khFx(it, "stroke", null); return "Обводка: контур вокруг PNG, текста или вырезанного человека."; },
  longShadow: function (it) { khFx(it, "longShadow", null); return "Длинная тень: плоская тень как в моушн-дизайне — для текста и PNG."; },
  roundCrop: function (it) { khFx(it, "roundCrop", null); return "Скруглённая рамка: кадр-карточка с закруглёнными углами — для «окна» поверх видео."; },
  clone: function (it) { khFx(it, "clone", null); return "Клоны: копии объекта рядом — для эффекта «размножения»."; },
  focus: function (it) { khFx(it, "focus", null); return "Размытие фокусировки: киношная малая глубина резкости."; },
  magnify: function (it) { khFx(it, "magnify", null); return "Лупа: увеличенный круг на детали. Центр и размер — в настройках эффекта."; },
  wiggle: function (it) { khFx(it, "wiggle", null); return "Покачивание: живое дрожание без ключей."; },
  squeeze: function (it) { khFx(it, "squeeze", null); return "Сжатие: объект сплющивается и пружинит."; },
  glint: function (it) { khFx(it, "glint", null); return "Блик: звёздочка-блеск на светах — бьюти и украшения."; },
  leaks: function (it) { khFx(it, "leaks", null); return "Утечки света: тёплые засветы прямо поверх клипа."; }
};
/* ---------- легенды v2: ещё 30 спрятанных эффектов (все встроены в Премьер, без плагинов) ----------
   Имена эффектов и параметров сверены со словарями Премьера 26.x (ru_RU / en_US).
   Выпадающие меню: значение 7 выбрано нарочно — это «Экран»/«Наложение» при счёте с 1 и «Наложение»/«Мягкий свет» при счёте с 0,
   так что результат красивый при любой нумерации. */
(function () {
  var fx = {
    unsharp: ["Нерезкая маска", "Контур. резкость", "Контурная резкость", "Unsharp Mask"],
    timecode: ["Тайм-код", "Таймкод", "Timecode"],
    grad4: ["4-цвет. градиент", "4-цветный градиент", "Четырехцветный градиент", "4-Color Gradient"],
    leave: ["Фильтр цвета", "Color Pass", "Оставить цвет", "Сохранение цвета", "Leave Color"], // в 26.5 RU нет «Оставить цвет» — есть «Фильтр цвета» (PR.ADBE Color Pass)
    toColor: ["Замена цвета", "Color Replace", "Заменить на цвет", "Change to Color"], // «Замена цвета» есть в 26.5 RU
    light: ["Эффекты освещения", "Lighting Effects"],
    corner: ["Привязка по углам", "Прив. по углам", "Corner Pin"],
    b3d: ["Базовый 3D", "Basic 3D"],
    waveW: ["Волнообр. деформ-ия", "Волнообразная деформация", "Эффект волны", "Wave Warp"],
    lensD: ["Искажение линзы", "Lens Distortion"],
    offset: ["Смещение", "Сдвиг", "Offset"],
    shadow: ["Тень", "Drop Shadow"],
    linWipe: ["Линейн. вытес. (пред.", "Линейное вытеснение (предыдущая версия)", "Линейное вытеснение", "Linear Wipe (Legacy)", "Linear Wipe"],
    blocks: ["Раствор. блоков", "Растворение блоков", "Block Dissolve"]
  };
  var pr = {
    umAmt: [["Величина", "Количество", "Amount"], 0], umRad: [["Радиус", "Radius"], 1], umThr: [["Пороговое значение", "Порог", "Threshold"], 2],
    tcPos: [["Положение", "Position"], 0], tcSize: [["Размер", "Size"], 1], tcOp: [["Непрозрачность", "Opacity"], 2],
    g4p1: [["Точка 1", "Point 1"], null], g4p2: [["Точка 2", "Point 2"], null], g4p3: [["Точка 3", "Point 3"], null], g4p4: [["Точка 4", "Point 4"], null],
    g4c1: [["Цвет 1", "Color 1"], null], g4c2: [["Цвет 2", "Color 2"], null], g4c3: [["Цвет 3", "Color 3"], null], g4c4: [["Цвет 4", "Color 4"], null],
    g4op: [["Непрозрачность", "Opacity"], null], g4mode: [["Режим смешивания", "Blending Mode"], null],
    lcAmt: [["Количество для обесцвечивания", "Amount to Decolor"], 0], lcCol: [["Цвет для сохранения", "Color To Leave"], 1], lcTol: [["Допуск", "Tolerance"], 2], lcSoft: [["Мягкость краев", "Мягкость краёв", "Edge Softness"], 3],
    ctFrom: [["С", "From"], 0], ctTo: [["На", "To"], 1],
    cpSim: [["Схожесть", "Similarity"], 0], cpRev: [["Инверсия", "Reverse"], 1], cpCol: [["Цвет", "Color"], 2],
    crSim: [["Схожесть", "Similarity"], null], crFrom: [["Исходный цвет", "Target Color"], null], crTo: [["Цвет для замены", "Replace Color"], null],
    liType: [["Тип освещения", "Light Type"], null], liColor: [["Цвет освещения", "Light Color"], null], liCenter: [["По центру", "Центр", "Center"], null],
    cpUL: [["Верхний левый", "Upper Left"], 0], cpUR: [["Верхний правый", "Upper Right"], 1], cpLL: [["Нижний левый", "Lower Left"], 2], cpLR: [["Нижний правый", "Lower Right"], 3],
    b3Sw: [["Поворот", "Swivel"], 0], b3Tilt: [["Наклон", "Tilt"], 1], b3Dist: [["Расстояние до изображения", "Distance to Image"], 2],
    b3Spec: [["Показать зеркальную подсветку", "Зеркальная подсветка", "Show Specular Highlight", "Specular Highlight"], 3],
    miCen: [["Центр отражения", "Reflection Center"], 0], miAng: [["Угол отражения", "Reflection Angle"], 1],
    emDir: [["Направление", "Direction"], 0], emRel: [["Рельеф", "Relief"], 1], emCon: [["Контрастность", "Контраст", "Contrast"], 2], emMix: [["Смешать с оригиналом", "Смешивание с оригиналом", "Blend With Original"], 3],
    wwH: [["Высота волны", "Wave Height"], 1], wwW: [["Ширина волны", "Wave Width"], 2], wwDir: [["Направление", "Direction"], 3], wwSp: [["Скорость волны", "Wave Speed"], 4],
    ldCurv: [["Кривизна", "Curvature"], 0], ofShift: [["Сместить центр в", "Shift Center To"], 0], spCen: [["Центр сферы", "Center of Sphere"], 1],
    echoDecay: [["Угасание", "Затухание", "Decay"], 3],
    shCol: [["Цвет тени", "Shadow Color"], 0], shOp: [["Непрозрачность", "Opacity"], 1], shDir: [["Направление", "Direction"], 2], shDist: [["Расстояние", "Distance"], 3], shSoft: [["Мягкость", "Softness"], 4],
    lwDone: [["Завершение перехода", "Transition Completion"], 0], lwAng: [["Угол вытеснения", "Wipe Angle"], 1], lwF: [["Растушевка", "Feather"], 2],
    bdDone: [["Завершение перехода", "Transition Completion"], 0], bdW: [["Ширина блока", "Block Width"], 1], bdH: [["Высота блока", "Block Height"], 2], bdF: [["Растушевка", "Feather"], 3],
    sbCol: [["Цвет проблеска", "Цвет проблескового света", "Strobe Color"], 0], sbMix: [["Смешать с оригиналом", "Смешивание с оригиналом", "Blend With Original"], 1],
    sbDur: [["Длительность проблеска (с)", "Длительность проблескового света (с)", "Strobe Duration (secs)"], 2], sbPer: [["Период проблеска (с)", "Период проблескового света (с)", "Strobe Period (secs)"], 3]
  };
  var k;
  for (k in fx) if (!KH_FX[k]) KH_FX[k] = fx[k];
  for (k in pr) if (!KH_P[k]) KH_P[k] = pr[k];
})();
function khNo(name) { return "err|В этой версии Премьера нет эффекта «" + name + "»"; }
/* размер исходника в пикселях (4K-клип в 1080-секвенции), чтобы пиксельные параметры смотрелись одинаково */
function khPx(it, W, H) { var s = kkSrcSize(it) || [W, H]; return { w: s[0], h: s[1], u: Math.min(s[0], s[1]) / 1080 }; }
function khBeatP(comp, key, sp, fps, period, f) { if (!comp) return; var d = KH_P[key], p = kkParam(comp, d[0], d[1]); if (p) try { khBeat(p, sp, fps, period, f); } catch (e) {} }
var KH_LEGENDS2 = {
  sharpCrisp: function (it, sp, fps, W, H) {
    if (!khFx(it, "unsharp", { umAmt: 90, umRad: 2, umThr: 2 })) return khNo("Нерезкая маска");
    return "Хрустящая резкость: «Нерезкая маска» вытягивает детали — кожа, ткань, еда. Сила — «Величина».";
  },
  timecode: function (it, sp, fps, W, H) {
    if (!khFx(it, "timecode", { tcPos: [W >= H ? 0.82 : 0.7, 0.9], tcSize: 6, tcOp: 0 })) return khNo("Тайм-код");
    return "Таймкод камеры: бегущие цифры, как на кассетной видеокамере. Положение и размер — в «Элементах управления эффектами».";
  },
  pixelIn: function (it, sp, fps, W, H) {
    var px = khPx(it, W, H), b = Math.max(8, Math.round(40 * px.u)), c = khFx(it, "blocks", { bdW: b, bdH: b, bdF: 0 }); if (!c) return khNo("Растворение блоков");
    khBake(c, "bdDone", sp.a, sp.a + Math.min(0.8, sp.len / 2), fps, function (x) { return 100 * (1 - KK_EASE.outCubic(x)); });
    return "Пиксельное появление: кадр собирается из случайных блоков. Размер блоков — «Ширина/Высота блока».";
  },
  pearl: function (it, sp, fps, W, H) {
    var c = khFx(it, "grad4", { g4c1: "#FFAD05", g4c2: "#FF2E88", g4c3: "#8A5CFF", g4c4: "#00E5FF", g4p2: [0.85, 0.15], g4p4: [0.85, 0.85], g4op: 45, g4mode: 7 });
    if (!c) return khNo("4-цветный градиент");
    khBake(c, "g4p1", sp.a, sp.b, fps / 4, function (x) { var a = x * sp.len * 0.9; return [0.2 + 0.12 * Math.cos(a), 0.2 + 0.12 * Math.sin(a)]; });
    khBake(c, "g4p3", sp.a, sp.b, fps / 4, function (x) { var a = x * sp.len * 0.7 + 2; return [0.25 + 0.15 * Math.cos(a), 0.8 + 0.1 * Math.sin(a)]; });
    return "Перламутр: четыре цвета медленно переливаются поверх кадра. Цвета и прозрачность — в настройках эффекта.";
  },
  watercolor: function (it, sp, fps, W, H) {
    if (!khFx(it, "brush", { brSize: 3, brLen: 10, brDen: 1.2, brMix: 0 })) return khNo("Мазки кистью");
    khFx(it, "procamp", { sat: 118, bright: 4 });
    return "Акварель: мелкие детали превращаются в мягкие мазки кисти. Крупность — «Размер кисти» и «Длина мазка».";
  },
  softShadow: function (it, sp, fps, W, H) {
    var px = khPx(it, W, H);
    if (!khFx(it, "shadow", { shCol: "#000000", shOp: 70, shDir: 160, shDist: Math.round(28 * px.u), shSoft: Math.round(60 * px.u) })) return khNo("Тень");
    return "Парящая тень: мягкая тень снизу — PNG, текст и вырезанный человек «парят» над кадром.";
  },
  leaveColor: function (it) {
    var c = kkAddEffect(it, KH_FX.leave); if (!c) return khNo("Фильтр цвета");
    if (/Color Pass/i.test(String(c.matchName))) { khSet(c, "cpSim", 25); khSet(c, "cpRev", false); khSet(c, "cpCol", "#D62828");
      return "Один цвет: всё ч/б, кроме красного («Фильтр цвета»). Другой цвет — пипеткой в «Цвет», ширина — «Схожесть»."; }
    khSet(c, "lcAmt", 100); khSet(c, "lcCol", "#D62828"); khSet(c, "lcTol", 25); khSet(c, "lcSoft", 12);
    return "Один цвет: всё ч/б, кроме красного. Другой цвет — пипеткой в «Цвет для сохранения».";
  },
  recolor: function (it) {
    var c = kkAddEffect(it, KH_FX.toColor); if (!c) return khNo("Замена цвета");
    if (/Color Replace/i.test(String(c.matchName))) { khSet(c, "crSim", 20); khSet(c, "crFrom", "#D62828"); khSet(c, "crTo", "#FFAD05");
      return "Перекрасить цвет: красное в кадре становится фирменным жёлтым («Замена цвета»). Цвета — пипеткой в «Исходный цвет» и «Цвет для замены»."; }
    khSet(c, "ctFrom", "#D62828"); khSet(c, "ctTo", "#FFAD05");
    return "Перекрасить цвет: красное в кадре становится фирменным жёлтым. Цвета «С» и «На» меняются пипеткой.";
  },
  spotlight: function (it, sp, fps) {
    var c = khFx(it, "light", { liType: 3, liColor: "#FFE6B0" }); if (!c) return khNo("Эффекты освещения");
    khBake(c, "liCenter", sp.a, sp.b, fps / 3, function (x) { var t = x * sp.len; return [0.5 + 0.28 * Math.sin(t * 0.8), 0.45 + 0.08 * Math.cos(t * 0.6)]; });
    return "Луч прожектора: пятно света плавно гуляет по кадру. Цвет и размер луча — в «Источник освещения 1».";
  },
  duoBrand: function (it) {
    if (!khFx(it, "tint", { tBlack: "#16130C", tWhite: "#FFAD05", tAmt: 100 })) return khNo("Оттенок");
    khFx(it, "bc", { bcC: 15 });
    return "Фирменный дуотон: кадр в чёрном и жёлтом КК. Цвета — «Привязать черный/белый к».";
  },
  softWipe: function (it, sp, fps, W, H) {
    var px = khPx(it, W, H), c = khFx(it, "linWipe", { lwAng: 135, lwF: Math.round(260 * px.u) }); if (!c) return khNo("Линейное вытеснение");
    khBake(c, "lwDone", sp.a, sp.a + Math.min(0.9, sp.len / 2), fps, function (x) { return 100 * (1 - KK_EASE.outCubic(x)); });
    return "Мягкая шторка: кадр проявляется по диагонали с мягким краем. Угол — «Угол вытеснения».";
  },
  perspective: function (it, sp, fps) {
    var c = khFx(it, "corner", null); if (!c) return khNo("Привязка по углам");
    var s = function (x) { return Math.sin(x * sp.len * 1.1); };
    khBake(c, "cpUL", sp.a, sp.b, fps / 3, function (x) { return [0.12 + 0.02 * s(x), 0.07]; });
    khBake(c, "cpUR", sp.a, sp.b, fps / 3, function (x) { return [0.9, 0.13 - 0.02 * s(x)]; });
    khBake(c, "cpLL", sp.a, sp.b, fps / 3, function (x) { return [0.08, 0.93]; });
    khBake(c, "cpLR", sp.a, sp.b, fps / 3, function (x) { return [0.94 - 0.02 * s(x), 0.86 + 0.01 * s(x)]; });
    return "Экран в пространстве: кадр наклонён и мягко покачивается. Углы двигай прямо на мониторе.";
  },
  card3d: function (it, sp, fps) {
    var c = khFx(it, "b3d", { b3Dist: 18, b3Spec: true }); if (!c) return khNo("Базовый 3D");
    khBake(c, "b3Sw", sp.a, sp.b, fps / 2, function (x) { return 22 * Math.sin(x * sp.len * Math.PI / 2); });
    khBake(c, "b3Tilt", sp.a, sp.b, fps / 2, function (x) { return 6 * Math.cos(x * sp.len * Math.PI / 3); });
    return "3D-карточка: кадр поворачивается в пространстве, по нему пробегает блик.";
  },
  mirrorWorld: function (it) {
    if (!khFx(it, "mirror", { miCen: [0.5, 0.5], miAng: 0 })) return khNo("Зеркало");
    return "Зеркальная симметрия: половина кадра отражается — лица, здания и природа становятся «инопланетными».";
  },
  relief: function (it, sp, fps, W, H) {
    var px = khPx(it, W, H);
    if (!khFx(it, "emboss", { emDir: 135, emRel: Math.max(2, Math.round(4 * px.u)), emCon: 180, emMix: 0 })) return khNo("Цветовое тиснение");
    khFx(it, "bw", null);
    return "Барельеф: кадр словно выбит на металле («Цветовое тиснение» + ч/б). Цвет вернётся, если выключить «Черное и белое».";
  },
  sketch: function (it) {
    if (!khFx(it, "edges", { edInv: false, edMix: 0 })) return khNo("Выделение краев");
    khFx(it, "bw", null); khFx(it, "bc", { bcC: 25 });
    return "Карандашный скетч: остаются только контуры, как рисунок простым карандашом.";
  },
  poster: function (it) {
    if (!khFx(it, "poster", { level: 4 })) return khNo("Постеризация");
    khFx(it, "procamp", { sat: 135, contrast: 112 });
    return "Шелкография: всего четыре оттенка на канал — кадр как напечатанный постер.";
  },
  xerox: function (it) {
    if (!khLum(it, { sat: 0, con: 100, wh: 70, bl: -70, sharpen: 80 })) return khNo("Цвет Lumetri");
    khFx(it, "noise", { noiseAmt: 8, noiseColor: false });
    return "Ксерокс: жёсткое ч/б почти без полутонов и зерно тонера. Сила — «Контрастность» в Lumetri.";
  },
  xray: function (it) {
    if (!khFx(it, "invert", null)) return khNo("Обратить");
    khFx(it, "bw", null); khFx(it, "tint", { tBlack: "#020812", tWhite: "#9FD8FF", tAmt: 100 });
    return "Рентген: негатив в холодном синем, как снимок на просвет.";
  },
  swapColors: function (it) {
    if (!khFx(it, "procamp", { hue: 180, sat: 120 })) return khNo("ProcAmp");
    return "Цвета наоборот: все оттенки разворачиваются на 180° — кожа холодная, небо оранжевое. Угол — «Цветовой тон».";
  },
  mirage: function (it, sp, fps, W, H) {
    var px = khPx(it, W, H);
    if (!khFx(it, "waveW", { wwH: Math.max(2, Math.round(4 * px.u)), wwW: Math.round(70 * px.u), wwDir: 0, wwSp: 1.2 })) return khNo("Волнообразная деформация");
    return "Мираж: кадр дрожит, как воздух над асфальтом в жару.";
  },
  vrGlitch: function (it) {
    if (!khFx(it, "glitch", null)) return khNo("Цифровой сбой VR");
    return "Цифровой сбой: срывы, полосы и цветные блоки, как у сломанного стрима. Сила — в настройках «Цифрового сбоя VR».";
  },
  timeClones: function (it) {
    if (!khFx(it, "echo", { echoT: -0.25, echoN: 3, echoI: 0.55, echoDecay: 0.65 })) return khNo("Эхо");
    return "Эхо-призраки: полупрозрачные копии отстают на четверть секунды — для танцев и проходок.";
  },
  lensWarp: function (it, sp, fps) {
    var c = khFx(it, "lensD", null); if (!c) return khNo("Искажение линзы");
    khBake(c, "ldCurv", sp.a, sp.b, fps / 2, function (x) { return 45 * Math.sin(x * sp.len * Math.PI * 2 / 1.6); });
    return "Комната смеха: кадр выгибается то наружу, то внутрь, как кривое зеркало.";
  },
  speedSmear: function (it, sp, fps, W, H) {
    var px = khPx(it, W, H), c = khFx(it, "dirblur", { dirAng: 90, dirLen: 0 }); if (!c) return khNo("Направленное размытие");
    khBeatP(c, "dirLen", sp, fps, 0.5, function (q) { return q < 0.3 ? 80 * px.u * Math.pow(1 - q / 0.3, 2) : 0; });
    return "Смаз в бит: кадр дёргается смазом скорости дважды в секунду (120 BPM).";
  },
  scroll: function (it, sp, fps) {
    var c = khFx(it, "offset", null); if (!c) return khNo("Смещение");
    khBake(c, "ofShift", sp.a, sp.b, fps, function (x) { return [(0.5 + x * sp.len * 0.45) % 1, 0.5]; });
    return "Бесконечная лента: кадр без шва прокручивается по кругу. Скорость — по ключам «Сместить центр в».";
  },
  zoomPunch: function (it, sp, fps) {
    var t = kkTransform(it, true); if (!t) return khNo("Преобразовать");
    kkBake(t.properties[3], sp.a, sp.a + Math.min(0.35, sp.len / 2), fps, function (x) { return 160 - 60 * KK_EASE.outExpo(x); });
    return "Зум-удар: влёт в кадр с настоящим смазом движения — трюк через «Преобразовать» и угол затвора 360°.";
  },
  strobe: function (it) {
    if (!khFx(it, "strobe", { sbCol: "#FFFFFF", sbMix: 0, sbDur: 0.04, sbPer: 0.5 })) return khNo("Проблесковый свет");
    return "Стробоскоп: белые вспышки дважды в секунду (120 BPM). Частота — «Период проблеска».";
  },
  fisheye: function (it, sp, fps, W, H) {
    var px = khPx(it, W, H);
    if (!khFx(it, "spher", { spR: Math.ceil(Math.sqrt(px.w * px.w + px.h * px.h) / 2) + 2, spCen: [0.5, 0.5] })) return khNo("Сферизация");
    return "Скейт-фишай: выпуклый кадр, как в скейт-видео 2000-х. Снимай ближе — эффект сильнее.";
  },
  melt: function (it, sp, fps, W, H) {
    var px = khPx(it, W, H), c = khFx(it, "turb", { tuAmt: 70, tuSize: Math.max(20, Math.round(120 * px.u)) }); if (!c) return khNo("Вихревое смещение");
    khBake(c, "tuEvo", sp.a, sp.b, fps / 2, function (x) { return x * sp.len * 120; });
    return "Жидкий кадр: картинка плавится и течёт. Сила — «Величина», скорость — ключи «Эволюции».";
  }
};
(function () { for (var k in KH_LEGENDS2) if (!KH_LEGENDS[k]) KH_LEGENDS[k] = KH_LEGENDS2[k]; })();
function kh_legend(id) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var fn = KH_LEGENDS[id]; if (!fn) return "err|Нет такого эффекта";
    var sel = kkSel(); if (!sel.length) return "err|Выдели клип на таймлайне";
    var fps = kkFps(seq), W = seq.frameSizeHorizontal, H = seq.frameSizeVertical, msg = "";
    for (var i = 0; i < sel.length; i++) { msg = fn(sel[i], kkSpan(sel[i]), fps, W, H); if (/^err\|/.test(String(msg))) return msg; }
    return "ok|" + msg;
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- спрятанные переходы Премьера ---------- */
function kh_trlist() {
  try { app.enableQE(); var l = qe.project.getVideoTransitionList(), a = []; for (var i = 0; i < l.length; i++) a.push(String(l[i])); return "ok|" + a.join("\u0001"); }
  catch (e) { return "err|" + e.toString(); }
}
function khTc(frames, fps) { var f = Math.round(frames), r = Math.round(fps), s = Math.floor(f / r), ff = f % r; var p = function (n) { return (n < 10 ? "0" : "") + n; }; return "00;00;" + p(s) + ";" + p(ff); }
function kh_tr(name, frames) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var cut = kkCut(seq); if (!cut) return "err|Поставь плейхед точно на стык двух клипов";
    app.enableQE(); var tr = qe.project.getVideoTransitionByName(name); if (!tr) return "err|В этой версии Премьера нет перехода «" + name + "»";
    var qa = kkQeItem(cut.a); if (!qa) return "err|Не нашла клип слева от стыка";
    var fps = kkFps(seq), tc = khTc(Number(frames) || 15, fps), done = false, err = "";
    try { qa.addTransition(tr, false, tc, "00;00;00;00", 0.5, false, true); done = true; } catch (e1) { err = e1.toString(); }
    if (!done) try { qa.addTransition(tr, false, tc); done = true; } catch (e2) { err = e2.toString(); }
    if (!done) return "err|Премьер не поставил переход: " + err;
    return "ok|«" + name + "» на стыке. Длительность меняй, потянув край перехода";
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- звук на плейхед (саунд-дизайн из пака) ---------- */
function kh_sound(path, offset) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var f = new File(path); if (!f.exists) return "err|Звук не скачался";
    var bin = kkBin("КК · Звуки"), it = kkFindByPath(bin, f.fsName);
    if (!it) { app.project.importFiles([f.fsName], true, bin, false); it = kkFindByPath(bin, f.fsName); }
    if (!it) return "err|Не получилось импортировать звук";
    var t0 = Math.max(0, seq.getPlayerPosition().seconds + (Number(offset) || 0)), d = 1;
    try { d = it.getOutPoint().seconds - it.getInPoint().seconds; } catch (e) {}
    var a = -1;
    for (var k = 0; k < seq.audioTracks.numTracks; k++) { var cl = seq.audioTracks[k].clips, busy = false; for (var i = 0; i < cl.numItems; i++) if (cl[i].start.seconds < t0 + d && cl[i].end.seconds > t0) { busy = true; break; } if (!busy) { a = k; break; } }
    if (a < 0) { app.enableQE(); qe.project.getActiveSequence().addTracks(0, 0, 1, 1, seq.audioTracks.numTracks); a = seq.audioTracks.numTracks - 1; }
    seq.audioTracks[a].overwriteClip(it, t0);
    return "ok|Звук на A" + (a + 1);
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- Lumetri: индексы параметров (26.x) + сверка по имени ---------- */
var KH_LUM = { temp: [14, "Температура"], tint: [15, "Оттенок"], sat: [43, "Насыщенность"], exp: [19, "Экспозиция"], con: [20, "Контрастность"], hl: [21, "Подсветка"], sh: [22, "Тени"],
  wh: [23, "Белые"], bl: [24, "Черные"], fade: [40, "Выцветшая пленка"], sharpen: [41, "Увеличить четкость"], vib: [42, "Красочность"], vig: [110, "Степень"] };
function khLum(item, vals) {
  var c = kkAddEffect(item, KH_FX.lum); if (!c) return null;
  for (var k in vals) { var d = KH_LUM[k]; if (!d) continue; var pr = null;
    if (d[0] < c.properties.numItems) { var p0 = c.properties[d[0]]; if (String(p0.displayName) === d[1] || !/[а-я]/i.test(String(p0.displayName))) pr = p0; }
    if (!pr) for (var i = 0; i < c.properties.numItems; i++) if (String(c.properties[i].displayName) === d[1]) { pr = c.properties[i]; break; }
    if (pr) try { pr.setValue(vals[k], true); } catch (e) {} }
  return c;
}
function khTr(item) { return kkTransform(item, true); }
function khBeat(prop, sp, fps, period, f) { // ключи на каждом кадре: f(доля внутри периода 0..1)
  kkBake(prop, sp.a, sp.b, fps, function (x) { var t = x * sp.len, q = (t % period) / period; return f(q, t); });
}
var KH_FN = {
  rgbBeat: function (it, sp, fps) { var r = khFx(it, "rgb", { rgbAmt: 0 }); khBake(r, "rgbAmt", sp.a, sp.b, fps, function (x) { var q = (x * sp.len % 0.5) / 0.5; return q < 0.25 ? 40 * (1 - q / 0.25) : 0; }); },
  invertBeat: function (it, sp, fps) { var c = khFx(it, "invert", null); if (!c) return; var pr = kkParam(c, ["Смешивание с оригиналом", "Смешать с оригиналом", "Blend With Original"], 1); if (pr) khBeat(pr, sp, fps, 0.5, function (q) { return q < 0.12 ? 0 : 100; }); },
  blurIn: function (it, sp, fps) { var b = khFx(it, "blur", { blur: 0 }); khBake(b, "blur", sp.a, Math.min(sp.b, sp.a + 0.8), fps, function (x) { return 60 * Math.pow(1 - x, 3); }); },
  dolly: function (it, sp, fps) { var t = khTr(it); if (t) kkBake(t.properties[3], sp.a, sp.b, Math.min(fps, 10), function (x) { return 100 + 14 * KK_EASE.inOutCubic(x); }); },
  punch: function (it, sp, fps) { var t = khTr(it); if (t) kkBake(t.properties[3], sp.a, Math.min(sp.b, sp.a + 0.25), fps, function (x) { return 135 - 35 * KK_EASE.outCubic(x); }); },
  heartbeat: function (it, sp, fps) { var t = khTr(it); if (t) khBeat(t.properties[3], sp, fps, 0.9, function (q) { var a = Math.exp(-Math.pow((q - 0.05) / 0.05, 2)), b = Math.exp(-Math.pow((q - 0.25) / 0.05, 2)); return 100 + 9 * a + 6 * b; }); },
  spinHit: function (it, sp, fps) { var t = khTr(it); if (!t) return; t.properties[3].setValue(118, true); khBeat(t.properties[7], sp, fps, 0.5, function (q, tt) { var s = Math.floor(tt / 0.5) % 2 ? 1 : -1; return q < 0.3 ? s * 6 * (1 - q / 0.3) : 0; }); },
  wiggleRot: function (it, sp, fps) { var t = khTr(it); if (!t) return; t.properties[3].setValue(112, true); kkBake(t.properties[7], sp.a, sp.b, Math.min(fps, 15), function (x) { return 3 * Math.sin(x * sp.len * Math.PI * 1.2); }); },
  bounceY: function (it, sp, fps) { var t = khTr(it); if (!t) return; t.properties[3].setValue(110, true); khBeat(t.properties[1], sp, fps, 0.5, function (q) { return [0.5, 0.5 - 0.03 * Math.abs(Math.sin(q * Math.PI)) * (1 - q)]; }); },
  infrared: function (it, sp, fps) { khFx(it, "procamp", { hue: 180, sat: 120 }); khLum(it, { tint: 30, con: 15 }); },
  flareSweep: function (it, sp, fps) { var c = khFx(it, "flare", { flBright: 110 }); khBake(c, "flCenter", sp.a, sp.b, fps / 2, function (x) { return [0.1 + 0.8 * x, 0.25 + 0.1 * Math.sin(x * 3)]; }); }
};
function khStep(it, st, sp, fps, W, H) {
  var k = st[0];
  if (k === "lum") return khLum(it, st[1]);
  if (k === "fx") return khFx(it, st[1], st[2]);
  if (k === "weave") return khWeave(it, fps, sp, st[1], st[2]);
  if (k === "pulse") { var t = khTr(it); if (t) khBeat(t.properties[3], sp, fps, st[1], function (q) { return 100 + st[2] * Math.pow(1 - q, 3); }); return; }
  if (k === "shake") { var t2 = khTr(it); if (!t2) return; t2.properties[3].setValue(100 + st[2] * 400, true); var R = khRand(5);
    khBeat(t2.properties[1], sp, fps, st[1], function (q) { var a = st[2] * Math.pow(1 - q, 2); return [0.5 + (R() - .5) * 2 * a, 0.5 + (R() - .5) * 2 * a]; }); return; }
  if (k === "flash") { var b = khFx(it, "bc", { bcB: 0 }); if (b) { var pr = kkParam(b, KH_P.bcB[0], KH_P.bcB[1]); if (pr) khBeat(pr, sp, fps, st[1], function (q) { return st[2] * Math.pow(Math.max(0, 1 - q / 0.3), 2); }); } return; }
  if (k === "hue") { var p = khFx(it, "procamp", { hue: 0 }); khBake(p, "hue", sp.a, sp.b, fps / 2, function (x) { return (x * sp.len * st[1] * 360) % 360; }); return; }
  if (k === "spikes") { var c = khFx(it, st[1], null); var R2 = khRand(9); khBake(c, st[2], sp.a, sp.b, fps, function () { return R2() > 1 - st[4] / fps * 3 ? st[3] * (0.5 + R2() * 0.5) : 0; }); return; }
  if (k === "fn") { if (KH_LOOKS[st[1]]) return KH_LOOKS[st[1]](it, sp, fps, W, H); if (KH_FN[st[1]]) return KH_FN[st[1]](it, sp, fps, W, H); }
}
var KH_DIR = ""; try { KH_DIR = (new File($.fileName)).parent.fsName; } catch (e) {}
function khCatalog() { if (typeof KH_CATALOG === "undefined") { var f = new File((KH_DIR || (KK_DIR + "/jsx")) + "/catalog.js"); if (f.exists) $.evalFile(f); } return typeof KH_CATALOG === "undefined" ? [] : KH_CATALOG; }
function kh_look2(id) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var C = khCatalog(), L = null; for (var i = 0; i < C.length; i++) if (C[i][0] === id) L = C[i];
    if (!L) return "err|Нет такого лука";
    var sel = kkSel(); if (!sel.length) return "err|Выдели клип на таймлайне";
    var fps = kkFps(seq), W = seq.frameSizeHorizontal, H = seq.frameSizeVertical;
    for (var j = 0; j < sel.length; j++) { var sp = kkSpan(sel[j]); for (var k = 0; k < L[5].length; k++) khStep(sel[j], L[5][k], sp, fps, W, H); }
    return "ok|«" + L[1] + "»: " + L[2] + ". Всё подкручивается в «Элементах управления эффектами»" + (sel.length > 1 ? " (клипов: " + sel.length + ")" : "");
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- легенды After Effects: MOGRT на плейхед ---------- */
function kh_aelegend(id, hex) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var fmt = seq.frameSizeHorizontal >= seq.frameSizeVertical ? "h" : "v";
    var mg = new File(KK_DIR + "/mogrt/legend-" + id + "-" + fmt + ".mogrt"); if (!mg.exists) return "err|Нет шаблона " + id;
    var ph = seq.getPlayerPosition().seconds, v = kkFreeTrack(seq, ph, ph + 5);
    var it = seq.importMGT(mg.fsName, String(Math.round(ph * KK_TICKS)), v, 0);
    if (!it) return "err|Премьер не открыл шаблон. Нужен Premiere Pro 2020 или новее";
    if (hex) try { var c = it.getMGTComponent(), p = c.properties.getParamForDisplayName("Цвет акцента"), n = parseInt(String(hex).replace("#", ""), 16); if (p) p.setColorValue(255, (n >> 16) & 255, (n >> 8) & 255, n & 255, true); } catch (e) {}
    return "ok|Легенда на V" + (v + 1) + ". Свой текст, цвет и размер — в «Элементах управления эффектами» → «Параметры графики»";
  } catch (e) { return "err|" + e.toString(); }
}

/* КК · Монтаж — пресеты v2: ~30 анимаций текста, ~30 переходов, ~25 эффектов.
   Подключается из host.jsx ($.evalFile). ES3: без let/const/стрелок.
   Сдвиги — в «пикселях 1080p», масштабируются под формат (U). Эффекты ищутся по русскому и английскому имени,
   параметры — по имени (с запасным индексом), поэтому работают в разных версиях и языках Премьера. */

/* ---------- параметры эффектов по имени ---------- */
function kkParam(comp, names, idx) {
  for (var n = 0; n < names.length; n++) for (var i = 0; i < comp.properties.numItems; i++) {
    var dn = String(comp.properties[i].displayName).toLowerCase();
    if (dn === String(names[n]).toLowerCase() || kkFxMatch(dn, String(names[n]).toLowerCase())) return comp.properties[i];
  }
  return (typeof idx === "number" && idx < comp.properties.numItems) ? comp.properties[idx] : null;
}
/* добавить эффект и вернуть его компонент (с учётом того, что Премьер ставит часть эффектов в конец) */
function kkAddEffect(item, names) {
  var fx = kkFx(names); if (!fx) return null;
  var qi = kkQeItem(item); if (!qi) return null;
  var before = kkMatchNames(item); qi.addVideoEffect(fx);
  return kkAddedComp(item, before);
}
var KK_EFFECTS = {
  blur: ["Размытие по Гауссу", "Gaussian Blur"], dirblur: ["Направленное размытие", "Directional Blur"],
  b3d: ["Базовый 3D", "Basic 3D"], spher: ["Сферизация", "Spherize"], twirl: ["Скручивание", "Twirl"], mosaic: ["Мозаика", "Mosaic"],
  rgb: ["Разделение RGB", "RGB Split"], bright: ["Brightness & Contrast", "Яркость и контрастность"], invert: ["Обратить", "Invert"],
  wave: ["Волнообразная деформация", "Wave Warp"], mirror: ["Зеркало", "Mirror"], replicate: ["Репликация", "Replicate"],
  echo: ["Эхо", "Echo"], shake: ["Тряска камеры", "Camera Shake"], glow: ["Чудесное свечение", "Wonder Glow"], leaks: ["Утечки света", "Light Leaks"],
  lens: ["Искажение линзы", "Lens Distortion"], strobe: ["Проблеск. свет", "Проблесковый свет", "Strobe Light"], bokeh: ["Размытие боке", "Bokeh Blur"],
  shadow: ["Длинная тень", "Long Shadow"], glitch: ["Цифровой сбой VR", "VR Digital Glitch"], post: ["Время постеризации", "Posterize Time"], rot3d: ["Поворот 3D", "3D Rotate"]
};
/* имена параметров (рус / англ) и запасной индекс */
var KK_PARAMS = {
  blur: [["Размытость", "Размытие", "Blurriness"], 0], dirlen: [["Длина размытия", "Blur Length"], 1], dirang: [["Направление", "Direction"], 0],
  swivel: [["Поворот", "Swivel"], 0], tilt: [["Наклон", "Tilt"], 1], dist: [["Расстояние до изображения", "Distance to Image"], 2],
  spherR: [["Радиус", "Radius"], 0], twirlA: [["Угол", "Angle"], 22], twirlR: [["Радиус скручивания", "Внешний радиус", "Twirl Radius", "Outer Radius"], 26],
  mosH: [["Горизонтальные блоки", "Horizontal Blocks"], 0], mosV: [["Вертикальные блоки", "Vertical Blocks"], 1],
  bright: [["Яркость", "Brightness"], 0], invMix: [["Смешать с оригиналом", "Смешивание с оригиналом", "Blend With Original"], 1],
  waveH: [["Высота волны", "Wave Height"], 1], waveW: [["Ширина волны", "Wave Width"], 2], waveS: [["Скорость волны", "Wave Speed"], 4],
  rep: [["Число", "Количество", "Count"], 0], echoT: [["Время эха (секунды)", "Echo Time (seconds)"], 0], echoN: [["Количество кадров эха", "Количество эха", "Number Of Echoes"], 1],
  postFps: [["Частота кадров", "Frame Rate"], 0], rgbAmt: [["Горизонтальное разделение", "Horizontal Split", "Величина", "Amount"], 4]
};
function kkP(comp, key) { var k = KK_PARAMS[key]; return kkParam(comp, k[0], k[1]); }

/* ---------- анимации текста v2 ---------- */
/* p: pos [dx,dy] (px 1080p), sc (стартовый масштаб %), sx/sy (раздельный масштаб %), rot (°), op (прозрачность), blur (px), e (кривая), fx: jitter|flicker */
var KK_ANIMS2 = {
  pop: { sc: 0, op: 1, e: "outBack", n: "Pop" }, popSoft: { sc: 60, op: 1, e: "outCubic", n: "Мягкий pop" }, popBig: { sc: 180, op: 1, e: "outCubic", n: "Из большого" },
  zoom: { sc: 0, op: 1, e: "outExpo", n: "Из точки" }, fade: { op: 1, e: "linear", n: "Растворение" },
  fadeUp: { pos: [0, 80], op: 1, e: "outCubic", n: "Подъём" }, fadeDown: { pos: [0, -80], op: 1, e: "outCubic", n: "Опускание" },
  fadeLeft: { pos: [120, 0], op: 1, e: "outCubic", n: "Справа налево" }, fadeRight: { pos: [-120, 0], op: 1, e: "outCubic", n: "Слева направо" },
  slide: { pos: [-260, 0], op: 1, e: "outQuint", n: "Выезд" }, slideUp: { pos: [0, 400], e: "outQuint", n: "Вылет снизу" }, slideDown: { pos: [0, -400], e: "outQuint", n: "Вылет сверху" },
  slideRight: { pos: [600, 0], e: "outQuint", n: "Вылет справа" },
  drop: { pos: [0, -240], op: 1, e: "outBounce", n: "Отскок" }, rise: { pos: [0, 240], op: 1, e: "outBack", n: "Прыжок снизу" },
  spin: { sc: 0, rot: -180, op: 1, e: "outBack", n: "Вращение" }, swing: { rot: -25, op: 1, e: "outElastic", n: "Качнуться" }, tilt: { rot: 12, pos: [0, 60], op: 1, e: "outCubic", n: "Наклон" },
  flipX: { sx: 0, e: "outBack", n: "Переворот ↔" }, flipY: { sy: 0, e: "outBack", n: "Переворот ↕" },
  stretch: { sx: 300, sy: 40, op: 1, e: "outQuint", n: "Растяжка" }, squash: { sx: 140, sy: 0, e: "outElastic", n: "Сплющить" },
  elastic: { sc: 0, e: "outElastic", n: "Резинка" }, rubber: { sx: 130, sy: 70, e: "outElastic", n: "Желе" },
  blurIn: { blur: 60, op: 1, e: "outCubic", n: "Из размытия" }, blurUp: { blur: 40, pos: [0, 80], op: 1, e: "outCubic", n: "Размытие + подъём" },
  blurZoom: { blur: 50, sc: 140, op: 1, e: "outCubic", n: "Размытие + зум" }, whip: { pos: [-700, 0], blur: 80, e: "outExpo", n: "Хлыст" },
  glitch: { op: 1, fx: "jitter", e: "linear", n: "Глитч" }, shake: { fx: "shake", e: "linear", n: "Дрожь" }, blink: { fx: "flicker", e: "linear", n: "Мигание" }
};
function kk_anim2(id, side, dur) {
  try {
    var A = KK_ANIMS2[id]; if (!A) return "err|Неизвестная анимация";
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var items = kkSel(); if (!items.length) return "err|Выдели клип, текст или графику";
    var fps = kkFps(seq), W = seq.frameSizeHorizontal, H = seq.frameSizeVertical, U = Math.min(W, H) / 1080;
    dur = Number(dur) || 0.4;
    var prog = function (x) { return side === "out" ? 1 - kkIn(A.e === "linear" ? "linear" : A.e)(x) : KK_EASE[A.e](x); };
    for (var i = 0; i < items.length; i++) {
      var it = items[i], sp = kkSpan(it), d = Math.min(dur, sp.len / 2);
      var mo = kkComp(it, "AE.ADBE Motion"), op = kkComp(it, "AE.ADBE Opacity");
      var t0 = side === "out" ? sp.b - d : sp.a, t1 = side === "out" ? sp.b : sp.a + d, refT = side === "out" ? t0 : t1;
      var pos = mo.properties[0], sc = mo.properties[1], scw = mo.properties[2], uni = mo.properties[3], rot = mo.properties[4];
      var P = kkBase(pos, refT), S = kkBase(sc, refT), R = kkBase(rot, refT), O = op ? kkBase(op.properties[0], refT) : 100;
      if (A.sx !== undefined || A.sy !== undefined) {
        uni.setValue(false, true); var SW = kkBase(scw, refT);
        var sx0 = A.sx !== undefined ? A.sx / 100 : 1, sy0 = A.sy !== undefined ? A.sy / 100 : 1;
        kkBake(scw, t0, t1, fps, function (x) { return SW * (sx0 + (1 - sx0) * prog(x)); });
        kkBake(sc, t0, t1, fps, function (x) { return S * (sy0 + (1 - sy0) * prog(x)); });
      } else if (A.sc !== undefined) kkBake(sc, t0, t1, fps, function (x) { var s0 = A.sc / 100; return S * (s0 + (1 - s0) * prog(x)); });
      if (A.pos) { var dx = A.pos[0] * U / W, dy = A.pos[1] * U / H; kkBake(pos, t0, t1, fps, function (x) { var k = 1 - prog(x); return [P[0] + dx * k, P[1] + dy * k]; }); }
      if (A.rot !== undefined) kkBake(rot, t0, t1, fps, function (x) { return R + A.rot * (1 - prog(x)); });
      if (A.op && op) kkBake(op.properties[0], t0, t1, fps, function (x) { var v = side === "out" ? 1 - Math.max(0, (x - .5) / .5) : Math.min(1, x * 2.5); return O * v; });
      if (A.blur) { var bc = kkAddEffect(it, KK_EFFECTS.blur); if (bc) { var bp = kkP(bc, "blur"); kkBake(bp, t0, t1, fps, function (x) { return A.blur * U * (1 - prog(x)); }); } }
      if (A.fx === "jitter") { kkBake(pos, t0, t1, fps, function (x) { var R2 = Math.sin(x * 97.3) * 43758.5453, r = R2 - Math.floor(R2); return [P[0] + (r - .5) * 40 * U / W * (1 - x), P[1]]; });
        if (op) kkBake(op.properties[0], t0, t1, fps, function (x) { return (Math.floor(x * 9) % 2 === 0 && x < .8) ? O * .2 : O; }); }
      if (A.fx === "shake") { var a = 10 * U / W; kkBake(pos, t0, t1, fps, function (x) { var k = 1 - x; return [P[0] + a * k * Math.sin(x * 40), P[1] + a * .6 * k * Math.cos(x * 33)]; });
        kkBake(rot, t0, t1, fps, function (x) { return R + 3 * (1 - x) * Math.sin(x * 37); }); }
      if (A.fx === "flicker" && op) kkBake(op.properties[0], t0, t1, fps, function (x) { var on = Math.floor(x * 6) % 2 === 0; return side === "out" ? (x > .95 ? 0 : (on ? O : 0)) : (x > .95 ? O : (on ? 0 : O)); });
    }
    return "ok|«" + A.n + "» готово: " + items.length + " шт.";
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}
function kk_animList() { var o = []; for (var k in KK_ANIMS2) o.push(k + ":" + KK_ANIMS2[k].n); return o.join(";"); }

/* ---------- переходы v2 ---------- */
/* a/b — что делаем с концом клипа A и началом B; t — тип: transform | fx-эффект */
var KK_TRANS2 = {
  zoom: { n: "Зум-рывок" }, zoomOut: { n: "Отъезд", tf: { aSc: 100, aEnd: 40, bSc: 250 } }, whipL: { n: "Смаз влево" }, whipR: { n: "Смаз вправо" },
  whipU: { n: "Смаз вверх", tf: { dir: [0, -1] } }, whipD: { n: "Смаз вниз", tf: { dir: [0, 1] } },
  spin: { n: "Вращение" }, spinL: { n: "Вращение против", tf: { spinDir: -1 } }, stretch: { n: "Растягивание" }, stretchV: { n: "Растяжка ↕", tf: { vertical: 1 } },
  shake: { n: "Тряска" }, dip: { n: "Затемнение" },
  flash: { n: "Белая вспышка", fx: "bright", val: [0, 100] }, flashZoom: { n: "Вспышка + зум", fx: "bright", val: [0, 100], also: "zoom" },
  blur: { n: "Размытие", fx: "blur", val: [0, 120] }, blurZoom: { n: "Размытие + зум", fx: "blur", val: [0, 90], also: "zoom" },
  fisheye: { n: "Рыбий глаз", fx: "spher", val: [0, 800] }, fisheyeZoom: { n: "Рыбий глаз + зум", fx: "spher", val: [0, 700], also: "zoom" },
  flip3d: { n: "3D-переворот", fx: "b3d", key: "swivel", val: [0, 90] }, tilt3d: { n: "3D-кувырок", fx: "b3d", key: "tilt", val: [0, 90] },
  twirl: { n: "Скручивание", fx: "twirl", key: "twirlA", val: [0, 540] }, pixel: { n: "Пиксели", fx: "mosaic", val: [1, 0] },
  rgb: { n: "RGB-сдвиг", fx: "rgb", key: "rgbAmt", val: [0, 60], also: "shakeSoft" }, glitch: { n: "Глитч", fx: "rgb", key: "rgbAmt", val: [0, 80], also: "jitter" },
  invert: { n: "Негатив-вспышка", fx: "invert", key: "invMix", val: [100, 0] }, wave: { n: "Волна", fx: "wave", key: "waveH", val: [0, 120] },
  echo: { n: "Шлейф", fx: "echo", key: "echoN", val: [0, 6], also: "whip" }, mirror: { n: "Калейдоскоп", fx: "replicate", key: "rep", val: [1, 4] },
  dirblur: { n: "Смаз-размытие", fx: "dirblur", key: "dirlen", val: [0, 200] }
};
function kk_trans2(id, frames) {
  try {
    var T = KK_TRANS2[id]; if (!T) return "err|Неизвестный переход";
    var old = { zoom: 1, whipL: 1, whipR: 1, spin: 1, stretch: 1, shake: 1, dip: 1 };
    if (old[id] && !T.tf) return kk_trans(id, frames).replace("«" + id + "»", "«" + T.n + "»");           // проверенные первые 7
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var cut = kkCut(seq); if (!cut) return "err|Поставь плейхед точно на стык двух клипов";
    var fps = kkFps(seq), n = Number(frames) || 8, d = n / fps, A = cut.a, B = cut.b, sa = kkSpan(A), sb = kkSpan(B);
    d = Math.min(d, sa.len / 2, sb.len / 2);
    var a0 = sa.b - d, a1 = sa.b, b0 = sb.a, b1 = sb.a + d, inn = KK_EASE.inCubic, out = KK_EASE.outCubic;
    if (T.tf) {                                                   // варианты на «Преобразовать»
      var ta = kkTransform(A, true), tb = kkTransform(B, true); if (!ta || !tb) return "err|Не получилось добавить «Преобразовать»";
      var SC = function (c) { return c.properties[3]; }, PS = function (c) { return c.properties[1]; };
      if (T.tf.aEnd) { kkBake(SC(ta), a0, a1, fps, function (x) { return 100 + 25 * inn(x); }); kkBake(SC(tb), b0, b1, fps, function (x) { return 180 - 80 * out(x); }); }
      else if (T.tf.dir) { var dy = T.tf.dir[1];
        kkBake(SC(ta), a0, a1, fps, function (x) { return 100 + 60 * inn(x); }); kkBake(PS(ta), a0, a1, fps, function (x) { return [0.5, 0.5 + dy * 0.3 * inn(x)]; });
        kkBake(SC(tb), b0, b1, fps, function (x) { return 160 - 60 * out(x); }); kkBake(PS(tb), b0, b1, fps, function (x) { return [0.5, 0.5 - dy * 0.3 * (1 - out(x))]; }); }
      else if (T.tf.spinDir) { var W = seq.frameSizeHorizontal, H = seq.frameSizeVertical, szA = kkSrcSize(A) || [W, H], szB = kkSrcSize(B) || [W, H];
        var cover0 = function (sz, deg) { var t = Math.abs(deg) * Math.PI / 180, c = Math.abs(Math.cos(t)), si = Math.abs(Math.sin(t)); return Math.max((sz[0] * c + sz[1] * si) / sz[0], (sz[0] * si + sz[1] * c) / sz[1]) * 102; }; var cover = function (sz, deg) { var m = 0; for (var dd = -60; dd <= 60; dd += 5) m = Math.max(m, cover0(sz, deg + dd)); return m; };
        kkBake(ta.properties[7], a0, a1, fps, function (x) { return -180 * inn(x); }); kkBake(SC(ta), a0, a1, fps, function (x) { return cover(szA, 180 * inn(x)); });
        kkBake(tb.properties[7], b0, b1, fps, function (x) { return 180 * (1 - out(x)); }); kkBake(SC(tb), b0, b1, fps, function (x) { return cover(szB, 180 * (1 - out(x))); }); }
      else if (T.tf.vertical) { ta.properties[2].setValue(false, true); tb.properties[2].setValue(false, true);
        kkBake(ta.properties[3], a0, a1, fps, function (x) { return 100 + 250 * inn(x); }); kkBake(tb.properties[3], b0, b1, fps, function (x) { return 350 - 250 * out(x); }); }
      return "ok|Переход «" + T.n + "» готов";
    }
    // варианты на эффектах: эффект нарастает к стыку на A и спадает на B
    var ca = kkAddEffect(A, KK_EFFECTS[T.fx]), cb = kkAddEffect(B, KK_EFFECTS[T.fx]);
    if (!ca || !cb) return "err|В этой версии Премьера нет эффекта для перехода «" + T.n + "»";
    var key = T.key || (T.fx === "bright" ? "bright" : T.fx === "blur" ? "blur" : T.fx === "spher" ? "spherR" : T.fx === "mosaic" ? "mosH" : null);
    var pa = kkP(ca, key), pb = kkP(cb, key); if (!pa || !pb) return "err|Не нашла параметр эффекта для «" + T.n + "»";
    var v0 = T.val[0], v1 = T.val[1], H2 = seq.frameSizeVertical, W2 = seq.frameSizeHorizontal;
    if (T.fx === "mosaic") { // пиксели: много блоков → мало блоков → много
      var pva = kkP(ca, "mosV"), pvb = kkP(cb, "mosV"), big = 200, small = 12;
      kkBake(pa, a0, a1, fps, function (x) { return Math.round(big - (big - small) * inn(x)); }); if (pva) kkBake(pva, a0, a1, fps, function (x) { return Math.round((big - (big - small) * inn(x)) * H2 / W2); });
      kkBake(pb, b0, b1, fps, function (x) { return Math.round(small + (big - small) * out(x)); }); if (pvb) kkBake(pvb, b0, b1, fps, function (x) { return Math.round((small + (big - small) * out(x)) * H2 / W2); });
    } else {
      kkBake(pa, a0, a1, fps, function (x) { return v0 + (v1 - v0) * inn(x); });
      kkBake(pb, b0, b1, fps, function (x) { return v1 + (v0 - v1) * out(x); });
    }
    if (T.also === "zoom" || T.also === "whip") { var za = kkTransform(A, true), zb = kkTransform(B, true);
      if (za && zb) { kkBake(za.properties[3], a0, a1, fps, function (x) { return 100 + 60 * inn(x); }); kkBake(zb.properties[3], b0, b1, fps, function (x) { return 160 - 60 * out(x); }); } }
    if (T.also === "jitter" || T.also === "shakeSoft") { var ja = kkTransform(A, false), jb = kkTransform(B, false), amp = T.also === "jitter" ? 0.03 : 0.012;
      if (ja && jb) { kkBake(ja.properties[1], a0, a1, fps, function (x) { return [0.5 + amp * Math.sin(x * 61) * x, 0.5]; }); kkBake(jb.properties[1], b0, b1, fps, function (x) { return [0.5 + amp * Math.sin(x * 53) * (1 - x), 0.5]; }); } }
    return "ok|Переход «" + T.n + "» готов";
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}
function kk_transList() { var o = []; for (var k in KK_TRANS2) o.push(k + ":" + KK_TRANS2[k].n); return o.join(";"); }

/* ---------- эффекты на клип ---------- */
/* mode: pulse (пульсирует весь клип), in (на входе), once (статично), loop (непрерывно) */
var KK_FX2 = {
  fisheye: { n: "Рыбий глаз", fx: "spher", key: "spherR", mode: "once", val: 900 }, fisheyePulse: { n: "Рыбий глаз-пульс", fx: "spher", key: "spherR", mode: "pulse", val: 800 },
  fisheyeIn: { n: "Рыбий глаз на входе", fx: "spher", key: "spherR", mode: "in", val: 1000 },
  rot3d: { n: "3D-покачивание", fx: "b3d", key: "swivel", mode: "loop", val: 18 }, tilt3d: { n: "3D-наклон", fx: "b3d", key: "tilt", mode: "loop", val: 14 },
  flip3dIn: { n: "3D-разворот на входе", fx: "b3d", key: "swivel", mode: "in", val: 90 },
  rgbPulse: { n: "RGB-пульс", fx: "rgb", key: "rgbAmt", mode: "pulse", val: 40 }, rgbStatic: { n: "RGB-разлом", fx: "rgb", key: "rgbAmt", mode: "once", val: 18 },
  twirlIn: { n: "Воронка на входе", fx: "twirl", key: "twirlA", mode: "in", val: 360 }, twirlLoop: { n: "Медленная воронка", fx: "twirl", key: "twirlA", mode: "loop", val: 40 },
  jelly: { n: "Желе (волна)", fx: "wave", key: "waveH", mode: "once", val: 12 }, dream: { n: "Сон (волна + размытие)", fx: "wave", key: "waveH", mode: "once", val: 6, plus: "blurSoft" },
  kaleido: { n: "Калейдоскоп 2×2", fx: "replicate", key: "rep", mode: "once", val: 2 }, kaleido3: { n: "Калейдоскоп 3×3", fx: "replicate", key: "rep", mode: "once", val: 3 },
  mirror: { n: "Зеркало", fx: "mirror", mode: "once" }, echo: { n: "Шлейф движения", fx: "echo", key: "echoN", mode: "once", val: 4 },
  pixelIn: { n: "Пиксели на входе", fx: "mosaic", key: "mosH", mode: "in", val: 8 }, pixelLook: { n: "Пиксель-арт", fx: "mosaic", key: "mosH", mode: "once", val: 90 },
  stop12: { n: "Через кадр (12 к/с)", fx: "post", key: "postFps", mode: "once", val: 12 },
  shake: { n: "Тряска камеры", fx: "shake", mode: "once" }, glow: { n: "Чудесное свечение", fx: "glow", mode: "once" }, leaks: { n: "Световые утечки", fx: "leaks", mode: "once" },
  glitch: { n: "Цифровой сбой", fx: "glitch", mode: "once" }, longShadow: { n: "Длинная тень (для текста)", fx: "shadow", mode: "once" },
  blurIn: { n: "Фокус на входе", fx: "blur", key: "blur", mode: "in", val: 80 }, invertFlash: { n: "Негатив-вспышка", fx: "invert", key: "invMix", mode: "flash", val: 0 }
};
function kk_fx2(id) {
  try {
    var F = KK_FX2[id]; if (!F) return "err|Неизвестный эффект";
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var items = kkSel(); if (!items.length) return "err|Выдели клип";
    var fps = kkFps(seq), U = Math.min(seq.frameSizeHorizontal, seq.frameSizeVertical) / 1080, n = 0;
    for (var i = 0; i < items.length; i++) {
      var it = items[i], sp = kkSpan(it); if (!kkQeItem(it)) return "err|Не нашла клип — выдели его ещё раз";
      var c = kkAddEffect(it, KK_EFFECTS[F.fx]); if (!c) return "err|В этой версии Премьера нет эффекта «" + KK_EFFECTS[F.fx][0] + "»";
      n++;
      if (F.fx === "b3d" || F.fx === "shake" || F.fx === "twirl") { var mo = kkComp(it, "AE.ADBE Motion"); if (mo && !mo.properties[1].isTimeVarying()) mo.properties[1].setValue(mo.properties[1].getValue() * (F.fx === "shake" ? 1.08 : 1.18), true); } // без чёрных краёв
      if (!F.key) continue;                                            // эффекты с хорошими настройками по умолчанию
      var p = kkP(c, F.key); if (!p) continue;
      var v = F.val * ((F.key === "spherR" || F.key === "blur") ? U : 1);
      if (F.mode === "once") p.setValue(v, true);
      else if (F.mode === "in") { var d = Math.min(0.5, sp.len / 2); kkBake(p, sp.a, sp.a + d, fps, function (x) { return F.key === "mosH" ? Math.round(v + (200 - v) * KK_EASE.outCubic(x)) : v * (1 - KK_EASE.outCubic(x)); }); }
      else if (F.mode === "pulse") kkBake(p, sp.a, sp.b, Math.min(fps, 15), function (x) { var t = x * sp.len; return v * Math.pow(Math.max(0, Math.sin(t * Math.PI * 2 / 0.9)), 6); });
      else if (F.mode === "loop") kkBake(p, sp.a, sp.b, Math.min(fps, 15), function (x) { return v * Math.sin(x * sp.len * Math.PI * 2 / 3); });
      else if (F.mode === "flash") { var m = Math.min(0.3, sp.len / 3); kkBake(p, sp.a, sp.a + m, fps, function (x) { return 100 * x; }); }
      if (F.plus === "blurSoft") { var bc = kkAddEffect(it, KK_EFFECTS.blur); if (bc) kkP(bc, "blur").setValue(6 * U, true); }
    }
    return "ok|«" + F.n + "» на " + n + " клип.";
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}
function kk_fxList() { var o = []; for (var k in KK_FX2) o.push(k + ":" + KK_FX2[k].n); return o.join(";"); }

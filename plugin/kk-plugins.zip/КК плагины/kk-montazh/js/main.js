/* КК · Монтаж — интерфейс панели. Вызывает функции из jsx/host.jsx через CEP evalScript. */
(function () {
  var VERSION = "1.6.0";
  var cep = window.__adobe_cep__;
  // превью кнопок — настоящий результат из Премьера (10 кадров, prev/mt/*.png), крутим кадры
  var spf = 0; setInterval(function () { spf = (spf + 1) % 10; var a = document.querySelectorAll(".spr"); for (var i = 0; i < a.length; i++) a[i].style.backgroundPosition = (spf * 100 / 9) + "% 0"; }, 220);
  function run(fn, args, cb) {
    var call = fn + "(" + (args || []).map(function (a) { return JSON.stringify(a); }).join(",") + ")";
    if (!cep) { cb && cb("err|Открой панель внутри Premiere Pro"); return; }
    // все панели КК живут в одном движке ExtendScript Премьера и перетирают общие функции —
    // перед каждой командой подгружаем свои файлы (на верхнем уровне: $.evalFile внутри функции не создаёт глобальных функций)
    var d = JSON.stringify(extDir());
    cep.evalScript("try{$.evalFile(new File(" + d + "+\"/jsx/host.jsx\"));kk_setDir(" + d + ");$.evalFile(new File(" + d + "+\"/jsx/presets.jsx\"));}catch(e){};" + (window.KKAuto ? KKAuto.wrap(fn, call) : call), function (r) { cb && cb(String(r || "")); });
  }
  if (window.KKAuto) KKAuto.mount(run, say);
  function say(r) {
    var m = document.getElementById("msg"), p = String(r).split("|");
    m.className = p[0] === "ok" ? "ok" : "err"; m.textContent = p.slice(1).join(" ") || r;
    clearTimeout(say.t); say.t = setTimeout(function () { m.textContent = ""; }, 6000);
  }
  var ttxt = "", dur = 0.4, side = "in", trf = 8, sub = "kk-word", subW = 0;
  var SUBS = [["kk-word", "КК · активное слово", "белый текст, сказанное слово — цветом акцента"], ["pop-word", "Поп по словам", "слова выскакивают по одному, капс"], ["word-by-word", "Слово за словом", "фраза набирается по словам"], ["karaoke", "Караоке", "цвет заливает текст по ходу речи"], ["caps-stroke", "Капс с обводкой", "крупно и жирно, как у блогеров"], ["kk-plate", "КК · плашка", "текст на цветной плашке"], ["typewriter", "Печатная машинка", "по буквам, моноширинный"], ["minimal", "Минимал", "тонкий шрифт и мягкая тень"]];
  /* списки: [id, имя, группа c|d|b, превью] — полные приходят из jsx (kk_animList / kk_transList / kk_fxList), здесь запасные */
  var TRANS = [["zoom", "Зум-рывок", "d", "zoom"], ["whipL", "Смаз влево", "d", "slide"], ["whipR", "Смаз вправо", "d", "slide"], ["spin", "Вращение", "b", "pop"], ["stretch", "Растягивание", "d", "zoom"], ["shake", "Тряска", "d", "shake"], ["dip", "Затемнение", "c", "blink"]];

  var ANIMS = [["pop", "Pop", "d", "pop"], ["fadeUp", "Подъём", "c", "fadeUp"], ["slide", "Выезд", "c", "slide"], ["zoom", "Из точки", "d", "zoom"], ["drop", "Отскок", "d", "drop"], ["shake", "Дрожь", "b", "shake"], ["blink", "Мигание", "d", "blink"]];
  var FXS = [], CURVES = {};
  function parseList(r) { return String(r || "").indexOf("err") === 0 || !r ? null : String(r).split(";").map(function (x) { var a = x.split(":"); return [a[0], a[1] || a[0], a[2] || "", a[3] || "", a[4] || ""]; }); }
  function esc(s) { return String(s || "").replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;"); }
  function loadLists() {
    run("kk_animList", [], function (r) { var l = parseList(r); if (l && l.length) { ANIMS = l; if (cur === "Текст") render(); } });
    run("kk_transList", [], function (r) { var l = parseList(r); if (l && l.length) { TRANS = l; if (cur === "Переходы") render(); } });
    run("kk_fxList", [], function (r) { var l = parseList(r); if (l && l.length) { FXS = l; if (cur === "Эффекты") render(); } });
    run("kk_easeCurves", [], function (r) { if (!r || r.indexOf("err") === 0) return; r.split(";").forEach(function (x) { var i = x.indexOf(":"); if (i > 0) CURVES[x.slice(0, i)] = x.slice(i + 1).split(",").map(Number); }); if (cur === "Плавность") render(); });
  }
  /* фильтр «Все / Спокойно / Динамично / Дерзко» — как группы в «Субтитрах»; у каждой вкладки свой выбор */
  var GRS = [["all", "Все"], ["c", "Спокойно"], ["d", "Динамично"], ["b", "Дерзко"]], grp = {};
  function chips() { var g = grp[cur] || "all"; return '<div class="tabs chips" style="padding:0;border:0">' + GRS.map(function (x) { return '<button class="' + (x[0] === g ? "on" : "") + '" data-grp="' + x[0] + '">' + x[1] + '</button>'; }).join("") + '</div>'; }
  function byGrp(list, gi) { var g = grp[cur] || "all", ord = { c: 0, d: 1, b: 2 };
    return list.map(function (x, i) { return [x, i]; }).filter(function (p) { return g === "all" || p[0][gi] === g; })
      .sort(function (a, b) { var A = ord[a[0][gi]], B = ord[b[0][gi]]; A = A === undefined ? 3 : A; B = B === undefined ? 3 : B; return A - B || a[1] - b[1]; }).map(function (p) { return p[0]; }); }
  /* мини-график кривой плавности */
  function curveSvg(id) {
    var v = id === "hold" ? [0, 0, 0, 0, 0, 0, 0, 0, 1] : CURVES[id === "ios" ? "outQuint" : id]; if (!v || !v.length) return "";
    var lo = -.45, hi = 1.6, y = function (q) { return (24 - (q - lo) / (hi - lo) * 22 - 1).toFixed(1); }, n = v.length - 1;
    var pts = v.map(function (q, i) { return (i / n * 40).toFixed(1) + "," + y(q); }); if (id === "hold") pts = ["0," + y(0), "40," + y(0), "40," + y(1)];
    return '<svg viewBox="0 0 40 24" aria-hidden="true"><path d="M0 ' + y(0) + 'H40M0 ' + y(1) + 'H40" class="ln"/><polyline points="' + pts.join(" ") + '"/></svg>';
  }
  var EASES = [
    ["inOutCubic", "Плавно", "мягкий разгон и мягкое торможение", "c"], ["outCubic", "Резкий старт", "быстро начинается, мягко останавливается", "c"], ["inCubic", "Резкий финиш", "мягко стартует, быстро доезжает", "c"],
    ["ios", "Как в iOS", "быстро и очень мягкая остановка", "c"], ["inOutQuint", "Кино-плавно", "очень мягкий разгон и остановка", "c"], ["inOutSine", "Мягкая волна", "самая деликатная плавность", "c"],
    ["outCirc", "Скольжение", "как по льду", "c"], ["springIOS", "Пружинка iOS", "мягко, с крошечным перелётом", "c"], ["softOver", "Мягкий перелёт", "плавно, чуть дальше и назад", "c"],
    ["uiStd", "Интерфейс", "как анимации в приложениях", "c"], ["drift", "Дрейф", "рывок, потом плывёт дальше", "c"], ["twoStage", "В два приёма", "плавно, с передышкой посередине", "c"],
    ["linear", "Линейно", "убрать плавность", "c"],
    ["outExpo", "Выстрел", "мгновенный старт и долгий доезд", "d"], ["inExpo", "Разгон", "медленно, а в конце рывок", "d"], ["outBack", "Пружина", "небольшой перелёт и возврат", "d"],
    ["inOutBack", "Замах и пружина", "отходит назад, перелетает и возвращается", "d"], ["outBounce", "Отскок", "как мячик", "d"], ["springBouncy", "Пружина с отдачей", "перелетает и пару раз качается", "d"],
    ["inBack", "Замах", "отходит назад и разгоняется", "d"], ["oneBounce", "Один отскок", "падает и разок подпрыгивает", "d"], ["inBounce", "Подпрыгивая", "скачет на старте и летит", "d"],
    ["brake", "Торможение", "едет ровно и резко тормозит", "d"], ["launch", "Газ в пол", "трогается и мчит до конца", "d"], ["jumpStart", "Скачок и доезд", "мгновенный скачок, плавный доезд", "d"],
    ["speedRamp", "Спид-рамп", "быстро, замедление, снова быстро", "d"], ["hang", "Зависание", "зависает в воздухе посередине", "d"], ["holdSnap", "Пауза и рывок", "ждёт, потом резко прыгает", "d"],
    ["snapHold", "Рывок и замри", "резко доезжает и стоит", "d"], ["magnet", "Магнит", "разгоняется и прилипает", "d"], ["latch", "Защёлка", "подъезжает и защёлкивается", "d"],
    ["hesitate", "Нерешительно", "дёрнулся, отступил, доехал", "d"], ["surges", "Толчками", "три плавных толчка", "d"], ["tick", "Тик-так", "шагами, как секундная стрелка", "d"],
    ["robot", "Робот", "механически, со сменой скорости", "d"], ["steps", "Ступеньки", "четыре резких шага", "d"], ["stopMotion", "Стоп-моушн", "рвано, как покадровая анимация", "d"],
    ["hold", "Стоп-кадр", "ключи без перехода", "d"],
    ["outElastic", "Резинка", "несколько колебаний", "b"], ["springWobbly", "Желе", "долго колышется в конце", "b"], ["inElastic", "Тетива", "дрожит и срывается с места", "b"],
    ["inOutElastic", "Двойная резинка", "дрожит на старте и финише", "b"], ["windup", "Замах и выстрел", "оттяжка назад и выстрел", "b"], ["whip", "Хлыст", "медленно, свист, перелёт", "b"],
    ["punch", "Панч", "ударно влетает и отпускает", "b"], ["coin", "Монетка", "дребезжит всё быстрее и замирает", "b"], ["vibro", "Вибро", "дрожит по всему пути", "b"],
    ["glitch", "Глитч", "цифровые скачки, потом на место", "b"], ["flicker", "Мерцание", "мигает между началом и концом", "b"], ["pingpong", "Туда-обратно", "доехал, вернулся, снова доехал", "b"]];
  var CAM = [
    ["zoomIn", "Наезд", "медленное приближение на весь клип", "c"], ["zoomOut", "Отъезд", "медленное отдаление", "c"], ["kenBurns", "Кен Бёрнс", "медленный наезд со сдвигом", "c"],
    ["faceZoom", "Наезд на лицо", "приближение к верхней трети кадра", "c"], ["vertigo", "Головокружение", "медленный отъезд как в триллере", "c"], ["breathe", "Дыхание кадра", "лёгкая пульсация масштаба", "c"],
    ["hover", "Парение", "кадр плавно парит", "c"], ["panL", "Панорама влево", "плавный проезд", "c"], ["panR", "Панорама вправо", "плавный проезд", "c"],
    ["tiltU", "Наклон вверх", "камера поднимается", "c"], ["tiltD", "Наклон вниз", "камера опускается", "c"], ["diag", "Диагональ", "проезд по диагонали", "c"],
    ["drone", "Дрон", "взлёт вверх с отдалением", "c"], ["spiral", "Спираль", "наезд с лёгким поворотом", "c"], ["roll", "Покачивание", "лёгкий наклон горизонта", "c"],
    ["sway", "Качка", "покачивание, как на лодке", "c"], ["dutch", "Голландский угол", "наклонный кадр, лёгкое напряжение", "c"], ["hand", "Ручная камера", "живое дрожание в руках", "c"],
    ["weave", "Плёнка", "дрожь старого кинопроектора", "c"], ["autofocus", "Автофокус", "камера ищет фокус", "c"], ["reveal", "Проявление", "выход из темноты с наездом", "c"],
    ["letterbox", "Кинополосы", "чёрные полосы, как в кино", "c"], ["card", "Карточка iOS", "кадр мягко уменьшается в окно", "c"],
    ["scrFly", "3D-экран: пролёт снизу вверх", "запись экрана лежит под наклоном, камера плывёт над ней, края в расфокусе; без чёрных углов", "c"],
    ["scrSlide", "3D-экран: проезд слева", "экран развёрнут в 3D, камера едет слева направо; без чёрных углов", "c"],
    ["scrDolly", "3D-экран: наезд сверху", "смотрим на экран сверху и плавно приближаемся, он выпрямляется", "c"],
    ["scrSwing", "3D-экран: с качанием", "экран плавает и покачивается карточкой на фоне — подложи фон на дорожку ниже", "c"],
    ["push", "Толчок", "быстрый наезд в начале", "d"], ["zoomPunch", "Зум-удар", "рывок вперёд и обратно", "d"], ["punchIn", "Панч-ин", "резкий кроп на плейхеде", "d"],
    ["twoCams", "Две камеры", "крупно-общо, будто снимали двумя", "d"], ["steps", "Ступенчатый зум", "зум рывками в бит", "d"], ["beatPulse", "Бит-пульс", "толчки кадра в ритм", "d"],
    ["beatTilt", "Наклоны в бит", "кадр качается в ритм", "d"], ["walk", "Шаги", "как будто идёшь с камерой", "d"], ["stopMo", "Стоп-моушн", "рваная ручная камера", "d"],
    ["nudge", "Толкнули", "камеру толкнули на плейхеде", "d"], ["blinkEye", "Моргание", "кадр моргает на плейхеде", "d"], ["swipe", "Свайп Reels", "въезд снизу, как лента", "d"],
    ["appOpen", "Открытие приложения", "раскрывается, как приложение iOS", "d"], ["pip", "Картинка в картинке", "окошко в углу, для реакций", "d"], ["spinSlow", "Медленный поворот", "кадр плавно вращается", "d"],
    ["scrFocus", "3D-экран: наезд на центр и размытие краёв", "камера приближается к центру экрана, края уходят в расфокус", "d"],
    ["scrOrbit", "3D-экран: облёт", "камера облетает экран слева направо; экран карточкой на фоне — фон на дорожку ниже", "d"],
    ["scrLay", "3D-экран: ложится карточкой", "кадр ложится под наклон и остаётся карточкой на фоне", "d"],
    ["crash", "Крэш-зум", "резкий влёт в конце клипа", "b"], ["crashIn", "Влёт из зума", "резкий отъезд из детали", "b"], ["whipIn", "Влёт смазом", "влетает сбоку со смазом", "b"],
    ["lookAway", "Оглянуться", "быстрый взгляд в сторону", "b"], ["shakeHit", "Удар", "встряска в начале клипа", "b"], ["bassShake", "Бас", "встряски в ритм баса", "b"],
    ["buildUp", "Нарастание", "тряска растёт перед дропом", "b"], ["glitchCam", "Сбой", "цифровые рывки кадра", "b"], ["jelly", "Желе-кадр", "кадр пружинит, как желе", "b"],
    ["bungee", "Тарзанка", "падает и пружинит на резинке", "b"], ["barrel", "Бочка", "полный оборот в начале", "b"], ["fall", "Камера упала", "кадр падает в конце", "b"],
    ["scrPop", "Экран выпрыгивает", "экран вылетает из глубины с пружинкой и встаёт во весь кадр; в начале виден фон", "b"]];

  /* ---------- автосубтитры: Whisper прямо на компьютере (русский распознаёт лучше встроенного) ---------- */
  var WH = { model: "ggml-large-v3-turbo-q5_0.bin", modelUrl: "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo-q5_0.bin", modelSize: 574041195,
    winUrl: "https://github.com/ggml-org/whisper.cpp/releases/download/b5454/whisper-blas-bin-x64.zip" };
  var subState = { phase: "", pct: 0, phrases: null, err: "" }, subGroup = "Все";
  // whisper.cpp на Windows открывает файлы в кодировке системы: кириллица в имени пользователя (C:\Users\Аня) ломает путь к модели и звуку.
  // Тогда кладём модель и временные файлы в общую папку с латинским путём (C:\Users\Public\kodkreatora).
  function winSafe(p, sub) { if (process.platform !== "win32" || !/[^\x00-\x7f]/.test(p)) return p;
    return require("path").join(process.env.PUBLIC || process.env.ALLUSERSPROFILE || "C:\\Users\\Public", "kodkreatora", sub); }
  function whDir() { var path = require("path"), os = require("os"); return winSafe(path.join(os.homedir(), ".kodkreatora", "whisper"), "whisper"); }
  function findFile(dir, name) { var fs = require("fs"), path = require("path"); if (!fs.existsSync(dir)) return null;
    var l = fs.readdirSync(dir); for (var i = 0; i < l.length; i++) { var p = path.join(dir, l[i]); if (l[i].toLowerCase() === name) return p; if (fs.statSync(p).isDirectory()) { var r = findFile(p, name); if (r) return r; } } return null; }
  function subPaint() { if (cur === "Субтитры") render(); }
  function fetchBig(url, file, total, onPct, done) {
    var fs = require("fs"), https = require("https"), tmp = file + ".part";
    (function get(u, n) { https.get(u, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && n < 8) { res.resume(); return get(res.headers.location, n + 1); }
      if (res.statusCode !== 200) { res.resume(); return done(new Error("HTTP " + res.statusCode)); }
      var size = +res.headers["content-length"] || total, got = 0, out = fs.createWriteStream(tmp), last = 0;
      res.on("data", function (c) { got += c.length; var p = Math.floor(got / size * 100); if (p !== last) { last = p; onPct(p); } });
      res.pipe(out); out.on("finish", function () { out.close(function () { fs.renameSync(tmp, file); done(null); }); });
    }).on("error", done); })(url, 0);
  }
  function whEnsure(done) {
    var fs = require("fs"), path = require("path"), cp = require("child_process"), dir = whDir(); mkdirp(dir);
    var model = path.join(dir, WH.model), win = process.platform === "win32";
    var bin = function (cb) {
      if (!win) { var b = path.join(extDir(), "bin", "mac", "whisper-cli"); try { fs.chmodSync(b, 493); cp.execSync('xattr -dr com.apple.quarantine "' + path.dirname(b) + '" 2>/dev/null || true'); } catch (e) {} return cb(null, b); }
      var have = findFile(path.join(dir, "win"), "whisper-cli.exe"); if (have) return cb(null, have);
      subState.phase = "Скачиваю распознаватель для Windows…"; subPaint();
      var zip = path.join(dir, "whisper-win.zip");
      fetchBig(WH.winUrl, zip, 21715607, function () {}, function (err) { if (err) return cb(err);
        cp.exec('powershell -NoProfile -Command "Expand-Archive -Force \'' + zip + '\' \'' + path.join(dir, "win") + '\'"', function (e2) { if (e2) return cb(e2); cb(null, findFile(path.join(dir, "win"), "whisper-cli.exe")); }); });
    };
    bin(function (err, b) {
      if (err || !b) return done(err || new Error("нет распознавателя"));
      if (fs.existsSync(model) && fs.statSync(model).size > 5e8) return done(null, b, model);
      subState.phase = "Первый запуск: скачиваю модель распознавания (550 МБ, один раз)…"; subState.pct = 0; subPaint();
      fetchBig(WH.modelUrl, model, WH.modelSize, function (p) { subState.pct = p; var e = document.getElementById("whp"); if (e) e.style.width = p + "%"; var t = document.getElementById("wht"); if (t) t.textContent = p + " %"; },
        function (e3) { if (e3) return done(e3); done(null, b, model); });
    });
  }
  // слова Whisper → фразы: по числу слов, паузам и знакам препинания
  // слова Whisper → фразы: по числу слов, паузам и знакам препинания; фраза не заканчивается предлогом или частицей
  var GLUE = /^(в|во|на|за|под|над|по|о|об|от|до|из|у|к|ко|с|со|и|а|но|не|ни|что|чтобы|как|это|же|ли|бы|для|при|без|про|через|мы|я|ты|он|она|они|вы|мой|моя|мои|твой|наш|ваш|их|его|её|все|всё|так|уже|ещё|если|когда|где|или|то)$/i;
  function toPhrases(words, maxW, maxC) {
    var out = [], cur = [];
    var txt = function (a) { return a.map(function (x) { return x.t; }).join(" "); };
    var flush = function () { if (!cur.length) return; var a = cur[0].a, b = cur[cur.length - 1].b; out.push({ a: a, b: b, t: txt(cur), w: cur.map(function (w) { return (w.a - a).toFixed(2); }).join(","), ws: cur.slice() }); cur = []; };
    for (var i = 0; i < words.length; i++) {
      var w = words[i], prev = cur[cur.length - 1];
      if (cur.length) {
        var bare = prev.t.replace(/[^а-яёa-z0-9]/gi, ""), hardEnd = /[.!?…]$/.test(prev.t), pause = w.a - prev.b > 0.6;
        var full = cur.length >= maxW || txt(cur).length + w.t.length + 1 > maxC, soft = /[,;:—]$/.test(prev.t) && cur.length >= Math.ceil(maxW / 2);
        if (hardEnd || pause || soft || (full && (!GLUE.test(bare) || cur.length >= maxW + 2))) flush();
      }
      cur.push(w);
    }
    flush();
    // одно-два коротких слова в хвосте предложения — приклеиваем к предыдущей фразе
    for (var k = out.length - 1; k > 0; k--) {
      var P = out[k], Q = out[k - 1];
      if (P.ws.length <= 1 && !/[.!?…]$/.test(Q.t) && Q.ws.length + P.ws.length <= maxW + 2 && P.a - Q.b < 0.6) {
        var ws = Q.ws.concat(P.ws), a0 = ws[0].a; out.splice(k - 1, 2, { a: a0, b: P.b, t: txt(ws), w: ws.map(function (x) { return (x.a - a0).toFixed(2); }).join(","), ws: ws });
      }
    }
    for (var j = 0; j < out.length; j++) { var nx = out[j + 1]; out[j].b = nx ? Math.min(nx.a, Math.max(out[j].b, out[j].a + 0.4) + 0.25) : out[j].b + 0.3; }
    return out;
  }
  function autoSubs() {
    var path = require("path"), os = require("os"), cp = require("child_process"), fs = require("fs");
    subState = { phase: "Готовлю звук секвенции…", pct: 0, phrases: null, err: "" }; subPaint();
    var tmp = winSafe(path.join(os.tmpdir(), "kk-subs"), "kk-subs"); mkdirp(tmp); var wav = path.join(tmp, "seq.wav"), outBase = path.join(tmp, "seq");
    run("kk_exportAudio", [wav], function (r) {
      var p = r.split("|"); if (p[0] !== "ok") { subState.phase = ""; subState.err = p.slice(1).join(" "); return subPaint(); }
      whEnsure(function (err, bin, model) {
        if (err) { subState.phase = ""; subState.err = "Не получилось подготовить распознавание: " + err.message; return subPaint(); }
        subState.phase = "Распознаю речь… (минута ролика — примерно 10–40 секунд)"; subState.pct = 0; subPaint();
        var args = ["-m", model, "-f", wav, "-l", "ru", "-ml", "1", "-sow", "-oj", "-of", outBase, "-np", "-pp"];
        if (process.platform === "win32") args.push("-t", String(Math.max(2, os.cpus().length - 1)));
        var ch = cp.spawn(bin, args, { cwd: path.dirname(bin) }), errTxt = "";
        ch.stderr.on("data", function (d) { var m = /progress\s*=\s*(\d+)%/.exec(String(d)); if (m) { var e = document.getElementById("whp"); if (e) e.style.width = m[1] + "%"; } else errTxt += d; });
        ch.on("close", function (code) {
          try {
            var j = JSON.parse(fs.readFileSync(outBase + ".json", "utf8")), words = [];
            j.transcription.forEach(function (s) { var t = String(s.text).trim(); if (t) words.push({ a: s.offsets.from / 1000, b: s.offsets.to / 1000, t: t }); });
            if (!words.length) throw new Error("в звуке не нашлось речи");
            seqInfo(function (o) { subState.phrases = toPhrases(words, subW || (o === "h" ? 7 : 4), o === "h" ? 36 : 22); subState.phase = ""; subPaint(); });
          } catch (e) { subState.phase = ""; subState.err = "Распознавание не удалось (" + code + "): " + (e.message || "") + " " + errTxt.slice(-200); subPaint(); }
        });
      });
    });
  }
  // правленый текст фраз живёт в полях ввода: забираем его перед перерисовкой, иначе выбор стиля или шрифта его сотрёт
  function subKeep() {
    var ph = subState.phrases, ins = document.querySelectorAll(".phr input"); if (!ph || ins.length !== ph.length) return;
    for (var i = 0; i < ins.length; i++) { var v = ins[i].value.trim(); if (v !== ph[i].t) { if (v.split(/\s+/).length !== ph[i].t.split(/\s+/).length) ph[i].w = ""; ph[i].t = v; } }
  }
  function subsCreate() {
    var ph = subState.phrases; if (!ph) return;
    subKeep();
    var data = ph.filter(function (p) { return p.t; }).map(function (p) { return [p.a.toFixed(3), p.b.toFixed(3), p.t, p.w].join("\u0002"); }).join("\u0001");
    say("ok|Ставлю субтитры…"); run("kk_subs2", [sub, data, font ? font.p : ""], say);
  }
  /* ---------- шрифт субтитров: любой с компьютера или из Adobe Fonts; пусто — как задумано в стиле ---------- */
  var FONTS = null, fontOpen = false, fontBusy = false, fontQ = "", fontCyr = true, font = null, fontIO = null, fontSeen = {};
  try { font = JSON.parse(ls("kk-sub-font") || "null"); } catch (e) {}
  function fontSet(f) { font = f; ls("kk-sub-font", f ? JSON.stringify(f) : null); }
  function fontScan() { if (fontBusy) return; fontBusy = true; KKFonts.scan(function (l) { FONTS = l; fontBusy = false; fontSeen = {}; subPaint(); }); }
  function fontFam() { if (!font || !FONTS) return null; for (var i = 0; i < FONTS.length; i++) if (FONTS[i].n === font.n) return FONTS[i]; return null; }
  function fontLoad(i, el) {
    if (!fontSeen[i]) { fontSeen[i] = 1; try { new FontFace("kkf" + i, 'url("' + KKFonts.url(FONTS[i].file) + '")').load().then(function (x) { document.fonts.add(x); }).catch(function () {}); } catch (e) {} }
    el.style.fontFamily = '"kkf' + i + '",sans-serif';
  }
  function fontPaint() {
    var box = document.getElementById("fl"); if (!box || !FONTS) return;
    var q = fontQ.trim().toLowerCase(), l = FONTS.map(function (F, i) { return [F, i]; }).filter(function (x) { return (!fontCyr || x[0].c) && (!q || x[0].n.toLowerCase().indexOf(q) >= 0); });
    document.getElementById("fn").textContent = l.length + " из " + FONTS.length;
    box.innerHTML = '<button class="frow' + (font ? "" : " on") + '" data-ff="-1"><b>Как в стиле</b><small>у каждого стиля свой шрифт</small></button>' +
      l.map(function (x) { var F = x[0]; return '<button class="frow' + (font && font.n === F.n ? " on" : "") + '" data-ff="' + x[1] + '"><b data-fp="' + x[1] + '">' + (F.c ? "Покажу классный приём" : "Quick brown fox") + '</b><small>' + esc(F.n) + (F.faces.length > 1 ? " · начертаний: " + F.faces.length : "") + (F.c ? "" : " · без кириллицы") + '</small></button>'; }).join("") +
      (l.length ? "" : '<p class="note">Такого шрифта не нашлось</p>');
    if (fontIO) fontIO.disconnect();
    fontIO = new IntersectionObserver(function (es) { es.forEach(function (e) { if (e.isIntersecting) { fontLoad(+e.target.dataset.fp, e.target); fontIO.unobserve(e.target); } }); }, { root: box, rootMargin: "200px" });
    Array.prototype.forEach.call(box.querySelectorAll("[data-fp]"), function (e) { fontIO.observe(e); });
  }
  function fontSec() {
    var F = fontFam();
    return '<div class="sec"><h3>Шрифт</h3><button class="btn fpick" data-fopen="1"><span><b>' + (font ? esc(font.n) : "Как в стиле") + '</b><small>' + (font ? esc(font.s) : "можно выбрать свой: с компьютера или из Adobe Fonts") + '</small></span><i>' + (fontOpen ? "▴" : "▾") + '</i></button>' +
      (fontOpen ? (FONTS ? '<input class="tin" id="fq" placeholder="Поиск по названию" value="' + esc(fontQ) + '"><div class="fopt"><label><input type="checkbox" id="fcyr"' + (fontCyr ? " checked" : "") + '> только с кириллицей</label><span id="fn"></span></div><div class="flist" id="fl"></div>' : '<p class="note">Ищу шрифты на компьютере…</p>') : "") +
      (F && F.faces.length > 1 ? '<div class="tabs" style="padding:0;border:0">' + F.faces.map(function (x) { return '<button class="' + (x.p === font.p ? "on" : "") + '" data-fs="' + esc(x.p) + '">' + esc(x.s) + '</button>'; }).join("") + '</div>' : "") +
      (font ? '<button class="btn" data-fapply="1">Сменить шрифт у выделенных субтитров<small>выдели их на таймлайне и нажми</small></button>' : "") +
      '<p class="note">Шрифт встанет во все новые субтитры. Только что установленный шрифт Премьер увидит после перезапуска, а из Adobe Fonts — сразу.</p></div>';
  }
  function fmtT(s) { var m = Math.floor(s / 60), x = (s % 60).toFixed(1); return m + ":" + (x < 10 ? "0" : "") + x; }

  try { var SJ = JSON.parse(require("fs").readFileSync(extDir() + "/mogrt/subs.json", "utf8")); if (SJ && SJ.length) SUBS = SJ.map(function (x) { return [x.id, x.name, x.desc, x.group]; }); } catch (e) {}
  var TITLES = [["headline", "Заголовок", "Заголовки"], ["quote", "Цитата", "Кино"], ["nick", "Ник", "Плашки"], ["subscribe", "Подпишись", "Призывы"]], titleGroup = "Все", TGROUPS = [];
  try { var TJ = JSON.parse(require("fs").readFileSync(extDir() + "/mogrt/titles.json", "utf8")); if (TJ && TJ.length) TITLES = TITLES.concat(TJ.map(function (x) { return [x.id, x.name, x.group]; })); } catch (e) {}
  TITLES.forEach(function (t) { if (TGROUPS.indexOf(t[2]) < 0) TGROUPS.push(t[2]); });
  var TABS = {
    "Текст": function () {
      return '<div class="sec"><h3>Где</h3><div class="row"><div class="seg" id="side"><button data-s="in" class="' + (side === "in" ? "on" : "") + '">Появление</button><button data-s="out" class="' + (side === "out" ? "on" : "") + '">Исчезновение</button></div></div>' +
        '<div class="row"><span>Длительность</span><input type="range" id="dur" min="0.2" max="1.2" step="0.1" value="' + dur + '"><b id="durv">' + dur + ' с</b></div></div>' +
        '<div class="sec"><h3>Анимации · ' + ANIMS.length + '</h3>' + chips() + '<div class="grid">' + byGrp(ANIMS, 2).map(function (a) { var pv = a[3] || ({ pop: 1, zoom: 1, fadeUp: 1, slide: 1, drop: 1, shake: 1, blink: 1 }[a[0]] ? a[0] : (/blur|fade/.test(a[0]) ? 'fadeUp' : /slide|whip/.test(a[0]) ? 'slide' : /drop|rise|elastic|rubber|squash|swing/.test(a[0]) ? 'drop' : /glitch/.test(a[0]) ? 'shake' : 'pop')); return '<button class="card" data-anim="' + a[0] + '"><span class="spr" style="background-image:url(prev/mt/a-' + a[0] + '.jpg)"></span>' + a[1] + '</button>'; }).join("") + '</div>' +
        '<p class="note">Выдели клип, текст или графику на таймлайне и нажми анимацию. Работает и с видео. Отменить: Cmd/Ctrl+Z.</p></div>' +
        '<div class="sec"><h3>Готовые титры</h3><input id="ttxt" class="tin" placeholder="Свой текст (можно оставить пустым)" value="' + (ttxt || "").replace(/"/g, "&quot;") + '">' +
        '<div class="tabs" style="padding:0;border:0">' + ["Все"].concat(TGROUPS).map(function (g) { return '<button class="' + (g === titleGroup ? "on" : "") + '" data-tgr="' + g + '">' + g + '</button>'; }).join("") + '</div>' +
        '<div class="grid subs">' + TITLES.filter(function (t) { return titleGroup === "Все" || t[2] === titleGroup; }).map(function (t) { return '<button class="card" data-title="' + t[0] + '"><img src="prev/title-' + t[0] + '.png" onerror="this.style.display=\'none\'" alt="" style="aspect-ratio:9/16;object-fit:cover">' + t[1] + '</button>'; }).join("") + '</div>' +
        '<p class="note">Титр встанет на плейхед на свободную дорожку. Текст в шаблоне — только пример: свой текст, цвета и размер меняешь сама — выдели титр на таймлайне → «Элементы управления эффектами» → «Параметры графики» (то же есть в «Окно → Основные графические элементы»).</p></div>';
    },
    "Эффекты": function () {
      return '<div class="sec"><h3>Необычные эффекты на клип · ' + FXS.length + '</h3>' + chips() + '<div class="grid">' + byGrp(FXS, 2).map(function (f) { return '<button class="card" data-fx2="' + f[0] + '"' + (f[4] ? ' title="' + esc(f[4]) + '"' : '') + '><span class="spr" style="background-image:url(prev/mt/f-' + f[0] + '.jpg)"></span>' + f[1] + '</button>'; }).join("") + '</div>' +
        '<p class="note">Выдели клип и нажми эффект: фокус и тилт-шифт, рыбий глаз, 3D, RGB-разлом, калейдоскоп, воронка, свечение, сбой… Настройки потом можно подкрутить в «Элементах управления эффектами». Часть эффектов есть только в новых версиях Премьера — плагин скажет, если эффекта нет.</p></div>';
    },
    "Плавность": function () {
      return '<div class="sec"><h3>На выделенные ключи · ' + EASES.length + '</h3>' + chips() + '<div class="list">' + byGrp(EASES, 3).map(function (e) { return '<button class="btn ez" data-ease="' + e[0] + '">' + curveSvg(e[0]) + '<span>' + e[1] + '<small>' + e[2] + '</small></span></button>'; }).join("") + '</div>' +
        '<p class="note">Поставь хотя бы два ключа (позиция, масштаб, поворот, непрозрачность), выдели клип и выбери плавность. Плагин сам рассчитает движение по кривой.</p></div>';
    },
    "Камера": function () {
      return '<div class="sec"><h3>Движение кадра · ' + CAM.length + '</h3>' + chips() + '<div class="list">' + byGrp(CAM, 3).map(function (e) { return '<button class="btn camb" data-cam="' + e[0] + '"><span class="spr cam" style="background-image:url(prev/mt/c-' + e[0] + '.jpg)"></span>' + e[1] + (e[2] ? '<small>' + e[2] + '</small>' : "") + '</button>'; }).join("") + '</div>' +
        '<p class="note">«3D-экран» — для записи экрана телефона или компьютера (и любого клипа): кадр наклоняется в 3D, а камера летает над ним. Варианты «карточкой» оставляют вокруг экрана фон — положи под клип фон, цвет или размытую копию. Горизонтальную запись в вертикальном ролике лучше делать «карточкой»: варианты без чёрных углов её сильно увеличат. Углы и размытие потом можно подкрутить: «Базовый 3D» и «Размытие фокусировки» в «Элементах управления эффектами».</p></div>';
    },
    "Исправить": function () {
      return '<div class="sec"><h3>Частые ошибки</h3><div class="list">' +
        '<button class="btn" data-fix="stab">Стабилизировать без рамок<small>Стабилизатор деформации с обрезкой и автомасштабом</small></button>' +
        '<button class="btn" data-fix="frames">Убрать чёрные рамки<small>растянуть кадр на весь экран секвенции</small></button>' +
        '<button class="btn" data-fix="slow50">Слоумо 50%<small>оптический поток — плавно, без рывков</small></button>' +
        '<button class="btn" data-fix="slow25">Слоумо 25%<small>для съёмки 100–120 кадров — идеально, для 25–30 — мягче с оптическим потоком</small></button>' +
        '<button class="btn" data-acut="1">Мягкая склейка звука<small>плейхед на стык — убирает щелчок и «кривую» склейку</small></button>' +
        '</div><p class="note">Мерцание от ламп: смотри шпаргалку «Мерцание» в паке — лучше всего лечится настройкой выдержки при съёмке и эффектом в Премьере.</p></div>';
    },
    "Секвенция": function () {
      var row = function (fmt, label) { return '<div class="row">' + [25, 30].map(function (f) { return '<button class="btn" data-seq="' + fmt + '" data-fps="' + f + '">' + label + '<small>' + f + ' кадров</small></button>'; }).join("") + '</div>'; };
      return '<div class="sec"><h3>Вертикаль</h3>' + row("v", "9:16 · 1080×1920") + row("p45", "4:5 · 1080×1350") + '</div>' +
        '<div class="sec"><h3>Горизонталь</h3>' + row("h", "16:9 · 1920×1080") + row("h4k", "16:9 · 4K 3840×2160") + row("sq", "1:1 · 1080×1080") + '</div>' +
        '<p class="note">Все анимации, плавность и камера одинаково работают в любом формате. Скоро: сетка безопасных зон и пресеты экспорта под площадки.</p>';
    },
    "Субтитры": function () {
      var st = subState, groups = ["Все"]; SUBS.forEach(function (t) { if (t[3] && groups.indexOf(t[3]) < 0) groups.push(t[3]); });
      var list = SUBS.filter(function (t) { return subGroup === "Все" || t[3] === subGroup; });
      var head = '<div class="sec"><h3>Автосубтитры · русский</h3>' +
        (st.phase ? '<div class="note" style="border-style:solid">' + st.phase + '<div class="bar"><i id="whp" style="width:' + st.pct + '%"></i></div><span id="wht"></span></div>'
        : st.phrases ? '<div class="phr">' + st.phrases.map(function (p, i) { return '<label><span>' + fmtT(p.a) + '</span><input value="' + p.t.replace(/"/g, "&quot;") + '"></label>'; }).join("") + '</div>' +
          '<button class="btn y" data-subok="1">Создать субтитры · ' + st.phrases.length + ' фраз' + (font ? '<small style="color:inherit;opacity:.75">шрифт: ' + esc(font.n) + '</small>' : '') + '</button><button class="btn" data-subauto="1">Распознать заново</button>'
        : '<button class="btn y" data-subauto="1">Распознать речь и сделать субтитры<small style="color:inherit;opacity:.75">звук всей секвенции → текст с точностью до слова</small></button>') +
        (st.err ? '<p class="note" style="color:var(--bad)">' + st.err + '</p>' : '') + '</div>';
      return head + fontSec() +
        '<div class="sec"><h3>Стиль · ' + SUBS.length + '</h3><div class="tabs" style="padding:0;border:0">' + groups.map(function (g) { return '<button class="' + (g === subGroup ? "on" : "") + '" data-subg="' + g + '">' + g + '</button>'; }).join("") + '</div>' +
        '<div class="grid subs">' + list.map(function (t) { return '<button class="card' + (sub === t[0] ? ' on' : '') + '" data-sub="' + t[0] + '" title="' + t[2] + '"><img src="prev/subs-' + t[0] + '.png" onerror="this.style.display=\'none\'" alt="">' + t[1] + '</button>'; }).join("") + '</div></div>' +
        '<div class="sec"><h3>Слов в одной фразе</h3><div class="row"><input type="range" id="sw" min="0" max="10" step="1" value="' + subW + '"><b id="swv">' + (subW || "авто") + '</b></div></div>' +
        '<p class="note">Распознавание идёт прямо на компьютере, без интернета (интернет нужен один раз — скачать модель). Перед созданием можно поправить текст фраз. Цвет текста и акцента, обводку, тень, плашку, размер и положение меняй как в CapCut: выдели субтитр → «Элементы управления эффектами» → «Параметры графики» (или «Окно → Основные графические элементы»).</p>' +
        '<details><summary class="note" style="cursor:pointer">Есть готовый файл SRT?</summary><button class="btn" data-subgo="1">Выбрать SRT и создать субтитры</button></details>';
    },
    "Переходы": function () {
      return '<div class="sec"><h3>Длина</h3><div class="row"><input type="range" id="trf" min="4" max="16" step="1" value="' + trf + '"><b id="trfv">' + trf + ' кадров</b></div></div>' +
        '<div class="sec"><h3>На стык двух клипов · ' + TRANS.length + '</h3>' + chips() + '<div class="grid">' + byGrp(TRANS, 2).map(function (t) { return '<button class="card" data-tr="' + t[0] + '"><span class="spr" style="background-image:url(prev/mt/t-' + t[0] + '.jpg)"></span>' + t[1] + '</button>'; }).join("") + '</div>' +
        '<p class="note">Поставь плейхед точно на стык (клавиши ↑ ↓ прыгают по склейкам) и нажми переход. Плагин сам анимирует конец первого клипа и начало второго, со смазом движения. Работает в вертикали и горизонтали.</p></div>';
    },
    "Наборы": function () {
      if (!LIB) { loadLib(); return '<p class="note">Загружаю библиотеку наборов…</p>'; }
      if (LIB.error) return '<p class="note">Не получилось загрузить библиотеку: ' + LIB.error + '</p>';
      var st = LIB.styles[libStyle] || LIB.styles[Object.keys(LIB.styles)[0]], items = st[libKind] || []; if (!items.length) { var kk2 = ["an", "png", "pin", "ov", "bg", "tr", "tx", "sfx"]; for (var q = 0; q < kk2.length; q++) if ((st[kk2[q]] || []).length) { libKind = kk2[q]; items = st[libKind]; break; } } // у «Футажей» и «Текстур» не все виды
      var grp = []; items.forEach(function (it) { if (it.group && grp.indexOf(it.group) < 0) grp.push(it.group); }); if (grp.length > 1 && grp.indexOf(libGroup) < 0) libGroup = grp[0]; // категории, как у «Футажей»: по одной на экран
      var GT = grp.length > 1 ? '<div class="tabs" style="padding:0;border:0">' + grp.map(function (g) { var n = items.filter(function (it) { return it.group === g; }).length; return '<button class="' + (g === libGroup ? "on" : "") + '" data-lgr="' + g + '">' + g + ' · ' + n + '</button>'; }).join("") + '</div>' : "";
      var kinds = [["png", "PNG дефолт"], ["pin", "PNG из Pinterest"], ["an", "Анимации"], ["tr", "Переходы"], ["ov", "Оверлеи"], ["bg", "Фоны"], ["tx", "Плашки"], ["sfx", "Звуки"]];
      return '<div class="sec"><h3>Стиль</h3><div class="tabs" style="padding:0;border:0">' + Object.keys(LIB.styles).filter(function (k) { return k !== "cut"; }).map(function (k) { return '<button class="' + (k === libStyle ? "on" : "") + '" data-ls="' + k + '">' + LIB.styles[k].name + '</button>'; }).join("") + '</div>' +
        '<div class="tabs" style="padding:0;border:0">' + kinds.map(function (k) { return '<button class="' + (k[0] === libKind ? "on" : "") + '" data-lk="' + k[0] + '">' + k[1] + '</button>'; }).join("") + '</div>' + GT + '</div>' +
      (libKind === "pin" && PQ[libStyle] ? '<p class="note"><a href="#" data-pq="' + PQ[libStyle] + '" style="color:var(--acc,#FFAD05)">Ещё больше в Pinterest: поиск «' + PQ[libStyle] + '» ↗</a> — трендовые PNG без фона, сохраняй себе</p>' : "") +
        '<div class="grid lib">' + items.map(function (it, i) { if (grp.length > 1 && it.group !== libGroup) return ""; var pv = LIB.base + libStyle + "/" + it.prev, vid = /\.mp4$/.test(it.prev);
          return '<button class="card" data-li="' + i + '" title="' + it.name + '">' + (libKind === "sfx" ? '<span class="snd">♪</span>' : vid ? '<video src="' + pv + '" muted loop playsinline preload="none" style="width:100%;border-radius:4px"></video>' : '<img src="' + pv + '" loading="lazy" style="width:100%;height:70px;object-fit:contain">') + '<span>' + it.name + '</span>' + (CFGK[libKind] && libStyle !== "cut" ? '<span class="cfg" data-cfg="' + i + '" title="Свои цвета, надписи, картинка, скорость">⚙ Настроить</span>' : '') + '</button>'; }).join("") + '</div>' +
        '<p class="note">Нажми — плагин скачает файл и поставит на плейхед. Переход встанет серединой на склейку, оверлей — с режимом «Экран», фон — на нижнюю дорожку. Вертикальная или горизонтальная версия выбирается по секвенции. Файлы сохраняются в «Документы / КК Наборы». «⚙ Настроить» — свои цвета, надписи, картинка вместо значка и скорость.</p>';
    }
  };
  var cur = "Текст";
  /* ---------- библиотека наборов ---------- */
  var PQ = {ios:"ios core png",retro:"retro aesthetic png",anime:"anime stickers png",doodle:"doodle stickers png",tech:"tech core png",future:"chrome 3d png",y2k:"y2k png stickers",romance:"coquette png",scrap:"scrapbook png",lux:"old money aesthetic png",cinema:"cinema aesthetic png",expert:"3d business icons png",grunge:"grunge png",eco:"nature aesthetic png",kk:"editing aesthetic png",season:"seasonal stickers png"}; // поиск в Pinterest под стиль
  var LIB = null, libStyle = "kk", libKind = "png", libGroup = "";
  function loadLib() {
    fetch("https://kodkreatora.bybusha.com/pack/manifest.json?t=" + Date.now()).then(function (r) { return r.json(); })
      .then(function (m) { LIB = m; if (!LIB.styles[libStyle]) libStyle = Object.keys(LIB.styles)[0]; if (cur === "Наборы") render(); })
      .catch(function (e) { LIB = { error: e.message }; if (cur === "Наборы") render(); });
  }
  function seqInfo(cb) { run("kk_fmt", [], cb); }
  function cachePath(style, rel) {
    var path = require("path"), os = require("os");
    return path.join(os.homedir(), "Documents", "КК Наборы", style, rel);
  }
  function download(url, file, done) {
    var fs = require("fs"), path = require("path"), https = require("https");
    if (fs.existsSync(file) && fs.statSync(file).size > 0) return done(null);
    mkdirp(path.dirname(file));
    var tmp = file + ".part";
    (function get(u, n) { https.get(u, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && n < 6) { res.resume(); return get(res.headers.location, n + 1); }
      if (res.statusCode !== 200) { res.resume(); return done(new Error("HTTP " + res.statusCode)); }
      var out = fs.createWriteStream(tmp); res.pipe(out); out.on("finish", function () { out.close(function () { fs.renameSync(tmp, file); done(null); }); });
    }).on("error", done); })(url, 0);
  }
  /* ---------- «Настроить»: свои цвета, надписи, картинка вместо значка, скорость. Кадры рисует движок наборов прямо в панели,
     складывает PNG-последовательностью в «Документы / КК Наборы / Мои» и ставит на таймлайн ---------- */
  var CFGK = { an: 1, tr: 1, ov: 1, bg: 1, tx: 1 };
  function editItem(i) {
    var it = LIB.styles[libStyle][libKind][i], kind = libKind, style = libStyle;
    seqInfo(function (fmt) {
      KKEDIT.open(document.getElementById("view"), { base: ls("kke_base") || "https://kodkreatora.bybusha.com/pack/engine/", style: style, kind: kind, id: it.id, name: it.name, fmt: fmt || "v", act: "Вставить на таймлайн",
        note: "Твоя версия сохранится в «Документы / КК Наборы / Мои». Цвета, надписи и картинку можно поменять и вставить ещё раз.",
        onBack: render,
        onAct: function (st, msg) { return new Promise(function (ok) {
          if (!fmt) { msg("Открой секвенцию"); return ok(); }
          var fs = require("fs"), path = require("path"), black = kind === "ov" && !it.files["mov_" + fmt];
          var dir = cachePath("Мои", style + "-" + it.id + "-" + (kind === "an" || kind === "tx" ? "" : fmt) + KKEDIT.sig(st)), first = null, still = false;
          var place = function () { run("kk_insert", [first, kind, kind === "bg" ? 5 : 3, black ? "screen" : "", still ? "" : String(KKE.FPS)], function (r) { say(r); msg(r.split("|")[1] || r); ok(); }); };
          if (fs.existsSync(path.join(dir, "ok.txt"))) { first = fs.readFileSync(path.join(dir, "ok.txt"), "utf8"); still = /still\.png$/.test(first); msg("Вставляю…"); return place(); }
          mkdirp(dir); msg("Рисую кадры…");
          KKEDIT.render(st, fmt, function (n, cv, F) {
            still = !!F.still; var f = path.join(dir, still ? "still.png" : "f_" + ("000" + n).slice(-4) + ".png"); if (!n) first = f;
            fs.writeFileSync(f, Buffer.from(cv.toDataURL("image/png").split(",")[1], "base64")); if (!still && n % 6 === 0) msg("Рисую кадры… " + Math.round(n * 100 / F.n) + "%");
          }, black ? "#000" : "").then(function () { fs.writeFileSync(path.join(dir, "ok.txt"), first); msg("Вставляю…"); place(); })
            .catch(function (e) { msg("Не получилось: " + e.message); ok(); });
        }); }
      });
    });
  }
  function insertItem(i) {
    var it = LIB.styles[libStyle][libKind][i]; say("ok|Скачиваю «" + it.name + "»…");
    seqInfo(function (o) {
      if (!o) { say("err|Открой секвенцию"); return; }
      var f = it.files, key = libKind === "sfx" ? f.wav : libKind === "png" || libKind === "pin" ? f.png : libKind === "tx" ? f.png : libKind === "an" ? f.mov : libKind === "bg" ? f[o] : libKind === "tr" ? f["mov_" + o] : (f["mov_" + o] || f["black_" + o]);
      var blend = libKind === "ov" && !f["mov_" + o] ? "screen" : "";
      if (!key) { say("err|Для этого формата нет файла"); return; }
      var url = key, file = cachePath(libStyle, decodeURIComponent(url.split("/").pop()).replace(/__/g, "/"));
      download(url, file, function (err) {
        if (err) { say("err|Не скачалось: " + err.message); return; }
        if (libKind === "sfx") { run("km_sound", [file], say); return; }
        var tex = libStyle === "tex" && libKind === "bg"; // текстура — поверх видео, режим наложения выбирает автор
        run("kk_insert", [file, tex ? "ov" : libKind === "pin" ? "png" : libKind, libKind === "bg" ? 5 : 3, blend], function (r) { say(tex && r.indexOf("ok") === 0 ? r + ". Режим наложения: «Умножение» или «Перекрытие», непрозрачность 20–60 %" : r); });
      });
    });
  }
  function render() {
    document.getElementById("tabs").innerHTML = Object.keys(TABS).map(function (k) { return '<button class="' + (k === cur ? "on" : "") + '" data-tab="' + k + '">' + k + '</button>'; }).join("");
    subKeep();
    document.getElementById("view").innerHTML = TABS[cur]();
    fontPaint();
    var fq = document.getElementById("fq");
    if (fq) fq.oninput = function () { fontQ = fq.value; fontPaint(); };
    var fc = document.getElementById("fcyr");
    if (fc) fc.onchange = function () { fontCyr = fc.checked; fontPaint(); };
    var r = document.getElementById("dur");
    if (r) r.oninput = function () { dur = +r.value; document.getElementById("durv").textContent = dur + " с"; };
    var sw = document.getElementById("sw");
    if (sw) sw.oninput = function () { subW = +sw.value; document.getElementById("swv").textContent = subW; };
    var tf = document.getElementById("trf");
    if (tf) tf.oninput = function () { trf = +tf.value; document.getElementById("trfv").textContent = trf + " кадров"; };
  }
  document.addEventListener("mouseover", function (ev) { var v = ev.target.closest(".card") && ev.target.closest(".card").querySelector("video"); if (v && v.paused) v.play().catch(function () {}); });
  document.addEventListener("click", function (ev) {
    var cf = ev.target.closest("[data-cfg]"); if (cf && LIB) { ev.preventDefault(); editItem(+cf.dataset.cfg); return; }
    var b = ev.target.closest("button,a[data-pq]"); if (!b) return; if (b.dataset.pq) ev.preventDefault();
    if (b.dataset.tab) { cur = b.dataset.tab; render(); return; }
    if (b.dataset.fopen) { fontOpen = !fontOpen; if (fontOpen) fontScan(); render(); return; }
    if (b.dataset.ff !== undefined) { var fi = +b.dataset.ff, FF = FONTS[fi]; fontSet(fi < 0 ? null : { n: FF.n, p: FF.reg.p, s: FF.reg.s }); fontOpen = false; render(); return; }
    if (b.dataset.fs) { var ffam = fontFam(); ffam.faces.forEach(function (x) { if (x.p === b.dataset.fs) fontSet({ n: ffam.n, p: x.p, s: x.s }); }); render(); return; }
    if (b.dataset.fapply) { run("kk_subsFont", [font.p], say); return; }
    if (b.dataset.ls) { libStyle = b.dataset.ls; var st0 = LIB.styles[libStyle]; if (st0 && !(st0[libKind] || []).length) { var ks = ["png", "an", "tr", "ov", "bg", "tx"]; for (var q = 0; q < ks.length; q++) if ((st0[ks[q]] || []).length) { libKind = ks[q]; break; } } render(); return; }
    if (b.dataset.pq) { var url = "https://www.pinterest.com/search/pins/?q=" + encodeURIComponent(b.dataset.pq); try { window.cep.util.openURLInDefaultBrowser(url); } catch (x) { window.open(url); } return; }
    if (b.dataset.lk) { libKind = b.dataset.lk; render(); return; }
    if (b.dataset.lgr) { libGroup = b.dataset.lgr; render(); return; }
    if (b.dataset.li !== undefined && LIB) { insertItem(+b.dataset.li); return; }
    if (b.dataset.s) { side = b.dataset.s; render(); return; }
    if (b.dataset.grp) { grp[cur] = b.dataset.grp; render(); return; }
    if (b.dataset.anim) run("kk_anim2", [b.dataset.anim, side, dur], say);
    else if (b.dataset.ease) run("kk_ease", [b.dataset.ease], say);
    else if (b.dataset.sub) { sub = b.dataset.sub; render(); return; }
    else if (b.dataset.subauto) { autoSubs(); return; }
    else if (b.dataset.subok) { subsCreate(); return; }
    else if (b.dataset.subg) { subGroup = b.dataset.subg; render(); return; }
    else if (b.dataset.subgo) { say("ok|Выбери файл…"); run("kk_subs", [sub, "", subW, font ? font.p : ""], say); }
    else if (b.dataset.tgr) { titleGroup = b.dataset.tgr; render(); return; }
    else if (b.dataset.title) { ttxt = (document.getElementById("ttxt") || {}).value || ""; run("kk_title", [b.dataset.title, ttxt, 3], say); }
    else if (b.dataset.tr) run("kk_trans2", [b.dataset.tr, trf], say);
    else if (b.dataset.fx2) run("kk_fx2", [b.dataset.fx2], say);
    else if (b.dataset.cam) run("kk_camera", [b.dataset.cam], say);
    else if (b.dataset.fix) run("kk_fix", [b.dataset.fix], say);
    else if (b.dataset.acut) run("kk_audioCut", [3], say);
    else if (b.dataset.seq) run("kk_newSeq", [b.dataset.seq, +b.dataset.fps], say);
  });
  /* ---------- доступ по ключу из приложения КК ---------- */
  var ID = "kk-montazh", API = "https://script.google.com/macros/s/AKfycbw2LmiS_HoOdrIQko16UGsLNQj6T1Br2BymAb2bh8_iHPxOB8QyVgbiZ0vuPcwhHCPwyQ/exec", SITE = "https://kodkreatora.bybusha.com";
  var OFFLINE_DAYS = 30;
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { return null; } }
  function api(body) { return fetch(API, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify(body) }).then(function (r) { return r.json(); }); }
  var ERR = { bad_key: "Ключ не подошёл. Скопируй его заново в приложении КК.", not_student: "Доступ только для учениц программы КОД КРЕАТОРА.", expired: "Доступ к программе закончился.", soon: "Плагин скоро откроется ученицам." };
  function loginView(msg) {
    document.getElementById("tabs").innerHTML = "";
    document.getElementById("view").innerHTML = '<div class="login"><b style="font-size:14px">Вход в плагин</b>' +
      '<span class="note">Открой приложение КК → «Полезные материалы» → «Пак режиссёра монтажа» → плагин → «Получить ключ». Скопируй ключ и вставь сюда.</span>' +
      '<input id="key" placeholder="KK-…" autocomplete="off"><button class="btn y" id="go">Войти</button>' + (msg ? '<span class="note" style="color:#ff6b5b">' + msg + '</span>' : "") + '</div>';
    document.getElementById("go").onclick = function () { var k = document.getElementById("key").value.trim(); if (k) check(k, true); };
  }
  function enter(u) { document.getElementById("who").textContent = (u.n || "") + (u.u ? " · @" + u.u : ""); render(); checkUpdate(); }
  function check(key, interactive) {
    api({ api: "plugincheck", key: key }).then(function (r) {
      if (r.ok) { ls("kk_key", key); ls("kk_ok_at", String(Date.now())); ls("kk_user", JSON.stringify(r)); sharedWrite({ key: key, at: Date.now(), user: r }); enter(r); }
      else { if (r.error !== "soon" || interactive) { ls("kk_key", null); if (r.error === "bad_key" || r.error === "not_student" || r.error === "expired") sharedClear(); } loginView(ERR[r.error] || "Не получилось войти: " + (r.error || "")); }
    }).catch(function () {
      var sh = sharedRead() || {}, at = Math.max(+ls("kk_ok_at") || 0, sh.at || 0), u = ls("kk_user") || (sh.user ? JSON.stringify(sh.user) : null);
      if (!interactive && u && Date.now() - at < OFFLINE_DAYS * 864e5) enter(JSON.parse(u)); // без интернета — 30 дней по сохранённому входу
      else loginView("Нет интернета: для первого входа он нужен.");
    });
  }

  /* ---------- файлы: свои помощники — в старых Премьерах (Node 8) нет mkdirSync({recursive}) и rmSync ---------- */
  function mkdirp(d) { var fs = require("fs"), path = require("path"); if (fs.existsSync(d)) return; mkdirp(path.dirname(d)); fs.mkdirSync(d); }
  function rmrf(d) { var fs = require("fs"), path = require("path"); if (!fs.existsSync(d)) return;
    if (fs.lstatSync(d).isDirectory()) { fs.readdirSync(d).forEach(function (n) { rmrf(path.join(d, n)); }); fs.rmdirSync(d); } else fs.unlinkSync(d); }
  function extDir() { // file:///C:/… на Windows и file:///Users/… на Mac
    var p = decodeURIComponent(String(cep.getSystemPath("extension")).replace(/^file:\/\//, ""));
    return /^\/[A-Za-z]:/.test(p) ? p.slice(1) : p;
  }
  /* общий ключ для всех плагинов КК: файл в домашней папке, его читают оба плагина */
  function sharedFile() { var path = require("path"), os = require("os"); return path.join(os.homedir(), ".kodkreatora", "plugin-key.json"); }
  function sharedRead() { try { return JSON.parse(require("fs").readFileSync(sharedFile(), "utf8")); } catch (e) { return null; } }
  function sharedWrite(o) { try { var f = sharedFile(); mkdirp(require("path").dirname(f)); require("fs").writeFileSync(f, JSON.stringify(o)); } catch (e) {} }
  function sharedClear() { try { require("fs").unlinkSync(sharedFile()); } catch (e) {} }
  /* ---------- обновления ---------- */
  function newer(a, b) { a = a.split(".").map(Number); b = b.split(".").map(Number); for (var i = 0; i < 3; i++) { if ((a[i] || 0) > (b[i] || 0)) return true; if ((a[i] || 0) < (b[i] || 0)) return false; } return false; }
  function checkUpdate() {
    fetch(SITE + "/plugin/version.json?t=" + Date.now()).then(function (r) { return r.json(); }).then(function (v) {
      var me = v[ID]; if (!me || !newer(me.v, VERSION)) return;
      var u = document.getElementById("upd"); u.hidden = false;
      u.innerHTML = '<span>Вышла версия ' + me.v + (me.notes ? ": " + me.notes : "") + '</span><button class="btn y" id="doupd" style="width:auto;padding:5px 10px">Обновить</button>';
      document.getElementById("doupd").onclick = function () { update(me); };
    }).catch(function () {});
  }
  function copyDir(src, dst) { // своё копирование: в старых Премьерах нет fs.cpSync
    var fs = require("fs"), path = require("path");
    if (!fs.existsSync(dst)) mkdirp(dst);
    fs.readdirSync(src).forEach(function (n) { var a = path.join(src, n), b = path.join(dst, n);
      if (fs.statSync(a).isDirectory()) copyDir(a, b); else fs.writeFileSync(b, fs.readFileSync(a)); });
  }
  function update(me) {
    var u = document.getElementById("upd");
    try {
      var https = require("https"), fs = require("fs"), path = require("path"), os = require("os"), cp = require("child_process");
      var dir = extDir();
      if (fs.lstatSync(dir).isSymbolicLink()) { u.innerHTML = "<span>Это версия разработчика — обновление не ставлю</span>"; return; }
      var zip = path.join(os.tmpdir(), ID + "-" + me.v + ".zip"), out = fs.createWriteStream(zip);
      u.innerHTML = "<span>Скачиваю обновление…</span>";
      var get = function (url) { https.get(url, function (res) { if (res.statusCode >= 300 && res.headers.location) return get(res.headers.location); res.pipe(out); out.on("finish", function () { out.close(unpack); }); }).on("error", function () { u.innerHTML = "<span>Не скачалось. Проверь интернет.</span>"; }); };
      var unpack = function () {
        var tmp = path.join(os.tmpdir(), ID + "-new"); try { rmrf(tmp); } catch (e) {}
        var cmd = process.platform === "win32" ? 'powershell -NoProfile -Command "Expand-Archive -Force \'' + zip + '\' \'' + tmp + '\'"' : 'ditto -x -k "' + zip + '" "' + tmp + '"';
        cp.exec(cmd, function (err) {
          if (err) { u.innerHTML = "<span>Не распаковалось: " + err.message + "</span>"; return; }
          var src = path.join(tmp, ID); if (!fs.existsSync(src)) src = tmp;
          try { copyDir(src, dir); u.innerHTML = "<span>Готово! Перезапусти Премьер, чтобы включилась версия " + me.v + "</span>"; }
          catch (e2) { u.innerHTML = "<span>Не получилось заменить файлы: " + e2.message + "</span>"; }
        });
      };
      get(me.zip);
    } catch (e) { u.innerHTML = "<span>Обновление недоступно: " + e.message + "</span>"; }
  }

  document.getElementById("ver").textContent = "v" + VERSION;
  try { run("kk_setDir", [extDir()], function () { loadLists(); }); } catch (e) {}
  run("kk_ping", [], function (r) { var p = r.split("|"); if (p[0] !== "ok") document.getElementById("who").textContent = "нет связи с Premiere"; });
  var saved = ls("kk_key") || (sharedRead() || {}).key; // вошла в одном плагине КК — остальные открываются сами
  if (saved) check(saved, false); else loginView();
})();

/* КК · Монтаж — интерфейс панели. Вызывает функции из jsx/host.jsx через CEP evalScript. */
(function () {
  var VERSION = "1.2.1";
  var cep = window.__adobe_cep__;
  function run(fn, args, cb) {
    var call = fn + "(" + (args || []).map(function (a) { return JSON.stringify(a); }).join(",") + ")";
    if (!cep) { cb && cb("err|Открой панель внутри Premiere Pro"); return; }
    cep.evalScript(call, function (r) { cb && cb(String(r || "")); });
  }
  function say(r) {
    var m = document.getElementById("msg"), p = String(r).split("|");
    m.className = p[0] === "ok" ? "ok" : "err"; m.textContent = p.slice(1).join(" ") || r;
    clearTimeout(say.t); say.t = setTimeout(function () { m.textContent = ""; }, 6000);
  }
  var ttxt = "", dur = 0.4, side = "in", trf = 8, sub = "kk-word", subW = 0;
  var SUBS = [["kk-word", "КК · активное слово", "белый текст, сказанное слово — цветом акцента"], ["pop-word", "Поп по словам", "слова выскакивают по одному, капс"], ["word-by-word", "Слово за словом", "фраза набирается по словам"], ["karaoke", "Караоке", "цвет заливает текст по ходу речи"], ["caps-stroke", "Капс с обводкой", "крупно и жирно, как у блогеров"], ["kk-plate", "КК · плашка", "текст на цветной плашке"], ["typewriter", "Печатная машинка", "по буквам, моноширинный"], ["minimal", "Минимал", "тонкий шрифт и мягкая тень"]];
  var TRANS = [["zoom", "Зум-рывок", "zoom"], ["whipL", "Смаз влево", "slide"], ["whipR", "Смаз вправо", "slide"], ["spin", "Вращение", "pop"], ["stretch", "Растягивание", "zoom"], ["shake", "Тряска", "shake"], ["dip", "Затемнение", "blink"]];

  var ANIMS = [["pop", "Pop"], ["fadeUp", "Подъём"], ["slide", "Выезд"], ["zoom", "Из точки"], ["drop", "Отскок"], ["shake", "Дрожь"], ["blink", "Мигание"]];
  var FXS = [];
  function parseList(r) { return String(r || "").indexOf("err") === 0 || !r ? null : String(r).split(";").map(function (x) { var i = x.indexOf(":"); return [x.slice(0, i), x.slice(i + 1)]; }); }
  function loadLists() {
    run("kk_animList", [], function (r) { var l = parseList(r); if (l && l.length) { ANIMS = l; if (cur === "Текст") render(); } });
    run("kk_transList", [], function (r) { var l = parseList(r); if (l && l.length) { TRANS = l.map(function (t) { return [t[0], t[1], "zoom"]; }); if (cur === "Переходы") render(); } });
    run("kk_fxList", [], function (r) { var l = parseList(r); if (l && l.length) { FXS = l; if (cur === "Эффекты") render(); } });
  }
  var EASES = [["inOutCubic", "Плавно", "мягкий разгон и мягкое торможение"], ["outCubic", "Резкий старт", "быстро начинается, мягко останавливается"], ["inCubic", "Резкий финиш", "мягко стартует, быстро доезжает"], ["ios", "Как в iOS", "быстро и очень мягкая остановка"], ["outBack", "Пружина", "небольшой перелёт и возврат"], ["outBounce", "Отскок", "как мячик"], ["outElastic", "Резинка", "несколько колебаний"], ["inOutQuint", "Кино-плавно", "очень мягкий разгон и остановка"], ["inOutSine", "Мягкая волна", "самая деликатная плавность"], ["outExpo", "Выстрел", "мгновенный старт и долгий доезд"], ["inExpo", "Разгон", "медленно, а в конце рывок"], ["outCirc", "Скольжение", "как по льду"], ["inOutBack", "Замах и пружина", "отходит назад, перелетает и возвращается"], ["linear", "Линейно", "убрать плавность"], ["hold", "Стоп-кадр", "ключи без перехода"]];
  var CAM = [["zoomIn", "Наезд", "медленное приближение на весь клип"], ["zoomOut", "Отъезд", "медленное отдаление"], ["push", "Толчок", "быстрый наезд в начале"], ["crash", "Крэш-зум", "резкий влёт в конце клипа"], ["steps", "Ступенчатый зум", "зум рывками в бит"], ["vertigo", "Головокружение", "медленный отъезд как в триллере"], ["breathe", "Дыхание кадра", "лёгкая пульсация масштаба"], ["panL", "Панорама влево", "плавный проезд"], ["panR", "Панорама вправо", "плавный проезд"], ["tiltU", "Наклон вверх", "камера поднимается"], ["tiltD", "Наклон вниз", "камера опускается"], ["diag", "Диагональ", "проезд по диагонали"], ["roll", "Покачивание", "лёгкий наклон горизонта"], ["hand", "Ручная камера", "живое дрожание в руках"], ["shakeHit", "Удар", "встряска в начале клипа"], ["spinSlow", "Медленный поворот", "кадр плавно вращается"]];

  /* ---------- автосубтитры: Whisper прямо на компьютере (русский распознаёт лучше встроенного) ---------- */
  var WH = { model: "ggml-large-v3-turbo-q5_0.bin", modelUrl: "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-large-v3-turbo-q5_0.bin", modelSize: 574041195,
    winUrl: "https://github.com/ggml-org/whisper.cpp/releases/download/b5454/whisper-blas-bin-x64.zip" };
  var subState = { phase: "", pct: 0, phrases: null, err: "" }, subGroup = "Все";
  function whDir() { var path = require("path"), os = require("os"); return path.join(os.homedir(), ".kodkreatora", "whisper"); }
  function findFile(dir, name) { var fs = require("fs"), path = require("path"); if (!fs.existsSync(dir)) return null;
    var l = fs.readdirSync(dir); for (var i = 0; i < l.length; i++) { var p = path.join(dir, l[i]); if (l[i].toLowerCase() === name) return p; if (fs.statSync(p).isDirectory()) { var r = findFile(p, name); if (r) return r; } } return null; }
  function subPaint() { if (cur === "Субтитры") render(); }
  function fetchBig(url, file, total, onPct, done) {
    var fs = require("fs"), https = require("https"), tmp = file + ".part";
    (function get(u, n) { https.get(u, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && n < 8) { res.resume(); return get(res.headers.location, n + 1); }
      if (res.statusCode !== 200) { res.resume(); return done(new Error("HTTP " + res.statusCode)); }
      var size = +res.headers["content-length"] || total, got = 0, out = fs.createWriteStream(tmp), last = 0;
      res.on("data", function (c) { got += c.length; var p = Math.floor(got / size * 100); if (p !== last) { last = p; onPct(p); } });
      res.pipe(out); out.on("finish", function () { out.close(function () { fs.renameSync(tmp, file); done(null); }); });
    }).on("error", done); })(url, 0);
  }
  function whEnsure(done) {
    var fs = require("fs"), path = require("path"), cp = require("child_process"), dir = whDir(); mkdirp(dir);
    var model = path.join(dir, WH.model), win = process.platform === "win32";
    var bin = function (cb) {
      if (!win) { var b = path.join(extDir(), "bin", "mac", "whisper-cli"); try { fs.chmodSync(b, 493); cp.execSync('xattr -dr com.apple.quarantine "' + path.dirname(b) + '" 2>/dev/null || true'); } catch (e) {} return cb(null, b); }
      var have = findFile(path.join(dir, "win"), "whisper-cli.exe"); if (have) return cb(null, have);
      subState.phase = "Скачиваю распознаватель для Windows…"; subPaint();
      var zip = path.join(dir, "whisper-win.zip");
      fetchBig(WH.winUrl, zip, 21715607, function () {}, function (err) { if (err) return cb(err);
        cp.exec('powershell -NoProfile -Command "Expand-Archive -Force \'' + zip + '\' \'' + path.join(dir, "win") + '\'"', function (e2) { if (e2) return cb(e2); cb(null, findFile(path.join(dir, "win"), "whisper-cli.exe")); }); });
    };
    bin(function (err, b) {
      if (err || !b) return done(err || new Error("нет распознавателя"));
      if (fs.existsSync(model) && fs.statSync(model).size > 5e8) return done(null, b, model);
      subState.phase = "Первый запуск: скачиваю модель распознавания (550 МБ, один раз)…"; subState.pct = 0; subPaint();
      fetchBig(WH.modelUrl, model, WH.modelSize, function (p) { subState.pct = p; var e = document.getElementById("whp"); if (e) e.style.width = p + "%"; var t = document.getElementById("wht"); if (t) t.textContent = p + " %"; },
        function (e3) { if (e3) return done(e3); done(null, b, model); });
    });
  }
  // слова Whisper → фразы: по числу слов, паузам и знакам препинания
  // слова Whisper → фразы: по числу слов, паузам и знакам препинания; фраза не заканчивается предлогом или частицей
  var GLUE = /^(в|во|на|за|под|над|по|о|об|от|до|из|у|к|ко|с|со|и|а|но|не|ни|что|чтобы|как|это|же|ли|бы|для|при|без|про|через|мы|я|ты|он|она|они|вы|мой|моя|мои|твой|наш|ваш|их|его|её|все|всё|так|уже|ещё|если|когда|где|или|то)$/i;
  function toPhrases(words, maxW, maxC) {
    var out = [], cur = [];
    var txt = function (a) { return a.map(function (x) { return x.t; }).join(" "); };
    var flush = function () { if (!cur.length) return; var a = cur[0].a, b = cur[cur.length - 1].b; out.push({ a: a, b: b, t: txt(cur), w: cur.map(function (w) { return (w.a - a).toFixed(2); }).join(","), ws: cur.slice() }); cur = []; };
    for (var i = 0; i < words.length; i++) {
      var w = words[i], prev = cur[cur.length - 1];
      if (cur.length) {
        var bare = prev.t.replace(/[^а-яёa-z0-9]/gi, ""), hardEnd = /[.!?…]$/.test(prev.t), pause = w.a - prev.b > 0.6;
        var full = cur.length >= maxW || txt(cur).length + w.t.length + 1 > maxC, soft = /[,;:—]$/.test(prev.t) && cur.length >= Math.ceil(maxW / 2);
        if (hardEnd || pause || soft || (full && (!GLUE.test(bare) || cur.length >= maxW + 2))) flush();
      }
      cur.push(w);
    }
    flush();
    // одно-два коротких слова в хвосте предложения — приклеиваем к предыдущей фразе
    for (var k = out.length - 1; k > 0; k--) {
      var P = out[k], Q = out[k - 1];
      if (P.ws.length <= 1 && !/[.!?…]$/.test(Q.t) && Q.ws.length + P.ws.length <= maxW + 2 && P.a - Q.b < 0.6) {
        var ws = Q.ws.concat(P.ws), a0 = ws[0].a; out.splice(k - 1, 2, { a: a0, b: P.b, t: txt(ws), w: ws.map(function (x) { return (x.a - a0).toFixed(2); }).join(","), ws: ws });
      }
    }
    for (var j = 0; j < out.length; j++) { var nx = out[j + 1]; out[j].b = nx ? Math.min(nx.a, Math.max(out[j].b, out[j].a + 0.4) + 0.25) : out[j].b + 0.3; }
    return out;
  }
  function autoSubs() {
    var path = require("path"), os = require("os"), cp = require("child_process"), fs = require("fs");
    subState = { phase: "Готовлю звук секвенции…", pct: 0, phrases: null, err: "" }; subPaint();
    var tmp = path.join(os.tmpdir(), "kk-subs"); mkdirp(tmp); var wav = path.join(tmp, "seq.wav"), outBase = path.join(tmp, "seq");
    run("kk_exportAudio", [wav], function (r) {
      var p = r.split("|"); if (p[0] !== "ok") { subState.phase = ""; subState.err = p.slice(1).join(" "); return subPaint(); }
      whEnsure(function (err, bin, model) {
        if (err) { subState.phase = ""; subState.err = "Не получилось подготовить распознавание: " + err.message; return subPaint(); }
        subState.phase = "Распознаю речь… (минута ролика — примерно 10–40 секунд)"; subState.pct = 0; subPaint();
        var args = ["-m", model, "-f", wav, "-l", "ru", "-ml", "1", "-sow", "-oj", "-of", outBase, "-np", "-pp"];
        if (process.platform === "win32") args.push("-t", String(Math.max(2, os.cpus().length - 1)));
        var ch = cp.spawn(bin, args, { cwd: path.dirname(bin) }), errTxt = "";
        ch.stderr.on("data", function (d) { var m = /progress\s*=\s*(\d+)%/.exec(String(d)); if (m) { var e = document.getElementById("whp"); if (e) e.style.width = m[1] + "%"; } else errTxt += d; });
        ch.on("close", function (code) {
          try {
            var j = JSON.parse(fs.readFileSync(outBase + ".json", "utf8")), words = [];
            j.transcription.forEach(function (s) { var t = String(s.text).trim(); if (t) words.push({ a: s.offsets.from / 1000, b: s.offsets.to / 1000, t: t }); });
            if (!words.length) throw new Error("в звуке не нашлось речи");
            seqInfo(function (o) { subState.phrases = toPhrases(words, subW || (o === "h" ? 7 : 4), o === "h" ? 36 : 22); subState.phase = ""; subPaint(); });
          } catch (e) { subState.phase = ""; subState.err = "Распознавание не удалось (" + code + "): " + (e.message || "") + " " + errTxt.slice(-200); subPaint(); }
        });
      });
    });
  }
  function subsCreate() {
    var ph = subState.phrases; if (!ph) return;
    var ins = document.querySelectorAll(".phr input");
    for (var i = 0; i < ins.length; i++) { var v = ins[i].value.trim(); if (v !== ph[i].t) { if (v.split(/\s+/).length !== ph[i].t.split(/\s+/).length) ph[i].w = ""; ph[i].t = v; } }
    var data = ph.filter(function (p) { return p.t; }).map(function (p) { return [p.a.toFixed(3), p.b.toFixed(3), p.t, p.w].join("\u0002"); }).join("\u0001");
    say("ok|Ставлю субтитры…"); run("kk_subs2", [sub, data], say);
  }
  function fmtT(s) { var m = Math.floor(s / 60), x = (s % 60).toFixed(1); return m + ":" + (x < 10 ? "0" : "") + x; }

  try { var SJ = JSON.parse(require("fs").readFileSync(extDir() + "/mogrt/subs.json", "utf8")); if (SJ && SJ.length) SUBS = SJ.map(function (x) { return [x.id, x.name, x.desc, x.group]; }); } catch (e) {}
  var TITLES = [["headline", "Заголовок", "Заголовки"], ["quote", "Цитата", "Кино"], ["nick", "Ник", "Плашки"], ["subscribe", "Подпишись", "Призывы"]], titleGroup = "Все", TGROUPS = [];
  try { var TJ = JSON.parse(require("fs").readFileSync(extDir() + "/mogrt/titles.json", "utf8")); if (TJ && TJ.length) TITLES = TITLES.concat(TJ.map(function (x) { return [x.id, x.name, x.group]; })); } catch (e) {}
  TITLES.forEach(function (t) { if (TGROUPS.indexOf(t[2]) < 0) TGROUPS.push(t[2]); });
  var TABS = {
    "Текст": function () {
      return '<div class="sec"><h3>Где</h3><div class="row"><div class="seg" id="side"><button data-s="in" class="' + (side === "in" ? "on" : "") + '">Появление</button><button data-s="out" class="' + (side === "out" ? "on" : "") + '">Исчезновение</button></div></div>' +
        '<div class="row"><span>Длительность</span><input type="range" id="dur" min="0.2" max="1.2" step="0.1" value="' + dur + '"><b id="durv">' + dur + ' с</b></div></div>' +
        '<div class="sec"><h3>Анимации · ' + ANIMS.length + '</h3><div class="grid">' + ANIMS.map(function (a) { var pv = { pop: 1, zoom: 1, fadeUp: 1, slide: 1, drop: 1, shake: 1, blink: 1 }[a[0]] ? a[0] : (/blur|fade/.test(a[0]) ? 'fadeUp' : /slide|whip/.test(a[0]) ? 'slide' : /drop|rise|elastic|rubber|squash|swing/.test(a[0]) ? 'drop' : /glitch/.test(a[0]) ? 'shake' : 'pop'); return '<button class="card" data-anim="' + a[0] + '"><span class="pv" style="--a:' + pv + '"><i></i></span>' + a[1] + '</button>'; }).join("") + '</div>' +
        '<p class="note">Выдели клип, текст или графику на таймлайне и нажми анимацию. Работает и с видео. Отменить: Cmd/Ctrl+Z.</p></div>' +
        '<div class="sec"><h3>Готовые титры</h3><input id="ttxt" class="tin" placeholder="Свой текст (можно оставить пустым)" value="' + (ttxt || "").replace(/"/g, "&quot;") + '">' +
        '<div class="tabs" style="padding:0;border:0">' + ["Все"].concat(TGROUPS).map(function (g) { return '<button class="' + (g === titleGroup ? "on" : "") + '" data-tgr="' + g + '">' + g + '</button>'; }).join("") + '</div>' +
        '<div class="grid subs">' + TITLES.filter(function (t) { return titleGroup === "Все" || t[2] === titleGroup; }).map(function (t) { return '<button class="card" data-title="' + t[0] + '"><img src="prev/title-' + t[0] + '.png" onerror="this.style.display=\'none\'" alt="" style="aspect-ratio:9/16;object-fit:cover">' + t[1] + '</button>'; }).join("") + '</div>' +
        '<p class="note">Титр встанет на плейхед на свободную дорожку. Цвет акцента и текста — в панели «Основные графические элементы».</p></div>';
    },
    "Эффекты": function () {
      return '<div class="sec"><h3>Необычные эффекты на клип</h3><div class="grid">' + FXS.map(function (f) { return '<button class="card" data-fx2="' + f[0] + '"><span class="pv" style="--a:zoom"><i></i></span>' + f[1] + '</button>'; }).join("") + '</div>' +
        '<p class="note">Выдели клип и нажми эффект: рыбий глаз, 3D, RGB-разлом, калейдоскоп, воронка, свечение, сбой… Настройки потом можно подкрутить в «Элементах управления эффектами». Часть эффектов есть только в новых версиях Премьера — плагин скажет, если эффекта нет.</p></div>';
    },
    "Плавность": function () {
      return '<div class="sec"><h3>На выделенные ключи</h3><div class="list">' + EASES.map(function (e) { return '<button class="btn" data-ease="' + e[0] + '">' + e[1] + '<small>' + e[2] + '</small></button>'; }).join("") + '</div>' +
        '<p class="note">Поставь хотя бы два ключа (позиция, масштаб, поворот, непрозрачность), выдели клип и выбери плавность. Плагин сам рассчитает движение по кривой.</p></div>';
    },
    "Камера": function () {
      return '<div class="sec"><h3>Движение кадра</h3><div class="list">' + CAM.map(function (e) { return '<button class="btn" data-cam="' + e[0] + '">' + e[1] + (e[2] ? '<small>' + e[2] + '</small>' : "") + '</button>'; }).join("") + '</div></div>';
    },
    "Исправить": function () {
      return '<div class="sec"><h3>Частые ошибки</h3><div class="list">' +
        '<button class="btn" data-fix="stab">Стабилизировать без рамок<small>Стабилизатор деформации с обрезкой и автомасштабом</small></button>' +
        '<button class="btn" data-fix="frames">Убрать чёрные рамки<small>растянуть кадр на весь экран секвенции</small></button>' +
        '<button class="btn" data-fix="slow50">Слоумо 50%<small>оптический поток — плавно, без рывков</small></button>' +
        '<button class="btn" data-fix="slow25">Слоумо 25%<small>для съёмки 100–120 кадров — идеально, для 25–30 — мягче с оптическим потоком</small></button>' +
        '<button class="btn" data-acut="1">Мягкая склейка звука<small>плейхед на стык — убирает щелчок и «кривую» склейку</small></button>' +
        '</div><p class="note">Мерцание от ламп: смотри шпаргалку «Мерцание» в паке — лучше всего лечится настройкой выдержки при съёмке и эффектом в Премьере.</p></div>';
    },
    "Секвенция": function () {
      var row = function (fmt, label) { return '<div class="row">' + [25, 30].map(function (f) { return '<button class="btn" data-seq="' + fmt + '" data-fps="' + f + '">' + label + '<small>' + f + ' кадров</small></button>'; }).join("") + '</div>'; };
      return '<div class="sec"><h3>Вертикаль</h3>' + row("v", "9:16 · 1080×1920") + row("p45", "4:5 · 1080×1350") + '</div>' +
        '<div class="sec"><h3>Горизонталь</h3>' + row("h", "16:9 · 1920×1080") + row("h4k", "16:9 · 4K 3840×2160") + row("sq", "1:1 · 1080×1080") + '</div>' +
        '<p class="note">Все анимации, плавность и камера одинаково работают в любом формате. Скоро: сетка безопасных зон и пресеты экспорта под площадки.</p>';
    },
    "Субтитры": function () {
      var st = subState, groups = ["Все"]; SUBS.forEach(function (t) { if (t[3] && groups.indexOf(t[3]) < 0) groups.push(t[3]); });
      var list = SUBS.filter(function (t) { return subGroup === "Все" || t[3] === subGroup; });
      var head = '<div class="sec"><h3>Автосубтитры · русский</h3>' +
        (st.phase ? '<div class="note" style="border-style:solid">' + st.phase + '<div class="bar"><i id="whp" style="width:' + st.pct + '%"></i></div><span id="wht"></span></div>'
        : st.phrases ? '<div class="phr">' + st.phrases.map(function (p, i) { return '<label><span>' + fmtT(p.a) + '</span><input value="' + p.t.replace(/"/g, "&quot;") + '"></label>'; }).join("") + '</div>' +
          '<button class="btn y" data-subok="1">Создать субтитры · ' + st.phrases.length + ' фраз</button><button class="btn" data-subauto="1">Распознать заново</button>'
        : '<button class="btn y" data-subauto="1">Распознать речь и сделать субтитры<small style="color:inherit;opacity:.75">звук всей секвенции → текст с точностью до слова</small></button>') +
        (st.err ? '<p class="note" style="color:var(--bad)">' + st.err + '</p>' : '') + '</div>';
      return head +
        '<div class="sec"><h3>Стиль · ' + SUBS.length + '</h3><div class="tabs" style="padding:0;border:0">' + groups.map(function (g) { return '<button class="' + (g === subGroup ? "on" : "") + '" data-subg="' + g + '">' + g + '</button>'; }).join("") + '</div>' +
        '<div class="grid subs">' + list.map(function (t) { return '<button class="card' + (sub === t[0] ? ' on' : '') + '" data-sub="' + t[0] + '" title="' + t[2] + '"><img src="prev/subs-' + t[0] + '.png" onerror="this.style.display=\'none\'" alt="">' + t[1] + '</button>'; }).join("") + '</div></div>' +
        '<div class="sec"><h3>Слов в одной фразе</h3><div class="row"><input type="range" id="sw" min="0" max="10" step="1" value="' + subW + '"><b id="swv">' + (subW || "авто") + '</b></div></div>' +
        '<p class="note">Распознавание идёт прямо на компьютере, без интернета (интернет нужен один раз — скачать модель). Перед созданием можно поправить текст фраз. Цвет текста и акцента, обводку, тень, плашку, размер и положение меняй в «Окно → Основные графические элементы» — как в CapCut.</p>' +
        '<details><summary class="note" style="cursor:pointer">Есть готовый файл SRT?</summary><button class="btn" data-subgo="1">Выбрать SRT и создать субтитры</button></details>';
    },
    "Переходы": function () {
      return '<div class="sec"><h3>Длина</h3><div class="row"><input type="range" id="trf" min="4" max="16" step="1" value="' + trf + '"><b id="trfv">' + trf + ' кадров</b></div></div>' +
        '<div class="sec"><h3>На стык двух клипов</h3><div class="grid">' + TRANS.map(function (t) { return '<button class="card" data-tr="' + t[0] + '"><span class="pv" style="--a:' + t[2] + '"><i></i></span>' + t[1] + '</button>'; }).join("") + '</div>' +
        '<p class="note">Поставь плейхед точно на стык (клавиши ↑ ↓ прыгают по склейкам) и нажми переход. Плагин сам анимирует конец первого клипа и начало второго, со смазом движения. Работает в вертикали и горизонтали.</p></div>';
    },
    "Наборы": function () {
      if (!LIB) { loadLib(); return '<p class="note">Загружаю библиотеку наборов…</p>'; }
      if (LIB.error) return '<p class="note">Не получилось загрузить библиотеку: ' + LIB.error + '</p>';
      var st = LIB.styles[libStyle] || LIB.styles[Object.keys(LIB.styles)[0]], items = st[libKind] || [];
      var kinds = [["png", "PNG классические"], ["pin", "PNG из Pinterest"], ["an", "Анимации"], ["tr", "Переходы"], ["ov", "Оверлеи"], ["bg", "Фоны"], ["tx", "Плашки"], ["sfx", "Звуки"]];
      return '<div class="sec"><h3>Стиль</h3><div class="tabs" style="padding:0;border:0">' + Object.keys(LIB.styles).filter(function (k) { return k !== "cut"; }).map(function (k) { return '<button class="' + (k === libStyle ? "on" : "") + '" data-ls="' + k + '">' + LIB.styles[k].name + '</button>'; }).join("") + '</div>' +
        '<div class="tabs" style="padding:0;border:0">' + kinds.map(function (k) { return '<button class="' + (k[0] === libKind ? "on" : "") + '" data-lk="' + k[0] + '">' + k[1] + '</button>'; }).join("") + '</div></div>' +
        '<div class="grid lib">' + items.map(function (it, i) { var pv = LIB.base + libStyle + "/" + it.prev, vid = /\.mp4$/.test(it.prev);
          return '<button class="card" data-li="' + i + '" title="' + it.name + '">' + (libKind === "sfx" ? '<span class="snd">♪</span>' : vid ? '<video src="' + pv + '" muted loop playsinline preload="none" style="width:100%;border-radius:4px"></video>' : '<img src="' + pv + '" loading="lazy" style="width:100%;height:70px;object-fit:contain">') + '<span>' + it.name + '</span></button>'; }).join("") + '</div>' +
        '<p class="note">Нажми — плагин скачает файл и поставит на плейхед. Переход встанет серединой на склейку, оверлей — с режимом «Экран», фон — на нижнюю дорожку. Вертикальная или горизонтальная версия выбирается по секвенции. Файлы сохраняются в «Документы / КК Наборы».</p>';
    }
  };
  var cur = "Текст";
  /* ---------- библиотека наборов ---------- */
  var LIB = null, libStyle = "kk", libKind = "png";
  function loadLib() {
    fetch("https://kodkreatora.bybusha.com/pack/manifest.json?t=" + Date.now()).then(function (r) { return r.json(); })
      .then(function (m) { LIB = m; if (!LIB.styles[libStyle]) libStyle = Object.keys(LIB.styles)[0]; if (cur === "Наборы") render(); })
      .catch(function (e) { LIB = { error: e.message }; if (cur === "Наборы") render(); });
  }
  function seqInfo(cb) { run("kk_fmt", [], cb); }
  function cachePath(style, rel) {
    var path = require("path"), os = require("os");
    return path.join(os.homedir(), "Documents", "КК Наборы", style, rel);
  }
  function download(url, file, done) {
    var fs = require("fs"), path = require("path"), https = require("https");
    if (fs.existsSync(file) && fs.statSync(file).size > 0) return done(null);
    mkdirp(path.dirname(file));
    var tmp = file + ".part";
    (function get(u, n) { https.get(u, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && n < 6) { res.resume(); return get(res.headers.location, n + 1); }
      if (res.statusCode !== 200) { res.resume(); return done(new Error("HTTP " + res.statusCode)); }
      var out = fs.createWriteStream(tmp); res.pipe(out); out.on("finish", function () { out.close(function () { fs.renameSync(tmp, file); done(null); }); });
    }).on("error", done); })(url, 0);
  }
  function insertItem(i) {
    var it = LIB.styles[libStyle][libKind][i]; say("ok|Скачиваю «" + it.name + "»…");
    seqInfo(function (o) {
      if (!o) { say("err|Открой секвенцию"); return; }
      var f = it.files, key = libKind === "sfx" ? f.wav : libKind === "png" || libKind === "pin" ? f.png : libKind === "tx" ? f.png : libKind === "an" ? f.mov : libKind === "bg" ? f[o] : libKind === "tr" ? f["mov_" + o] : (f["mov_" + o] || f["black_" + o]);
      var blend = libKind === "ov" && !f["mov_" + o] ? "screen" : "";
      if (!key) { say("err|Для этого формата нет файла"); return; }
      var url = key, file = cachePath(libStyle, decodeURIComponent(url.split("/").pop()).replace(/__/g, "/"));
      download(url, file, function (err) {
        if (err) { say("err|Не скачалось: " + err.message); return; }
        if (libKind === "sfx") { run("km_sound", [file], say); return; }
        var tex = libStyle === "tex" && libKind === "bg"; // текстура — поверх видео, режим наложения выбирает автор
        run("kk_insert", [file, tex ? "ov" : libKind === "pin" ? "png" : libKind, libKind === "bg" ? 5 : 3, blend], function (r) { say(tex && r.indexOf("ok") === 0 ? r + ". Режим наложения: «Умножение» или «Перекрытие», непрозрачность 20–60 %" : r); });
      });
    });
  }
  function render() {
    document.getElementById("tabs").innerHTML = Object.keys(TABS).map(function (k) { return '<button class="' + (k === cur ? "on" : "") + '" data-tab="' + k + '">' + k + '</button>'; }).join("");
    document.getElementById("view").innerHTML = TABS[cur]();
    var r = document.getElementById("dur");
    if (r) r.oninput = function () { dur = +r.value; document.getElementById("durv").textContent = dur + " с"; };
    var sw = document.getElementById("sw");
    if (sw) sw.oninput = function () { subW = +sw.value; document.getElementById("swv").textContent = subW; };
    var tf = document.getElementById("trf");
    if (tf) tf.oninput = function () { trf = +tf.value; document.getElementById("trfv").textContent = trf + " кадров"; };
  }
  document.addEventListener("mouseover", function (ev) { var v = ev.target.closest(".card") && ev.target.closest(".card").querySelector("video"); if (v && v.paused) v.play().catch(function () {}); });
  document.addEventListener("click", function (ev) {
    var b = ev.target.closest("button"); if (!b) return;
    if (b.dataset.tab) { cur = b.dataset.tab; render(); return; }
    if (b.dataset.ls) { libStyle = b.dataset.ls; var st0 = LIB.styles[libStyle]; if (st0 && !(st0[libKind] || []).length) { var ks = ["png", "an", "tr", "ov", "bg", "tx"]; for (var q = 0; q < ks.length; q++) if ((st0[ks[q]] || []).length) { libKind = ks[q]; break; } } render(); return; }
    if (b.dataset.lk) { libKind = b.dataset.lk; render(); return; }
    if (b.dataset.li !== undefined && LIB) { insertItem(+b.dataset.li); return; }
    if (b.dataset.s) { side = b.dataset.s; render(); return; }
    if (b.dataset.anim) run("kk_anim2", [b.dataset.anim, side, dur], say);
    else if (b.dataset.ease) run("kk_ease", [b.dataset.ease], say);
    else if (b.dataset.sub) { sub = b.dataset.sub; render(); return; }
    else if (b.dataset.subauto) { autoSubs(); return; }
    else if (b.dataset.subok) { subsCreate(); return; }
    else if (b.dataset.subg) { subGroup = b.dataset.subg; render(); return; }
    else if (b.dataset.subgo) { say("ok|Выбери файл…"); run("kk_subs", [sub, "", subW], say); }
    else if (b.dataset.tgr) { titleGroup = b.dataset.tgr; render(); return; }
    else if (b.dataset.title) { ttxt = (document.getElementById("ttxt") || {}).value || ""; run("kk_title", [b.dataset.title, ttxt, 3], say); }
    else if (b.dataset.tr) run("kk_trans2", [b.dataset.tr, trf], say);
    else if (b.dataset.fx2) run("kk_fx2", [b.dataset.fx2], say);
    else if (b.dataset.cam) run("kk_camera", [b.dataset.cam], say);
    else if (b.dataset.fix) run("kk_fix", [b.dataset.fix], say);
    else if (b.dataset.acut) run("kk_audioCut", [3], say);
    else if (b.dataset.seq) run("kk_newSeq", [b.dataset.seq, +b.dataset.fps], say);
  });
  /* ---------- доступ по ключу из приложения КК ---------- */
  var ID = "kk-montazh", API = "https://script.google.com/macros/s/AKfycbw2LmiS_HoOdrIQko16UGsLNQj6T1Br2BymAb2bh8_iHPxOB8QyVgbiZ0vuPcwhHCPwyQ/exec", SITE = "https://kodkreatora.bybusha.com";
  var OFFLINE_DAYS = 30;
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { return null; } }
  function api(body) { return fetch(API, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify(body) }).then(function (r) { return r.json(); }); }
  var ERR = { bad_key: "Ключ не подошёл. Скопируй его заново в приложении КК.", not_student: "Доступ только для учениц программы КОД КРЕАТОРА.", expired: "Доступ к программе закончился.", soon: "Плагин скоро откроется ученицам." };
  function loginView(msg) {
    document.getElementById("tabs").innerHTML = "";
    document.getElementById("view").innerHTML = '<div class="login"><b style="font-size:14px">Вход в плагин</b>' +
      '<span class="note">Открой приложение КК → «Полезные материалы» → «Пак режиссёра монтажа» → плагин → «Получить ключ». Скопируй ключ и вставь сюда.</span>' +
      '<input id="key" placeholder="KK-…" autocomplete="off"><button class="btn y" id="go">Войти</button>' + (msg ? '<span class="note" style="color:#ff6b5b">' + msg + '</span>' : "") + '</div>';
    document.getElementById("go").onclick = function () { var k = document.getElementById("key").value.trim(); if (k) check(k, true); };
  }
  function enter(u) { document.getElementById("who").textContent = (u.n || "") + (u.u ? " · @" + u.u : ""); render(); checkUpdate(); }
  function check(key, interactive) {
    api({ api: "plugincheck", key: key }).then(function (r) {
      if (r.ok) { ls("kk_key", key); ls("kk_ok_at", String(Date.now())); ls("kk_user", JSON.stringify(r)); sharedWrite({ key: key, at: Date.now(), user: r }); enter(r); }
      else { if (r.error !== "soon" || interactive) { ls("kk_key", null); if (r.error === "bad_key" || r.error === "not_student" || r.error === "expired") sharedClear(); } loginView(ERR[r.error] || "Не получилось войти: " + (r.error || "")); }
    }).catch(function () {
      var sh = sharedRead() || {}, at = Math.max(+ls("kk_ok_at") || 0, sh.at || 0), u = ls("kk_user") || (sh.user ? JSON.stringify(sh.user) : null);
      if (!interactive && u && Date.now() - at < OFFLINE_DAYS * 864e5) enter(JSON.parse(u)); // без интернета — 30 дней по сохранённому входу
      else loginView("Нет интернета: для первого входа он нужен.");
    });
  }

  /* ---------- файлы: свои помощники — в старых Премьерах (Node 8) нет mkdirSync({recursive}) и rmSync ---------- */
  function mkdirp(d) { var fs = require("fs"), path = require("path"); if (fs.existsSync(d)) return; mkdirp(path.dirname(d)); fs.mkdirSync(d); }
  function rmrf(d) { var fs = require("fs"), path = require("path"); if (!fs.existsSync(d)) return;
    if (fs.lstatSync(d).isDirectory()) { fs.readdirSync(d).forEach(function (n) { rmrf(path.join(d, n)); }); fs.rmdirSync(d); } else fs.unlinkSync(d); }
  function extDir() { // file:///C:/… на Windows и file:///Users/… на Mac
    var p = decodeURIComponent(String(cep.getSystemPath("extension")).replace(/^file:\/\//, ""));
    return /^\/[A-Za-z]:/.test(p) ? p.slice(1) : p;
  }
  /* общий ключ для всех плагинов КК: файл в домашней папке, его читают оба плагина */
  function sharedFile() { var path = require("path"), os = require("os"); return path.join(os.homedir(), ".kodkreatora", "plugin-key.json"); }
  function sharedRead() { try { return JSON.parse(require("fs").readFileSync(sharedFile(), "utf8")); } catch (e) { return null; } }
  function sharedWrite(o) { try { var f = sharedFile(); mkdirp(require("path").dirname(f)); require("fs").writeFileSync(f, JSON.stringify(o)); } catch (e) {} }
  function sharedClear() { try { require("fs").unlinkSync(sharedFile()); } catch (e) {} }
  /* ---------- обновления ---------- */
  function newer(a, b) { a = a.split(".").map(Number); b = b.split(".").map(Number); for (var i = 0; i < 3; i++) { if ((a[i] || 0) > (b[i] || 0)) return true; if ((a[i] || 0) < (b[i] || 0)) return false; } return false; }
  function checkUpdate() {
    fetch(SITE + "/plugin/version.json?t=" + Date.now()).then(function (r) { return r.json(); }).then(function (v) {
      var me = v[ID]; if (!me || !newer(me.v, VERSION)) return;
      var u = document.getElementById("upd"); u.hidden = false;
      u.innerHTML = '<span>Вышла версия ' + me.v + (me.notes ? ": " + me.notes : "") + '</span><button class="btn y" id="doupd" style="width:auto;padding:5px 10px">Обновить</button>';
      document.getElementById("doupd").onclick = function () { update(me); };
    }).catch(function () {});
  }
  function copyDir(src, dst) { // своё копирование: в старых Премьерах нет fs.cpSync
    var fs = require("fs"), path = require("path");
    if (!fs.existsSync(dst)) mkdirp(dst);
    fs.readdirSync(src).forEach(function (n) { var a = path.join(src, n), b = path.join(dst, n);
      if (fs.statSync(a).isDirectory()) copyDir(a, b); else fs.writeFileSync(b, fs.readFileSync(a)); });
  }
  function update(me) {
    var u = document.getElementById("upd");
    try {
      var https = require("https"), fs = require("fs"), path = require("path"), os = require("os"), cp = require("child_process");
      var dir = extDir();
      if (fs.lstatSync(dir).isSymbolicLink()) { u.innerHTML = "<span>Это версия разработчика — обновление не ставлю</span>"; return; }
      var zip = path.join(os.tmpdir(), ID + "-" + me.v + ".zip"), out = fs.createWriteStream(zip);
      u.innerHTML = "<span>Скачиваю обновление…</span>";
      var get = function (url) { https.get(url, function (res) { if (res.statusCode >= 300 && res.headers.location) return get(res.headers.location); res.pipe(out); out.on("finish", function () { out.close(unpack); }); }).on("error", function () { u.innerHTML = "<span>Не скачалось. Проверь интернет.</span>"; }); };
      var unpack = function () {
        var tmp = path.join(os.tmpdir(), ID + "-new"); try { rmrf(tmp); } catch (e) {}
        var cmd = process.platform === "win32" ? 'powershell -NoProfile -Command "Expand-Archive -Force \'' + zip + '\' \'' + tmp + '\'"' : 'ditto -x -k "' + zip + '" "' + tmp + '"';
        cp.exec(cmd, function (err) {
          if (err) { u.innerHTML = "<span>Не распаковалось: " + err.message + "</span>"; return; }
          var src = path.join(tmp, ID); if (!fs.existsSync(src)) src = tmp;
          try { copyDir(src, dir); u.innerHTML = "<span>Готово! Перезапусти Премьер, чтобы включилась версия " + me.v + "</span>"; }
          catch (e2) { u.innerHTML = "<span>Не получилось заменить файлы: " + e2.message + "</span>"; }
        });
      };
      get(me.zip);
    } catch (e) { u.innerHTML = "<span>Обновление недоступно: " + e.message + "</span>"; }
  }

  document.getElementById("ver").textContent = "v" + VERSION;
  try { run("kk_setDir", [extDir()], function () { loadLists(); }); } catch (e) {}
  run("kk_ping", [], function (r) { var p = r.split("|"); if (p[0] !== "ok") document.getElementById("who").textContent = "нет связи с Premiere"; });
  var saved = ls("kk_key") || (sharedRead() || {}).key; // вошла в одном плагине КК — остальные открываются сами
  if (saved) check(saved, false); else loginView();
})();

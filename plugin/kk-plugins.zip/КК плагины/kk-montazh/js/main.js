/* КК · Монтаж — интерфейс панели. Вызывает функции из jsx/host.jsx через CEP evalScript. */
(function () {
  var VERSION = "1.0.0";
  var cep = window.__adobe_cep__;
  function run(fn, args, cb) {
    var call = fn + "(" + (args || []).map(function (a) { return JSON.stringify(a); }).join(",") + ")";
    if (!cep) { cb && cb("err|Открой панель внутри Premiere Pro"); return; }
    cep.evalScript(call, function (r) { cb && cb(String(r || "")); });
  }
  function say(r) {
    var m = document.getElementById("msg"), p = String(r).split("|");
    m.className = p[0] === "ok" ? "ok" : "err"; m.textContent = p.slice(1).join(" ") || r;
    clearTimeout(say.t); say.t = setTimeout(function () { m.textContent = ""; }, 6000);
  }
  var ttxt = "", dur = 0.4, side = "in", trf = 8, sub = "kk-word", subW = 0;
  var SUBS = [["kk-word", "КК · активное слово", "белый текст, сказанное слово — цветом акцента"], ["pop-word", "Поп по словам", "слова выскакивают по одному, капс"], ["word-by-word", "Слово за словом", "фраза набирается по словам"], ["karaoke", "Караоке", "цвет заливает текст по ходу речи"], ["caps-stroke", "Капс с обводкой", "крупно и жирно, как у блогеров"], ["kk-plate", "КК · плашка", "текст на цветной плашке"], ["typewriter", "Печатная машинка", "по буквам, моноширинный"], ["minimal", "Минимал", "тонкий шрифт и мягкая тень"]];
  var TRANS = [["zoom", "Зум-рывок", "zoom"], ["whipL", "Смаз влево", "slide"], ["whipR", "Смаз вправо", "slide"], ["spin", "Вращение", "pop"], ["stretch", "Растягивание", "zoom"], ["shake", "Тряска", "shake"], ["dip", "Затемнение", "blink"]];

  var ANIMS = [["pop", "Pop"], ["fadeUp", "Подъём"], ["slide", "Выезд"], ["zoom", "Из точки"], ["drop", "Отскок"], ["shake", "Дрожь"], ["blink", "Мигание"]];
  var EASES = [["inOutCubic", "Плавно", "мягкий разгон и мягкое торможение"], ["outCubic", "Резкий старт", "быстро начинается, мягко останавливается"], ["inCubic", "Резкий финиш", "мягко стартует, быстро доезжает"], ["ios", "Как в iOS", "быстро и очень мягкая остановка"], ["outBack", "Пружина", "небольшой перелёт и возврат"], ["outBounce", "Отскок", "как мячик"], ["outElastic", "Резинка", "несколько колебаний"], ["linear", "Линейно", "убрать плавность"], ["hold", "Стоп-кадр", "ключи без перехода"]];
  var CAM = [["zoomIn", "Наезд", "медленное приближение на весь клип"], ["zoomOut", "Отъезд", "медленное отдаление"], ["breathe", "Дыхание кадра", "лёгкая пульсация масштаба"], ["panL", "Панорама влево", ""], ["panR", "Панорама вправо", ""]];

  var TABS = {
    "Текст": function () {
      return '<div class="sec"><h3>Где</h3><div class="row"><div class="seg" id="side"><button data-s="in" class="' + (side === "in" ? "on" : "") + '">Появление</button><button data-s="out" class="' + (side === "out" ? "on" : "") + '">Исчезновение</button></div></div>' +
        '<div class="row"><span>Длительность</span><input type="range" id="dur" min="0.2" max="1.2" step="0.1" value="' + dur + '"><b id="durv">' + dur + ' с</b></div></div>' +
        '<div class="sec"><h3>Анимации</h3><div class="grid">' + ANIMS.map(function (a) { return '<button class="card" data-anim="' + a[0] + '"><span class="pv" style="--a:' + a[0] + '"><i></i></span>' + a[1] + '</button>'; }).join("") + '</div>' +
        '<p class="note">Выдели клип, текст или графику на таймлайне и нажми анимацию. Работает и с видео. Отменить: Cmd/Ctrl+Z.</p></div>' +
        '<div class="sec"><h3>Готовые титры</h3><input id="ttxt" class="tin" placeholder="Свой текст (можно оставить пустым)" value="' + (ttxt || "").replace(/"/g, "&quot;") + '">' +
        '<div class="grid">' + [["headline", "Заголовок"], ["quote", "Цитата"], ["nick", "Ник"], ["subscribe", "Подпишись"]].map(function (t) { return '<button class="card" data-title="' + t[0] + '"><span class="pv" style="--a:pop"><i></i></span>' + t[1] + '</button>'; }).join("") + '</div>' +
        '<p class="note">Титр встанет на плейхед на свободную дорожку. Цвет акцента и текста — в панели «Основные графические элементы».</p></div>';
    },
    "Плавность": function () {
      return '<div class="sec"><h3>На выделенные ключи</h3><div class="list">' + EASES.map(function (e) { return '<button class="btn" data-ease="' + e[0] + '">' + e[1] + '<small>' + e[2] + '</small></button>'; }).join("") + '</div>' +
        '<p class="note">Поставь хотя бы два ключа (позиция, масштаб, поворот, непрозрачность), выдели клип и выбери плавность. Плагин сам рассчитает движение по кривой.</p></div>';
    },
    "Камера": function () {
      return '<div class="sec"><h3>Движение кадра</h3><div class="list">' + CAM.map(function (e) { return '<button class="btn" data-cam="' + e[0] + '">' + e[1] + (e[2] ? '<small>' + e[2] + '</small>' : "") + '</button>'; }).join("") + '</div></div>';
    },
    "Исправить": function () {
      return '<div class="sec"><h3>Частые ошибки</h3><div class="list">' +
        '<button class="btn" data-fix="stab">Стабилизировать без рамок<small>Стабилизатор деформации с обрезкой и автомасштабом</small></button>' +
        '<button class="btn" data-fix="frames">Убрать чёрные рамки<small>растянуть кадр на весь экран секвенции</small></button>' +
        '<button class="btn" data-fix="slow50">Слоумо 50%<small>оптический поток — плавно, без рывков</small></button>' +
        '<button class="btn" data-fix="slow25">Слоумо 25%<small>для съёмки 100–120 кадров — идеально, для 25–30 — мягче с оптическим потоком</small></button>' +
        '<button class="btn" data-acut="1">Мягкая склейка звука<small>плейхед на стык — убирает щелчок и «кривую» склейку</small></button>' +
        '</div><p class="note">Мерцание от ламп: смотри шпаргалку «Мерцание» в паке — лучше всего лечится настройкой выдержки при съёмке и эффектом в Премьере.</p></div>';
    },
    "Секвенция": function () {
      var row = function (fmt, label) { return '<div class="row">' + [25, 30].map(function (f) { return '<button class="btn" data-seq="' + fmt + '" data-fps="' + f + '">' + label + '<small>' + f + ' кадров</small></button>'; }).join("") + '</div>'; };
      return '<div class="sec"><h3>Вертикаль</h3>' + row("v", "9:16 · 1080×1920") + row("p45", "4:5 · 1080×1350") + '</div>' +
        '<div class="sec"><h3>Горизонталь</h3>' + row("h", "16:9 · 1920×1080") + row("h4k", "16:9 · 4K 3840×2160") + row("sq", "1:1 · 1080×1080") + '</div>' +
        '<p class="note">Все анимации, плавность и камера одинаково работают в любом формате. Скоро: сетка безопасных зон и пресеты экспорта под площадки.</p>';
    },
    "Субтитры": function () {
      return '<div class="sec"><h3>Стиль</h3><div class="list">' + SUBS.map(function (t) { return '<button class="btn' + (sub === t[0] ? ' y' : '') + '" data-sub="' + t[0] + '">' + t[1] + '<small>' + t[2] + '</small></button>'; }).join("") + '</div></div>' +
        '<div class="sec"><h3>Слов в одной фразе</h3><div class="row"><input type="range" id="sw" min="2" max="10" step="1" value="' + subW + '"><b id="swv">' + (subW || "авто") + '</b></div></div>' +
        '<button class="btn y" data-subgo="1">Выбрать файл SRT и создать субтитры</button>' +
        '<p class="note">1. Распознай речь в Премьере: Окно → Текст → «Транскрибировать эпизод», затем «Создать подписи».<br>2. В панели «Текст» на вкладке «Подписи» нажми «…» → «Экспорт в SRT».<br>3. Здесь выбери стиль и этот файл. Плагин положит анимированные титры на новую дорожку: вертикальные или горизонтальные по формату секвенции.<br>Цвет акцента и положение меняются в панели «Основные графические элементы». Нужны шрифты из установщика (Montserrat, Unbounded, JetBrains Mono).</p>';
    },
    "Переходы": function () {
      return '<div class="sec"><h3>Длина</h3><div class="row"><input type="range" id="trf" min="4" max="16" step="1" value="' + trf + '"><b id="trfv">' + trf + ' кадров</b></div></div>' +
        '<div class="sec"><h3>На стык двух клипов</h3><div class="grid">' + TRANS.map(function (t) { return '<button class="card" data-tr="' + t[0] + '"><span class="pv" style="--a:' + t[2] + '"><i></i></span>' + t[1] + '</button>'; }).join("") + '</div>' +
        '<p class="note">Поставь плейхед точно на стык (клавиши ↑ ↓ прыгают по склейкам) и нажми переход. Плагин сам анимирует конец первого клипа и начало второго, со смазом движения. Работает в вертикали и горизонтали.</p></div>';
    },
    "Вставки": function () {
      if (!LIB) { loadLib(); return '<p class="note">Загружаю библиотеку наборов…</p>'; }
      if (LIB.error) return '<p class="note">Не получилось загрузить библиотеку: ' + LIB.error + '</p>';
      var st = LIB.styles[libStyle] || LIB.styles[Object.keys(LIB.styles)[0]], items = st[libKind] || [];
      var kinds = [["png", "Стикеры"], ["an", "Анимации"], ["tr", "Переходы"], ["ov", "Оверлеи"], ["bg", "Фоны"], ["tx", "Плашки"]];
      return '<div class="sec"><h3>Стиль</h3><div class="tabs" style="padding:0;border:0">' + Object.keys(LIB.styles).map(function (k) { return '<button class="' + (k === libStyle ? "on" : "") + '" data-ls="' + k + '">' + LIB.styles[k].name + '</button>'; }).join("") + '</div>' +
        '<div class="tabs" style="padding:0;border:0">' + kinds.map(function (k) { return '<button class="' + (k[0] === libKind ? "on" : "") + '" data-lk="' + k[0] + '">' + k[1] + '</button>'; }).join("") + '</div></div>' +
        '<div class="grid lib">' + items.map(function (it, i) { var pv = LIB.base + libStyle + "/" + it.prev, vid = /\.mp4$/.test(it.prev);
          return '<button class="card" data-li="' + i + '" title="' + it.name + '">' + (vid ? '<video src="' + pv + '" muted loop playsinline preload="none" style="width:100%;border-radius:4px"></video>' : '<img src="' + pv + '" style="width:100%;height:70px;object-fit:contain">') + '<span>' + it.name + '</span></button>'; }).join("") + '</div>' +
        '<p class="note">Нажми — плагин скачает файл и поставит на плейхед. Переход встанет серединой на склейку, оверлей — с режимом «Экран», фон — на нижнюю дорожку. Вертикальная или горизонтальная версия выбирается по секвенции. Файлы сохраняются в «Документы / КК Наборы».</p>';
    }
  };
  var cur = "Текст";
  /* ---------- библиотека наборов ---------- */
  var LIB = null, libStyle = "kk", libKind = "png";
  function loadLib() {
    fetch("https://kodkreatora.bybusha.com/pack/manifest.json?t=" + Date.now()).then(function (r) { return r.json(); })
      .then(function (m) { LIB = m; if (!LIB.styles[libStyle]) libStyle = Object.keys(LIB.styles)[0]; if (cur === "Вставки") render(); })
      .catch(function (e) { LIB = { error: e.message }; if (cur === "Вставки") render(); });
  }
  function seqInfo(cb) { run("kk_fmt", [], cb); }
  function cachePath(style, rel) {
    var path = require("path"), os = require("os");
    return path.join(os.homedir(), "Documents", "КК Наборы", style, rel);
  }
  function download(url, file, done) {
    var fs = require("fs"), path = require("path"), https = require("https");
    if (fs.existsSync(file) && fs.statSync(file).size > 0) return done(null);
    fs.mkdirSync(path.dirname(file), { recursive: true });
    var tmp = file + ".part";
    (function get(u, n) { https.get(u, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && n < 6) { res.resume(); return get(res.headers.location, n + 1); }
      if (res.statusCode !== 200) { res.resume(); return done(new Error("HTTP " + res.statusCode)); }
      var out = fs.createWriteStream(tmp); res.pipe(out); out.on("finish", function () { out.close(function () { fs.renameSync(tmp, file); done(null); }); });
    }).on("error", done); })(url, 0);
  }
  function insertItem(i) {
    var it = LIB.styles[libStyle][libKind][i]; say("ok|Скачиваю «" + it.name + "»…");
    seqInfo(function (o) {
      if (!o) { say("err|Открой секвенцию"); return; }
      var f = it.files, key = libKind === "png" ? f.png : libKind === "tx" ? f.png : libKind === "an" ? f.mov : libKind === "bg" ? f[o] : libKind === "tr" ? f["mov_" + o] : (f["mov_" + o] || f["black_" + o]);
      var blend = libKind === "ov" && !f["mov_" + o] ? "screen" : "";
      if (!key) { say("err|Для этого формата нет файла"); return; }
      var url = key, file = cachePath(libStyle, decodeURIComponent(url.split("/").pop()).replace(/__/g, "/"));
      download(url, file, function (err) {
        if (err) { say("err|Не скачалось: " + err.message); return; }
        run("kk_insert", [file, libKind, libKind === "bg" ? 5 : 3, blend], say);
      });
    });
  }
  function render() {
    document.getElementById("tabs").innerHTML = Object.keys(TABS).map(function (k) { return '<button class="' + (k === cur ? "on" : "") + '" data-tab="' + k + '">' + k + '</button>'; }).join("");
    document.getElementById("view").innerHTML = TABS[cur]();
    var r = document.getElementById("dur");
    if (r) r.oninput = function () { dur = +r.value; document.getElementById("durv").textContent = dur + " с"; };
    var sw = document.getElementById("sw");
    if (sw) sw.oninput = function () { subW = +sw.value; document.getElementById("swv").textContent = subW; };
    var tf = document.getElementById("trf");
    if (tf) tf.oninput = function () { trf = +tf.value; document.getElementById("trfv").textContent = trf + " кадров"; };
  }
  document.addEventListener("mouseover", function (ev) { var v = ev.target.closest(".card") && ev.target.closest(".card").querySelector("video"); if (v && v.paused) v.play().catch(function () {}); });
  document.addEventListener("click", function (ev) {
    var b = ev.target.closest("button"); if (!b) return;
    if (b.dataset.tab) { cur = b.dataset.tab; render(); return; }
    if (b.dataset.ls) { libStyle = b.dataset.ls; render(); return; }
    if (b.dataset.lk) { libKind = b.dataset.lk; render(); return; }
    if (b.dataset.li !== undefined && LIB) { insertItem(+b.dataset.li); return; }
    if (b.dataset.s) { side = b.dataset.s; render(); return; }
    if (b.dataset.anim) run("kk_anim", [b.dataset.anim, side, dur], say);
    else if (b.dataset.ease) run("kk_ease", [b.dataset.ease], say);
    else if (b.dataset.sub) { sub = b.dataset.sub; render(); return; }
    else if (b.dataset.subgo) { say("ok|Выбери файл…"); run("kk_subs", [sub, "", subW], say); }
    else if (b.dataset.title) { ttxt = (document.getElementById("ttxt") || {}).value || ""; run("kk_title", [b.dataset.title, ttxt, 3], say); }
    else if (b.dataset.tr) run("kk_trans", [b.dataset.tr, trf], say);
    else if (b.dataset.cam) run("kk_camera", [b.dataset.cam], say);
    else if (b.dataset.fix) run("kk_fix", [b.dataset.fix], say);
    else if (b.dataset.acut) run("kk_audioCut", [3], say);
    else if (b.dataset.seq) run("kk_newSeq", [b.dataset.seq, +b.dataset.fps], say);
  });
  /* ---------- доступ по ключу из приложения КК ---------- */
  var ID = "kk-montazh", API = "https://script.google.com/macros/s/AKfycbw2LmiS_HoOdrIQko16UGsLNQj6T1Br2BymAb2bh8_iHPxOB8QyVgbiZ0vuPcwhHCPwyQ/exec", SITE = "https://kodkreatora.bybusha.com";
  var OFFLINE_DAYS = 30;
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { return null; } }
  function api(body) { return fetch(API, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify(body) }).then(function (r) { return r.json(); }); }
  var ERR = { bad_key: "Ключ не подошёл. Скопируй его заново в приложении КК.", not_student: "Доступ только для учениц программы КОД КРЕАТОРА.", expired: "Доступ к программе закончился.", soon: "Плагин скоро откроется ученицам." };
  function loginView(msg) {
    document.getElementById("tabs").innerHTML = "";
    document.getElementById("view").innerHTML = '<div class="login"><b style="font-size:14px">Вход в плагин</b>' +
      '<span class="note">Открой приложение КК → «Полезные материалы» → «Пак режиссёра монтажа» → плагин → «Получить ключ». Скопируй ключ и вставь сюда.</span>' +
      '<input id="key" placeholder="KK-…" autocomplete="off"><button class="btn y" id="go">Войти</button>' + (msg ? '<span class="note" style="color:#ff6b5b">' + msg + '</span>' : "") + '</div>';
    document.getElementById("go").onclick = function () { var k = document.getElementById("key").value.trim(); if (k) check(k, true); };
  }
  function enter(u) { document.getElementById("who").textContent = (u.n || "") + (u.u ? " · @" + u.u : ""); render(); checkUpdate(); }
  function check(key, interactive) {
    api({ api: "plugincheck", key: key }).then(function (r) {
      if (r.ok) { ls("kk_key", key); ls("kk_ok_at", String(Date.now())); ls("kk_user", JSON.stringify(r)); enter(r); }
      else { if (r.error !== "soon" || interactive) ls("kk_key", null); loginView(ERR[r.error] || "Не получилось войти: " + (r.error || "")); }
    }).catch(function () {
      var at = +ls("kk_ok_at") || 0, u = ls("kk_user");
      if (!interactive && u && Date.now() - at < OFFLINE_DAYS * 864e5) enter(JSON.parse(u)); // без интернета — 30 дней по сохранённому входу
      else loginView("Нет интернета: для первого входа он нужен.");
    });
  }

  /* ---------- обновления ---------- */
  function newer(a, b) { a = a.split(".").map(Number); b = b.split(".").map(Number); for (var i = 0; i < 3; i++) { if ((a[i] || 0) > (b[i] || 0)) return true; if ((a[i] || 0) < (b[i] || 0)) return false; } return false; }
  function checkUpdate() {
    fetch(SITE + "/plugin/version.json?t=" + Date.now()).then(function (r) { return r.json(); }).then(function (v) {
      var me = v[ID]; if (!me || !newer(me.v, VERSION)) return;
      var u = document.getElementById("upd"); u.hidden = false;
      u.innerHTML = '<span>Вышла версия ' + me.v + (me.notes ? ": " + me.notes : "") + '</span><button class="btn y" id="doupd" style="width:auto;padding:5px 10px">Обновить</button>';
      document.getElementById("doupd").onclick = function () { update(me); };
    }).catch(function () {});
  }
  function copyDir(src, dst) { // своё копирование: в старых Премьерах нет fs.cpSync
    var fs = require("fs"), path = require("path");
    if (!fs.existsSync(dst)) fs.mkdirSync(dst);
    fs.readdirSync(src).forEach(function (n) { var a = path.join(src, n), b = path.join(dst, n);
      if (fs.statSync(a).isDirectory()) copyDir(a, b); else fs.writeFileSync(b, fs.readFileSync(a)); });
  }
  function update(me) {
    var u = document.getElementById("upd");
    try {
      var https = require("https"), fs = require("fs"), path = require("path"), os = require("os"), cp = require("child_process");
      var dir = decodeURIComponent(String(cep.getSystemPath("extension")).replace(/^file:\/\//, ""));
      if (fs.lstatSync(dir).isSymbolicLink()) { u.innerHTML = "<span>Это версия разработчика — обновление не ставлю</span>"; return; }
      var zip = path.join(os.tmpdir(), ID + "-" + me.v + ".zip"), out = fs.createWriteStream(zip);
      u.innerHTML = "<span>Скачиваю обновление…</span>";
      var get = function (url) { https.get(url, function (res) { if (res.statusCode >= 300 && res.headers.location) return get(res.headers.location); res.pipe(out); out.on("finish", function () { out.close(unpack); }); }).on("error", function () { u.innerHTML = "<span>Не скачалось. Проверь интернет.</span>"; }); };
      var unpack = function () {
        var tmp = path.join(os.tmpdir(), ID + "-new"); try { fs.rmSync(tmp, { recursive: true, force: true }); } catch (e) {}
        var cmd = process.platform === "win32" ? 'powershell -NoProfile -Command "Expand-Archive -Force \'' + zip + '\' \'' + tmp + '\'"' : 'ditto -x -k "' + zip + '" "' + tmp + '"';
        cp.exec(cmd, function (err) {
          if (err) { u.innerHTML = "<span>Не распаковалось: " + err.message + "</span>"; return; }
          var src = path.join(tmp, ID); if (!fs.existsSync(src)) src = tmp;
          try { copyDir(src, dir); u.innerHTML = "<span>Готово! Перезапусти Премьер, чтобы включилась версия " + me.v + "</span>"; }
          catch (e2) { u.innerHTML = "<span>Не получилось заменить файлы: " + e2.message + "</span>"; }
        });
      };
      get(me.zip);
    } catch (e) { u.innerHTML = "<span>Обновление недоступно: " + e.message + "</span>"; }
  }

  document.getElementById("ver").textContent = "v" + VERSION;
  run("kk_ping", [], function (r) { var p = r.split("|"); if (p[0] !== "ok") document.getElementById("who").textContent = "нет связи с Premiere"; });
  var saved = ls("kk_key");
  if (saved) check(saved, false); else loginView();
})();

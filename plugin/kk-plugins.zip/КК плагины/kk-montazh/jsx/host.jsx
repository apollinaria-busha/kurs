/* КК · Монтаж — часть внутри Premiere Pro (ExtendScript, ES3: без let/const и стрелок).
   Скрипты Премьера не умеют задавать кривые плавности ключей, поэтому анимации «запекаются»:
   плагин сам считает промежуточные ключи по кривой (как это делают коммерческие плагины).
   Каждая функция возвращает строку: "ok|сообщение" или "err|сообщение". */

var KK_TICKS = 254016000000;

/* ---------- кривые ---------- */
var KK_EASE = {
  linear: function (t) { return t; },
  outCubic: function (t) { return 1 - Math.pow(1 - t, 3); },
  inCubic: function (t) { return t * t * t; },
  inOutCubic: function (t) { return t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; },
  outExpo: function (t) { return t === 1 ? 1 : 1 - Math.pow(2, -10 * t); },
  outQuint: function (t) { return 1 - Math.pow(1 - t, 5); },
  outBack: function (t) { var c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
  outElastic: function (t) { if (t === 0 || t === 1) return t; return Math.pow(2, -10 * t) * Math.sin((t * 10 - .75) * (2 * Math.PI / 3)) + 1; },
  outBounce: function (t) {
    var n = 7.5625, d = 2.75;
    if (t < 1 / d) return n * t * t;
    if (t < 2 / d) { t -= 1.5 / d; return n * t * t + .75; }
    if (t < 2.5 / d) { t -= 2.25 / d; return n * t * t + .9375; }
    t -= 2.625 / d; return n * t * t + .984375;
  }
};

/* ---------- помощники ---------- */
function kkSeq() { return app.project.activeSequence; }
function kkFps(seq) { return KK_TICKS / Number(seq.timebase); }
function kkSel() {
  var seq = kkSeq(); if (!seq) return [];
  var s = seq.getSelection(), out = [];
  for (var i = 0; i < s.length; i++) if (s[i].mediaType === "Video") out.push(s[i]);
  return out;
}
function kkComp(item, match) {
  for (var i = 0; i < item.components.numItems; i++) if (item.components[i].matchName === match) return item.components[i];
  return null;
}
function kkLerp(a, b, e) {
  if (a instanceof Array) { var r = []; for (var i = 0; i < a.length; i++) r.push(a[i] + (b[i] - a[i]) * e); return r; }
  return a + (b - a) * e;
}
/* клип: время начала/конца в «времени исходника» — так Премьер считает ключи */
function kkSpan(item) {
  var inS = item.inPoint.seconds, len = item.end.seconds - item.start.seconds;
  return { a: inS, b: inS + len, len: len };
}
function kkBase(prop, t) {
  return prop.isTimeVarying() ? prop.getValueAtTime(t) : prop.getValue();
}
/* ставит ряд ключей: f(k) -> значение, на кадрах t0..t1 */
function kkBake(prop, t0, t1, fps, f) {
  if (!prop.isTimeVarying()) prop.setTimeVarying(true);
  var n = Math.max(2, Math.round((t1 - t0) * fps));
  for (var k = 0; k <= n; k++) {
    var t = t0 + (t1 - t0) * k / n;
    prop.addKey(t);
    prop.setValueAtKey(t, f(k / n), k === n);
  }
}

/* ---------- анимации появления/исчезновения ---------- */
/* preset: pop | fadeUp | slide | zoom | drop | shake | blink ; side: in | out ; dur — секунды */
function kk_anim(preset, side, dur) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var items = kkSel(); if (!items.length) return "err|Выдели клип или текст на таймлайне";
    var fps = kkFps(seq), H = seq.frameSizeVertical, W = seq.frameSizeHorizontal;
    var U = Math.min(W, H) / 1080; // сдвиги в «пикселях 1080p»: одинаково смотрятся в 9:16, 16:9, 4K
    dur = Number(dur) || 0.4;
    for (var i = 0; i < items.length; i++) {
      var it = items[i], sp = kkSpan(it), d = Math.min(dur, sp.len / 2);
      var mo = kkComp(it, "AE.ADBE Motion"), op = kkComp(it, "AE.ADBE Opacity");
      if (!mo) return "err|У клипа нет «Движения»";
      var pos = mo.properties[0], sc = mo.properties[1], rot = mo.properties[4], opa = op ? op.properties[0] : null;
      var t0 = side === "out" ? sp.b - d : sp.a, t1 = side === "out" ? sp.b : sp.a + d;
      var refT = side === "out" ? t0 : t1;
      var P = kkBase(pos, refT), S = kkBase(sc, refT), O = opa ? kkBase(opa, refT) : 100;
      // прогресс появления 0..1; для исчезновения — зеркальная кривая
      var prog = function (fn, x) { return side === "out" ? 1 - kkIn(fn)(x) : KK_EASE[fn](x); };
      var fade = function (x) { var v = side === "out" ? 1 - Math.max(0, (x - .6) / .4) : Math.min(1, x * 3); return O * v; };
      if (preset === "pop") {
        kkBake(sc, t0, t1, fps, function (x) { return S * prog("outBack", x); });
        if (opa) kkBake(opa, t0, t1, fps, fade);
      } else if (preset === "zoom") {
        kkBake(sc, t0, t1, fps, function (x) { return S * prog("outExpo", x); });
        if (opa) kkBake(opa, t0, t1, fps, fade);
      } else if (preset === "fadeUp") {
        var dy = 80 * U / H;
        kkBake(pos, t0, t1, fps, function (x) { return [P[0], P[1] + dy * (1 - prog("outCubic", x))]; });
        if (opa) kkBake(opa, t0, t1, fps, fade);
      } else if (preset === "slide") {
        var dx = 260 * U / W;
        kkBake(pos, t0, t1, fps, function (x) { return [P[0] - dx * (1 - prog("outQuint", x)), P[1]]; });
        if (opa) kkBake(opa, t0, t1, fps, fade);
      } else if (preset === "drop") {
        var dd = 240 * U / H;
        kkBake(pos, t0, t1, fps, function (x) { return [P[0], P[1] - dd * (1 - prog("outBounce", x))]; });
        if (opa) kkBake(opa, t0, t1, fps, function (x) { return O * Math.min(1, (side === "out" ? 1 - x : x) * 4); });
      } else if (preset === "shake") {
        var a = 10 * U / W;
        kkBake(pos, t0, t1, fps, function (x) { var k = 1 - x; return [P[0] + a * k * Math.sin(x * 40), P[1] + a * .6 * k * Math.cos(x * 33)]; });
        kkBake(rot, t0, t1, fps, function (x) { return kkBase(rot, refT) + 3 * (1 - x) * Math.sin(x * 37); });
      } else if (preset === "blink") {
        if (!opa) return "err|У клипа нет «Непрозрачности»";
        kkBake(opa, t0, t1, fps, function (x) { var on = Math.floor(x * 6) % 2 === 0; return side === "out" ? (x > .95 ? 0 : (on ? O : 0)) : (x > .95 ? O : (on ? 0 : O)); });
      } else return "err|Неизвестная анимация";
    }
    return "ok|Готово: " + items.length + " шт.";
  } catch (e) { return "err|" + e.toString(); }
}
/* «вход» для исчезновения: зеркальная кривая */
function kkIn(fn) { return function (x) { return 1 - KK_EASE[fn](1 - x); }; }

/* ---------- плавность на готовых ключах ---------- */
/* kind: linear | hold | outCubic | inCubic | inOutCubic | outBack | outBounce | outElastic | ios */
function kk_ease(kind) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var items = kkSel(); if (!items.length) return "err|Выдели клип с ключами";
    var fps = kkFps(seq), changed = 0;
    var fn = kind === "ios" ? "outQuint" : kind;
    for (var i = 0; i < items.length; i++) {
      var comps = [kkComp(items[i], "AE.ADBE Motion"), kkComp(items[i], "AE.ADBE Opacity")];
      for (var c = 0; c < comps.length; c++) {
        if (!comps[c]) continue;
        for (var p = 0; p < comps[c].properties.numItems; p++) {
          var pr = comps[c].properties[p];
          if (!pr.isTimeVarying()) continue;
          var keys = pr.getKeys(); if (!keys || keys.length < 2) continue;
          if (kind === "linear" || kind === "hold") {
            var mode = kind === "hold" ? 4 : 0; // 4 — стоп-кадр, 0 — линейно (типы Премьера; плавность считаем сами)
            for (var k = 0; k < keys.length; k++) pr.setInterpolationTypeAtKey(keys[k], mode, k === keys.length - 1);
          } else {
            // между каждой парой ключей ставим промежуточные по кривой
            var pairs = [];
            for (var k2 = 0; k2 < keys.length - 1; k2++) pairs.push([keys[k2].seconds, keys[k2 + 1].seconds, pr.getValueAtKey(keys[k2]), pr.getValueAtKey(keys[k2 + 1])]);
            for (var q = 0; q < pairs.length; q++) {
              var a = pairs[q][0], b = pairs[q][1], va = pairs[q][2], vb = pairs[q][3];
              var n = Math.round((b - a) * fps); if (n < 3) continue;
              for (var f = 1; f < n; f++) {
                var t = a + (b - a) * f / n;
                pr.addKey(t); pr.setValueAtKey(t, kkLerp(va, vb, KK_EASE[fn](f / n)), false);
              }
            }
          }
          changed++;
        }
      }
    }
    return changed ? "ok|Плавность применена" : "err|На выделенном нет ключей: поставь хотя бы два";
  } catch (e) { return "err|" + e.toString(); }
}

/* ---------- движение камеры ---------- */
/* kind: zoomIn | zoomOut | breathe | panL | panR */
function kk_camera(kind) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var items = kkSel(); if (!items.length) return "err|Выдели клип";
    var fps = kkFps(seq), W = seq.frameSizeHorizontal, U = Math.min(W, seq.frameSizeVertical) / 1080;
    for (var i = 0; i < items.length; i++) {
      var sp = kkSpan(items[i]), mo = kkComp(items[i], "AE.ADBE Motion");
      var pos = mo.properties[0], sc = mo.properties[1], S = kkBase(sc, sp.a), P = kkBase(pos, sp.a);
      if (kind === "zoomIn") kkBake(sc, sp.a, sp.b, Math.min(fps, 12), function (x) { return S * (1 + .12 * KK_EASE.inOutCubic(x)); });
      else if (kind === "zoomOut") kkBake(sc, sp.a, sp.b, Math.min(fps, 12), function (x) { return S * (1.12 - .12 * KK_EASE.inOutCubic(x)); });
      else if (kind === "breathe") kkBake(sc, sp.a, sp.b, Math.min(fps, 12), function (x) { return S * (1.03 + .03 * Math.sin(x * Math.PI * 2 * Math.max(1, sp.len / 3))); });
      else {
        var dir = kind === "panL" ? -1 : 1, dx = 60 * U / W;
        kkBake(sc, sp.a, sp.a + .04, fps, function () { return S * 1.1; });
        kkBake(pos, sp.a, sp.b, Math.min(fps, 12), function (x) { return [P[0] - dir * dx / 2 + dir * dx * KK_EASE.inOutCubic(x), P[1]]; });
      }
    }
    return "ok|Готово";
  } catch (e) { return "err|" + e.toString(); }
}

/* ---------- переходы ---------- */
/* стык ищем по плейхеду: клип A кончается там, где начинается B (на одной дорожке, сверху вниз) */
function kkCut(seq) {
  var ph = seq.getPlayerPosition().seconds, half = 0.5 / kkFps(seq);
  for (var v = seq.videoTracks.numTracks - 1; v >= 0; v--) {
    var cl = seq.videoTracks[v].clips, a = null, b = null;
    for (var i = 0; i < cl.numItems; i++) {
      if (Math.abs(cl[i].end.seconds - ph) < half) a = cl[i];
      if (Math.abs(cl[i].start.seconds - ph) < half) b = cl[i];
    }
    if (a && b) return { a: a, b: b };
  }
  return null;
}
/* добавляет эффект «Преобразовать» с размытием движения и возвращает его компонент */
function kkTransform(item, blur) {
  var fx = kkFx(KK_FX.transform); if (!fx) return null;
  var qi = kkQeItem(item); if (!qi) return null;
  qi.addVideoEffect(fx);
  var c = item.components[item.components.numItems - 1];
  if (c.matchName !== "AE.ADBE Geometry2") return null;
  c.properties[9].setValue(blur ? false : true, true); // свой угол затвора
  if (blur) c.properties[10].setValue(360, true);
  return c;
}
/* kind: zoom | whipL | whipR | spin | stretch | shake | dip ; frames — кадров на каждую сторону */
function kk_trans(kind, frames) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var cut = kkCut(seq); if (!cut) return "err|Поставь плейхед точно на стык двух клипов";
    var fps = kkFps(seq), n = Number(frames) || 8, d = n / fps;
    var A = cut.a, B = cut.b, sa = kkSpan(A), sb = kkSpan(B);
    d = Math.min(d, sa.len / 2, sb.len / 2);
    var ta = kind === "dip" ? 1 : kkTransform(A, true), tb = kind === "dip" ? 1 : kkTransform(B, true);
    if (!ta || !tb) return "err|Не получилось добавить эффект «Преобразовать»";
    var a0 = sa.b - d, a1 = sa.b, b0 = sb.a, b1 = sb.a + d;
    var W = seq.frameSizeHorizontal, H = seq.frameSizeVertical;
    var inn = KK_EASE.inCubic, out = KK_EASE.outCubic;
    var P = function (c) { return c.properties[1]; }, SC = function (c) { return c.properties[3]; };
    if (kind === "zoom") {
      kkBake(SC(ta), a0, a1, fps, function (x) { return 100 + 150 * inn(x); });
      kkBake(SC(tb), b0, b1, fps, function (x) { return 250 - 150 * out(x); });
    } else if (kind === "whipL" || kind === "whipR") {
      var dir = kind === "whipL" ? -1 : 1, off = 0.3;
      kkBake(SC(ta), a0, a1, fps, function (x) { return 100 + 60 * inn(x); });
      kkBake(P(ta), a0, a1, fps, function (x) { return [0.5 + dir * off * inn(x), 0.5]; });
      kkBake(SC(tb), b0, b1, fps, function (x) { return 160 - 60 * out(x); });
      kkBake(P(tb), b0, b1, fps, function (x) { return [0.5 - dir * off * (1 - out(x)), 0.5]; });
    } else if (kind === "spin") {
      // на каждом кадре масштаб ровно такой, чтобы повёрнутый кадр закрывал окно (без чёрных углов)
      var szA = kkSrcSize(A) || [W, H], szB = kkSrcSize(B) || [W, H];
      var cover = function (sz, deg) { var t = Math.abs(deg) * Math.PI / 180, c = Math.abs(Math.cos(t)), si = Math.abs(Math.sin(t)), w = sz[0], h = sz[1];
        return Math.max((w * c + h * si) / w, (w * si + h * c) / h) * 100 * 1.02; };
      kkBake(ta.properties[7], a0, a1, fps, function (x) { return 180 * inn(x); });
      kkBake(SC(ta), a0, a1, fps, function (x) { return cover(szA, 180 * inn(x)); });
      kkBake(tb.properties[7], b0, b1, fps, function (x) { return -180 * (1 - out(x)); });
      kkBake(SC(tb), b0, b1, fps, function (x) { return cover(szB, 180 * (1 - out(x))); });
    } else if (kind === "stretch") {
      ta.properties[2].setValue(false, true); tb.properties[2].setValue(false, true);
      kkBake(ta.properties[4], a0, a1, fps, function (x) { return 100 + 250 * inn(x); });
      kkBake(tb.properties[4], b0, b1, fps, function (x) { return 350 - 250 * out(x); });
    } else if (kind === "shake") {
      var amp = 0.03, b2 = Math.min(sb.b, sb.a + d * 2);
      SC(tb).setValue(112, true);
      kkBake(P(tb), b0, b2, fps, function (x) { var k = Math.pow(1 - x, 2); return [0.5 + amp * k * Math.sin(x * 47), 0.5 + amp * k * Math.cos(x * 39)]; });
      kkBake(tb.properties[7], b0, b2, fps, function (x) { return 4 * Math.pow(1 - x, 2) * Math.sin(x * 31); });
      kkBake(SC(ta), a0, a1, fps, function (x) { return 100 + 12 * inn(x); });
    } else if (kind === "dip") {
      var oa = kkComp(A, "AE.ADBE Opacity").properties[0], ob = kkComp(B, "AE.ADBE Opacity").properties[0];
      kkBake(oa, a0, a1, fps, function (x) { return 100 * (1 - KK_EASE.inOutCubic(x)); });
      kkBake(ob, b0, b1, fps, function (x) { return 100 * KK_EASE.inOutCubic(x); });
    } else return "err|Неизвестный переход";
    return "ok|Переход «" + kind + "» на стыке готов";
  } catch (e) { return "err|" + e.toString(); }
}

/* ---------- субтитры ---------- */
function kkTime(sec) { var t = new Time(); t.seconds = sec; return t; }
function kkSrtTime(s) { var m = /(\d+):(\d+):(\d+)[,.](\d+)/.exec(s); return m ? (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) + (+m[4]) / 1000 : 0; }
function kkReadSrt(path) {
  var f = new File(path); f.encoding = "UTF-8"; if (!f.open("r")) return null;
  var txt = f.read(); f.close();
  txt = txt.replace(/^\uFEFF/, "").replace(/\r/g, "");
  var blocks = txt.split(/\n\s*\n/), out = [];
  for (var i = 0; i < blocks.length; i++) {
    var L = blocks[i].split("\n"), k = 0;
    while (k < L.length && L[k].indexOf("-->") < 0) k++;
    if (k >= L.length) continue;
    var tt = L[k].split("-->"), text = L.slice(k + 1).join(" ").replace(/<[^>]+>/g, "").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
    if (text) out.push({ a: kkSrtTime(tt[0]), b: kkSrtTime(tt[1]), t: text });
  }
  return out;
}
/* режем реплику на короткие фразы, время делим пропорционально длине слов */
function kkChunks(cues, maxW) {
  var out = [];
  for (var i = 0; i < cues.length; i++) {
    var w = cues[i].t.split(" "), total = 0, lens = [];
    for (var j = 0; j < w.length; j++) { lens.push(w[j].length + 1); total += w[j].length + 1; }
    var t = cues[i].a, span = cues[i].b - cues[i].a;
    for (var s = 0; s < w.length; s += maxW) {
      var part = w.slice(s, s + maxW), pl = 0;
      for (var q = s; q < Math.min(w.length, s + maxW); q++) pl += lens[q];
      var d = span * pl / total;
      out.push({ a: t, b: t + d, t: part.join(" ") }); t += d;
    }
  }
  return out;
}
function kkSetMgt(item, name, value) {
  var c = item.getMGTComponent(); if (!c) return false;
  var p = c.properties.getParamForDisplayName(name); if (!p) return false;
  p.setValue(value, true); return true;
}
/* style: id шаблона (kk-word, word-by-word, karaoke, caps-stroke, minimal, kk-plate, typewriter, pop-word) */
function kk_subs(style, srtPath, maxWords) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var fmt = seq.frameSizeHorizontal >= seq.frameSizeVertical ? "h" : "v";
    var mg = new File(KK_DIR + "/mogrt/subs-" + style + "-" + fmt + ".mogrt"); if (!mg.exists) return "err|Нет шаблона " + style;
    if (!srtPath) { var pick = File.openDialog("Выбери файл субтитров .srt (Премьер: Подписи → Экспорт в SRT)", "*.srt"); if (!pick) return "err|Файл не выбран"; srtPath = pick.fsName; }
    var cues = kkReadSrt(srtPath); if (!cues || !cues.length) return "err|В файле нет субтитров";
    var parts = kkChunks(cues, Number(maxWords) || (fmt === "v" ? 4 : 7));
    app.enableQE();
    qe.project.getActiveSequence().addTracks(1, seq.videoTracks.numTracks, 0); // новая дорожка сверху
    var vIdx = seq.videoTracks.numTracks - 1, ok = 0;
    for (var i = 0; i < parts.length; i++) {
      var P = parts[i];
      var it = seq.importMGT(mg.fsName, String(Math.round(P.a * KK_TICKS)), vIdx, 0);
      if (!it) continue;
      it.end = kkTime(P.b);
      kkSetMgt(it, "Текст", P.t);
      kkSetMgt(it, "Длительность", Math.max(0.2, P.b - P.a));
      ok++;
    }
    return "ok|Субтитры готовы: " + ok + " фраз на дорожке V" + (vIdx + 1);
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- вставки из стилевых наборов ---------- */
var KK_BLEND_SCREEN = 22; // «Экран» (проверено в 25.1: значение свойства «Режим смешивания»)
function kkBin(name) {
  var r = app.project.rootItem;
  for (var i = 0; i < r.children.numItems; i++) if (r.children[i].name === name && r.children[i].type === ProjectItemType.BIN) return r.children[i];
  return r.createBin(name);
}
function kkFindByPath(bin, path) {
  for (var i = 0; i < bin.children.numItems; i++) { var c = bin.children[i]; try { if (c.getMediaPath && c.getMediaPath() === path) return c; } catch (e) {} }
  return null;
}
/* дорожка, свободная на [a,b], выше V1; если нет — добавляем новую сверху */
function kkFreeTrack(seq, a, b) {
  for (var v = 1; v < seq.videoTracks.numTracks; v++) {
    var cl = seq.videoTracks[v].clips, busy = false;
    for (var i = 0; i < cl.numItems; i++) if (cl[i].start.seconds < b - 0.001 && cl[i].end.seconds > a + 0.001) { busy = true; break; }
    if (!busy) return v;
  }
  app.enableQE(); qe.project.getActiveSequence().addTracks(1, seq.videoTracks.numTracks, 0);
  return seq.videoTracks.numTracks - 1;
}
/* kind: png | an | tr | ov | bg | tx ; secs — длительность для картинок; blend — "screen" для оверлеев на чёрном */
function kk_insert(path, kind, secs, blend) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var f = new File(path); if (!f.exists) return "err|Файл не скачался";
    var bin = kkBin("КК · Наборы"), it = kkFindByPath(bin, f.fsName);
    if (!it) { app.project.importFiles([f.fsName], true, bin, false); it = kkFindByPath(bin, f.fsName); }
    if (!it) return "err|Не получилось импортировать файл";
    var ph = seq.getPlayerPosition().seconds, d = Number(secs) || 3;
    var isStill = /\.(png|jpe?g)$/i.test(f.name);
    if (!isStill) { try { d = it.getOutPoint().seconds - it.getInPoint().seconds; } catch (e) {} }
    var t0 = kind === "tr" ? Math.max(0, ph - d / 2) : ph; // переход — серединой на склейку
    var v = kind === "bg" ? 0 : kkFreeTrack(seq, t0, t0 + d);
    if (kind === "bg") { app.enableQE(); qe.project.getActiveSequence().addTracks(1, 0, 0); v = 0; } // фон — на новую нижнюю дорожку
    seq.videoTracks[v].overwriteClip(it, t0);
    var cl = seq.videoTracks[v].clips, placed = null;
    for (var i = 0; i < cl.numItems; i++) if (Math.abs(cl[i].start.seconds - t0) < 0.02) placed = cl[i];
    if (placed) {
      if (isStill) placed.end = kkTime(t0 + d);
      if (blend === "screen") { var op = kkComp(placed, "AE.ADBE Opacity"); if (op) op.properties[1].setValue(KK_BLEND_SCREEN, true); }
      if (kind === "bg" || kind === "ov" || kind === "tr") { // растянуть на кадр
        var sz = kkSrcSize(placed), mo = kkComp(placed, "AE.ADBE Motion");
        if (sz && mo) mo.properties[1].setValue(Math.ceil(Math.max(seq.frameSizeHorizontal / sz[0], seq.frameSizeVertical / sz[1]) * 1000) / 10, true);
      }
    }
    return "ok|Вставлено на V" + (v + 1) + (blend === "screen" ? " с режимом «Экран»" : "");
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- готовые титры ---------- */
function kk_title(id, txt, secs) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var fmt = seq.frameSizeHorizontal >= seq.frameSizeVertical ? "h" : "v";
    var mg = new File(KK_DIR + "/mogrt/title-" + id + "-" + fmt + ".mogrt"); if (!mg.exists) return "err|Нет шаблона " + id;
    var ph = seq.getPlayerPosition().seconds, d = Number(secs) || 3, v = kkFreeTrack(seq, ph, ph + d);
    var it = seq.importMGT(mg.fsName, String(Math.round(ph * KK_TICKS)), v, 0); if (!it) return "err|Не получилось вставить титр";
    it.end = kkTime(ph + d);
    if (txt) kkSetMgt(it, "Текст", txt);
    return "ok|Титр на V" + (v + 1) + ". Цвета — в «Основных графических элементах»";
  } catch (e) { return "err|" + e.toString(); }
}

/* ---------- рилс ---------- */
var KK_DIR = (new File($.fileName)).parent.parent.fsName; // папка плагина
var KK_FORMATS = {
  v: [1080, 1920, "Вертикаль 9x16"], h: [1920, 1080, "Горизонталь 16x9"], h4k: [3840, 2160, "Горизонталь 4K"],
  p45: [1080, 1350, "Пост 4x5"], sq: [1080, 1080, "Квадрат 1x1"]
};
/* fmt: v | h | h4k | p45 | sq ; fps: 24 | 25 | 30 | 50 | 60 */
function kk_newSeq(fmt, fps) {
  try {
    var f = KK_FORMATS[fmt]; if (!f) return "err|Неизвестный формат";
    var d = new Date(), name = f[2] + " " + d.getHours() + "-" + (d.getMinutes() < 10 ? "0" : "") + d.getMinutes();
    var preset = new File(KK_DIR + "/presets/reel-9x16.sqpreset");
    if (!preset.exists) return "err|Не нашла пресет в папке плагина";
    app.enableQE();
    qe.project.newSequence(name, preset.fsName); // без окна выбора, дальше задаём размер сами
    var seq = app.project.activeSequence; if (!seq) return "err|Секвенция не создалась";
    var s = seq.getSettings();
    s.videoFrameWidth = f[0]; s.videoFrameHeight = f[1];
    if (fps) { var tb = new Time(); tb.seconds = 1 / Number(fps); s.videoFrameRate = tb; }
    seq.setSettings(s);
    return "ok|Создана «" + name + "» " + f[0] + "×" + f[1] + ", " + (fps || 30) + " кадров";
  } catch (e) { return "err|" + e.toString(); }
}
function kk_reelSeq(fps) { return kk_newSeq("v", fps); } // старое имя

/* ---------- исправить ---------- */
var KK_FX = {
  stab: ["Warp Stabilizer", "Стабилизатор деформации"],
  transform: ["Transform", "Преобразовать"]
};
function kkQeItem(item) {
  app.enableQE();
  var qs = qe.project.getActiveSequence(), seq = kkSeq();
  for (var v = 0; v < seq.videoTracks.numTracks; v++) {
    var tr = seq.videoTracks[v];
    for (var c = 0; c < tr.clips.numItems; c++) if (tr.clips[c].nodeId === item.nodeId) {
      var qt = qs.getVideoTrackAt(v), n = 0;
      for (var q = 0; q < qt.numItems; q++) { var qi = qt.getItemAt(q); if (qi.type === "Empty") continue; if (n === c) return qi; n++; }
    }
  }
  return null;
}
// getVideoEffectByName «находит» что угодно, поэтому сверяемся со списком эффектов этой версии/языка
function kkFx(names) {
  app.enableQE();
  var list = qe.project.getVideoEffectList(), have = {};
  for (var j = 0; j < list.length; j++) have[list[j]] = 1;
  for (var i = 0; i < names.length; i++) if (have[names[i]]) return qe.project.getVideoEffectByName(names[i]);
  return null;
}
function kkSrcSize(item) {
  try { var m = item.projectItem.getProjectMetadata(); var r = /VideoInfo>(\d+) x (\d+)/.exec(m); if (r) return [+r[1], +r[2]]; } catch (e) {}
  return null;
}
function kk_fix(kind) {
  try {
    var items = kkSel(); if (!items.length) return "err|Выдели клип";
    if (kind === "stab") {
      var fx = kkFx(KK_FX.stab); if (!fx) return "err|Не нашла «Стабилизатор деформации» в этой версии";
      for (var i = 0; i < items.length; i++) { var qi = kkQeItem(items[i]); if (qi) qi.addVideoEffect(fx); }
      return "ok|Стабилизатор добавлен. Дождись анализа; рамки убирает режим «Стабилизация, обрезка, автомасштаб» (стоит по умолчанию)";
    }
    if (kind === "frames") {
      // подогнать кадр под секвенцию: масштаб «заполнить»
      var seq = kkSeq();
      for (var j = 0; j < items.length; j++) {
        var mo = kkComp(items[j], "AE.ADBE Motion"), pi = items[j].projectItem;
        var w = 0, h = 0;
        try { var md = pi.getFootageInterpretation(); } catch (e2) {}
        try { var m = pi.getProjectMetadata(); var r = /VideoInfo>(\d+) x (\d+)/.exec(m); if (r) { w = +r[1]; h = +r[2]; } } catch (e3) {}
        if (!w || !h) continue;
        var sc = Math.max(seq.frameSizeHorizontal / w, seq.frameSizeVertical / h) * 100;
        var cur = mo.properties[1];
        if (cur.isTimeVarying()) cur.setTimeVarying(false);
        cur.setValue(Math.ceil(sc * 1.02 * 10) / 10, true);
      }
      return "ok|Кадр растянут на весь экран, чёрных рамок нет";
    }
    if (kind === "slow50" || kind === "slow25") {
      var sp = kind === "slow50" ? 0.5 : 0.25, n = 0;
      for (var k = 0; k < items.length; k++) {
        var q = kkQeItem(items[k]); if (!q) continue;
        try { q.setSpeed(sp, "", false, false, false); } catch (e4) {} // Премьер 25.1 меняет скорость, но кидает ошибку — проверяем по факту
        try { q.setTimeInterpolationType(2); } catch (e5) {}        // 2 — оптический поток: плавное слоумо без рывков
        if (Math.abs(kkQeItem(items[k]).speed - sp) < 0.001) n++;
      }
      return n ? "ok|Слоумо " + (sp * 100) + "% с оптическим потоком. Длина клипа на таймлайне не изменилась" : "err|Не получилось поменять скорость";
    }
    return "err|Неизвестное действие";
  } catch (e) { return "err|" + e.toString(); }
}
/* мягкая склейка звука по плейхеду: короткое затухание/нарастание (равная мощность), без щелчка */
function kk_audioCut(frames) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var fps = kkFps(seq), d = (Number(frames) || 3) / fps, ph = seq.getPlayerPosition().seconds, half = 0.5 / fps, n = 0;
    for (var t = 0; t < seq.audioTracks.numTracks; t++) {
      var cl = seq.audioTracks[t].clips, a = null, b = null;
      for (var i = 0; i < cl.numItems; i++) {
        if (Math.abs(cl[i].end.seconds - ph) < half) a = cl[i];
        if (Math.abs(cl[i].start.seconds - ph) < half) b = cl[i];
      }
      if (a) { var la = a.components[0].properties[1], sa = kkSpan(a), va = kkBase(la, sa.b - d);
        kkBake(la, sa.b - d, sa.b, fps, function (x) { return va * Math.cos(x * Math.PI / 2); }); n++; }
      if (b) { var lb = b.components[0].properties[1], sb = kkSpan(b), vb = kkBase(lb, sb.a + d);
        kkBake(lb, sb.a, sb.a + d, fps, function (x) { return vb * Math.sin(x * Math.PI / 2); }); n++; }
    }
    return n ? "ok|Звук на стыке сглажен (" + n + " клип.)" : "err|Поставь плейхед на стык звука";
  } catch (e) { return "err|" + e.toString(); }
}

function kk_fmt() { var s = app.project.activeSequence; return s ? (s.frameSizeHorizontal >= s.frameSizeVertical ? "h" : "v") : ""; }
function kk_ping() { return "ok|" + app.version + "|" + (app.project ? app.project.name : ""); }

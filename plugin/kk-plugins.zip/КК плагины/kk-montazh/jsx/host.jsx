/* КК · Монтаж — часть внутри Premiere Pro (ExtendScript, ES3: без let/const и стрелок).
   Скрипты Премьера не умеют задавать кривые плавности ключей, поэтому анимации «запекаются»:
   плагин сам считает промежуточные ключи по кривой (как это делают коммерческие плагины).
   Каждая функция возвращает строку: "ok|сообщение" или "err|сообщение". */

var KK_TICKS = 254016000000;

/* ---------- кривые ---------- */
var KK_EASE = {
  linear: function (t) { return t; },
  outCubic: function (t) { return 1 - Math.pow(1 - t, 3); },
  inCubic: function (t) { return t * t * t; },
  inOutCubic: function (t) { return t < .5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2; },
  outExpo: function (t) { return t === 1 ? 1 : 1 - Math.pow(2, -10 * t); },
  outQuint: function (t) { return 1 - Math.pow(1 - t, 5); },
  inOutQuint: function (t) { return t < .5 ? 16 * Math.pow(t, 5) : 1 - Math.pow(-2 * t + 2, 5) / 2; },
  inOutSine: function (t) { return -(Math.cos(Math.PI * t) - 1) / 2; },
  inExpo: function (t) { return t === 0 ? 0 : Math.pow(2, 10 * t - 10); },
  outCirc: function (t) { return Math.sqrt(1 - Math.pow(t - 1, 2)); },
  inOutBack: function (t) { var c2 = 1.70158 * 1.525; return t < .5 ? (Math.pow(2 * t, 2) * ((c2 + 1) * 2 * t - c2)) / 2 : (Math.pow(2 * t - 2, 2) * ((c2 + 1) * (t * 2 - 2) + c2) + 2) / 2; },
  outBack: function (t) { var c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
  outElastic: function (t) { if (t === 0 || t === 1) return t; return Math.pow(2, -10 * t) * Math.sin((t * 10 - .75) * (2 * Math.PI / 3)) + 1; },
  outBounce: function (t) {
    var n = 7.5625, d = 2.75;
    if (t < 1 / d) return n * t * t;
    if (t < 2 / d) { t -= 1.5 / d; return n * t * t + .75; }
    if (t < 2.5 / d) { t -= 2.25 / d; return n * t * t + .9375; }
    t -= 2.625 / d; return n * t * t + .984375;
  }
};
/* ---------- кривые v2: пружины iOS, безье как в CSS, ступени, глитч… ---------- */
var KK_EASE_N = 24;                                   // кадров между ключами — для покадровых кривых (стоп-моушн, глитч, дрожь)
function kkHash(i) { var x = Math.sin(i * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); }
function kkClamp01(x) { return x < 0 ? 0 : x > 1 ? 1 : x; }
/* пружина «из покоя в цель»: z — затухание (1 — без перелёта), w — жёсткость за всю длину */
function kkSpring(z, w) {
  var raw = function (t) {
    if (z >= 1) return 1 - Math.exp(-w * t) * (1 + w * t);
    var wd = w * Math.sqrt(1 - z * z);
    return 1 - Math.exp(-z * w * t) * (Math.cos(wd * t) + z * w / wd * Math.sin(wd * t));
  };
  var end = raw(1);
  return function (t) { if (t <= 0) return 0; if (t >= 1) return 1; return raw(t) + t * (1 - end); };
}
/* cubic-bezier(x1, y1, x2, y2) как в CSS: ищем параметр кривой по времени (Ньютон + деление пополам) */
function kkBez(x1, y1, x2, y2) {
  var cx = 3 * x1, bx = 3 * (x2 - x1) - cx, ax = 1 - cx - bx, cy = 3 * y1, by = 3 * (y2 - y1) - cy, ay = 1 - cy - by;
  var X = function (s) { return ((ax * s + bx) * s + cx) * s; };
  return function (t) {
    if (t <= 0) return 0; if (t >= 1) return 1;
    var s = t, i;
    for (i = 0; i < 8; i++) { var e = X(s) - t, dx = (3 * ax * s + 2 * bx) * s + cx; if (Math.abs(e) < 1e-6 || Math.abs(dx) < 1e-6) break; s -= e / dx; }
    if (s < 0 || s > 1 || Math.abs(X(s) - t) > 1e-5) { var lo = 0, hi = 1; s = t; for (i = 0; i < 40; i++) { if (X(s) < t) lo = s; else hi = s; s = (lo + hi) / 2; } }
    return ((ay * s + by) * s + cy) * s;
  };
}
function kkBackC(u, c) { return 1 + (c + 1) * Math.pow(u - 1, 3) + c * Math.pow(u - 1, 2); }
function kkLaunch(t) { var a = .35, v = 1 / (1 - a / 2); return t < a ? v * t * t / (2 * a) : v * (t - a / 2); }
(function () {
  var E = KK_EASE;
  E.twoStage = function (t) { if (t < .42) return .5 * E.inOutSine(t / .42); if (t < .58) return .5; return .5 + .5 * E.inOutSine((t - .58) / .42); };
  E.drift = function (t) { return .5 * E.outExpo(t) + .5 * t; };
  E.softOver = kkBez(.5, 0, .2, 1.6);
  E.uiStd = kkBez(.4, 0, .2, 1);
  E.springIOS = kkSpring(.7, 9);
  E.springBouncy = kkSpring(.4, 15);
  E.springWobbly = kkSpring(.2, 25);
  E.brake = function (t) { var f = 1 - kkLaunch(1 - t); if (t > .86) f += .035 * Math.sin(Math.PI * (t - .86) / .14); return f; };
  E.launch = kkLaunch;
  E.jumpStart = function (t) { return t <= 0 ? 0 : .35 + .65 * E.outCubic(t); };
  E.speedRamp = function (t) { return t < .5 ? .5 * (1 - Math.pow(1 - 2 * t, 3)) : .5 + .5 * Math.pow(2 * t - 1, 3); };
  E.hang = function (t) { if (t < .22) return .48 * E.outCubic(t / .22); if (t < .78) return .48 + .04 * (t - .22) / .56; return .52 + .48 * E.inCubic((t - .78) / .22); };
  E.inBack = function (t) { var c1 = 1.70158; return (c1 + 1) * t * t * t - c1 * t * t; };
  E.oneBounce = function (t) { if (t < .6) return (t / .6) * (t / .6); var u = (t - .6) / .4; return 1 - .88 * u * (1 - u); };
  E.steps = function (t) { return t >= 1 ? 1 : Math.min(4, Math.floor(t * 5)) / 4; };
  E.stopMotion = function (t) { if (t >= 1) return 1; var h = 3 / Math.max(3, KK_EASE_N || 24); return E.inOutCubic(Math.floor(t / h + 1e-9) * h); };
  E.surges = function (t) { return t - Math.sin(6 * Math.PI * t) / (6 * Math.PI); };
  E.hesitate = function (t) { if (t < .35) return .6 * E.outCubic(t / .35); if (t < .55) return .6 - .22 * E.inOutSine((t - .35) / .2); return .38 + .62 * E.inOutCubic((t - .55) / .45); };
  E.holdSnap = function (t) { return t < .55 ? 0 : E.outBack((t - .55) / .45); };
  E.snapHold = function (t) { return t < .35 ? 1 - Math.pow(1 - t / .35, 4) : 1; };
  E.magnet = function (t) { if (t < .85) return Math.pow(t / .85, 4); var u = (t - .85) / .15; return 1 + .08 * Math.sin(u * Math.PI * 2) * (1 - u); };
  E.tick = function (t) { if (t >= 1) return 1; var k = Math.floor(t * 4), u = t * 4 - k; return (k + E.outBack(Math.min(1, u / .3))) / 4; };
  E.latch = function (t) { if (t < .8) return .86 * E.outCubic(t / .8); var u = (t - .8) / .2; return u < .4 ? .86 + .14 * kkBackC(u / .4, 3) : 1; };
  E.robot = function (t) { var T = [0, .25, .5, .75, 1], V = [0, .42, .5, .92, 1]; for (var i = 1; i < 5; i++) if (t <= T[i]) return V[i - 1] + (V[i] - V[i - 1]) * (t - T[i - 1]) / (T[i] - T[i - 1]); return 1; };
  E.inBounce = function (t) { return 1 - E.outBounce(1 - t); };
  E.windup = function (t) { return t < .35 ? -.18 * E.inOutSine(t / .35) : -.18 + 1.18 * E.outExpo((t - .35) / .65); };
  E.vibro = function (t) { var C = Math.max(3, Math.min(14, Math.floor((KK_EASE_N || 24) / 2.5))); return E.inOutCubic(t) + .06 * Math.sin(2 * Math.PI * C * t) * Math.sin(Math.PI * t); };
  E.inElastic = function (t) { if (t <= 0) return 0; if (t >= 1) return 1; return -Math.pow(2, 10 * t - 10) * Math.sin((t * 10 - 10.75) * 2 * Math.PI / 3); };
  E.glitch = function (t) { if (t <= 0) return 0; if (t >= 1) return 1; if (t > .75) return E.outCubic(t); var h = 2 / Math.max(4, KK_EASE_N || 24), k = Math.floor(t / h + 1e-9), q = k * h; return E.outCubic(q) + (kkHash(k + 1) - .5) * .7 * (1 - q / .75); };
  E.flicker = function (t) { if (t >= .6) return 1; var i = Math.floor(t * (KK_EASE_N || 24)); return ((i * 7 + 3) % 5 < 2) ? 1 : 0; };
  E.whip = function (t) { if (t <= 0) return 0; return t < .5 ? Math.pow(2, 20 * t - 10) / 2 : .5 + .5 * kkBackC((t - .5) / .5, 4); };
  E.punch = function (t) { if (t < .18) return 1.25 * E.outCubic(t / .18); var u = (t - .18) / .82, e5 = Math.exp(-5); return 1 + .25 * (Math.exp(-5 * u) - e5) / (1 - e5); };
  E.coin = function (t) { if (t < .3) return E.outCubic(t / .3); var u = (t - .3) / .7, C = Math.max(2, Math.min(6, Math.floor((KK_EASE_N || 24) * .7 / 3))); return 1 + .2 * (1 - u) * (1 - u) * Math.sin(2 * Math.PI * C * u * u); };
  E.pingpong = function (t) { if (t < .4) return E.inOutCubic(t / .4); if (t < .65) return 1 - E.inOutCubic((t - .4) / .25); return E.inOutCubic((t - .65) / .35); };
  E.inOutElastic = function (t) { if (t <= 0) return 0; if (t >= 1) return 1; var c5 = 2 * Math.PI / 4.5; return t < .5 ? -(Math.pow(2, 20 * t - 10) * Math.sin((20 * t - 11.125) * c5)) / 2 : (Math.pow(2, -20 * t + 10) * Math.sin((20 * t - 11.125) * c5)) / 2 + 1; };
})();

/* ---------- помощники ---------- */
function kkSeq() { return app.project.activeSequence; }
function kkFps(seq) { return KK_TICKS / Number(seq.timebase); }
function kkSel() {
  var seq = kkSeq(); if (!seq) return [];
  var s = seq.getSelection(), out = [];
  for (var i = 0; i < s.length; i++) if (s[i].mediaType === "Video") out.push(s[i]);
  return out;
}
function kkComp(item, match) {
  for (var i = 0; i < item.components.numItems; i++) if (item.components[i].matchName === match) return item.components[i];
  return null;
}
function kkLerp(a, b, e) {
  if (a instanceof Array) { var r = []; for (var i = 0; i < a.length; i++) r.push(a[i] + (b[i] - a[i]) * e); return r; }
  return a + (b - a) * e;
}
/* клип: время начала/конца в «времени исходника» — так Премьер считает ключи */
function kkSpan(item) {
  var inS = item.inPoint.seconds, len = item.end.seconds - item.start.seconds;
  return { a: inS, b: inS + len, len: len };
}
function kkBase(prop, t) {
  return prop.isTimeVarying() ? prop.getValueAtTime(t) : prop.getValue();
}
/* ставит ряд ключей: f(k) -> значение, на кадрах t0..t1 */
function kkBake(prop, t0, t1, fps, f) {
  if (!prop.isTimeVarying()) prop.setTimeVarying(true);
  var n = Math.max(2, Math.round((t1 - t0) * fps));
  for (var k = 0; k <= n; k++) {
    var t = t0 + (t1 - t0) * k / n;
    prop.addKey(t);
    prop.setValueAtKey(t, f(k / n), k === n);
  }
}
/* ключи «стоп-кадром» в заданные моменты: значение держится до следующего ключа (резкие смены, без перетекания) */
function kkHoldKeys(prop, t0, t1) {
  try { var ks = prop.getKeys(); if (!ks) return;
    for (var i = 0; i < ks.length; i++) if (ks[i].seconds >= t0 - 1e-4 && ks[i].seconds < t1 - 1e-4) prop.setInterpolationTypeAtKey(ks[i], 4, false); } catch (e) {}
}
function kkKeysAt(prop, ts, vs, hold) {
  if (!prop.isTimeVarying()) prop.setTimeVarying(true);
  for (var i = 0; i < ts.length; i++) { prop.addKey(ts[i]); prop.setValueAtKey(ts[i], vs[i], i === ts.length - 1); }
  if (hold) kkHoldKeys(prop, ts[0], ts[ts.length - 1] + 1e-3);
}
/* ступени: каждые step секунд новое значение f(x, i), x — доля пути 0..1; в конце ключ f(1) */
function kkSteps(prop, t0, t1, step, f) {
  if (!prop.isTimeVarying()) prop.setTimeVarying(true);
  var n = Math.max(1, Math.floor((t1 - t0) / step + 1e-6)), len = Math.max(1e-6, t1 - t0);
  for (var i = 0; i < n; i++) { var t = t0 + i * step; prop.addKey(t); prop.setValueAtKey(t, f((t - t0) / len, i), false); }
  prop.addKey(t1); prop.setValueAtKey(t1, f(1, n), true);
  kkHoldKeys(prop, t0, t1);
}
/* поворот кадра на deg без чёрных углов: во сколько раз увеличить (кадр w×h) */
function kkRotCover(w, h, deg) { var t = Math.abs(deg) * Math.PI / 180, c = Math.abs(Math.cos(t)), s = Math.abs(Math.sin(t)); return Math.max((w * c + h * s) / w, (w * s + h * c) / h); }
function kkCoverWin(sz, deg, win) { var m = 0; for (var d = -win; d <= win; d += 5) m = Math.max(m, kkRotCover(sz[0], sz[1], deg + d)); return m; }
/* момент плейхеда во «времени исходника» клипа; если плейхед вне клипа — 40% длины */
function kkSrcAt(seq, item, sp) {
  var ph = seq.getPlayerPosition().seconds;
  if (ph > item.start.seconds + 0.02 && ph < item.end.seconds - 0.05) return sp.a + (ph - item.start.seconds);
  return sp.a + sp.len * 0.4;
}

/* ---------- анимации появления/исчезновения ---------- */
/* preset: pop | fadeUp | slide | zoom | drop | shake | blink ; side: in | out ; dur — секунды */
function kk_anim(preset, side, dur) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var items = kkSel(); if (!items.length) return "err|Выдели клип или текст на таймлайне";
    var fps = kkFps(seq), H = seq.frameSizeVertical, W = seq.frameSizeHorizontal;
    var U = Math.min(W, H) / 1080; // сдвиги в «пикселях 1080p»: одинаково смотрятся в 9:16, 16:9, 4K
    dur = Number(dur) || 0.4;
    for (var i = 0; i < items.length; i++) {
      var it = items[i], sp = kkSpan(it), d = Math.min(dur, sp.len / 2);
      var mo = kkComp(it, "AE.ADBE Motion"), op = kkComp(it, "AE.ADBE Opacity");
      if (!mo) return "err|У клипа нет «Движения»";
      var pos = mo.properties[0], sc = mo.properties[1], rot = mo.properties[4], opa = op ? op.properties[0] : null;
      var t0 = side === "out" ? sp.b - d : sp.a, t1 = side === "out" ? sp.b : sp.a + d;
      var refT = side === "out" ? t0 : t1;
      var P = kkBase(pos, refT), S = kkBase(sc, refT), O = opa ? kkBase(opa, refT) : 100;
      // прогресс появления 0..1; для исчезновения — зеркальная кривая
      var prog = function (fn, x) { return side === "out" ? 1 - kkIn(fn)(x) : KK_EASE[fn](x); };
      var fade = function (x) { var v = side === "out" ? 1 - Math.max(0, (x - .6) / .4) : Math.min(1, x * 3); return O * v; };
      if (preset === "pop") {
        kkBake(sc, t0, t1, fps, function (x) { return S * prog("outBack", x); });
        if (opa) kkBake(opa, t0, t1, fps, fade);
      } else if (preset === "zoom") {
        kkBake(sc, t0, t1, fps, function (x) { return S * prog("outExpo", x); });
        if (opa) kkBake(opa, t0, t1, fps, fade);
      } else if (preset === "fadeUp") {
        var dy = 80 * U / H;
        kkBake(pos, t0, t1, fps, function (x) { return [P[0], P[1] + dy * (1 - prog("outCubic", x))]; });
        if (opa) kkBake(opa, t0, t1, fps, fade);
      } else if (preset === "slide") {
        var dx = 260 * U / W;
        kkBake(pos, t0, t1, fps, function (x) { return [P[0] - dx * (1 - prog("outQuint", x)), P[1]]; });
        if (opa) kkBake(opa, t0, t1, fps, fade);
      } else if (preset === "drop") {
        var dd = 240 * U / H;
        kkBake(pos, t0, t1, fps, function (x) { return [P[0], P[1] - dd * (1 - prog("outBounce", x))]; });
        if (opa) kkBake(opa, t0, t1, fps, function (x) { return O * Math.min(1, (side === "out" ? 1 - x : x) * 4); });
      } else if (preset === "shake") {
        var a = 10 * U / W;
        kkBake(pos, t0, t1, fps, function (x) { var k = 1 - x; return [P[0] + a * k * Math.sin(x * 40), P[1] + a * .6 * k * Math.cos(x * 33)]; });
        kkBake(rot, t0, t1, fps, function (x) { return kkBase(rot, refT) + 3 * (1 - x) * Math.sin(x * 37); });
      } else if (preset === "blink") {
        if (!opa) return "err|У клипа нет «Непрозрачности»";
        kkBake(opa, t0, t1, fps, function (x) { var on = Math.floor(x * 6) % 2 === 0; return side === "out" ? (x > .95 ? 0 : (on ? O : 0)) : (x > .95 ? O : (on ? 0 : O)); });
      } else return "err|Неизвестная анимация";
    }
    return "ok|Готово: " + items.length + " шт.";
  } catch (e) { return "err|" + e.toString(); }
}
/* «вход» для исчезновения: зеркальная кривая */
function kkIn(fn) { return function (x) { return 1 - KK_EASE[fn](1 - x); }; }

/* ---------- плавность на готовых ключах ---------- */
/* kind: linear | hold | ios | любое имя из KK_EASE (outCubic, springIOS, whip, glitch…) */
function kk_ease(kind) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var items = kkSel(); if (!items.length) return "err|Выдели клип с ключами";
    var fps = kkFps(seq), changed = 0;
    var fn = kind === "ios" ? "outQuint" : kind;
    if (kind !== "linear" && kind !== "hold" && typeof KK_EASE[fn] !== "function") return "err|Неизвестная плавность";
    for (var i = 0; i < items.length; i++) {
      var comps = [kkComp(items[i], "AE.ADBE Motion"), kkComp(items[i], "AE.ADBE Opacity")];
      for (var c = 0; c < comps.length; c++) {
        if (!comps[c]) continue;
        for (var p = 0; p < comps[c].properties.numItems; p++) {
          var pr = comps[c].properties[p];
          if (!pr.isTimeVarying()) continue;
          var keys = pr.getKeys(); if (!keys || keys.length < 2) continue;
          if (kind === "linear" || kind === "hold") {
            var mode = kind === "hold" ? 4 : 0; // 4 — стоп-кадр, 0 — линейно (типы Премьера; плавность считаем сами)
            for (var k = 0; k < keys.length; k++) pr.setInterpolationTypeAtKey(keys[k], mode, k === keys.length - 1);
          } else {
            // между каждой парой ключей ставим промежуточные по кривой
            var pairs = [];
            for (var k2 = 0; k2 < keys.length - 1; k2++) pairs.push([keys[k2].seconds, keys[k2 + 1].seconds, pr.getValueAtKey(keys[k2]), pr.getValueAtKey(keys[k2 + 1])]);
            for (var q = 0; q < pairs.length; q++) {
              var a = pairs[q][0], b = pairs[q][1], va = pairs[q][2], vb = pairs[q][3];
              var n = Math.round((b - a) * fps); if (n < 3) continue;
              KK_EASE_N = n;
              for (var f = 1; f < n; f++) {
                var t = a + (b - a) * f / n;
                pr.addKey(t); pr.setValueAtKey(t, kkLerp(va, vb, KK_EASE[fn](f / n)), false);
              }
            }
          }
          changed++;
        }
      }
    }
    return changed ? "ok|Плавность применена" : "err|На выделенном нет ключей: поставь хотя бы два";
  } catch (e) { return "err|" + e.toString(); }
}

/* сэмплы кривых для мини-графиков в панели: "id:v,v,…;…" */
function kk_easeCurves() {
  var o = [], N0 = KK_EASE_N; KK_EASE_N = 24;
  for (var k in KK_EASE) { var f = KK_EASE[k], v = []; for (var i = 0; i <= 32; i++) v.push(Math.round((i === 0 ? 0 : i === 32 ? 1 : f(i / 32)) * 1000) / 1000); o.push(k + ":" + v.join(",")); }
  KK_EASE_N = N0; return o.join(";");
}

/* ---------- камера v2: 34 движения (данные — объект c: it, sp, mo, pos, sc, rot, op, S, P, R, O, fps, W, H, U, seq) ---------- */
/* сдвиги — в «пикселях 1080p» (U), поэтому одинаково в 9:16 и 16:9; масштаб с запасом — без чёрных краёв */
function kkCamK(c, k) { kkBake(c.sc, c.sp.a, c.sp.a + .04, c.fps, function () { return c.S * k; }); }      // постоянный масштаб с запасом
function kkCamPx(c, x, y) { return [c.P[0] + x * c.U / c.W, c.P[1] + y * c.U / c.H]; }                    // позиция со сдвигом в px
function kkCamPre(prop, t, v, a) { if (t - 0.001 > a) kkKeysAt(prop, [t], [v], false); }                    // ключ «до» — чтобы до события кадр стоял
function kkCamFx(c, key) { if (typeof kkAddEffect !== "function" || typeof KK_EFFECTS === "undefined") return null; return kkAddEffect(c.it, KK_EFFECTS[key]); }
var KK_CAM2 = {
  /* ---- спокойно ---- */
  kenBurns: function (c) { var fr = Math.min(c.fps, 12);
    kkBake(c.sc, c.sp.a, c.sp.b, fr, function (x) { return c.S * (1.06 + .1 * KK_EASE.inOutSine(x)); });
    kkBake(c.pos, c.sp.a, c.sp.b, fr, function (x) { var e = KK_EASE.inOutSine(x) - .5; return kkCamPx(c, 36 * e, -24 * e); }); },
  hover: function (c) { var fr = Math.min(c.fps, 15), L = c.sp.len; kkCamK(c, 1.08);
    kkBake(c.pos, c.sp.a, c.sp.b, fr, function (x) { var t = x * L; return kkCamPx(c, 14 * Math.sin(2 * Math.PI * t / 5.2), 10 * Math.sin(2 * Math.PI * t / 3.7 + 1)); });
    kkBake(c.rot, c.sp.a, c.sp.b, fr, function (x) { return c.R + .5 * Math.sin(2 * Math.PI * x * L / 6.3); }); },
  dutch: function (c) { var fr = Math.min(c.fps, 12);
    kkBake(c.rot, c.sp.a, c.sp.b, fr, function (x) { return c.R + 6 + 2 * x; });
    kkBake(c.sc, c.sp.a, c.sp.b, fr, function (x) { return c.S * kkRotCover(c.W, c.H, 6 + 2 * x) * 1.01; }); },
  sway: function (c) { var fr = Math.min(c.fps, 15), L = c.sp.len; kkCamK(c, kkRotCover(c.W, c.H, 2.2) * 1.03);
    kkBake(c.rot, c.sp.a, c.sp.b, fr, function (x) { return c.R + 2 * Math.sin(2 * Math.PI * x * L / 3.2); });
    kkBake(c.pos, c.sp.a, c.sp.b, fr, function (x) { var t = x * L; return kkCamPx(c, 5 * Math.sin(2 * Math.PI * t / 6.4), 8 * Math.cos(2 * Math.PI * t / 3.2)); }); },
  drone: function (c) { var fr = Math.min(c.fps, 12);
    kkBake(c.sc, c.sp.a, c.sp.b, fr, function (x) { return c.S * (1.2 - .12 * KK_EASE.inOutSine(x)); });
    kkBake(c.pos, c.sp.a, c.sp.b, fr, function (x) { return kkCamPx(c, 0, -30 + 60 * KK_EASE.inOutSine(x)); }); },
  faceZoom: function (c) { var fr = Math.min(c.fps, 12), fy = .36;                    // точка лица (верхняя треть) остаётся на месте
    kkBake(c.sc, c.sp.a, c.sp.b, fr, function (x) { return c.S * (1 + .25 * KK_EASE.inOutSine(x)); });
    kkBake(c.pos, c.sp.a, c.sp.b, fr, function (x) { var k = 1 + .25 * KK_EASE.inOutSine(x); return [c.P[0], c.P[1] + (fy - c.P[1]) * (1 - k)]; }); },
  letterbox: function (c) { var cr = kkCamFx(c, "crop"); if (!cr) return "В этой версии нет эффекта «Обрезать»";
    var bar = c.W >= c.H ? Math.max(6, (1 - (c.W / c.H) / 2.39) / 2 * 100) : 12, d = Math.min(.6, c.sp.len / 2);
    var tp = kkP(cr, "crT"), bt = kkP(cr, "crB"), f = function (x) { return bar * KK_EASE.outCubic(x); };
    if (tp) kkBake(tp, c.sp.a, c.sp.a + d, c.fps, f); if (bt) kkBake(bt, c.sp.a, c.sp.a + d, c.fps, f); },
  card: function (c) { var d = Math.min(.6, c.sp.len / 2);
    kkBake(c.sc, c.sp.a, c.sp.a + d, c.fps, function (x) { return c.S * (1 - .14 * KK_EASE.springIOS(x)); });
    try { kkCamFx(c, "roundCrop"); } catch (e) {} },                                     // скруглённые углы — если эффект есть в этой версии
  weave: function (c) { kkCamK(c, 1.03);
    kkSteps(c.pos, c.sp.a, c.sp.b, 2 / c.fps, function (x, i) { return kkCamPx(c, (kkHash(i * 3 + 1) - .5) * 2, (kkHash(i * 3 + 2) - .5) * 5); }); },
  reveal: function (c) { var d1 = Math.min(1, c.sp.len / 2), d2 = Math.min(1.6, c.sp.len * .8);
    if (c.op) kkBake(c.op.properties[0], c.sp.a, c.sp.a + d1, c.fps, function (x) { return c.O * KK_EASE.inOutSine(x); });
    kkBake(c.sc, c.sp.a, c.sp.a + d2, c.fps, function (x) { return c.S * (1.08 - .08 * KK_EASE.outCubic(x)); }); },
  spiral: function (c) { var fr = Math.min(c.fps, 12);
    kkBake(c.rot, c.sp.a, c.sp.b, fr, function (x) { return c.R + 5 * KK_EASE.inOutSine(x); });
    kkBake(c.sc, c.sp.a, c.sp.b, fr, function (x) { var e = KK_EASE.inOutSine(x); return c.S * Math.max(1 + .18 * e, kkRotCover(c.W, c.H, 5 * e) * 1.01); }); },
  autofocus: function (c) { var bc = kkCamFx(c, "blur"); if (!bc) return "Не нашла «Размытие по Гауссу»";
    var d = Math.min(1.2, c.sp.len * .8), bp = kkP(bc, "blur"); kkEdgePx(bc);
    if (bp) kkBake(bp, c.sp.a, c.sp.a + d, c.fps, function (x) { return 22 * c.U * Math.pow(1 - x, 1.5) * Math.abs(Math.cos(x * Math.PI * 2.5)); });
    kkBake(c.sc, c.sp.a, c.sp.a + d, c.fps, function (x) { return c.S * (1.01 + .015 * (1 - x) * Math.sin(x * Math.PI * 5)); }); },
  /* ---- динамично ---- */
  beatPulse: function (c) { var L = c.sp.len;
    kkBake(c.sc, c.sp.a, c.sp.b, Math.min(c.fps, 30), function (x) { var ph = (x * L % .5) / .5; return c.S * (1 + .06 * Math.pow(1 - ph, 3)); }); },
  zoomPunch: function (c) { var d = Math.min(.45, c.sp.len / 2);
    kkBake(c.sc, c.sp.a, c.sp.a + d, c.fps, function (x) { var k = x < .25 ? KK_EASE.outCubic(x / .25) : 1 - KK_EASE.inOutSine((x - .25) / .75); return c.S * (1 + .22 * k); }); },
  punchIn: function (c) { var t = Math.max(c.sp.a + 1 / c.fps, kkSrcAt(c.seq, c.it, c.sp)), k = 1.18, fy = .36;
    kkKeysAt(c.sc, [c.sp.a, t], [c.S, c.S * k], true);
    kkKeysAt(c.pos, [c.sp.a, t], [c.P, [c.P[0], c.P[1] + (fy - c.P[1]) * (1 - k)]], true); },
  twoCams: function (c) { var n = Math.max(2, Math.round(c.sp.len / 1.6)), L = c.sp.len / n, k = 1.2, fy = .36;
    kkSteps(c.sc, c.sp.a, c.sp.b, L, function (x, i) { return (i % 2 && i < n) ? c.S * k : c.S; });
    kkSteps(c.pos, c.sp.a, c.sp.b, L, function (x, i) { return (i % 2 && i < n) ? [c.P[0] + 28 * c.U / c.W, c.P[1] + (fy - c.P[1]) * (1 - k)] : c.P; }); },
  beatTilt: function (c) { var L = c.sp.len; kkCamK(c, kkRotCover(c.W, c.H, 3.2) * 1.01);
    kkBake(c.rot, c.sp.a, c.sp.b, Math.min(c.fps, 30), function (x) { var t = x * L, k = Math.floor(t / .5), ph = (t % .5) / .5, to = (k % 2 ? -2.5 : 2.5), fr = k ? ((k - 1) % 2 ? -2.5 : 2.5) : 0;
      return c.R + fr + (to - fr) * (ph < .3 ? KK_EASE.outBack(ph / .3) : 1); }); },
  stopMo: function (c) { kkCamK(c, 1.07);
    kkSteps(c.pos, c.sp.a, c.sp.b, .125, function (x, i) { return kkCamPx(c, (kkHash(i * 5 + 1) - .5) * 16, (kkHash(i * 5 + 2) - .5) * 16); });
    kkSteps(c.rot, c.sp.a, c.sp.b, .125, function (x, i) { return c.R + (kkHash(i * 5 + 3) - .5) * 1.6; }); },
  swipe: function (c) { var d = Math.min(.5, c.sp.len / 2), sp = kkSpring(.85, 10);
    kkBake(c.pos, c.sp.a, c.sp.a + d, c.fps, function (x) { return [c.P[0], c.P[1] + (1 - sp(x))]; }); },
  blinkEye: function (c) { var cr = kkCamFx(c, "crop"); if (!cr) return "В этой версии нет эффекта «Обрезать»";
    var d = Math.min(.36, c.sp.len / 2), t = Math.max(c.sp.a, Math.min(kkSrcAt(c.seq, c.it, c.sp), c.sp.b - d)), f = function (x) { return 50 * Math.pow(Math.sin(Math.PI * x), .8); };
    var tp = kkP(cr, "crT"), bt = kkP(cr, "crB"); if (tp) kkBake(tp, t, t + d, c.fps, f); if (bt) kkBake(bt, t, t + d, c.fps, f); },
  nudge: function (c) { var t = kkSrcAt(c.seq, c.it, c.sp), d = Math.min(.6, c.sp.b - t), f = function (x) { return Math.exp(-5 * x) * Math.cos(2 * Math.PI * 1.5 * x) * (1 - x); };
    kkCamK(c, 1.07); kkCamPre(c.pos, t - 1 / c.fps, c.P, c.sp.a); kkCamPre(c.rot, t - 1 / c.fps, c.R, c.sp.a);
    kkBake(c.pos, t, t + d, c.fps, function (x) { return kkCamPx(c, 45 * f(x), 0); });
    kkBake(c.rot, t, t + d, c.fps, function (x) { return c.R + 2 * f(x); }); },
  pip: function (c) { var sz = kkSrcSize(c.it) || [c.W, c.H], fw = sz[0] * c.S / 100 / c.W, fh = sz[1] * c.S / 100 / c.H, k = .36, d = Math.min(.5, c.sp.len / 2), sp = kkSpring(.75, 10);
    var tx = 1 - 36 * c.U / c.W - fw * k / 2, ty = (c.H > c.W ? 220 : 40) * c.U / c.H + fh * k / 2;
    kkBake(c.sc, c.sp.a, c.sp.a + d, c.fps, function (x) { return c.S * (1 - (1 - k) * sp(x)); });
    kkBake(c.pos, c.sp.a, c.sp.a + d, c.fps, function (x) { var e = sp(x); return [c.P[0] + (tx - c.P[0]) * e, c.P[1] + (ty - c.P[1]) * e]; }); },
  walk: function (c) { var fr = Math.min(c.fps, 15), L = c.sp.len; kkCamK(c, 1.06);
    kkBake(c.pos, c.sp.a, c.sp.b, fr, function (x) { var t = x * L; return kkCamPx(c, 6 * Math.sin(Math.PI * .9 * t), -10 * Math.abs(Math.sin(Math.PI * 1.8 * t))); });
    kkBake(c.rot, c.sp.a, c.sp.b, fr, function (x) { return c.R + .7 * Math.sin(Math.PI * .9 * x * L); }); },
  appOpen: function (c) { var d = Math.min(.55, c.sp.len / 2), sp = kkSpring(.8, 11);
    kkBake(c.sc, c.sp.a, c.sp.a + d, c.fps, function (x) { return c.S * (.06 + .94 * sp(x)); });
    kkBake(c.pos, c.sp.a, c.sp.a + d, c.fps, function (x) { return [c.P[0], c.P[1] + .32 * (1 - sp(x))]; });
    if (c.op) kkBake(c.op.properties[0], c.sp.a, c.sp.a + d, c.fps, function (x) { return c.O * Math.min(1, x * 4); }); },
  /* ---- дерзко ---- */
  bassShake: function (c) { var L = c.sp.len, fr = Math.min(c.fps, 30); kkCamK(c, 1.08);
    kkBake(c.pos, c.sp.a, c.sp.b, fr, function (x) { var t = x * L, ph = t % .5, k = ph < .16 ? Math.pow(1 - ph / .16, 2) : 0, i = Math.round(t * fr);
      return kkCamPx(c, (kkHash(i) - .5) * 36 * k, (kkHash(i + 99) - .5) * 28 * k); }); },
  whipIn: function (c) { var tr = kkTransform(c.it, true); if (!tr) return "Не получилось добавить «Преобразовать»"; var d = Math.min(.28, c.sp.len / 2);
    kkBake(tr.properties[1], c.sp.a, c.sp.a + d, c.fps, function (x) { return [.5 - 1.1 * (1 - KK_EASE.outCubic(x)), .5]; });
    kkBake(tr.properties[3], c.sp.a, c.sp.a + d, c.fps, function (x) { return 100 + 20 * (1 - KK_EASE.outCubic(x)); }); },
  crashIn: function (c) { var tr = kkTransform(c.it, true); if (!tr) return "Не получилось добавить «Преобразовать»"; var d = Math.min(.3, c.sp.len / 2);
    kkBake(tr.properties[3], c.sp.a, c.sp.a + d, c.fps, function (x) { return 100 + 200 * (1 - KK_EASE.outExpo(x)); }); },
  glitchCam: function (c) { var ts = [c.sp.a], sv = [c.S], pv = [c.P], f1 = 1 / c.fps, slot = .35;
    for (var s = 0; c.sp.a + (s + 1) * slot < c.sp.b; s++) { if (kkHash(s * 7 + 3) < .55) continue;
      var t = c.sp.a + s * slot + kkHash(s * 7 + 4) * (slot - 4 * f1); if (t <= ts[ts.length - 1] + f1) continue;
      ts.push(t); sv.push(c.S * (1.12 + .08 * kkHash(s))); pv.push(kkCamPx(c, (kkHash(s * 7 + 5) - .5) * 110, (kkHash(s * 7 + 6) - .5) * 30));
      ts.push(t + 3 * f1); sv.push(c.S); pv.push(c.P); }
    if (ts.length < 2) { ts.push(c.sp.a + c.sp.len / 2); sv.push(c.S * 1.15); pv.push(kkCamPx(c, 50, 0)); ts.push(c.sp.a + c.sp.len / 2 + 3 * f1); sv.push(c.S); pv.push(c.P); }
    kkKeysAt(c.sc, ts, sv, true); kkKeysAt(c.pos, ts, pv, true); },
  barrel: function (c) { var tr = kkTransform(c.it, true); if (!tr) return "Не получилось добавить «Преобразовать»";
    var d = Math.min(.55, c.sp.len / 2), sz = kkSrcSize(c.it) || [c.W, c.H];
    kkBake(tr.properties[7], c.sp.a, c.sp.a + d, c.fps, function (x) { return 360 * KK_EASE.inOutCubic(x); });
    kkBake(tr.properties[3], c.sp.a, c.sp.a + d, c.fps, function (x) { return x >= 1 ? 100 : kkCoverWin(sz, 360 * KK_EASE.inOutCubic(x), 30) * 102; }); },
  fall: function (c) { var tr = kkTransform(c.it, true); if (!tr) return "Не получилось добавить «Преобразовать»";
    var d = Math.min(.45, c.sp.len / 2), t0 = c.sp.b - d, e = KK_EASE.inCubic;
    kkBake(tr.properties[7], t0, c.sp.b, c.fps, function (x) { return 28 * e(x); });
    kkBake(tr.properties[1], t0, c.sp.b, c.fps, function (x) { return [.5 + .05 * e(x), .5 + .75 * e(x)]; });
    kkBake(tr.properties[3], t0, c.sp.b, c.fps, function (x) { return 100 + 15 * e(x); }); },
  jelly: function (c) { var tr = kkTransform(c.it, false); if (!tr) return "Не получилось добавить «Преобразовать»";
    var d = Math.min(.8, c.sp.len / 2), osc = function (x) { return Math.exp(-4 * x) * Math.cos(2 * Math.PI * 1.75 * x); }, cv = function (x) { return x >= 1 ? 100 : 100 + 13 * Math.exp(-3 * x); };
    try { tr.properties[2].setValue(false, true); } catch (e) {}
    kkBake(tr.properties[4], c.sp.a, c.sp.a + d, c.fps, function (x) { return x >= 1 ? 100 : cv(x) * (1 + .14 * osc(x)); });
    kkBake(tr.properties[3], c.sp.a, c.sp.a + d, c.fps, function (x) { return x >= 1 ? 100 : cv(x) * (1 - .12 * osc(x)); }); },
  buildUp: function (c) { var fr = Math.min(c.fps, 24), L = c.sp.len;
    kkBake(c.sc, c.sp.a, c.sp.b, Math.min(c.fps, 12), function (x) { return c.S * (1.02 + .1 * x * x); });
    kkBake(c.pos, c.sp.a, c.sp.b, fr, function (x) { var k = x * x, i = Math.round(x * L * fr); return kkCamPx(c, (kkHash(i) - .5) * 44 * k, (kkHash(i + 51) - .5) * 34 * k); }); },
  bungee: function (c) { var d = Math.min(1, c.sp.len / 2); kkCamK(c, 1.16);
    kkBake(c.pos, c.sp.a, c.sp.a + d, c.fps, function (x) { return [c.P[0], c.P[1] + .078 * Math.exp(-3.2 * x) * Math.sin(2 * Math.PI * 1.5 * x)]; }); },
  lookAway: function (c) { var tr = kkTransform(c.it, true); if (!tr) return "Не получилось добавить «Преобразовать»";
    var t = Math.min(kkSrcAt(c.seq, c.it, c.sp), c.sp.b - .3), t1 = t + .12, t2 = t + .28;
    if (t < c.sp.a) { t = c.sp.a; t1 = t + .12; t2 = t + .28; }
    kkBake(tr.properties[1], t, t1, c.fps, function (x) { return [.5 + .32 * KK_EASE.inCubic(x), .5]; });
    kkBake(tr.properties[1], t1, t2, c.fps, function (x) { return [.82 - .32 * KK_EASE.outCubic(x), .5]; });
    kkBake(tr.properties[3], t, t1, c.fps, function (x) { return 100 + 60 * KK_EASE.inCubic(x); });
    kkBake(tr.properties[3], t1, t2, c.fps, function (x) { return 160 - 60 * KK_EASE.outCubic(x); }); }
};
/* у «Размытия по Гауссу» — «Повторить краевые пиксели», чтобы края не темнели */
function kkEdgePx(comp) { try { var p = kkParam(comp, ["Повторить краевые пиксели", "Повторять краевые пиксели", "Repeat Edge Pixels"], 2); if (p) p.setValue(true, true); } catch (e) {} }

/* ---------- 3D-экран: запись экрана под наклоном, камера летает над ней («Базовый 3D» + «Движение») ----------
   Премьер применяет «Движение» после эффектов, поэтому: «Базовый 3D» наклоняет кадр клипа, а «Движение» — это камера.
   Точная перспектива «Базового 3D» и знак углов не проверены, поэтому считаем с запасом: камера ближе, чем на самом деле,
   и оба знака угла. Так «полный кадр» точно без чёрных углов, а «карточка» не обрезается краями клипа. */
function kkScrProj(x, y, sw, tl, f) {                       // точка кадра клипа (px от центра) → экран после поворота
  var a = sw * Math.PI / 180, b = tl * Math.PI / 180, x1 = x * Math.cos(a), z1 = x * Math.sin(a);
  var y2 = y * Math.cos(b) - z1 * Math.sin(b), z2 = y * Math.sin(b) + z1 * Math.cos(b), k = f / Math.max(f * .05, f + z2);
  return [x1 * k, y2 * k];
}
function kkScrQuads(sz, sw, tl, card) {                     // 4 варианта знаков углов → 4 четырёхугольника
  var f = .8 * Math.max(sz[0], sz[1]), hw = sz[0] * card / 2, hh = sz[1] * card / 2, sg = [[1, 1], [-1, 1], [1, -1], [-1, -1]], out = [], c = [[-hw, -hh], [hw, -hh], [hw, hh], [-hw, hh]];
  for (var s = 0; s < 4; s++) { var q = []; for (var i = 0; i < 4; i++) q.push(kkScrProj(c[i][0], c[i][1], sw * sg[s][0], tl * sg[s][1], f)); out.push(q); }
  return out;
}
function kkInQuad(q, x, y) {
  var sgn = 0;
  for (var i = 0; i < 4; i++) { var a = q[i], b = q[(i + 1) % 4], cr = (b[0] - a[0]) * (y - a[1]) - (b[1] - a[1]) * (x - a[0]);
    if (Math.abs(cr) < 1e-9) continue; var s = cr > 0 ? 1 : -1; if (!sgn) sgn = s; else if (s !== sgn) return false; }
  return true;
}
/* масштаб «исходник → секвенция», при котором окно кадра W×H с центром v (px исходника) целиком лежит на наклонённом экране */
function kkScrCover(sz, W, H, sw, tl, v) {
  var qs = kkScrQuads(sz, sw, tl, 1), hw = sz[0] / 2, hh = sz[1] / 2;
  var fits = function (s) { var ax = W / 2 / s, ay = H / 2 / s, px = [v[0] - ax, v[0] + ax, v[0] + ax, v[0] - ax], py = [v[1] - ay, v[1] - ay, v[1] + ay, v[1] + ay];
    for (var i = 0; i < 4; i++) { if (Math.abs(px[i]) > hw || Math.abs(py[i]) > hh) return false; for (var k = 0; k < 4; k++) if (!kkInQuad(qs[k], px[i], py[i])) return false; }
    return true; };
  var lo = .01, hi = 50, n; if (!fits(hi)) return hi;
  for (n = 0; n < 26; n++) { var m = (lo + hi) / 2; if (fits(m)) hi = m; else lo = m; }
  return hi;
}
/* «карточка»: насколько уменьшить кадр внутри клипа («Преобразовать»), чтобы при всех углах angs наклонённый экран не обрезался */
function kkScrCard(sz, angs, want) {
  var hw = sz[0] / 2 * .985, hh = sz[1] / 2 * .985, n;
  var fits = function (k) { for (var a = 0; a < angs.length; a++) { var qs = kkScrQuads(sz, angs[a][0], angs[a][1], k);
    for (var s = 0; s < 4; s++) for (var i = 0; i < 4; i++) if (Math.abs(qs[s][i][0]) > hw || Math.abs(qs[s][i][1]) > hh) return false; } return true; };
  if (fits(want)) return want;
  var lo = .2, hi = want; for (n = 0; n < 20; n++) { var m = (lo + hi) / 2; if (fits(m)) lo = m; else hi = m; }
  return lo;
}
function kkScrNo() { return "нет эффекта «Базовый 3D» в этой версии Премьера"; }
function kkScrSz(c) { return kkSrcSize(c.it) || [c.W * 100 / c.S, c.H * 100 / c.S]; }   // размер исходника; не узнали — считаем, что клип ровно во весь кадр
function kkScrB3d(c) { var e = kkCamFx(c, "b3d"); if (!e) return kkScrNo();
  var ps = kkP(e, "swivel"), pt = kkP(e, "tilt"); if (!ps || !pt) return "не нашла «Поворот» и «Наклон» у «Базового 3D»";
  return { sw: ps, tl: pt }; }
var KK_SCR_CARD = "ok:экран теперь карточкой на фоне — подложи фон или размытую копию на дорожку ниже, иначе вокруг будет чёрное";
/* полный кадр: F(x) → { sw, tl — углы, k — приближение камеры (1 — старт), vx, vy — куда смотрит камера (доля исходника от центра) }.
   Масштаб = запас «без углов» × k: движение идёт по задуманной кривой и нигде не открывает края. blur — размытие глубины по «Размытию фокусировки» */
function kkScrFull(c, t0, t1, fr, F, blur) {
  var r = kkScrB3d(c); if (typeof r === "string") return r;
  var sz = kkScrSz(c), s0 = c.S / 100, n = Math.max(2, Math.round((t1 - t0) * fr)), Q = [], base = s0, i, q;
  for (i = 0; i <= n; i++) { q = F(i / n); q.v = [q.vx * sz[0], q.vy * sz[1]]; base = Math.max(base, kkScrCover(sz, c.W, c.H, q.sw, q.tl, q.v) * 1.04 / q.k); Q.push(q); }
  base = Math.min(base, s0 * 3.5);
  for (i = 0; i <= n; i++) { q = Q[i]; var s = base * q.k; q.s = s * 100; q.p = [.5 - q.v[0] * s / c.W, .5 - q.v[1] * s / c.H]; q.win = [c.W / s / sz[0] * 100, c.H / s / sz[1] * 100]; }
  var at = function (prop, f) { kkBake(prop, t0, t1, fr, function (x) { return f(Q[Math.min(n, Math.round(x * n))]); }); };
  at(r.sw, function (o) { return o.sw; }); at(r.tl, function (o) { return o.tl; });
  at(c.sc, function (o) { return o.s; }); at(c.pos, function (o) { return o.p; });
  if (!blur) return "";
  var fb = kkCamFx(c, "focus"); if (!fb || typeof kkPf !== "function") return "ok:эффекта «Размытие фокусировки» в этой версии нет — экран без размытия глубины";
  kkPfs(fb, "fbAng", 0); kkPfs(fb, "fbRound", blur.band ? 0 : 100); kkPfs(fb, "fbFeath", blur.feath || 65);
  if (blur.band) kkPfBig(fb, "fbW", [400, 200, 100]);
  var pp = kkPf(fb, "fbPos"), pw = kkPf(fb, "fbW"), ph = kkPf(fb, "fbH"), pa = kkPf(fb, "fbAmt");
  if (pp) at(pp, function (o) { return [.5 + o.v[0] / sz[0], .5 + o.v[1] / sz[1]]; });       // резкость там, куда смотрит камера
  if (pw && !blur.band) at(pw, function (o) { return o.win[0] * blur.w; });
  if (ph) at(ph, function (o) { return o.win[1] * blur.h; });
  if (pa) at(pa, function (o) { return o.amt !== undefined ? o.amt : blur.amt; });
  return "";
}
/* карточка: «Преобразовать» (уменьшает кадр внутри клипа — запас под перспективу) → «Базовый 3D». Сначала проверяем, что 3D есть, чтобы не оставить лишний эффект */
function kkScrRig(c) {
  if (typeof KK_EFFECTS === "undefined" || !kkFx(KK_EFFECTS.b3d)) return kkScrNo();
  var tr = kkTransform(c.it, false); if (!tr) return "Не получилось добавить «Преобразовать»";
  var r = kkScrB3d(c); if (typeof r === "string") return r;
  r.tsc = tr.properties[3]; r.sz = kkScrSz(c); return r;
}
KK_CAM2.scrFly = function (c) {                     // пролёт снизу вверх над лежащим экраном, полоса резкости едет вместе с камерой
  return kkScrFull(c, c.sp.a, c.sp.b, Math.min(c.fps, 15), function (x) { var e = KK_EASE.inOutSine(x);
    return { sw: -3 + 6 * e, tl: 16, k: 1 + .08 * e, vx: 0, vy: .05 - .1 * e }; }, { band: 1, h: .38, amt: 38, feath: 70 }); };
KK_CAM2.scrSlide = function (c) {                   // экран развёрнут, камера едет слева направо, разворот чуть уменьшается
  return kkScrFull(c, c.sp.a, c.sp.b, Math.min(c.fps, 15), function (x) { var e = KK_EASE.inOutSine(x);
    return { sw: 16 - 6 * e, tl: 5, k: 1 + .05 * e, vx: -.06 + .12 * e, vy: 0 }; }); };
KK_CAM2.scrDolly = function (c) {                   // смотрим сверху, плавно приближаемся, экран выпрямляется
  return kkScrFull(c, c.sp.a, c.sp.b, Math.min(c.fps, 15), function (x) { var e = KK_EASE.inOutCubic(x);
    return { sw: 0, tl: 22 - 12 * e, k: 1 + .22 * e, vx: 0, vy: 0 }; }); };
KK_CAM2.scrFocus = function (c) {                   // наезд на центр: экран выпрямляется, края уходят в расфокус
  var d = Math.min(2, c.sp.len), r = kkScrFull(c, c.sp.a, c.sp.a + d, c.fps, function (x) { var e = KK_EASE.inOutCubic(x);
    return { sw: 0, tl: 20 - 12 * e, k: 1 + .25 * e, vx: 0, vy: 0, amt: 40 * e }; }, { w: .62, h: .66, amt: 40, feath: 70 });
  return r; };
KK_CAM2.scrSwing = function (c) { var r = kkScrRig(c); if (typeof r === "string") return r;   // плавает и покачивается
  var fr = Math.min(c.fps, 15), L = c.sp.len, k = kkScrCard(r.sz, [[11, 13], [-11, 13], [11, -1], [-11, -1], [0, 13]], .84);
  r.tsc.setValue(k * 100, true);
  kkBake(r.sw, c.sp.a, c.sp.b, fr, function (x) { return 11 * Math.sin(2 * Math.PI * x * L / 5.5); });
  kkBake(r.tl, c.sp.a, c.sp.b, fr, function (x) { return 6 + 7 * Math.sin(2 * Math.PI * x * L / 4.1 + 1); });
  kkBake(c.pos, c.sp.a, c.sp.b, fr, function (x) { var t = x * L; return kkCamPx(c, 10 * Math.sin(2 * Math.PI * t / 6.3), 8 * Math.sin(2 * Math.PI * t / 4.7 + 2)); });
  return KK_SCR_CARD; };
KK_CAM2.scrOrbit = function (c) { var r = kkScrRig(c); if (typeof r === "string") return r;  // камера облетает экран слева направо
  var fr = Math.min(c.fps, 15), k = kkScrCard(r.sz, [[26, 9], [-26, 9], [13, 9], [-13, 9], [0, 9]], .8);
  r.tsc.setValue(k * 100, true); try { r.tl.setValue(9, true); } catch (e) {}
  kkBake(r.sw, c.sp.a, c.sp.b, fr, function (x) { return -26 + 52 * KK_EASE.inOutSine(x); });
  kkBake(c.sc, c.sp.a, c.sp.b, Math.min(c.fps, 12), function (x) { return c.S * (1 + .05 * KK_EASE.inOutSine(x)); });
  return KK_SCR_CARD; };
KK_CAM2.scrLay = function (c) { var r = kkScrRig(c); if (typeof r === "string") return r;    // кадр ложится под наклон и становится карточкой
  var d = Math.min(.9, c.sp.len / 2), t1 = c.sp.a + d, e = KK_EASE.inOutCubic, k = kkScrCard(r.sz, [[-10, 26], [-4, 26]], .82);
  var ks = function (x) { return e(Math.min(1, x / .75)); }, ka = function (x) { return e(Math.max(0, (x - .15) / .85)); };   // сначала уменьшается, потом наклоняется — не обрезается
  kkBake(r.tsc, c.sp.a, t1, c.fps, function (x) { return 100 - (100 - k * 100) * ks(x); });
  kkBake(r.tl, c.sp.a, t1, c.fps, function (x) { return 26 * ka(x); });
  kkBake(r.sw, c.sp.a, t1, c.fps, function (x) { return -10 * ka(x); });
  if (c.sp.b - t1 > .3) kkBake(r.sw, t1, c.sp.b, Math.min(c.fps, 12), function (x) { return -10 + 6 * KK_EASE.inOutSine(x); });
  return KK_SCR_CARD; };
KK_CAM2.scrPop = function (c) { var r = kkScrRig(c); if (typeof r === "string") return r;    // экран вылетает из глубины и встаёт во весь кадр
  var d = Math.min(.7, c.sp.len / 2), t1 = c.sp.a + d, sp = KK_EASE.springIOS, k0 = kkScrCard(r.sz, [[-20, 38]], .5);
  kkBake(r.tsc, c.sp.a, t1, c.fps, function (x) { return x >= 1 ? 100 : 100 * (k0 + (1 - k0) * KK_EASE.outBack(x)); });
  kkBake(r.tl, c.sp.a, t1, c.fps, function (x) { return x >= 1 ? 0 : 38 * (1 - sp(x)); });
  kkBake(r.sw, c.sp.a, t1, c.fps, function (x) { return x >= 1 ? 0 : -20 * (1 - sp(x)); });
  if (c.op) kkBake(c.op.properties[0], c.sp.a, t1, c.fps, function (x) { return c.O * Math.min(1, x * 4); });
  return "ok:экран выпрыгивает из глубины и встаёт во весь кадр; в первые доли секунды виден фон — подложи его на дорожку ниже"; };

/* ---------- движение камеры ---------- */
/* kind: zoomIn | zoomOut | breathe | panL | panR | … | любое имя из KK_CAM2 */
function kk_camera(kind) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var items = kkSel(); if (!items.length) return "err|Выдели клип";
    var fps = kkFps(seq), W = seq.frameSizeHorizontal, U = Math.min(W, seq.frameSizeVertical) / 1080, note = "";
    for (var i = 0; i < items.length; i++) {
      var sp = kkSpan(items[i]), mo = kkComp(items[i], "AE.ADBE Motion");
      if (!mo) return "err|У клипа нет «Движения»";
      var pos = mo.properties[0], sc = mo.properties[1], S = kkBase(sc, sp.a), P = kkBase(pos, sp.a);
      if (KK_CAM2[kind]) {
        var op = kkComp(items[i], "AE.ADBE Opacity"), rt0 = mo.properties[4];
        var cr = KK_CAM2[kind]({ it: items[i], sp: sp, mo: mo, pos: pos, sc: sc, rot: rt0, op: op, S: S, P: P, R: kkBase(rt0, sp.a), O: op ? kkBase(op.properties[0], sp.a + Math.min(1, sp.len / 2)) : 100,
          fps: fps, W: W, H: seq.frameSizeVertical, U: U, seq: seq });
        if (cr && String(cr).indexOf("ok:") === 0) note = String(cr).slice(3);   // получилось, но есть что подсказать
        else if (cr) return "err|" + cr;
        continue;
      }
      if (kind === "zoomIn") kkBake(sc, sp.a, sp.b, Math.min(fps, 12), function (x) { return S * (1 + .12 * KK_EASE.inOutCubic(x)); });
      else if (kind === "zoomOut") kkBake(sc, sp.a, sp.b, Math.min(fps, 12), function (x) { return S * (1.12 - .12 * KK_EASE.inOutCubic(x)); });
      else if (kind === "breathe") kkBake(sc, sp.a, sp.b, Math.min(fps, 12), function (x) { return S * (1.03 + .03 * Math.sin(x * Math.PI * 2 * Math.max(1, sp.len / 3))); });
      else if (kind === "panL" || kind === "panR" || kind === "tiltU" || kind === "tiltD" || kind === "diag") {
        var dx = (kind === "panL" ? -1 : kind === "panR" ? 1 : kind === "diag" ? 0.7 : 0) * 60 * U / W, dy = (kind === "tiltU" ? -1 : kind === "tiltD" ? 1 : kind === "diag" ? -0.7 : 0) * 60 * U / seq.frameSizeVertical;
        kkBake(sc, sp.a, sp.a + .04, fps, function () { return S * 1.1; });
        kkBake(pos, sp.a, sp.b, Math.min(fps, 12), function (x) { var e = KK_EASE.inOutCubic(x); return [P[0] - dx / 2 + dx * e, P[1] - dy / 2 + dy * e]; });
      }
      else if (kind === "push") kkBake(sc, sp.a, Math.min(sp.b, sp.a + .5), fps, function (x) { return S * (1 + .15 * KK_EASE.outQuint(x)); });
      else if (kind === "crash") kkBake(sc, Math.max(sp.a, sp.b - .35), sp.b, fps, function (x) { return S * (1 + .6 * KK_EASE.inExpo(x)); });
      else if (kind === "steps") { var n0 = Math.max(1, Math.floor(sp.len / .5)); kkBake(sc, sp.a, sp.b, fps, function (x) { var k = Math.min(n0, Math.floor(x * sp.len / .5)); return S * (1 + .07 * (k % 4)); }); }
      else if (kind === "vertigo") kkBake(sc, sp.a, sp.b, Math.min(fps, 15), function (x) { return S * (1.25 - .25 * KK_EASE.inOutSine(x)); });
      else if (kind === "roll") { var rt = mo.properties[4]; kkBake(sc, sp.a, sp.a + .04, fps, function () { return S * 1.12; }); kkBake(rt, sp.a, sp.b, Math.min(fps, 12), function (x) { return -3 + 6 * KK_EASE.inOutSine(x); }); }
      else if (kind === "hand") { var R = 11, rnd = function () { R = (R * 16807) % 2147483647; return R / 2147483647 - .5; }, rt2 = mo.properties[4];
        kkBake(sc, sp.a, sp.a + .04, fps, function () { return S * 1.06; });
        var nx = 0, ny = 0, nr = 0; kkBake(pos, sp.a, sp.b, Math.min(fps, 10), function () { nx = nx * .7 + rnd() * .6; ny = ny * .7 + rnd() * .6; return [P[0] + nx * 10 * U / W, P[1] + ny * 10 * U / seq.frameSizeVertical]; });
        kkBake(rt2, sp.a, sp.b, Math.min(fps, 10), function () { nr = nr * .7 + rnd() * .5; return nr * .8; }); }
      else if (kind === "shakeHit") { var R2 = 5, rnd2 = function () { R2 = (R2 * 16807) % 2147483647; return R2 / 2147483647 - .5; };
        kkBake(sc, sp.a, sp.a + .04, fps, function () { return S * 1.1; }); kkBake(pos, sp.a, Math.min(sp.b, sp.a + .4), fps, function (x) { var k = Math.pow(1 - x, 2) * 30 * U; return [P[0] + rnd2() * k / W, P[1] + rnd2() * k / seq.frameSizeVertical]; }); }
      else if (kind === "spinSlow") { var rt3 = mo.properties[4]; kkBake(sc, sp.a, sp.a + .04, fps, function () { return S * 1.42; }); kkBake(rt3, sp.a, sp.b, Math.min(fps, 12), function (x) { return 12 * x * sp.len; }); }
      else return "err|Неизвестное движение камеры";
    }
    return "ok|Готово" + (note ? ": " + note : "");
  } catch (e) { return "err|" + e.toString(); }
}

/* ---------- переходы ---------- */
/* стык ищем по плейхеду: клип A кончается там, где начинается B (на одной дорожке, сверху вниз) */
function kkCut(seq) {
  var ph = seq.getPlayerPosition().seconds, half = 0.5 / kkFps(seq);
  for (var v = seq.videoTracks.numTracks - 1; v >= 0; v--) {
    var cl = seq.videoTracks[v].clips, a = null, b = null;
    for (var i = 0; i < cl.numItems; i++) {
      if (Math.abs(cl[i].end.seconds - ph) < half) a = cl[i];
      if (Math.abs(cl[i].start.seconds - ph) < half) b = cl[i];
    }
    if (a && b) return { a: a, b: b };
  }
  return null;
}
/* какой эффект добавился: Премьер ставит некоторые эффекты (стабилизатор) всегда в конец, поэтому «последний» не годится */
function kkAddedComp(item, before) {
  var cnt = {}, i;
  for (i = 0; i < before.length; i++) cnt[before[i]] = (cnt[before[i]] || 0) + 1;
  var seen = {};
  for (i = 0; i < item.components.numItems; i++) { var m = item.components[i].matchName; seen[m] = (seen[m] || 0) + 1; }
  for (i = item.components.numItems - 1; i >= 0; i--) { var mm = item.components[i].matchName; if ((seen[mm] || 0) > (cnt[mm] || 0)) return item.components[i]; }
  return null;
}
function kkMatchNames(item) { var a = []; for (var i = 0; i < item.components.numItems; i++) a.push(item.components[i].matchName); return a; }
/* добавляет эффект «Преобразовать» с размытием движения и возвращает его компонент */
function kkTransform(item, blur) {
  var fx = kkFx(KK_FX.transform); if (!fx) return null;
  var qi = kkQeItem(item); if (!qi) return null;
  var before = kkMatchNames(item);
  qi.addVideoEffect(fx);
  var c = kkAddedComp(item, before);
  if (!c || !/^AE\.ADBE Geometry2?$/.test(c.matchName)) return null; // 26.x: «AE.ADBE Geometry», раньше — Geometry2
  try { c.properties[2].setValue(true, true); } catch (e) {} // «Равномерный масштаб»: в 26.x по умолчанию выключен
  c.properties[9].setValue(blur ? false : true, true); // свой угол затвора
  if (blur) c.properties[10].setValue(360, true);
  return c;
}
/* kind: zoom | whipL | whipR | spin | stretch | shake | dip ; frames — кадров на каждую сторону */
function kk_trans(kind, frames) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var cut = kkCut(seq); if (!cut) return "err|Поставь плейхед точно на стык двух клипов";
    var fps = kkFps(seq), n = Number(frames) || 8, d = n / fps;
    var A = cut.a, B = cut.b, sa = kkSpan(A), sb = kkSpan(B);
    d = Math.min(d, sa.len / 2, sb.len / 2);
    var ta = kind === "dip" ? 1 : kkTransform(A, true), tb = kind === "dip" ? 1 : kkTransform(B, true);
    if (!ta || !tb) return "err|Не получилось добавить эффект «Преобразовать»";
    var a0 = sa.b - d, a1 = sa.b, b0 = sb.a, b1 = sb.a + d;
    var W = seq.frameSizeHorizontal, H = seq.frameSizeVertical;
    var inn = KK_EASE.inCubic, out = KK_EASE.outCubic;
    var P = function (c) { return c.properties[1]; }, SC = function (c) { return c.properties[3]; };
    if (kind === "zoom") {
      kkBake(SC(ta), a0, a1, fps, function (x) { return 100 + 150 * inn(x); });
      kkBake(SC(tb), b0, b1, fps, function (x) { return 250 - 150 * out(x); });
    } else if (kind === "whipL" || kind === "whipR") {
      var dir = kind === "whipL" ? -1 : 1, off = 0.3;
      kkBake(SC(ta), a0, a1, fps, function (x) { return 100 + 60 * inn(x); });
      kkBake(P(ta), a0, a1, fps, function (x) { return [0.5 + dir * off * inn(x), 0.5]; });
      kkBake(SC(tb), b0, b1, fps, function (x) { return 160 - 60 * out(x); });
      kkBake(P(tb), b0, b1, fps, function (x) { return [0.5 - dir * off * (1 - out(x)), 0.5]; });
    } else if (kind === "spin") {
      // на каждом кадре масштаб ровно такой, чтобы повёрнутый кадр закрывал окно (без чёрных углов)
      var szA = kkSrcSize(A) || [W, H], szB = kkSrcSize(B) || [W, H];
      var cover0 = function (sz, deg) { var t = Math.abs(deg) * Math.PI / 180, c = Math.abs(Math.cos(t)), si = Math.abs(Math.sin(t)), w = sz[0], h = sz[1];
        return Math.max((w * c + h * si) / w, (w * si + h * c) / h) * 100 * 1.02; }; var cover = function (sz, deg) { var m = 0; for (var dd = -60; dd <= 60; dd += 5) m = Math.max(m, cover0(sz, deg + dd)); return m; };
      kkBake(ta.properties[7], a0, a1, fps, function (x) { return 180 * inn(x); });
      kkBake(SC(ta), a0, a1, fps, function (x) { return cover(szA, 180 * inn(x)); });
      kkBake(tb.properties[7], b0, b1, fps, function (x) { return -180 * (1 - out(x)); });
      kkBake(SC(tb), b0, b1, fps, function (x) { return cover(szB, 180 * (1 - out(x))); });
    } else if (kind === "stretch") {
      ta.properties[2].setValue(false, true); tb.properties[2].setValue(false, true);
      kkBake(ta.properties[4], a0, a1, fps, function (x) { return 100 + 250 * inn(x); });
      kkBake(tb.properties[4], b0, b1, fps, function (x) { return 350 - 250 * out(x); });
    } else if (kind === "shake") {
      var amp = 0.03, b2 = Math.min(sb.b, sb.a + d * 2);
      SC(tb).setValue(112, true);
      kkBake(P(tb), b0, b2, fps, function (x) { var k = Math.pow(1 - x, 2); return [0.5 + amp * k * Math.sin(x * 47), 0.5 + amp * k * Math.cos(x * 39)]; });
      kkBake(tb.properties[7], b0, b2, fps, function (x) { return 4 * Math.pow(1 - x, 2) * Math.sin(x * 31); });
      kkBake(SC(ta), a0, a1, fps, function (x) { return 100 + 12 * inn(x); });
    } else if (kind === "dip") {
      var oa = kkComp(A, "AE.ADBE Opacity").properties[0], ob = kkComp(B, "AE.ADBE Opacity").properties[0];
      kkBake(oa, a0, a1, fps, function (x) { return 100 * (1 - KK_EASE.inOutCubic(x)); });
      kkBake(ob, b0, b1, fps, function (x) { return 100 * KK_EASE.inOutCubic(x); });
    } else return "err|Неизвестный переход";
    return "ok|Переход «" + kind + "» на стыке готов";
  } catch (e) { return "err|" + e.toString(); }
}

/* ---------- субтитры ---------- */
function kkTime(sec) { var t = new Time(); t.seconds = sec; return t; }
function kkSrtTime(s) { var m = /(\d+):(\d+):(\d+)[,.](\d+)/.exec(s); return m ? (+m[1]) * 3600 + (+m[2]) * 60 + (+m[3]) + (+m[4]) / 1000 : 0; }
function kkReadSrt(path) {
  var f = new File(path); f.encoding = "UTF-8"; if (!f.open("r")) return null;
  var txt = f.read(); f.close();
  txt = txt.replace(/^\uFEFF/, "").replace(/\r/g, "");
  var blocks = txt.split(/\n\s*\n/), out = [];
  for (var i = 0; i < blocks.length; i++) {
    var L = blocks[i].split("\n"), k = 0;
    while (k < L.length && L[k].indexOf("-->") < 0) k++;
    if (k >= L.length) continue;
    var tt = L[k].split("-->"), text = L.slice(k + 1).join(" ").replace(/<[^>]+>/g, "").replace(/\s+/g, " ").replace(/^\s+|\s+$/g, "");
    if (text) out.push({ a: kkSrtTime(tt[0]), b: kkSrtTime(tt[1]), t: text });
  }
  return out;
}
/* режем реплику на короткие фразы, время делим пропорционально длине слов */
function kkChunks(cues, maxW) {
  var out = [];
  for (var i = 0; i < cues.length; i++) {
    var w = cues[i].t.split(" "), total = 0, lens = [];
    for (var j = 0; j < w.length; j++) { lens.push(w[j].length + 1); total += w[j].length + 1; }
    var t = cues[i].a, span = cues[i].b - cues[i].a;
    for (var s = 0; s < w.length; s += maxW) {
      var part = w.slice(s, s + maxW), pl = 0;
      for (var q = s; q < Math.min(w.length, s + maxW); q++) pl += lens[q];
      var d = span * pl / total;
      out.push({ a: t, b: t + d, t: part.join(" ") }); t += d;
    }
  }
  return out;
}
function kkSetMgt(item, name, value) {
  var c = item.getMGTComponent(); if (!c) return false;
  var p = c.properties.getParamForDisplayName(name); if (!p) return false;
  p.setValue(value, true); return true;
}
/* style: id шаблона (kk-word, word-by-word, karaoke, caps-stroke, minimal, kk-plate, typewriter, pop-word) */
function kk_subs(style, srtPath, maxWords) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var fmt = seq.frameSizeHorizontal >= seq.frameSizeVertical ? "h" : "v";
    var mg = new File(KK_DIR + "/mogrt/subs-" + style + "-" + fmt + ".mogrt"); if (!mg.exists) return "err|Нет шаблона " + style;
    if (!srtPath) { var pick = File.openDialog("Выбери файл субтитров .srt (Премьер: Подписи → Экспорт в SRT)", "*.srt"); if (!pick) return "err|Файл не выбран"; srtPath = pick.fsName; }
    var cues = kkReadSrt(srtPath); if (!cues || !cues.length) return "err|В файле нет субтитров";
    var parts = kkChunks(cues, Number(maxWords) || (fmt === "v" ? 4 : 7));
    app.enableQE();
    qe.project.getActiveSequence().addTracks(1, seq.videoTracks.numTracks, 0); // новая дорожка сверху
    var vIdx = seq.videoTracks.numTracks - 1, ok = 0;
    for (var i = 0; i < parts.length; i++) {
      var P = parts[i];
      var it = seq.importMGT(mg.fsName, String(Math.round(P.a * KK_TICKS)), vIdx, 0);
      if (!it) { if (!ok) return "err|Премьер не открыл шаблон субтитров. Нужен Premiere Pro 2020 или новее"; continue; }
      it.end = kkTime(P.b);
      kkSetMgt(it, "Текст", P.t);
      kkSetMgt(it, "Длительность", Math.max(0.2, P.b - P.a));
      ok++;
    }
    return "ok|Субтитры готовы: " + ok + " фраз на дорожке V" + (vIdx + 1);
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- вставки из стилевых наборов ---------- */
var KK_BLEND_SCREEN = 22; // «Экран» (проверено в 25.1: значение свойства «Режим смешивания»)
function kkBin(name) {
  var r = app.project.rootItem;
  for (var i = 0; i < r.children.numItems; i++) if (r.children[i].name === name && r.children[i].type === ProjectItemType.BIN) return r.children[i];
  return r.createBin(name);
}
function kkFindByPath(bin, path) {
  for (var i = 0; i < bin.children.numItems; i++) { var c = bin.children[i]; try { if (c.getMediaPath && c.getMediaPath() === path) return c; } catch (e) {} }
  return null;
}
/* дорожка, свободная на [a,b], выше V1; если нет — добавляем новую сверху */
function kkFreeTrack(seq, a, b) {
  for (var v = 1; v < seq.videoTracks.numTracks; v++) {
    var cl = seq.videoTracks[v].clips, busy = false;
    for (var i = 0; i < cl.numItems; i++) if (cl[i].start.seconds < b - 0.001 && cl[i].end.seconds > a + 0.001) { busy = true; break; }
    if (!busy) return v;
  }
  app.enableQE(); qe.project.getActiveSequence().addTracks(1, seq.videoTracks.numTracks, 0);
  return seq.videoTracks.numTracks - 1;
}
/* kind: png | an | tr | ov | bg | tx ; secs — длительность для картинок; blend — "screen" для оверлеев на чёрном */
function kk_insert(path, kind, secs, blend, fps) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var f = new File(path); if (!f.exists) return "err|Файл не скачался";
    var bin = kkBin("КК · Наборы"), it = kkFindByPath(bin, f.fsName);
    if (!it) { app.project.importFiles([f.fsName], true, bin, !!fps); it = kkFindByPath(bin, f.fsName); } // fps — своя версия из «Настроить»: PNG-последовательность
    if (it && fps) { try { it.setOverrideFrameRate(Number(fps)); } catch (e0) {} }
    if (!it) return "err|Не получилось импортировать файл";
    var ph = seq.getPlayerPosition().seconds, d = Number(secs) || 3;
    var isStill = !fps && /\.(png|jpe?g)$/i.test(f.name);
    if (!isStill) { try { d = it.getOutPoint().seconds - it.getInPoint().seconds; } catch (e) {} }
    var t0 = kind === "tr" ? Math.max(0, ph - d / 2) : ph; // переход — серединой на склейку
    var v = kind === "bg" ? 0 : kkFreeTrack(seq, t0, t0 + d);
    if (kind === "bg") { app.enableQE(); qe.project.getActiveSequence().addTracks(1, 0, 0); v = 0; } // фон — на новую нижнюю дорожку
    seq.videoTracks[v].overwriteClip(it, t0);
    var cl = seq.videoTracks[v].clips, placed = null;
    for (var i = 0; i < cl.numItems; i++) if (Math.abs(cl[i].start.seconds - t0) < 0.02) placed = cl[i];
    if (placed) {
      if (isStill) placed.end = kkTime(t0 + d);
      if (blend === "screen") { var op = kkComp(placed, "AE.ADBE Opacity"); if (op) op.properties[1].setValue(KK_BLEND_SCREEN, true); }
      if (kind === "bg" || kind === "ov" || kind === "tr") { // растянуть на кадр
        var sz = kkSrcSize(placed), mo = kkComp(placed, "AE.ADBE Motion");
        if (sz && mo) mo.properties[1].setValue(Math.ceil(Math.max(seq.frameSizeHorizontal / sz[0], seq.frameSizeVertical / sz[1]) * 1000) / 10, true);
      }
    }
    return "ok|Вставлено на V" + (v + 1) + (blend === "screen" ? " с режимом «Экран»" : "");
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

/* ---------- готовые титры ---------- */
function kk_title(id, txt, secs) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var fmt = seq.frameSizeHorizontal >= seq.frameSizeVertical ? "h" : "v";
    var mg = new File(KK_DIR + "/mogrt/title-" + id + "-" + fmt + ".mogrt"); if (!mg.exists) return "err|Нет шаблона " + id;
    var ph = seq.getPlayerPosition().seconds, d = Number(secs) || 3, v = kkFreeTrack(seq, ph, ph + d);
    var it = seq.importMGT(mg.fsName, String(Math.round(ph * KK_TICKS)), v, 0); if (!it) return "err|Премьер не открыл шаблон титра. Нужен Premiere Pro 2020 или новее";
    it.end = kkTime(ph + d);
    if (txt) kkSetMgt(it, "Текст", txt);
    return "ok|Титр на V" + (v + 1) + ". Свой текст и цвета — в «Элементах управления эффектами» → «Параметры графики»";
  } catch (e) { return "err|" + e.toString(); }
}

/* ---------- рилс ---------- */
// папка плагина: при автозагрузке Премьером $.fileName бывает пустым — тогда её передаёт панель (kk_setDir)
var KK_DIR = "";
try { KK_DIR = (new File($.fileName)).parent.parent.fsName; } catch (e) {}
function kkLoadPresets() { try { var f = new File(KK_DIR + "/jsx/presets.jsx"); if (f.exists) $.evalFile(f); return typeof kk_anim2 === "function"; } catch (e) { return false; } }
function kk_setDir(d) { if (d) KK_DIR = d; var ok = kkLoadPresets(); return "ok|" + KK_DIR + "|" + (ok ? "presets" : "no-presets"); }
if (KK_DIR) kkLoadPresets();
var KK_FORMATS = {
  v: [1080, 1920, "Вертикаль 9x16"], h: [1920, 1080, "Горизонталь 16x9"], h4k: [3840, 2160, "Горизонталь 4K"],
  p45: [1080, 1350, "Пост 4x5"], sq: [1080, 1080, "Квадрат 1x1"]
};
/* fmt: v | h | h4k | p45 | sq ; fps: 24 | 25 | 30 | 50 | 60 */
function kk_newSeq(fmt, fps) {
  try {
    var f = KK_FORMATS[fmt]; if (!f) return "err|Неизвестный формат";
    var d = new Date(), name = f[2] + " " + d.getHours() + "-" + (d.getMinutes() < 10 ? "0" : "") + d.getMinutes();
    var preset = new File(KK_DIR + "/presets/reel-9x16.sqpreset");
    if (!preset.exists) return "err|Не нашла пресет в папке плагина";
    app.enableQE();
    qe.project.newSequence(name, preset.fsName); // без окна выбора, дальше задаём размер сами
    var seq = app.project.activeSequence; if (!seq) return "err|Секвенция не создалась";
    var s = seq.getSettings();
    s.videoFrameWidth = f[0]; s.videoFrameHeight = f[1];
    if (fps) { var tb = new Time(); tb.seconds = 1 / Number(fps); s.videoFrameRate = tb; }
    seq.setSettings(s);
    return "ok|Создана «" + name + "» " + f[0] + "×" + f[1] + ", " + (fps || 30) + " кадров";
  } catch (e) { return "err|" + e.toString(); }
}
function kk_reelSeq(fps) { return kk_newSeq("v", fps); } // старое имя

/* ---------- исправить ---------- */
var KK_FX = {
  stab: ["Warp Stabilizer", "Стабилизатор деформации"],
  transform: ["Transform", "Преобразовать"]
};
function kkQeItem(item) {
  // ищем по времени начала и имени: порядковый номер сбивают переходы и пустоты на дорожке
  app.enableQE();
  var qs = qe.project.getActiveSequence(), seq = kkSeq(), st = item.start.seconds, en = item.end.seconds;
  for (var v = 0; v < seq.videoTracks.numTracks; v++) {
    var tr = seq.videoTracks[v], here = false;
    for (var c = 0; c < tr.clips.numItems; c++) if (tr.clips[c].nodeId === item.nodeId) here = true;
    if (!here) continue;
    var qt = qs.getVideoTrackAt(v), best = null;
    for (var q = 0; q < qt.numItems; q++) {
      var qi = qt.getItemAt(q); if (!qi || qi.type === "Empty") continue;
      var s0 = -1, e0 = -1; try { s0 = qi.start.secs; e0 = qi.end.secs; } catch (e) { continue; }
      if (Math.abs(s0 - st) < 0.02 && Math.abs(e0 - en) < 0.02) { if (qi.name === item.name) return qi; best = best || qi; }
    }
    if (best) return best;
  }
  return null;
}
// Премьер отдаёт названия эффектов то полностью, то сокращённо («Волнообр. деформ-ия», «Стабил-тор деформ.»),
// а getVideoEffectByName «находит» что угодно — поэтому сверяем со списком с учётом сокращений
function kkFxMatch(listName, want) {
  var a = String(listName).toLowerCase().replace(/\s*\(.*$/, "").split(/\s+/), b = String(want).toLowerCase().split(/\s+/);
  if (a.length !== b.length) return false;
  for (var i = 0; i < a.length; i++) {
    var w = a[i], t = b[i];
    if (w === t) continue;
    var cut = w.search(/[.\-]/);                                   // «деформ-ия» → «деформ», «Волнообр.» → «волнообр»
    if (cut > 1) { var pre = w.slice(0, cut), suf = w.slice(cut + 1).replace(/\./g, "");
      if (t.indexOf(pre) === 0 && (!suf || t.slice(-suf.length) === suf)) continue; }
    return false;
  }
  return true;
}
function kkFx(names) {
  app.enableQE();
  var list = qe.project.getVideoEffectList();
  var j, i, pass;
  for (pass = 0; pass < 3; pass++)            // 0 — точное имя, 1 — сокращение, 2 — устаревшая версия «(пред.)»
    for (i = 0; i < names.length; i++) for (j = 0; j < list.length; j++) {
      var L = String(list[j]), legacy = /\(пред|\(legacy/i.test(L);
      if (pass === 0 ? L === names[i] : pass === 1 ? (!legacy && kkFxMatch(L, names[i])) : kkFxMatch(L, names[i]))
        return qe.project.getVideoEffectByName(L);
    }
  return null;
}

function kkSrcSize(item) {
  try { var m = item.projectItem.getProjectMetadata(); var r = /VideoInfo>(\d+) x (\d+)/.exec(m); if (r) return [+r[1], +r[2]]; } catch (e) {}
  return null;
}
function kk_fix(kind) {
  try {
    var items = kkSel(); if (!items.length) return "err|Выдели клип";
    if (kind === "stab") {
      var fx = kkFx(KK_FX.stab); if (!fx) return "err|Не нашла «Стабилизатор деформации» в этой версии";
      for (var i = 0; i < items.length; i++) { var qi = kkQeItem(items[i]); if (qi) qi.addVideoEffect(fx); }
      return "ok|Стабилизатор добавлен. Дождись анализа; рамки убирает режим «Стабилизация, обрезка, автомасштаб» (стоит по умолчанию)";
    }
    if (kind === "frames") {
      // подогнать кадр под секвенцию: масштаб «заполнить»
      var seq = kkSeq();
      for (var j = 0; j < items.length; j++) {
        var mo = kkComp(items[j], "AE.ADBE Motion"), pi = items[j].projectItem;
        var w = 0, h = 0;
        try { var md = pi.getFootageInterpretation(); } catch (e2) {}
        try { var m = pi.getProjectMetadata(); var r = /VideoInfo>(\d+) x (\d+)/.exec(m); if (r) { w = +r[1]; h = +r[2]; } } catch (e3) {}
        if (!w || !h) continue;
        var sc = Math.max(seq.frameSizeHorizontal / w, seq.frameSizeVertical / h) * 100;
        var cur = mo.properties[1];
        if (cur.isTimeVarying()) cur.setTimeVarying(false);
        cur.setValue(Math.ceil(sc * 1.02 * 10) / 10, true);
      }
      return "ok|Кадр растянут на весь экран, чёрных рамок нет";
    }
    if (kind === "slow50" || kind === "slow25") {
      var sp = kind === "slow50" ? 0.5 : 0.25, n = 0;
      for (var k = 0; k < items.length; k++) {
        var q = kkQeItem(items[k]); if (!q) continue;
        try { q.setSpeed(sp, "", false, false, false); } catch (e4) {} // Премьер 25.1 меняет скорость, но кидает ошибку — проверяем по факту
        try { q.setTimeInterpolationType(2); } catch (e5) {}        // 2 — оптический поток: плавное слоумо без рывков
        if (Math.abs(kkQeItem(items[k]).speed - sp) < 0.001) n++;
      }
      return n ? "ok|Слоумо " + (sp * 100) + "% с оптическим потоком. Длина клипа на таймлайне не изменилась" : "err|Не получилось поменять скорость";
    }
    return "err|Неизвестное действие";
  } catch (e) { return "err|" + e.toString(); }
}
/* мягкая склейка звука по плейхеду: короткое затухание/нарастание (равная мощность), без щелчка */
function kk_audioCut(frames) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var fps = kkFps(seq), d = (Number(frames) || 3) / fps, ph = seq.getPlayerPosition().seconds, half = 0.5 / fps, n = 0;
    for (var t = 0; t < seq.audioTracks.numTracks; t++) {
      var cl = seq.audioTracks[t].clips, a = null, b = null;
      for (var i = 0; i < cl.numItems; i++) {
        if (Math.abs(cl[i].end.seconds - ph) < half) a = cl[i];
        if (Math.abs(cl[i].start.seconds - ph) < half) b = cl[i];
      }
      if (a) { var la = a.components[0].properties[1], sa = kkSpan(a), va = kkBase(la, sa.b - d);
        kkBake(la, sa.b - d, sa.b, fps, function (x) { return va * Math.cos(x * Math.PI / 2); }); n++; }
      if (b) { var lb = b.components[0].properties[1], sb = kkSpan(b), vb = kkBase(lb, sb.a + d);
        kkBake(lb, sb.a, sb.a + d, fps, function (x) { return vb * Math.sin(x * Math.PI / 2); }); n++; }
    }
    return n ? "ok|Звук на стыке сглажен (" + n + " клип.)" : "err|Поставь плейхед на стык звука";
  } catch (e) { return "err|" + e.toString(); }
}

function kk_fmt() { var s = app.project.activeSequence; return s ? (s.frameSizeHorizontal >= s.frameSizeVertical ? "h" : "v") : ""; }
function kk_ping() { return "ok|" + app.version + "|" + (app.project ? app.project.name : ""); }

/* звук из пака на плейхед: на свободную аудиодорожку */
function km_sound(path) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var f = new File(path); if (!f.exists) return "err|Звук не скачался";
    var bin = kkBin("КК · Звуки"), it = kkFindByPath(bin, f.fsName);
    if (!it) { app.project.importFiles([f.fsName], true, bin, !!fps); it = kkFindByPath(bin, f.fsName); } // fps — своя версия из «Настроить»: PNG-последовательность
    if (it && fps) { try { it.setOverrideFrameRate(Number(fps)); } catch (e0) {} }
    if (!it) return "err|Не получилось импортировать звук";
    var t0 = seq.getPlayerPosition().seconds, d = 1;
    try { d = it.getOutPoint().seconds - it.getInPoint().seconds; } catch (e) {}
    var a = -1;
    for (var k = 0; k < seq.audioTracks.numTracks && a < 0; k++) { var cl = seq.audioTracks[k].clips, busy = false; for (var i = 0; i < cl.numItems; i++) if (cl[i].start.seconds < t0 + d && cl[i].end.seconds > t0) { busy = true; break; } if (!busy) a = k; }
    if (a < 0) { app.enableQE(); qe.project.getActiveSequence().addTracks(0, 0, 1, 1, seq.audioTracks.numTracks); a = seq.audioTracks.numTracks - 1; }
    seq.audioTracks[a].overwriteClip(it, t0);
    return "ok|Звук на A" + (a + 1);
  } catch (e) { return "err|" + e.toString(); }
}

/* ---------- автосубтитры: звук секвенции в WAV 16 кГц (его распознаёт Whisper в панели) ---------- */
function kk_exportAudio(outPath) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var epr = new File(KK_DIR + "/presets/wav16k.epr"); if (!epr.exists) return "err|Нет пресета звука, переустанови плагин";
    var f = new File(outPath); if (f.exists) f.remove();
    var ok = seq.exportAsMediaDirect(f.fsName, epr.fsName, 0); // 0 — вся секвенция
    for (var i = 0; i < 40 && !f.exists; i++) $.sleep(250);
    if (!f.exists) return "err|Премьер не сохранил звук (" + ok + ")";
    return "ok|" + f.fsName + "|" + seq.end / KK_TICKS;
  } catch (e) { return "err|" + e.toString(); }
}
/* субтитры из готовых фраз: data — фразы через \u0001, поля через \u0002: начало, конец, текст, тайминги слов (секунды от начала фразы через запятую) */
function kk_subs2(style, data) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var fmt = seq.frameSizeHorizontal >= seq.frameSizeVertical ? "h" : "v";
    var mg = new File(KK_DIR + "/mogrt/subs-" + style + "-" + fmt + ".mogrt"); if (!mg.exists) return "err|Нет шаблона " + style;
    var rows = String(data).split("\u0001"), parts = [];
    for (var r = 0; r < rows.length; r++) { var c = rows[r].split("\u0002"); if (c.length >= 3 && c[2]) parts.push({ a: +c[0], b: +c[1], t: c[2], w: c[3] || "" }); }
    if (!parts.length) return "err|Нет фраз";
    app.enableQE();
    qe.project.getActiveSequence().addTracks(1, seq.videoTracks.numTracks, 0);
    var vIdx = seq.videoTracks.numTracks - 1, ok = 0;
    for (var i = 0; i < parts.length; i++) {
      var P = parts[i], it = seq.importMGT(mg.fsName, String(Math.round(P.a * KK_TICKS)), vIdx, 0);
      if (!it) { if (!ok) return "err|Премьер не открыл шаблон субтитров. Нужен Premiere Pro 2020 или новее"; continue; }
      it.end = kkTime(P.b);
      kkSetMgt(it, "Текст", P.t);
      kkSetMgt(it, "Длительность", Math.max(0.2, P.b - P.a));
      if (P.w) kkSetMgt(it, "Тайминги", P.w);
      ok++;
    }
    return "ok|Субтитры готовы: " + ok + " фраз на дорожке V" + (vIdx + 1) + ". Текст, цвет, обводка, тень, размер — в «Элементах управления эффектами» → «Параметры графики»";
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}

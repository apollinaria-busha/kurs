/* КК · Моушн — интерфейс панели: фигуры моушн-дизайна (MOGRT) и все наборы пака прямо в Премьере. */
(function () {
  var VERSION = "1.4.0";
  var cep = window.__adobe_cep__;
  function run(fn, args, cb) {
    var call = fn + "(" + (args || []).map(function (a) { return JSON.stringify(a); }).join(",") + ")";
    if (!cep) { cb && cb("err|Открой панель внутри Premiere Pro"); return; }
    // все панели КК живут в одном движке ExtendScript Премьера и перетирают общие функции —
    // перед каждой командой подгружаем свои файлы (на верхнем уровне: $.evalFile внутри функции не создаёт глобальных функций)
    var d = JSON.stringify(extDir());
    cep.evalScript("try{$.evalFile(new File(" + d + "+\"/jsx/host.jsx\"));km_setDir(" + d + ");}catch(e){};" + (window.KKAuto ? KKAuto.wrap(fn, call) : call), function (r) { cb && cb(String(r || "")); });
  }
  if (window.KKAuto) KKAuto.mount(run, say);
  function say(r) {
    var m = document.getElementById("msg"), p = String(r).split("|");
    m.className = p[0] === "ok" ? "ok" : "err"; m.textContent = p.slice(1).join(" ") || r;
    clearTimeout(say.t); say.t = setTimeout(function () { m.textContent = ""; }, 7000);
  }
  /* ---------- фигуры ---------- */
  var SHAPES = [], CATS = [], color = "#FFAD05";
  var SW = ["#FFAD05", "#FFFFFF", "#16130C", "#FF4D8D", "#3D7BFF", "#2BD67B", "#B26BFF", "#FF5B3A"];
  try { SHAPES = JSON.parse(require("fs").readFileSync(extDir() + "/motion.json", "utf8")); } catch (e) {}
  SHAPES.forEach(function (s) { if (CATS.indexOf(s.cat) < 0) CATS.push(s.cat); });
  function shapeTab(cat) {
    return function () {
      var items = SHAPES.filter(function (s) { return s.cat === cat; });
      return '<div class="sec"><h3>Цвет 1</h3><div class="sw">' + SW.map(function (c) { return '<button class="dot' + (c === color ? " on" : "") + '" data-col="' + c + '" style="background:' + c + '"></button>'; }).join("") +
        '<input type="color" id="colp" value="' + color + '"></div></div>' +
        '<div class="sec"><h3>' + cat + ' · ' + items.length + '</h3><div class="grid">' + items.map(function (s) {
          return '<button class="card" data-shape="' + s.id + '" title="' + s.name + '"><span class="spr" style="background-image:url(prev/' + s.id + '.png)"></span>' + s.name + '</button>'; }).join("") + '</div>' +
        '<p class="note">Нажми — фигура встанет на плейхед на свободную дорожку. Дальше всё меняешь сама: выдели фигуру на таймлайне → «Элементы управления эффектами» → «Параметры графики»' + (cat === "Плашки и реплики" || cat === "Инфографика" || cat === "Рукописный текст" || cat === "3D-текст" ? ' — там же свой текст вместо примера' : '') + ': цвета, толщина, скорость, размер, положение, поворот. То же есть в «Окно → Основные графические элементы»' + (cat === "Переходы-фигуры" ? '. Переход ставь серединой на склейку: он сам закрывает и открывает кадр' : '') + '.</p></div>';
    };
  }
  var TABS = {};
  CATS.forEach(function (c) { TABS[c] = shapeTab(c); });
  if (!CATS.length) TABS["Фигуры"] = function () { return '<p class="note">Не нашла фигуры в папке плагина. Переустанови плагин.</p>'; };
  /* ---------- все наборы пака: стикеры, анимации, переходы, оверлеи, фоны ---------- */
  TABS["Наборы"] = function () {
    if (!LIB) { loadLib(); return '<p class="note">Загружаю библиотеку наборов…</p>'; }
    if (LIB.error) return '<p class="note">Не получилось загрузить библиотеку: ' + LIB.error + '</p>';
    var st = LIB.styles[libStyle] || LIB.styles[Object.keys(LIB.styles)[0]], items = st[libKind] || []; if (!items.length) { var kk2 = ["an", "png", "pin", "ov", "bg", "tr", "tx", "sfx"]; for (var q = 0; q < kk2.length; q++) if ((st[kk2[q]] || []).length) { libKind = kk2[q]; items = st[libKind]; break; } } // у «Футажей» и «Текстур» не все виды
    var grp = []; items.forEach(function (it) { if (it.group && grp.indexOf(it.group) < 0) grp.push(it.group); }); if (grp.length > 1 && grp.indexOf(libGroup) < 0) libGroup = grp[0]; // категории, как у «Футажей»: по одной на экран
    var GT = grp.length > 1 ? '<div class="tabs" style="padding:0;border:0">' + grp.map(function (g) { var n = items.filter(function (it) { return it.group === g; }).length; return '<button class="' + (g === libGroup ? "on" : "") + '" data-lgr="' + g + '">' + g + ' · ' + n + '</button>'; }).join("") + '</div>' : "";
    var kinds = [["png", "PNG дефолт"], ["pin", "PNG из Pinterest"], ["an", "Анимации"], ["tr", "Переходы"], ["ov", "Оверлеи"], ["bg", "Фоны"], ["tx", "Плашки"], ["sfx", "Звуки"]];
    return '<div class="sec"><h3>Стиль</h3><div class="tabs" style="padding:0;border:0">' + Object.keys(LIB.styles).filter(function (k) { return k !== "cut"; }).map(function (k) { return '<button class="' + (k === libStyle ? "on" : "") + '" data-ls="' + k + '">' + LIB.styles[k].name + '</button>'; }).join("") + '</div>' +
      '<div class="tabs" style="padding:0;border:0">' + kinds.map(function (k) { return '<button class="' + (k[0] === libKind ? "on" : "") + '" data-lk="' + k[0] + '">' + k[1] + '</button>'; }).join("") + '</div>' + GT + '</div>' +
      (libKind === "pin" && PQ[libStyle] ? '<p class="note"><a href="#" data-pq="' + PQ[libStyle] + '" style="color:var(--acc,#FFAD05)">Ещё больше в Pinterest: поиск «' + PQ[libStyle] + '» ↗</a> — трендовые PNG без фона, сохраняй себе</p>' : "") +
      '<div class="grid lib">' + items.map(function (it, i) { if (grp.length > 1 && it.group !== libGroup) return ""; var pv = LIB.base + libStyle + "/" + it.prev, vid = /\.mp4$/.test(it.prev);
        return '<button class="card" data-li="' + i + '" title="' + it.name + '">' + (libKind === "sfx" ? '<span class="snd">♪</span>' : vid ? '<video data-lz="' + pv + '" muted loop playsinline preload="none" style="width:100%;border-radius:4px"></video>' : '<img src="' + pv + '" loading="lazy" style="width:100%;height:70px;object-fit:contain">') + '<span>' + it.name + '</span>' + (CFGK[libKind] && libStyle !== "cut" ? '<span class="cfg" data-cfg="' + i + '" title="Свои цвета, надписи, картинка, скорость">⚙ Настроить</span>' : '') + '</button>'; }).join("") + '</div>' +
      '<p class="note">Нажми — плагин скачает файл и поставит на плейхед. Переход встанет серединой на склейку, оверлей — с режимом «Экран», фон — на нижнюю дорожку. Вертикальная или горизонтальная версия выбирается по секвенции. Файлы сохраняются в «Документы / КК Наборы». «⚙ Настроить» — свои цвета, надписи, картинка вместо значка и скорость.</p>';
  };
  var cur = CATS[0] || "Наборы";
  var PQ = {ios:"ios core png",retro:"retro aesthetic png",anime:"anime stickers png",doodle:"doodle stickers png",tech:"tech core png",future:"chrome 3d png",y2k:"y2k png stickers",romance:"coquette png",scrap:"scrapbook png",lux:"old money aesthetic png",cinema:"cinema aesthetic png",expert:"3d business icons png",grunge:"grunge png",eco:"nature aesthetic png",kk:"editing aesthetic png",season:"seasonal stickers png"}; // поиск в Pinterest под стиль
  var LIB = null, libStyle = "kk", libKind = "png", libGroup = "";
  function loadLib() {
    fetch("https://kodkreatora.bybusha.com/pack/manifest.json?t=" + Date.now()).then(function (r) { return r.json(); })
      .then(function (m) { LIB = m; if (!LIB.styles[libStyle]) libStyle = Object.keys(LIB.styles)[0]; if (cur === "Наборы") render(); })
      .catch(function (e) { LIB = { error: e.message }; if (cur === "Наборы") render(); });
  }
  function seqInfo(cb) { run("kk_fmt", [], cb); }
  function cachePath(style, rel) {
    var path = require("path"), os = require("os");
    return path.join(os.homedir(), "Documents", "КК Наборы", style, rel);
  }
  function download(url, file, done) {
    var fs = require("fs"), path = require("path"), https = require("https");
    if (fs.existsSync(file) && fs.statSync(file).size > 0) return done(null);
    mkdirp(path.dirname(file));
    var tmp = file + ".part";
    (function get(u, n) { https.get(u, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && n < 6) { res.resume(); return get(res.headers.location, n + 1); }
      if (res.statusCode !== 200) { res.resume(); return done(new Error("HTTP " + res.statusCode)); }
      var out = fs.createWriteStream(tmp); res.pipe(out); out.on("finish", function () { out.close(function () { fs.renameSync(tmp, file); done(null); }); });
    }).on("error", done); })(url, 0);
  }
  /* ---------- «Настроить»: свои цвета, надписи, картинка вместо значка, скорость. Кадры рисует движок наборов прямо в панели,
     складывает PNG-последовательностью в «Документы / КК Наборы / Мои» и ставит на таймлайн ---------- */
  var CFGK = { an: 1, tr: 1, ov: 1, bg: 1, tx: 1 };
  function editItem(i) {
    var it = LIB.styles[libStyle][libKind][i], kind = libKind, style = libStyle;
    seqInfo(function (fmt) {
      KKEDIT.open(document.getElementById("view"), { base: ls("kke_base") || "https://kodkreatora.bybusha.com/pack/engine/", style: style, kind: kind, id: it.id, name: it.name, fmt: fmt || "v", act: "Вставить на таймлайн",
        note: "Твоя версия сохранится в «Документы / КК Наборы / Мои». Цвета, надписи и картинку можно поменять и вставить ещё раз.",
        onBack: render,
        onAct: function (st, msg) { return new Promise(function (ok) {
          if (!fmt) { msg("Открой секвенцию"); return ok(); }
          var fs = require("fs"), path = require("path"), black = kind === "ov" && !it.files["mov_" + fmt];
          var dir = cachePath("Мои", style + "-" + it.id + "-" + (kind === "an" || kind === "tx" ? "" : fmt) + KKEDIT.sig(st)), first = null, still = false;
          var place = function () { run("kk_insert", [first, kind, kind === "bg" ? 5 : 3, black ? "screen" : "", still ? "" : String(KKE.FPS)], function (r) { say(r); msg(r.split("|")[1] || r); ok(); }); };
          if (fs.existsSync(path.join(dir, "ok.txt"))) { first = fs.readFileSync(path.join(dir, "ok.txt"), "utf8"); still = /still\.png$/.test(first); msg("Вставляю…"); return place(); }
          mkdirp(dir); msg("Рисую кадры…");
          KKEDIT.render(st, fmt, function (n, cv, F) {
            still = !!F.still; var f = path.join(dir, still ? "still.png" : "f_" + ("000" + n).slice(-4) + ".png"); if (!n) first = f;
            fs.writeFileSync(f, Buffer.from(cv.toDataURL("image/png").split(",")[1], "base64")); if (!still && n % 6 === 0) msg("Рисую кадры… " + Math.round(n * 100 / F.n) + "%");
          }, black ? "#000" : "").then(function () { fs.writeFileSync(path.join(dir, "ok.txt"), first); msg("Вставляю…"); place(); })
            .catch(function (e) { msg("Не получилось: " + e.message); ok(); });
        }); }
      });
    });
  }
  function insertItem(i) {
    var it = LIB.styles[libStyle][libKind][i]; say("ok|Скачиваю «" + it.name + "»…");
    seqInfo(function (o) {
      if (!o) { say("err|Открой секвенцию"); return; }
      var f = it.files, key = libKind === "sfx" ? f.wav : libKind === "png" || libKind === "pin" ? f.png : libKind === "tx" ? f.png : libKind === "an" ? f.mov : libKind === "bg" ? f[o] : libKind === "tr" ? f["mov_" + o] : (f["mov_" + o] || f["black_" + o]);
      var blend = libKind === "ov" && !f["mov_" + o] ? "screen" : "";
      if (!key) { say("err|Для этого формата нет файла"); return; }
      var url = key, file = cachePath(libStyle, decodeURIComponent(url.split("/").pop()).replace(/__/g, "/"));
      download(url, file, function (err) {
        if (err) { say("err|Не скачалось: " + err.message); return; }
        if (libKind === "sfx") { run("km_sound", [file], say); return; }
        var tex = libStyle === "tex" && libKind === "bg"; // текстура — поверх видео, режим наложения выбирает автор
        run("kk_insert", [file, tex ? "ov" : libKind === "pin" ? "png" : libKind, libKind === "bg" ? 5 : 3, blend], function (r) { say(tex && r.indexOf("ok") === 0 ? r + ". Режим наложения: «Умножение» или «Перекрытие», непрозрачность 20–60 %" : r); });
      });
    });
  }
  /* видео-превью грузятся и играют, только когда видны (в наборах их по 50) */
  var IO = window.IntersectionObserver ? new IntersectionObserver(function (es) { es.forEach(function (en) { var v = en.target;
    if (en.isIntersecting) { if (!v.getAttribute("src")) v.src = v.getAttribute("data-lz"); var p = v.play(); if (p && p.catch) p.catch(function () {}); } else v.pause(); }); }, { rootMargin: "200px" }) : null;
  function lazy() { var vs = document.querySelectorAll("video[data-lz]"); for (var i = 0; i < vs.length; i++) { if (IO) IO.observe(vs[i]); else { vs[i].src = vs[i].getAttribute("data-lz"); vs[i].autoplay = true; } } }
  /* превью-анимации фигур: полоска из 10 кадров */
  var fr = 0; setInterval(function () { fr = (fr + 1) % 10; var a = document.querySelectorAll(".spr"); for (var i = 0; i < a.length; i++) a[i].style.backgroundPosition = (fr * 100 / 9) + "% 0"; }, 130);
  function render() {
    document.getElementById("tabs").innerHTML = Object.keys(TABS).map(function (k) { return '<button class="' + (k === cur ? "on" : "") + '" data-tab="' + k + '">' + k + '</button>'; }).join("");
    document.getElementById("view").innerHTML = TABS[cur]();
    lazy();
    var cp = document.getElementById("colp"); if (cp) cp.oninput = function () { color = cp.value.toUpperCase(); };
  }
  document.addEventListener("click", function (ev) {
    var cf = ev.target.closest("[data-cfg]"); if (cf && LIB) { ev.preventDefault(); editItem(+cf.dataset.cfg); return; }
    var b = ev.target.closest("button,a[data-pq]"); if (!b) return; if (b.dataset.pq) ev.preventDefault();
    if (b.dataset.tab) { cur = b.dataset.tab; render(); return; }
    if (b.dataset.col) { color = b.dataset.col; render(); return; }
    if (b.dataset.shape) { run("km_shape", [b.dataset.shape, color], say); return; }
    if (b.dataset.ls) { libStyle = b.dataset.ls; var st0 = LIB.styles[libStyle]; if (st0 && !(st0[libKind] || []).length) { var ks = ["png", "an", "tr", "ov", "bg", "tx"]; for (var q = 0; q < ks.length; q++) if ((st0[ks[q]] || []).length) { libKind = ks[q]; break; } } render(); return; }
    if (b.dataset.pq) { var url = "https://www.pinterest.com/search/pins/?q=" + encodeURIComponent(b.dataset.pq); try { window.cep.util.openURLInDefaultBrowser(url); } catch (x) { window.open(url); } return; }
    if (b.dataset.lk) { libKind = b.dataset.lk; render(); return; }
    if (b.dataset.lgr) { libGroup = b.dataset.lgr; render(); return; }
    if (b.dataset.li !== undefined && LIB) { insertItem(+b.dataset.li); return; }
  });
  /* ---------- доступ по ключу из приложения КК ---------- */
  var ID = "kk-motion", API = "https://script.google.com/macros/s/AKfycbw2LmiS_HoOdrIQko16UGsLNQj6T1Br2BymAb2bh8_iHPxOB8QyVgbiZ0vuPcwhHCPwyQ/exec", SITE = "https://kodkreatora.bybusha.com";
  var OFFLINE_DAYS = 30;
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { return null; } }
  function api(body) { return fetch(API, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify(body) }).then(function (r) { return r.json(); }); }
  var ERR = { bad_key: "Ключ не подошёл. Скопируй его заново в приложении КК.", not_student: "Доступ только для учениц программы КОД КРЕАТОРА.", expired: "Доступ к программе закончился.", soon: "Плагин скоро откроется ученицам." };
  function loginView(msg) {
    document.getElementById("tabs").innerHTML = "";
    document.getElementById("view").innerHTML = '<div class="login"><b style="font-size:14px">Вход в плагин</b>' +
      '<span class="note">Открой приложение КК → «Полезные материалы» → «Пак режиссёра монтажа» → плагин → «Получить ключ». Скопируй ключ и вставь сюда.</span>' +
      '<input id="key" placeholder="KK-…" autocomplete="off"><button class="btn y" id="go">Войти</button>' + (msg ? '<span class="note" style="color:#ff6b5b">' + msg + '</span>' : "") + '</div>';
    document.getElementById("go").onclick = function () { var k = document.getElementById("key").value.trim(); if (k) check(k, true); };
  }
  function enter(u) { document.getElementById("who").textContent = (u.n || "") + (u.u ? " · @" + u.u : ""); render(); checkUpdate(); }
  function check(key, interactive) {
    api({ api: "plugincheck", key: key }).then(function (r) {
      if (r.ok) { ls("kk_key", key); ls("kk_ok_at", String(Date.now())); ls("kk_user", JSON.stringify(r)); sharedWrite({ key: key, at: Date.now(), user: r }); enter(r); }
      else { if (r.error !== "soon" || interactive) { ls("kk_key", null); if (r.error === "bad_key" || r.error === "not_student" || r.error === "expired") sharedClear(); } loginView(ERR[r.error] || "Не получилось войти: " + (r.error || "")); }
    }).catch(function () {
      var sh = sharedRead() || {}, at = Math.max(+ls("kk_ok_at") || 0, sh.at || 0), u = ls("kk_user") || (sh.user ? JSON.stringify(sh.user) : null);
      if (!interactive && u && Date.now() - at < OFFLINE_DAYS * 864e5) enter(JSON.parse(u)); // без интернета — 30 дней по сохранённому входу
      else loginView("Нет интернета: для первого входа он нужен.");
    });
  }

  /* ---------- файлы: свои помощники — в старых Премьерах (Node 8) нет mkdirSync({recursive}) и rmSync ---------- */
  function mkdirp(d) { var fs = require("fs"), path = require("path"); if (fs.existsSync(d)) return; mkdirp(path.dirname(d)); fs.mkdirSync(d); }
  function rmrf(d) { var fs = require("fs"), path = require("path"); if (!fs.existsSync(d)) return;
    if (fs.lstatSync(d).isDirectory()) { fs.readdirSync(d).forEach(function (n) { rmrf(path.join(d, n)); }); fs.rmdirSync(d); } else fs.unlinkSync(d); }
  function extDir() { // file:///C:/… на Windows и file:///Users/… на Mac
    var p = decodeURIComponent(String(cep.getSystemPath("extension")).replace(/^file:\/\//, ""));
    return /^\/[A-Za-z]:/.test(p) ? p.slice(1) : p;
  }
  /* общий ключ для всех плагинов КК: файл в домашней папке, его читают оба плагина */
  function sharedFile() { var path = require("path"), os = require("os"); return path.join(os.homedir(), ".kodkreatora", "plugin-key.json"); }
  function sharedRead() { try { return JSON.parse(require("fs").readFileSync(sharedFile(), "utf8")); } catch (e) { return null; } }
  function sharedWrite(o) { try { var f = sharedFile(); mkdirp(require("path").dirname(f)); require("fs").writeFileSync(f, JSON.stringify(o)); } catch (e) {} }
  function sharedClear() { try { require("fs").unlinkSync(sharedFile()); } catch (e) {} }
  /* ---------- обновления ---------- */
  function newer(a, b) { a = a.split(".").map(Number); b = b.split(".").map(Number); for (var i = 0; i < 3; i++) { if ((a[i] || 0) > (b[i] || 0)) return true; if ((a[i] || 0) < (b[i] || 0)) return false; } return false; }
  function checkUpdate() {
    fetch(SITE + "/plugin/version.json?t=" + Date.now()).then(function (r) { return r.json(); }).then(function (v) {
      var me = v[ID]; if (!me || !newer(me.v, VERSION)) return;
      var u = document.getElementById("upd"); u.hidden = false;
      u.innerHTML = '<span>Вышла версия ' + me.v + (me.notes ? ": " + me.notes : "") + '</span><button class="btn y" id="doupd" style="width:auto;padding:5px 10px">Обновить</button>';
      document.getElementById("doupd").onclick = function () { update(me); };
    }).catch(function () {});
  }
  function copyDir(src, dst) { // своё копирование: в старых Премьерах нет fs.cpSync
    var fs = require("fs"), path = require("path");
    if (!fs.existsSync(dst)) mkdirp(dst);
    fs.readdirSync(src).forEach(function (n) { var a = path.join(src, n), b = path.join(dst, n);
      if (fs.statSync(a).isDirectory()) copyDir(a, b); else fs.writeFileSync(b, fs.readFileSync(a)); });
  }
  function update(me) {
    var u = document.getElementById("upd");
    try {
      var https = require("https"), fs = require("fs"), path = require("path"), os = require("os"), cp = require("child_process");
      var dir = extDir();
      if (fs.lstatSync(dir).isSymbolicLink()) { u.innerHTML = "<span>Это версия разработчика — обновление не ставлю</span>"; return; }
      var zip = path.join(os.tmpdir(), ID + "-" + me.v + ".zip"), out = fs.createWriteStream(zip);
      u.innerHTML = "<span>Скачиваю обновление…</span>";
      var get = function (url) { https.get(url, function (res) { if (res.statusCode >= 300 && res.headers.location) return get(res.headers.location); res.pipe(out); out.on("finish", function () { out.close(unpack); }); }).on("error", function () { u.innerHTML = "<span>Не скачалось. Проверь интернет.</span>"; }); };
      var unpack = function () {
        var tmp = path.join(os.tmpdir(), ID + "-new"); try { rmrf(tmp); } catch (e) {}
        var cmd = process.platform === "win32" ? 'powershell -NoProfile -Command "Expand-Archive -Force \'' + zip + '\' \'' + tmp + '\'"' : 'ditto -x -k "' + zip + '" "' + tmp + '"';
        cp.exec(cmd, function (err) {
          if (err) { u.innerHTML = "<span>Не распаковалось: " + err.message + "</span>"; return; }
          var src = path.join(tmp, ID); if (!fs.existsSync(src)) src = tmp;
          try { copyDir(src, dir); u.innerHTML = "<span>Готово! Перезапусти Премьер, чтобы включилась версия " + me.v + "</span>"; }
          catch (e2) { u.innerHTML = "<span>Не получилось заменить файлы: " + e2.message + "</span>"; }
        });
      };
      get(me.zip);
    } catch (e) { u.innerHTML = "<span>Обновление недоступно: " + e.message + "</span>"; }
  }

  document.getElementById("ver").textContent = "v" + VERSION;
  run("kk_ping", [], function (r) { var p = r.split("|"); if (p[0] !== "ok") document.getElementById("who").textContent = "нет связи с Premiere"; });
  var saved = ls("kk_key") || (sharedRead() || {}).key; // вошла в одном плагине КК — остальные открываются сами
  if (saved) check(saved, false); else loginView();
  try { run("km_setDir", [extDir()]); } catch (e) {}
})();

/* КК · Моушн — часть внутри Premiere Pro (ExtendScript, ES3). Вставляет фигуры (MOGRT) и файлы наборов на плейхед. */
var KK_TICKS = 254016000000;
var KK_BLEND_SCREEN = 22;
function kkSeq() { return app.project.activeSequence; }
function kkTime(sec) { var t = new Time(); t.seconds = sec; return t; }
function kkFreeTrack(seq, a, b) {
  for (var v = 1; v < seq.videoTracks.numTracks; v++) {
    var cl = seq.videoTracks[v].clips, busy = false;
    for (var i = 0; i < cl.numItems; i++) if (cl[i].start.seconds < b - 0.001 && cl[i].end.seconds > a + 0.001) { busy = true; break; }
    if (!busy) return v;
  }
  app.enableQE(); qe.project.getActiveSequence().addTracks(1, seq.videoTracks.numTracks, 0);
  return seq.videoTracks.numTracks - 1;
}
function kkBin(name) {
  var r = app.project.rootItem;
  for (var i = 0; i < r.children.numItems; i++) if (r.children[i].name === name && r.children[i].type === ProjectItemType.BIN) return r.children[i];
  return r.createBin(name);
}
function kkFindByPath(bin, path) {
  for (var i = 0; i < bin.children.numItems; i++) { var c = bin.children[i]; try { if (c.getMediaPath && c.getMediaPath() === path) return c; } catch (e) {} }
  return null;
}
function kkComp(item, match) {
  for (var i = 0; i < item.components.numItems; i++) if (item.components[i].matchName === match) return item.components[i];
  return null;
}
function kkSrcSize(item) {
  try { var m = item.projectItem.getProjectMetadata(); var r = /VideoInfo>(\d+) x (\d+)/.exec(m); if (r) return [+r[1], +r[2]]; } catch (e) {}
  return null;
}
function kk_insert(path, kind, secs, blend) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var f = new File(path); if (!f.exists) return "err|Файл не скачался";
    var bin = kkBin("КК · Наборы"), it = kkFindByPath(bin, f.fsName);
    if (!it) { app.project.importFiles([f.fsName], true, bin, false); it = kkFindByPath(bin, f.fsName); }
    if (!it) return "err|Не получилось импортировать файл";
    var ph = seq.getPlayerPosition().seconds, d = Number(secs) || 3;
    var isStill = /\.(png|jpe?g)$/i.test(f.name);
    if (!isStill) { try { d = it.getOutPoint().seconds - it.getInPoint().seconds; } catch (e) {} }
    var t0 = kind === "tr" ? Math.max(0, ph - d / 2) : ph; // переход — серединой на склейку
    var v = kind === "bg" ? 0 : kkFreeTrack(seq, t0, t0 + d);
    if (kind === "bg") { app.enableQE(); qe.project.getActiveSequence().addTracks(1, 0, 0); v = 0; } // фон — на новую нижнюю дорожку
    seq.videoTracks[v].overwriteClip(it, t0);
    var cl = seq.videoTracks[v].clips, placed = null;
    for (var i = 0; i < cl.numItems; i++) if (Math.abs(cl[i].start.seconds - t0) < 0.02) placed = cl[i];
    if (placed) {
      if (isStill) placed.end = kkTime(t0 + d);
      if (blend === "screen") { var op = kkComp(placed, "AE.ADBE Opacity"); if (op) op.properties[1].setValue(KK_BLEND_SCREEN, true); }
      if (kind === "bg" || kind === "ov" || kind === "tr") { // растянуть на кадр
        var sz = kkSrcSize(placed), mo = kkComp(placed, "AE.ADBE Motion");
        if (sz && mo) mo.properties[1].setValue(Math.ceil(Math.max(seq.frameSizeHorizontal / sz[0], seq.frameSizeVertical / sz[1]) * 1000) / 10, true);
      }
    }
    return "ok|Вставлено на V" + (v + 1) + (blend === "screen" ? " с режимом «Экран»" : "");
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}
function kk_fmt() { var s = app.project.activeSequence; return s ? (s.frameSizeHorizontal >= s.frameSizeVertical ? "h" : "v") : ""; }
function kk_ping() { return "ok|" + app.version + "|" + (app.project ? app.project.name : ""); }

var KM_DIR = "";
try { KM_DIR = (new File($.fileName)).parent.parent.fsName; } catch (e) {}
function km_setDir(d) { if (d) KM_DIR = d; return "ok|" + KM_DIR; }
function kmColor(item, name, hex) {
  try {
    var c = item.getMGTComponent(); if (!c) return;
    var p = c.properties.getParamForDisplayName(name); if (!p) return;
    var n = parseInt(String(hex).replace("#", ""), 16);
    p.setColorValue(255, (n >> 16) & 255, (n >> 8) & 255, n & 255, true);
  } catch (e) {}
}
/* фигура моушн-дизайна на плейхед; hex — «Цвет 1» */
function km_shape(id, hex) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var mg = new File(KM_DIR + "/mogrt/motion-" + id + ".mogrt"); if (!mg.exists) return "err|Нет фигуры " + id;
    var ph = seq.getPlayerPosition().seconds, v = kkFreeTrack(seq, ph, ph + 4);
    var it = seq.importMGT(mg.fsName, String(Math.round(ph * KK_TICKS)), v, 0);
    if (!it) return "err|Премьер не открыл фигуру. Нужен Premiere Pro 2020 или новее";
    if (hex) kmColor(it, "Цвет 1", hex);
    return "ok|Фигура на V" + (v + 1) + ". Цвета, толщина, скорость, размер — в «Основных графических элементах»";
  } catch (e) { return "err|" + e.toString(); }
}

/* звук из пака на плейхед: на свободную аудиодорожку */
function km_sound(path) {
  try {
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var f = new File(path); if (!f.exists) return "err|Звук не скачался";
    var bin = kkBin("КК · Звуки"), it = kkFindByPath(bin, f.fsName);
    if (!it) { app.project.importFiles([f.fsName], true, bin, false); it = kkFindByPath(bin, f.fsName); }
    if (!it) return "err|Не получилось импортировать звук";
    var t0 = seq.getPlayerPosition().seconds, d = 1;
    try { d = it.getOutPoint().seconds - it.getInPoint().seconds; } catch (e) {}
    var a = -1;
    for (var k = 0; k < seq.audioTracks.numTracks && a < 0; k++) { var cl = seq.audioTracks[k].clips, busy = false; for (var i = 0; i < cl.numItems; i++) if (cl[i].start.seconds < t0 + d && cl[i].end.seconds > t0) { busy = true; break; } if (!busy) a = k; }
    if (a < 0) { app.enableQE(); qe.project.getActiveSequence().addTracks(0, 0, 1, 1, seq.audioTracks.numTracks); a = seq.audioTracks.numTracks - 1; }
    seq.audioTracks[a].overwriteClip(it, t0);
    return "ok|Звук на A" + (a + 1);
  } catch (e) { return "err|" + e.toString(); }
}

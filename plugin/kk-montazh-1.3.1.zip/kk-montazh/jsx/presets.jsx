/* КК · Монтаж — пресеты v3: по 50 анимаций текста, переходов и эффектов (группы: спокойно / динамично / дерзко).
   Подключается из host.jsx ($.evalFile). ES3: без let/const/стрелок.
   Сдвиги — в «пикселях 1080p», масштабируются под формат (U). Эффекты ищутся по русскому и английскому имени,
   параметры — по имени (с запасным индексом), поэтому работают в разных версиях и языках Премьера. */

/* ---------- параметры эффектов по имени ---------- */
function kkParam(comp, names, idx) {
  for (var n = 0; n < names.length; n++) for (var i = 0; i < comp.properties.numItems; i++) {
    var dn = String(comp.properties[i].displayName).toLowerCase();
    if (dn === String(names[n]).toLowerCase() || kkFxMatch(dn, String(names[n]).toLowerCase())) return comp.properties[i];
  }
  return (typeof idx === "number" && idx < comp.properties.numItems) ? comp.properties[idx] : null;
}
/* добавить эффект и вернуть его компонент (с учётом того, что Премьер ставит часть эффектов в конец) */
function kkAddEffect(item, names) {
  var fx = kkFx(names); if (!fx) return null;
  var qi = kkQeItem(item); if (!qi) return null;
  var before = kkMatchNames(item); qi.addVideoEffect(fx);
  return kkAddedComp(item, before);
}
var KK_EFFECTS = {
  blur: ["Размытие по Гауссу", "Gaussian Blur"], dirblur: ["Направленное размытие", "Directional Blur"],
  b3d: ["Базовый 3D", "Basic 3D"], spher: ["Сферизация", "Spherize"], twirl: ["Скручивание", "Twirl"], mosaic: ["Мозаика", "Mosaic"],
  rgb: ["Разделение RGB", "RGB Split"], bright: ["Brightness & Contrast", "Яркость и контрастность"], invert: ["Обратить", "Invert"],
  wave: ["Волнообразная деформация", "Wave Warp"], mirror: ["Зеркало", "Mirror"], replicate: ["Репликация", "Replicate"],
  echo: ["Эхо", "Echo"], shake: ["Тряска камеры", "Camera Shake"], glow: ["Чудесное свечение", "Wonder Glow"], leaks: ["Утечки света", "Light Leaks"],
  lens: ["Искажение линзы", "Lens Distortion"], strobe: ["Проблеск. свет", "Проблесковый свет", "Strobe Light"], bokeh: ["Размытие боке", "Bokeh Blur"],
  shadow: ["Длинная тень", "Long Shadow"], glitch: ["Цифровой сбой VR", "VR Digital Glitch"], post: ["Время постеризации", "Posterize Time"], rot3d: ["Поворот 3D", "3D Rotate"]
};
/* имена параметров (рус / англ) и запасной индекс */
var KK_PARAMS = {
  blur: [["Размытость", "Размытие", "Blurriness"], 0], dirlen: [["Длина размытия", "Blur Length"], 1], dirang: [["Направление", "Direction"], 0],
  swivel: [["Поворот", "Swivel"], 0], tilt: [["Наклон", "Tilt"], 1], dist: [["Расстояние до изображения", "Distance to Image"], 2],
  spherR: [["Радиус", "Radius"], 0], twirlA: [["Угол", "Angle"], 22], twirlR: [["Радиус скручивания", "Внешний радиус", "Twirl Radius", "Outer Radius"], 26],
  mosH: [["Горизонтальные блоки", "Horizontal Blocks"], 0], mosV: [["Вертикальные блоки", "Vertical Blocks"], 1],
  bright: [["Яркость", "Brightness"], 0], invMix: [["Смешать с оригиналом", "Смешивание с оригиналом", "Blend With Original"], 1],
  waveH: [["Высота волны", "Wave Height"], 1], waveW: [["Ширина волны", "Wave Width"], 2], waveS: [["Скорость волны", "Wave Speed"], 4],
  rep: [["Число", "Количество", "Count"], 0], echoT: [["Время эха (секунды)", "Echo Time (seconds)"], 0], echoN: [["Количество кадров эха", "Количество эха", "Number Of Echoes"], 1],
  postFps: [["Частота кадров", "Frame Rate"], 0], rgbAmt: [["Горизонтальное разделение", "Horizontal Split", "Величина", "Amount"], 4]
};
function kkP(comp, key) { var k = KK_PARAMS[key]; return kkParam(comp, k[0], k[1]); }
/* v3: эффекты, которые нужны новым пресетам (имена — как в kk-hity, проверены там; часть есть только в новых версиях) */
KK_EFFECTS.crop = ["Обрезать", "Crop"]; KK_EFFECTS.flare = ["Блики", "Lens Flare"];
KK_EFFECTS.noise = ["Шум (предыд.", "Noise (Legacy)", "Шум", "Noise"]; KK_EFFECTS.tint = ["Оттенок", "Tint"]; KK_EFFECTS.procamp = ["ProcAmp"];
KK_EFFECTS.edges = ["Выделение краев", "Выделение краёв", "Find Edges"]; KK_EFFECTS.turb = ["Вихр. смещение", "Вихревое смещение", "Turbulent Displace"];
KK_EFFECTS.rough = ["Шероховатые края", "Roughen Edges"]; KK_EFFECTS.stroke = ["Обводка", "Stroke"]; KK_EFFECTS.dshadow = ["Тень", "Drop Shadow"];
KK_EFFECTS.leave = ["Фильтр цвета", "Color Pass", "Оставить цвет", "Leave Color"]; /* в Премьере 2024+ «Оставить цвет» убран, есть «Фильтр цвета» */ KK_EFFECTS.offset = ["Смещение", "Offset"];
KK_EFFECTS.roundCrop = ["Закругленное кадрирование", "Закруглённое кадрирование", "Rounded Crop"];
var KK_P3 = {
  crL: [["Слева", "Left"], 0], crT: [["Сверху", "Top"], 1], crR: [["Справа", "Right"], 2], crB: [["Снизу", "Bottom"], 3], crF: [["Растушевка краев", "Растушевка краёв", "Растушевка края", "Edge Feather"], 5],
  flC: [["Центр бликов", "Центр блика", "Flare Center"], 0], flB: [["Яркость бликов", "Яркость блика", "Flare Brightness"], 1],
  noiseAmt: [["Количество шума", "Amount of Noise", "Величина"], 0], noiseCol: [["Использовать цветной шум", "Тип шума", "Use Color Noise", "Noise Type"], 1],
  tBlack: [["Сопоставить черный с", "Сопоставить чёрный с", "Map Black To"], 0], tWhite: [["Сопоставить белый с", "Map White To"], 1], tAmt: [["Величина оттенка", "Amount to Tint"], 2],
  paCon: [["Контрастность", "Контраст", "Contrast"], 1], paHue: [["Цветовой тон", "Тон", "Hue"], 2], paSat: [["Насыщенность", "Saturation"], 3],
  edInv: [["Обратить", "Инвертировать", "Invert"], 0], edMix: [["Смешивание с оригиналом", "Смешать с оригиналом", "Blend With Original"], 1],
  tuAmt: [["Величина", "Количество", "Amount"], 1], tuSize: [["Размер", "Size"], 2], tuEvo: [["Эволюция", "Evolution"], 5],
  rgBorder: [["Граница", "Border"], 2], rgEvo: [["Эволюция", "Evolution"], 9],
  dsOp: [["Непрозрачность", "Opacity"], 1], dsDir: [["Направление", "Direction"], 2], dsDist: [["Расстояние", "Distance"], 3], dsSoft: [["Мягкость", "Softness"], 4],
  lcAmt: [["Количество обесцвечивания", "Величина обесцвечивания", "Amount to Decolor"], 0], lcCol: [["Цвет, который нужно оставить", "Оставляемый цвет", "Сохраняемый цвет", "Color To Leave"], 1],
  cpCol: [["Цвет", "Color"], 2], lcTol: [["Допуск", "Tolerance"], 2], lcSoft: [["Мягкость края", "Мягкость краев", "Мягкость краёв", "Edge Softness"], 3],
  ofsC: [["Сместить центр в", "Сдвинуть центр в", "Переместить центр в", "Shift Center To"], 0], mirC: [["Центр отражения", "Reflection Center"], 0],
  echoI: [["Начальная интенсивность", "Starting Intensity"], 2], echoD: [["Затухание", "Decay"], 3],
  stSize: [["Размер", "Ширина", "Толщина", "Size", "Width"], null], stCol: [["Цвет", "Color"], null]
};
for (var kkK3 in KK_P3) KK_PARAMS[kkK3] = KK_P3[kkK3];
/* поставить значение параметра (если он есть) / цвет "#rrggbb" */
function kkPs(comp, key, v) { var p = comp ? kkP(comp, key) : null; if (p) { try { p.setValue(v, true); } catch (e) {} } return p; }
function kkPc(comp, key, hex) { var p = comp ? kkP(comp, key) : null; if (p) { var n = parseInt(String(hex).replace("#", ""), 16); try { p.setColorValue(255, (n >> 16) & 255, (n >> 8) & 255, n & 255, true); } catch (e) {} } return p; }
/* группы для фильтра в панели (c — спокойно, d — динамично, b — дерзко) и превью карточки: "id:группа:превью,…" */
function kkMeta(T, s) { var a = s.split(","); for (var i = 0; i < a.length; i++) { var m = a[i].split(":"); if (T[m[0]]) { if (!T[m[0]].g) T[m[0]].g = m[1]; if (!T[m[0]].p) T[m[0]].p = m[2]; } } }
/* список для панели: спокойные → динамичные → дерзкие; "id:имя:группа:превью;…" */
function kkListOut(T) { var o = [], gs = ["c", "d", "b"], k, g; for (g = 0; g < 3; g++) for (k in T) if ((T[k].g || "d") === gs[g]) o.push(k + ":" + T[k].n + ":" + gs[g] + ":" + (T[k].p || "")); return o.join(";"); }

/* ---------- анимации текста v2 ---------- */
/* p: pos [dx,dy] (px 1080p), sc (стартовый масштаб %), sx/sy (раздельный масштаб %), rot (°), op (прозрачность), blur (px), e (кривая), fx: jitter|flicker */
var KK_ANIMS2 = {
  pop: { sc: 0, op: 1, e: "outBack", n: "Pop" }, popSoft: { sc: 60, op: 1, e: "outCubic", n: "Мягкий pop" }, popBig: { sc: 180, op: 1, e: "outCubic", n: "Из большого" },
  zoom: { sc: 0, op: 1, e: "outExpo", n: "Из точки" }, fade: { op: 1, e: "linear", n: "Растворение" },
  fadeUp: { pos: [0, 80], op: 1, e: "outCubic", n: "Подъём" }, fadeDown: { pos: [0, -80], op: 1, e: "outCubic", n: "Опускание" },
  fadeLeft: { pos: [120, 0], op: 1, e: "outCubic", n: "Справа налево" }, fadeRight: { pos: [-120, 0], op: 1, e: "outCubic", n: "Слева направо" },
  slide: { pos: [-260, 0], op: 1, e: "outQuint", n: "Выезд" }, slideUp: { pos: [0, 400], e: "outQuint", n: "Вылет снизу" }, slideDown: { pos: [0, -400], e: "outQuint", n: "Вылет сверху" },
  slideRight: { pos: [600, 0], e: "outQuint", n: "Вылет справа" },
  drop: { pos: [0, -240], op: 1, e: "outBounce", n: "Отскок" }, rise: { pos: [0, 240], op: 1, e: "outBack", n: "Прыжок снизу" },
  spin: { sc: 0, rot: -180, op: 1, e: "outBack", n: "Вращение" }, swing: { rot: -25, op: 1, e: "outElastic", n: "Качнуться" }, tilt: { rot: 12, pos: [0, 60], op: 1, e: "outCubic", n: "Наклон" },
  flipX: { sx: 0, e: "outBack", n: "Переворот ↔" }, flipY: { sy: 0, e: "outBack", n: "Переворот ↕" },
  stretch: { sx: 300, sy: 40, op: 1, e: "outQuint", n: "Растяжка" }, squash: { sx: 140, sy: 0, e: "outElastic", n: "Сплющить" },
  elastic: { sc: 0, e: "outElastic", n: "Резинка" }, rubber: { sx: 130, sy: 70, e: "outElastic", n: "Желе" },
  blurIn: { blur: 60, op: 1, e: "outCubic", n: "Из размытия" }, blurUp: { blur: 40, pos: [0, 80], op: 1, e: "outCubic", n: "Размытие + подъём" },
  blurZoom: { blur: 50, sc: 140, op: 1, e: "outCubic", n: "Размытие + зум" }, whip: { pos: [-700, 0], blur: 80, e: "outExpo", n: "Хлыст" },
  glitch: { op: 1, fx: "jitter", e: "linear", n: "Глитч" }, shake: { fx: "shake", e: "linear", n: "Дрожь" }, blink: { fx: "flicker", e: "linear", n: "Мигание" }
};
/* v3: ещё 19 анимаций. Новые поля: crop "lr" (проявление слева направо, steps — ступенями), skew (°), rgb, mosaic (блоков на старте),
   wave (высота волны), bright (вспышка яркости), noise (шум %), fn — своя функция из KK_A2FN */
KK_ANIMS2.glassIn = { sc: 95, blur: 26, bright: 40, op: 1, e: "springIOS", n: "Стекло iOS", g: "c", p: "ios" };
KK_ANIMS2.marker = { crop: "lr", skew: 16, e: "inOutCubic", n: "Маркер", g: "c", p: "wipe" };
KK_ANIMS2.leaf = { fn: "leaf", op: 1, e: "outCubic", n: "Листок", g: "c", p: "leaf" };
KK_ANIMS2.island = { fn: "island", e: "linear", n: "Остров", g: "d", p: "island" };
KK_ANIMS2.typewriter = { crop: "lr", steps: 9, fx: "type", e: "linear", n: "Печатная машинка", g: "d", p: "type" };
KK_ANIMS2.skew = { pos: [320, 0], skew: 28, op: 1, e: "outQuint", n: "Скос", g: "d", p: "skew" };
KK_ANIMS2.pixels = { mosaic: 6, op: 1, e: "outCubic", n: "Из пикселей", g: "d", p: "pixel" };
KK_ANIMS2.wave = { wave: 45, op: 1, e: "outCubic", n: "Волна", g: "d", p: "wave" };
KK_ANIMS2.magnet = { pos: [0, -220], op: 1, e: "magnet", n: "Магнит", g: "d", p: "drop" };
KK_ANIMS2.windup = { pos: [-280, 0], op: 1, e: "windup", n: "Замах", g: "d", p: "windup" };
KK_ANIMS2.arc = { fn: "arc", op: 1, e: "outCubic", n: "По дуге", g: "d", p: "arc" };
KK_ANIMS2.noiseIn = { noise: 100, op: 1, e: "outCubic", n: "Из шума", g: "d", p: "noise" };
KK_ANIMS2.trail = { fn: "trail", op: 1, e: "outQuint", n: "Шлейф", g: "d", p: "trail" };
KK_ANIMS2.slam = { fn: "slam", op: 1, e: "linear", n: "Слэм", g: "b", p: "slam" };
KK_ANIMS2.neon = { fn: "neon", e: "linear", n: "Неон", g: "b", p: "neon" };
KK_ANIMS2.rgbIn = { rgb: 60, pos: [40, 0], op: 1, e: "outExpo", n: "RGB-вход", g: "b", p: "rgb" };
KK_ANIMS2.stopMo = { fn: "stopMo", op: 1, e: "outCubic", n: "Стоп-моушн", g: "b", p: "stopmo" };
KK_ANIMS2.wheel = { pos: [-520, 0], rot: -360, op: 1, e: "outCubic", n: "Колесо", g: "b", p: "wheel" };
KK_ANIMS2.splat = { fn: "splat", op: 1, e: "linear", n: "Шмяк", g: "b", p: "land" };
kkMeta(KK_ANIMS2, "pop:d:pop,popSoft:c:pop,popBig:d:big,zoom:d:zoom,fade:c:fade,fadeUp:c:fadeUp,fadeDown:c:fadeUp,fadeLeft:c:slide,fadeRight:c:slide," +
  "slide:c:slide,slideUp:d:swipe,slideDown:d:drop,slideRight:d:slide,drop:d:drop,rise:d:swipe,spin:b:spin,swing:d:sway,tilt:c:fadeUp,flipX:d:flip,flipY:d:board," +
  "stretch:b:stretch,squash:b:jelly,elastic:b:pop,rubber:b:jelly,blurIn:c:blurIn,blurUp:c:blurIn,blurZoom:d:big,whip:b:whip,glitch:b:rgb,shake:b:shake,blink:d:blink");
/* сплющивание: если «Равномерный масштаб» был включён, ширина = общему масштабу */
function kkA2Wide(X) { var was = true; try { was = X.uni.getValue(); } catch (e) {} X.uni.setValue(false, true); return was ? X.S : kkBase(X.scw, X.refT); }
function kkA2Tm(X) { return function (x) { return X.side === "out" ? 1 - x : x; }; }
var KK_A2FN = {
  leaf: function (X) { var dy = -260 * X.U / X.H, ax = 70 * X.U / X.W;
    kkBake(X.pos, X.t0, X.t1, X.fps, function (x) { var p = X.prog(x), k = 1 - p; return [X.P[0] + ax * k * Math.sin(p * Math.PI * 2.5), X.P[1] + dy * k]; });
    kkBake(X.rot, X.t0, X.t1, X.fps, function (x) { var p = X.prog(x); return X.R + 22 * (1 - p) * Math.cos(p * Math.PI * 2.5); }); },
  island: function (X) { var tm = kkA2Tm(X), SW = kkA2Wide(X);                  // как Dynamic Island: сначала вширь, потом в высоту
    kkBake(X.scw, X.t0, X.t1, X.fps, function (x) { return SW * (.2 + .8 * KK_EASE.springIOS(Math.min(1, tm(x) / .6))); });
    kkBake(X.sc, X.t0, X.t1, X.fps, function (x) { return X.S * (.35 + .65 * KK_EASE.springBouncy(Math.max(0, (tm(x) - .2) / .8))); });
    if (X.op) kkBake(X.op.properties[0], X.t0, X.t1, X.fps, function (x) { return X.O * Math.min(1, tm(x) * 5); }); },
  arc: function (X) { var sx = -320 * X.U / X.W, sy = 80 * X.U / X.H, h = -170 * X.U / X.H;
    kkBake(X.pos, X.t0, X.t1, X.fps, function (x) { var p = X.prog(x); return [X.P[0] + sx * (1 - p), X.P[1] + sy * (1 - p) + h * Math.sin(Math.PI * p)]; });
    kkBake(X.rot, X.t0, X.t1, X.fps, function (x) { return X.R - 25 * (1 - X.prog(x)); }); },
  trail: function (X) { var tr = kkTransform(X.it, false); if (!tr) return;          // движение через «Преобразовать», чтобы «Эхо» видело его
    kkBake(tr.properties[1], X.t0, X.t1, X.fps, function (x) { return [.5 - .35 * (1 - X.prog(x)), .5]; });
    var ec = kkAddEffect(X.it, KK_EFFECTS.echo); if (!ec) return;
    kkPs(ec, "echoT", -1.5 / X.fps); kkPs(ec, "echoI", 1); kkPs(ec, "echoD", .6);
    var en = kkP(ec, "echoN"); if (en) kkBake(en, X.t0, X.t1, X.fps, function (x) { return (X.side === "out" ? x <= .001 : x >= .999) ? 0 : 7; }); },
  slam: function (X) { var tm = kkA2Tm(X), e5 = Math.exp(-5);
    var q = function (u) { return u < .18 ? 1.0875 * KK_EASE.outCubic(u / .18) : 1 + .0875 * (Math.exp(-5 * (u - .18) / .82) - e5) / (1 - e5); };
    kkBake(X.sc, X.t0, X.t1, X.fps, function (x) { return X.S * (1 + .6 * (1 - q(tm(x)))); });
    kkBake(X.pos, X.t0, X.t1, X.fps, function (x) { var u = tm(x), k = u < .18 ? 0 : Math.pow(1 - (u - .18) / .82, 2), i = Math.round(x * 97);
      return [X.P[0] + (kkHash(i) - .5) * 28 * X.U / X.W * k, X.P[1] + (kkHash(i + 31) - .5) * 22 * X.U / X.H * k]; });
    var rc = kkAddEffect(X.it, KK_EFFECTS.rgb); if (rc) { var rp = kkP(rc, "rgbAmt"); if (rp) kkBake(rp, X.t0, X.t1, X.fps, function (x) { var u = tm(x); return u >= 1 ? 0 : 45 * (1 - u) * (1 - u); }); } },
  neon: function (X) { var seg = [[.12, 0], [.2, 1], [.34, 0], [.42, 1], [.47, .25], [.62, 1], [.68, .3], [2, 1]], tm = kkA2Tm(X);
    var lv = function (u) { if (u >= 1) return 1; for (var i = 0; i < seg.length; i++) if (u < seg[i][0]) return seg[i][1]; return 1; };
    if (X.op) kkBake(X.op.properties[0], X.t0, X.t1, X.fps, function (x) { return X.O * lv(tm(x)); });
    var bc = kkAddEffect(X.it, KK_EFFECTS.bright); if (bc) { var bp = kkP(bc, "bright"); if (bp) kkBake(bp, X.t0, X.t1, X.fps, function (x) { var u = tm(x); return u >= 1 ? 0 : 55 * lv(u) * (1 - u); }); } },
  stopMo: function (X) { var st = 3 / X.fps;                                       // 3 кадра на позу — как покадровая анимация вырезками
    kkSteps(X.sc, X.t0, X.t1, st, function (x) { var p = X.prog(x); return X.S * (.35 + .65 * p); });
    kkSteps(X.pos, X.t0, X.t1, st, function (x, i) { var k = 1 - X.prog(x); return [X.P[0] + (kkHash(i * 3 + 1) - .5) * 40 * X.U / X.W * k, X.P[1] + (kkHash(i * 3 + 2) - .5) * 40 * X.U / X.H * k]; });
    kkSteps(X.rot, X.t0, X.t1, st, function (x, i) { return X.R + (kkHash(i * 3 + 3) - .5) * 16 * (1 - X.prog(x)); }); },
  splat: function (X) { var tm = kkA2Tm(X), SW = kkA2Wide(X), dy = -320 * X.U / X.H;   // падает, вытягиваясь, и шмякается с приплющиванием
    var k = function (u) { var v = (u - .5) / .5; return Math.exp(-4 * v) * Math.cos(2 * Math.PI * 1.25 * v) * (1 - v); };
    kkBake(X.pos, X.t0, X.t1, X.fps, function (x) { var u = tm(x); return [X.P[0], X.P[1] + (u < .5 ? dy * (1 - (u / .5) * (u / .5)) : 0)]; });
    kkBake(X.sc, X.t0, X.t1, X.fps, function (x) { var u = tm(x); return X.S * (u < .5 ? 1 + .15 * u / .5 : 1 - .28 * k(u)); });
    kkBake(X.scw, X.t0, X.t1, X.fps, function (x) { var u = tm(x); return SW * (u < .5 ? 1 - .1 * u / .5 : 1 + .25 * k(u)); }); }
};
function kk_anim2(id, side, dur) {
  try {
    var A = KK_ANIMS2[id]; if (!A) return "err|Неизвестная анимация";
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var items = kkSel(); if (!items.length) return "err|Выдели клип, текст или графику";
    var fps = kkFps(seq), W = seq.frameSizeHorizontal, H = seq.frameSizeVertical, U = Math.min(W, H) / 1080;
    dur = Number(dur) || 0.4;
    var prog = function (x) { return side === "out" ? 1 - kkIn(A.e === "linear" ? "linear" : A.e)(x) : KK_EASE[A.e](x); };
    for (var i = 0; i < items.length; i++) {
      var it = items[i], sp = kkSpan(it), d = Math.min(dur, sp.len / 2);
      var mo = kkComp(it, "AE.ADBE Motion"), op = kkComp(it, "AE.ADBE Opacity");
      var t0 = side === "out" ? sp.b - d : sp.a, t1 = side === "out" ? sp.b : sp.a + d, refT = side === "out" ? t0 : t1;
      var pos = mo.properties[0], sc = mo.properties[1], scw = mo.properties[2], uni = mo.properties[3], rot = mo.properties[4];
      var P = kkBase(pos, refT), S = kkBase(sc, refT), R = kkBase(rot, refT), O = op ? kkBase(op.properties[0], refT) : 100;
      if (A.sx !== undefined || A.sy !== undefined) {
        uni.setValue(false, true); var SW = kkBase(scw, refT);
        var sx0 = A.sx !== undefined ? A.sx / 100 : 1, sy0 = A.sy !== undefined ? A.sy / 100 : 1;
        kkBake(scw, t0, t1, fps, function (x) { return SW * (sx0 + (1 - sx0) * prog(x)); });
        kkBake(sc, t0, t1, fps, function (x) { return S * (sy0 + (1 - sy0) * prog(x)); });
      } else if (A.sc !== undefined) kkBake(sc, t0, t1, fps, function (x) { var s0 = A.sc / 100; return S * (s0 + (1 - s0) * prog(x)); });
      if (A.pos) { var dx = A.pos[0] * U / W, dy = A.pos[1] * U / H; kkBake(pos, t0, t1, fps, function (x) { var k = 1 - prog(x); return [P[0] + dx * k, P[1] + dy * k]; }); }
      if (A.rot !== undefined) kkBake(rot, t0, t1, fps, function (x) { return R + A.rot * (1 - prog(x)); });
      if (A.op && op) kkBake(op.properties[0], t0, t1, fps, function (x) { var v = side === "out" ? 1 - Math.max(0, (x - .5) / .5) : Math.min(1, x * 2.5); return O * v; });
      if (A.blur) { var bc = kkAddEffect(it, KK_EFFECTS.blur); if (bc) { var bp = kkP(bc, "blur"); kkBake(bp, t0, t1, fps, function (x) { return Math.max(0, A.blur * U * (1 - prog(x))); }); } }
      if (A.fx === "jitter") { kkBake(pos, t0, t1, fps, function (x) { var R2 = Math.sin(x * 97.3) * 43758.5453, r = R2 - Math.floor(R2); return [P[0] + (r - .5) * 40 * U / W * (1 - x), P[1]]; });
        if (op) kkBake(op.properties[0], t0, t1, fps, function (x) { return (Math.floor(x * 9) % 2 === 0 && x < .8) ? O * .2 : O; }); }
      if (A.fx === "shake") { var a = 10 * U / W; kkBake(pos, t0, t1, fps, function (x) { var k = 1 - x; return [P[0] + a * k * Math.sin(x * 40), P[1] + a * .6 * k * Math.cos(x * 33)]; });
        kkBake(rot, t0, t1, fps, function (x) { return R + 3 * (1 - x) * Math.sin(x * 37); }); }
      if (A.fx === "flicker" && op) kkBake(op.properties[0], t0, t1, fps, function (x) { var on = Math.floor(x * 6) % 2 === 0; return side === "out" ? (x > .95 ? 0 : (on ? O : 0)) : (x > .95 ? O : (on ? 0 : O)); });
      kkAnim3({ it: it, A: A, side: side, prog: prog, t0: t0, t1: t1, fps: fps, mo: mo, op: op, pos: pos, sc: sc, scw: scw, uni: uni, rot: rot, P: P, S: S, R: R, O: O, U: U, W: W, H: H, refT: refT });
    }
    return "ok|«" + A.n + "» готово: " + items.length + " шт.";
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}
function kk_animList() { return kkListOut(KK_ANIMS2); }
/* новые поля анимаций v3 (старые пресеты их не используют) */
function kkAnim3(X) {
  var A = X.A, it = X.it, t0 = X.t0, t1 = X.t1, fps = X.fps, prog = X.prog, U = X.U;
  if (A.crop) { var cc = kkAddEffect(it, KK_EFFECTS.crop), cp = cc ? kkP(cc, "crR") : null;
    if (cp) { if (!A.steps) kkPs(cc, "crF", 14 * U);
      kkBake(cp, t0, t1, fps, function (x) { var q = prog(x); if (A.steps) q = Math.floor(q * A.steps + 1e-6) / A.steps; return q >= 1 ? 0 : q <= 0 ? 100 : 95 - 90 * q; }); } }
  if (A.fx === "type") kkBake(X.pos, t0, t1, fps, function (x) { var q = prog(x); return (q >= 1 || q <= 0) ? X.P : [X.P[0], X.P[1] + (kkHash(Math.floor(q * (A.steps || 9)) + 7) - .5) * 3 * U / X.H]; });
  if (A.skew) { var tk = kkTransform(it, false); if (tk) kkBake(tk.properties[5], t0, t1, fps, function (x) { return A.skew * (1 - prog(x)); }); }
  if (A.rgb) { var rc = kkAddEffect(it, KK_EFFECTS.rgb), rp = rc ? kkP(rc, "rgbAmt") : null;
    if (rp) kkBake(rp, t0, t1, fps, function (x) { var k = 1 - prog(x); return k <= 0 ? 0 : A.rgb * k * (.55 + .45 * kkHash(Math.round(x * 89))); }); }
  if (A.mosaic) { var mc = kkAddEffect(it, KK_EFFECTS.mosaic), mh = mc ? kkP(mc, "mosH") : null, mv = mc ? kkP(mc, "mosV") : null, FW = Math.min(4000, X.W);
    var blk = function (x) { var p = prog(x); return p >= .999 ? FW : Math.max(1, Math.round(A.mosaic * Math.pow(FW / A.mosaic, Math.max(0, p)))); };
    if (mh) kkBake(mh, t0, t1, fps, blk);
    if (mv) kkBake(mv, t0, t1, fps, function (x) { return Math.min(4000, Math.max(1, Math.round(blk(x) * X.H / X.W))); }); }
  if (A.wave) { var wc = kkAddEffect(it, KK_EFFECTS.wave), wp = wc ? kkP(wc, "waveH") : null; if (wp) kkBake(wp, t0, t1, fps, function (x) { return Math.max(0, A.wave * U * (1 - prog(x))); }); }
  if (A.bright) { var bc = kkAddEffect(it, KK_EFFECTS.bright), bp = bc ? kkP(bc, "bright") : null; if (bp) kkBake(bp, t0, t1, fps, function (x) { return A.bright * (1 - prog(x)); }); }
  if (A.noise) { var nc = kkAddEffect(it, KK_EFFECTS.noise), np = nc ? kkP(nc, "noiseAmt") : null; if (np) kkBake(np, t0, t1, fps, function (x) { return Math.max(0, A.noise * (1 - prog(x))); }); }
  if (A.fn && KK_A2FN[A.fn]) KK_A2FN[A.fn](X);
}

/* ---------- переходы v2 ---------- */
/* a/b — что делаем с концом клипа A и началом B; t — тип: transform | fx-эффект */
var KK_TRANS2 = {
  zoom: { n: "Зум-рывок" }, zoomOut: { n: "Отъезд", tf: { aSc: 100, aEnd: 40, bSc: 250 } }, whipL: { n: "Смаз влево" }, whipR: { n: "Смаз вправо" },
  whipU: { n: "Смаз вверх", tf: { dir: [0, -1] } }, whipD: { n: "Смаз вниз", tf: { dir: [0, 1] } },
  spin: { n: "Вращение" }, spinL: { n: "Вращение против", tf: { spinDir: -1 } }, stretch: { n: "Растягивание" }, stretchV: { n: "Растяжка ↕", tf: { vertical: 1 } },
  shake: { n: "Тряска" }, dip: { n: "Затемнение" },
  flash: { n: "Белая вспышка", fx: "bright", val: [0, 100] }, flashZoom: { n: "Вспышка + зум", fx: "bright", val: [0, 100], also: "zoom" },
  blur: { n: "Размытие", fx: "blur", val: [0, 120] }, blurZoom: { n: "Размытие + зум", fx: "blur", val: [0, 90], also: "zoom" },
  fisheye: { n: "Рыбий глаз", fx: "spher", val: [0, 800] }, fisheyeZoom: { n: "Рыбий глаз + зум", fx: "spher", val: [0, 700], also: "zoom" },
  flip3d: { n: "3D-переворот", fx: "b3d", key: "swivel", val: [0, 90] }, tilt3d: { n: "3D-кувырок", fx: "b3d", key: "tilt", val: [0, 90] },
  twirl: { n: "Скручивание", fx: "twirl", key: "twirlA", val: [0, 540] }, pixel: { n: "Пиксели", fx: "mosaic", val: [1, 0] },
  rgb: { n: "RGB-сдвиг", fx: "rgb", key: "rgbAmt", val: [0, 60], also: "shakeSoft" }, glitch: { n: "Глитч", fx: "rgb", key: "rgbAmt", val: [0, 80], also: "jitter" },
  invert: { n: "Негатив-вспышка", fx: "invert", key: "invMix", val: [100, 0] }, wave: { n: "Волна", fx: "wave", key: "waveH", val: [0, 120] },
  echo: { n: "Шлейф", fx: "echo", key: "echoN", val: [0, 6], also: "whip" }, mirror: { n: "Калейдоскоп", fx: "replicate", key: "rep", val: [1, 4] },
  dirblur: { n: "Смаз-размытие", fx: "dirblur", key: "dirlen", val: [0, 200] }
};
/* v3: ещё 21 переход — своя функция на каждый (KK_TR3), c: A, B, a0..a1 (конец A), b0..b1 (начало B), fps, W, H, U, d */
KK_TRANS2.pageSwipe = { n: "Перелистывание", fn: "pageSwipe", g: "c", p: "push" }; KK_TRANS2.cards = { n: "Карточки iOS", fn: "cards", g: "c", p: "card" };
KK_TRANS2.frost = { n: "Матовое стекло", fn: "frost", g: "c", p: "ios" }; KK_TRANS2.wipe = { n: "Шторка", fn: "wipe", g: "c", p: "wipe" };
KK_TRANS2.slit = { n: "Кино-шторки", fn: "slit", g: "c", p: "slit" };
KK_TRANS2.cube = { n: "Куб", fn: "cube", g: "d", p: "cube" }; KK_TRANS2.fall = { n: "Падение", fn: "fall", g: "d", p: "drop" };
KK_TRANS2.toss = { n: "Бросок карточки", fn: "toss", g: "d", p: "toss" }; KK_TRANS2.point = { n: "В точку", fn: "point", g: "d", p: "point" };
KK_TRANS2.stutter = { n: "Заикание", fn: "stutter", g: "d", p: "stopmo" }; KK_TRANS2.flare = { n: "Блик", fn: "flare", g: "d", p: "flare" };
KK_TRANS2.jelly = { n: "Желе", fn: "jelly", g: "d", p: "jelly" }; KK_TRANS2.strobe = { n: "Стробоскоп", fn: "strobe", g: "d", p: "blink" };
KK_TRANS2.desat = { n: "Обесцвечивание", fn: "desat", g: "d", p: "desat" }; KK_TRANS2.stepZoom = { n: "Ступени", fn: "stepZoom", g: "d", p: "stepz" };
KK_TRANS2.tvOff = { n: "Выключение ТВ", fn: "tvOff", g: "b", p: "tv" }; KK_TRANS2.noise = { n: "Помехи", fn: "noise", g: "b", p: "noise" };
KK_TRANS2.burn = { n: "Прожиг плёнки", fn: "burn", g: "b", p: "burn" }; KK_TRANS2.through = { n: "Сквозь кадр", fn: "through", g: "b", p: "through" };
KK_TRANS2.acid = { n: "Кислота", fn: "acid", g: "b", p: "hue" }; KK_TRANS2.filmTear = { n: "Обрыв плёнки", fn: "filmTear", g: "b", p: "stopmo" };
kkMeta(KK_TRANS2, "zoom:d:zoom,zoomOut:d:big,whipL:d:whip,whipR:d:whip,whipU:d:swipe,whipD:d:drop,spin:b:spin,spinL:b:spin,stretch:d:stretch,stretchV:d:board," +
  "shake:d:shake,dip:c:dip,flash:d:flash,flashZoom:b:flash,blur:c:blurIn,blurZoom:d:big,fisheye:d:pulse,fisheyeZoom:b:pulse,flip3d:d:flip,tilt3d:d:board," +
  "twirl:b:spin,pixel:d:pixel,rgb:b:rgb,glitch:b:rgb,invert:b:inv,wave:c:wave,echo:d:trail,mirror:d:pulse,dirblur:d:whip");
function kkTr2(c, blur) { var a = kkTransform(c.A, blur), b = kkTransform(c.B, blur); return a && b ? [a, b] : null; }
function kkTrFx(c, key) { var a = kkAddEffect(c.A, KK_EFFECTS[key]), b = kkAddEffect(c.B, KK_EFFECTS[key]); return a && b ? [a, b] : null; }
/* один параметр на обоих клипах: fa — на конце A, fb — на начале B */
function kkTrP(pair, key, c, fa, fb) { var pa = kkP(pair[0], key), pb = kkP(pair[1], key); if (pa) kkBake(pa, c.a0, c.a1, c.fps, fa); if (pb) kkBake(pb, c.b0, c.b1, c.fps, fb); return pa && pb; }
var KK_TR3 = {
  pageSwipe: function (c) { var t = kkTr2(c, true); if (!t) return "tf";
    kkBake(t[0].properties[1], c.a0, c.a1, c.fps, function (x) { return [.5 - c.inn(x), .5]; });
    kkBake(t[1].properties[1], c.b0, c.b1, c.fps, function (x) { return [1.5 - c.out(x), .5]; }); },
  cards: function (c) { var t = kkTr2(c, true); if (!t) return "tf";
    kkBake(t[0].properties[3], c.a0, c.a1, c.fps, function (x) { return 100 - 14 * KK_EASE.outCubic(Math.min(1, x * 1.6)); });
    kkBake(t[0].properties[1], c.a0, c.a1, c.fps, function (x) { return [.5, .5 - 1.05 * c.inn(x)]; });
    kkBake(t[1].properties[1], c.b0, c.b1, c.fps, function (x) { return [.5, 1.55 - 1.05 * KK_EASE.outQuint(x)]; });
    kkBake(t[1].properties[3], c.b0, c.b1, c.fps, function (x) { return 86 + 14 * KK_EASE.inOutCubic(x); }); },
  frost: function (c) { var bl = kkTrFx(c, "blur"), br = kkTrFx(c, "bright"), t = kkTr2(c, false); if (!bl || !br || !t) return "fx";
    kkEdgePx(bl[0]); kkEdgePx(bl[1]); var B = 36 * c.U;
    kkTrP(bl, "blur", c, function (x) { return B * c.inn(x); }, function (x) { return B * (1 - c.out(x)); });
    kkTrP(br, "bright", c, function (x) { return 28 * c.inn(x); }, function (x) { return 28 * (1 - c.out(x)); });
    kkBake(t[0].properties[3], c.a0, c.a1, c.fps, function (x) { return 100 - 4 * c.inn(x); });
    kkBake(t[1].properties[3], c.b0, c.b1, c.fps, function (x) { return 104 - 4 * c.out(x); }); },
  wipe: function (c) { var cr = kkTrFx(c, "crop"); if (!cr) return "fx"; kkPs(cr[0], "crF", 40 * c.U); kkPs(cr[1], "crF", 40 * c.U);
    var pa = kkP(cr[0], "crL"), pb = kkP(cr[1], "crR"); if (!pa || !pb) return "p";
    kkBake(pa, c.a0, c.a1, c.fps, function (x) { return 100 * c.inn(x); }); kkBake(pb, c.b0, c.b1, c.fps, function (x) { return 100 * (1 - c.out(x)); }); },
  slit: function (c) { var cr = kkTrFx(c, "crop"); if (!cr) return "fx"; kkPs(cr[0], "crF", 20 * c.U); kkPs(cr[1], "crF", 20 * c.U);
    var fa = function (x) { return 50 * c.inn(x); }, fb = function (x) { return 50 * (1 - c.out(x)); };
    if (!kkTrP(cr, "crT", c, fa, fb) || !kkTrP(cr, "crB", c, fa, fb)) return "p"; },
  cube: function (c) { var t = kkTr2(c, false), br = kkTrFx(c, "bright"); if (!t) return "tf";
    try { t[0].properties[2].setValue(false, true); t[1].properties[2].setValue(false, true); } catch (e) {}
    t[0].properties[0].setValue([0, .5], true); t[0].properties[1].setValue([0, .5], true); t[1].properties[0].setValue([1, .5], true); t[1].properties[1].setValue([1, .5], true);
    kkBake(t[0].properties[4], c.a0, c.a1, c.fps, function (x) { return Math.max(.5, 100 * (1 - c.inn(x))); });
    kkBake(t[1].properties[4], c.b0, c.b1, c.fps, function (x) { return Math.max(.5, 100 * c.out(x)); });
    if (br) kkTrP(br, "bright", c, function (x) { return -50 * c.inn(x); }, function (x) { return -50 * (1 - c.out(x)); }); },
  fall: function (c) { var t = kkTr2(c, true); if (!t) return "tf";
    kkBake(t[0].properties[1], c.a0, c.a1, c.fps, function (x) { return [.5, .5 + 1.05 * x * x]; });
    kkBake(t[0].properties[7], c.a0, c.a1, c.fps, function (x) { return 10 * c.inn(x); });
    kkBake(t[1].properties[1], c.b0, c.b1, c.fps, function (x) { return [.5, -.55 + 1.05 * KK_EASE.outBounce(x)]; }); },
  toss: function (c) { var t = kkTr2(c, true); if (!t) return "tf";
    kkBake(t[0].properties[1], c.a0, c.a1, c.fps, function (x) { var e = c.inn(x); return [.5 + .75 * e, .5 + .25 * e]; });
    kkBake(t[0].properties[7], c.a0, c.a1, c.fps, function (x) { return 32 * c.inn(x); });
    kkBake(t[0].properties[3], c.a0, c.a1, c.fps, function (x) { return 100 - 12 * x; });
    kkBake(t[1].properties[3], c.b0, c.b1, c.fps, function (x) { return 95 + 5 * KK_EASE.springIOS(x); });
    kkBake(t[1].properties[8], c.b0, c.b1, c.fps, function (x) { return 100 * Math.min(1, x * 2.5); }); },
  point: function (c) { var t = kkTr2(c, true); if (!t) return "tf";
    kkBake(t[0].properties[3], c.a0, c.a1, c.fps, function (x) { return Math.max(.5, 100 * (1 - c.inn(x))); });
    kkBake(t[0].properties[7], c.a0, c.a1, c.fps, function (x) { return 90 * c.inn(x); });
    kkBake(t[1].properties[3], c.b0, c.b1, c.fps, function (x) { return Math.max(.5, 100 * KK_EASE.outBack(x)); });
    kkBake(t[1].properties[7], c.b0, c.b1, c.fps, function (x) { return -90 * (1 - c.out(x)); }); },
  stutter: function (c) { var po = kkTrFx(c, "post"), t = kkTr2(c, false); if (!po || !t) return "fx";
    var F = Math.round(c.fps), da = Math.min(2 * c.d, c.sa.len / 2), db = Math.min(2 * c.d, c.sb.len / 2), a0 = c.a1 - da, b1 = c.b0 + db, f1 = 1 / c.fps;
    var pa = kkP(po[0], "postFps"), pb = kkP(po[1], "postFps"); if (!pa || !pb) return "p";
    kkKeysAt(pa, [a0, a0 + f1], [F, 6], true); kkKeysAt(pb, [b1 - f1, b1], [6, F], true);
    kkSteps(t[0].properties[3], a0, c.a1, 1 / 6, function (x, i) { return 100 + 3 * i; });
    var nb = Math.max(1, Math.floor(db * 6 + 1e-6)); kkSteps(t[1].properties[3], c.b0, b1, 1 / 6, function (x, i) { return i >= nb ? 100 : 100 + 3 * (nb - i); }); },
  flare: function (c) { var fl = kkTrFx(c, "flare"); if (!fl) return "fx";
    kkTrP(fl, "flB", c, function (x) { return 150 * c.inn(x); }, function (x) { return 150 * (1 - c.out(x)); });
    kkTrP(fl, "flC", c, function (x) { return [.15 + .35 * x, .35 + .05 * x]; }, function (x) { return [.5 + .35 * x, .4 + .05 * x]; }); },
  jelly: function (c) { var t = kkTr2(c, false); if (!t) return "tf";
    try { t[0].properties[2].setValue(false, true); t[1].properties[2].setValue(false, true); } catch (e) {}
    var osc = function (x) { return Math.exp(-4 * x) * Math.cos(2 * Math.PI * 1.75 * x); };
    kkBake(t[0].properties[4], c.a0, c.a1, c.fps, function (x) { return 100 + 40 * c.inn(x); }); kkBake(t[0].properties[3], c.a0, c.a1, c.fps, function (x) { return 100 - 30 * c.inn(x); });
    kkBake(t[1].properties[4], c.b0, c.b1, c.fps, function (x) { return x >= 1 ? 100 : 100 + 40 * osc(x); }); kkBake(t[1].properties[3], c.b0, c.b1, c.fps, function (x) { return x >= 1 ? 100 : 100 - 30 * osc(x); }); },
  strobe: function (c) { var t = kkTr2(c, false); if (!t) return "tf"; var f1 = 1 / c.fps;
    kkSteps(t[0].properties[8], c.a0, c.a1, f1, function (x, i) { return (i % 2 === 0 && x < .85) ? 100 : 0; });
    kkSteps(t[1].properties[8], c.b0, c.b1, f1, function (x, i) { return (i % 2 === 1 || x > .6) ? 100 : 0; });
    kkSteps(t[0].properties[3], c.a0, c.a1, f1, function (x, i) { return i % 2 ? 104 : 100; }); kkSteps(t[1].properties[3], c.b0, c.b1, f1, function (x, i) { return (i % 2 && x < .6) ? 104 : 100; }); },
  desat: function (c) { var pr = kkTrFx(c, "procamp"), t = kkTr2(c, false); if (!pr || !t) return "fx";
    kkTrP(pr, "paSat", c, function (x) { return 100 * (1 - c.inn(x)); }, function (x) { return 100 * c.out(x); });
    kkTrP(pr, "paCon", c, function (x) { return 100 + 50 * c.inn(x); }, function (x) { return 150 - 50 * c.out(x); });
    kkBake(t[0].properties[3], c.a0, c.a1, c.fps, function (x) { return 100 + 8 * c.inn(x); }); kkBake(t[1].properties[3], c.b0, c.b1, c.fps, function (x) { return 108 - 8 * c.out(x); }); },
  stepZoom: function (c) { var t = kkTr2(c, false); if (!t) return "tf"; var q = c.d / 4;
    kkKeysAt(t[0].properties[3], [c.a0, c.a0 + q, c.a0 + 2 * q, c.a0 + 3 * q], [100, 112, 126, 142], true);
    kkKeysAt(t[1].properties[3], [c.b0, c.b0 + q, c.b0 + 2 * q, c.b0 + 3 * q], [142, 126, 112, 100], true); },
  tvOff: function (c) { var t = kkTr2(c, false), br = kkTrFx(c, "bright"); if (!t) return "tf";
    try { t[0].properties[2].setValue(false, true); t[1].properties[2].setValue(false, true); } catch (e) {}
    kkBake(t[0].properties[3], c.a0, c.a1, c.fps, function (x) { return x < .7 ? 100 - 99 * c.inn(x / .7) : 1; });
    kkBake(t[0].properties[4], c.a0, c.a1, c.fps, function (x) { return x < .7 ? 100 + 30 * KK_EASE.outCubic(x / .7) : Math.max(.5, 130 * (1 - c.inn((x - .7) / .3))); });
    kkBake(t[1].properties[3], c.b0, c.b1, c.fps, function (x) { return x < .3 ? 1 : 1 + 99 * c.out((x - .3) / .7); });
    kkBake(t[1].properties[4], c.b0, c.b1, c.fps, function (x) { return x < .3 ? Math.max(.5, 130 * c.out(x / .3)) : 130 - 30 * c.out((x - .3) / .7); });
    if (br) kkTrP(br, "bright", c, function (x) { return 70 * c.inn(x); }, function (x) { return 70 * (1 - c.out(x)); }); },
  noise: function (c) { var nz = kkTrFx(c, "noise"), rg = kkTrFx(c, "rgb"), t = kkTr2(c, false); if (!nz) return "fx";
    kkTrP(nz, "noiseAmt", c, function (x) { return 80 * c.inn(x); }, function (x) { return 80 * (1 - c.out(x)); });
    if (rg) kkTrP(rg, "rgbAmt", c, function (x) { return 30 * x; }, function (x) { return 30 * (1 - x); });
    if (t) { kkBake(t[0].properties[1], c.a0, c.a1, c.fps, function (x) { return [.5, .5 + .02 * Math.sin(x * 50) * x]; }); kkBake(t[1].properties[1], c.b0, c.b1, c.fps, function (x) { return [.5, .5 + .02 * Math.sin(x * 43) * (1 - x)]; }); } },
  burn: function (c) { var tn = kkTrFx(c, "tint"), br = kkTrFx(c, "bright"), bl = kkTrFx(c, "blur"); if (!tn) return "fx";
    for (var i = 0; i < 2; i++) { kkPc(tn[i], "tBlack", "#FFAD05"); kkPc(tn[i], "tWhite", "#FFFFFF"); }      // фирменный жёлтый КК
    kkTrP(tn, "tAmt", c, function (x) { return 100 * c.inn(x); }, function (x) { return 100 * (1 - c.out(x)); });
    if (br) kkTrP(br, "bright", c, function (x) { return 45 * c.inn(x) + 15 * kkHash(Math.round(x * 50)) * x; }, function (x) { return 45 * (1 - c.out(x)) + 15 * kkHash(Math.round(x * 50) + 7) * (1 - x); });
    if (bl) { kkEdgePx(bl[0]); kkEdgePx(bl[1]); kkTrP(bl, "blur", c, function (x) { return 20 * c.U * c.inn(x); }, function (x) { return 20 * c.U * (1 - c.out(x)); }); } },
  through: function (c) { var t = kkTr2(c, true); if (!t) return "tf";
    kkBake(t[0].properties[3], c.a0, c.a1, c.fps, function (x) { return 100 + 300 * KK_EASE.inExpo(x); });
    kkBake(t[1].properties[3], c.b0, c.b1, c.fps, function (x) { return 40 + 60 * c.out(x); });
    kkBake(t[1].properties[8], c.b0, c.b1, c.fps, function (x) { return 100 * Math.min(1, x * 3); }); },
  acid: function (c) { var pr = kkTrFx(c, "procamp"), t = kkTr2(c, false); if (!pr) return "fx";
    kkTrP(pr, "paHue", c, function (x) { return 180 * c.inn(x); }, function (x) { return -180 * (1 - c.out(x)); });
    kkTrP(pr, "paSat", c, function (x) { return 100 + 80 * c.inn(x); }, function (x) { return 180 - 80 * c.out(x); });
    if (t) { kkBake(t[0].properties[3], c.a0, c.a1, c.fps, function (x) { return 100 + 12 * c.inn(x); }); kkBake(t[1].properties[3], c.b0, c.b1, c.fps, function (x) { return 112 - 12 * c.out(x); }); } },
  filmTear: function (c) { var t = kkTr2(c, false), br = kkTrFx(c, "bright"), po = kkTrFx(c, "post"); if (!t) return "tf"; var st = 2 / c.fps;
    kkSteps(t[0].properties[1], c.a0, c.a1, st, function (x, i) { return x >= 1 ? [.5, .5 + .2] : [.5, .5 + (kkHash(i + 3) - .3) * .22 * x]; });
    kkSteps(t[1].properties[1], c.b0, c.b1, st, function (x, i) { return x >= 1 ? [.5, .5] : [.5, .5 - (kkHash(i + 9) - .3) * .22 * (1 - x)]; });
    var q0 = br ? kkP(br[0], "bright") : null, q1 = br ? kkP(br[1], "bright") : null;
    if (q0) kkSteps(q0, c.a0, c.a1, st, function (x, i) { return (kkHash(i + 5) > .55 ? 50 : -20) * x; });
    if (q1) kkSteps(q1, c.b0, c.b1, st, function (x, i) { return x >= 1 ? 0 : (kkHash(i + 11) > .55 ? 50 : -20) * (1 - x); });
    if (po) { var pa = kkP(po[0], "postFps"), pb = kkP(po[1], "postFps"), F = Math.round(c.fps); if (pa) kkKeysAt(pa, [c.a0, c.a0 + 1 / c.fps], [F, 8], true); if (pb) kkKeysAt(pb, [c.b1 - 1 / c.fps, c.b1], [8, F], true); } }
};
function kk_trans2(id, frames) {
  try {
    var T = KK_TRANS2[id]; if (!T) return "err|Неизвестный переход";
    var old = { zoom: 1, whipL: 1, whipR: 1, spin: 1, stretch: 1, shake: 1, dip: 1 };
    if (old[id] && !T.tf) return kk_trans(id, frames).replace("«" + id + "»", "«" + T.n + "»");           // проверенные первые 7
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var cut = kkCut(seq); if (!cut) return "err|Поставь плейхед точно на стык двух клипов";
    var fps = kkFps(seq), n = Number(frames) || 8, d = n / fps, A = cut.a, B = cut.b, sa = kkSpan(A), sb = kkSpan(B);
    d = Math.min(d, sa.len / 2, sb.len / 2);
    var a0 = sa.b - d, a1 = sa.b, b0 = sb.a, b1 = sb.a + d, inn = KK_EASE.inCubic, out = KK_EASE.outCubic;
    if (T.fn) {                                                   // переходы v3 — своя функция
      var r3 = KK_TR3[T.fn]({ A: A, B: B, sa: sa, sb: sb, a0: a0, a1: a1, b0: b0, b1: b1, d: d, fps: fps, seq: seq, W: seq.frameSizeHorizontal, H: seq.frameSizeVertical,
        U: Math.min(seq.frameSizeHorizontal, seq.frameSizeVertical) / 1080, inn: inn, out: out });
      if (r3 === "tf") return "err|Не получилось добавить «Преобразовать»";
      if (r3 === "fx") return "err|В этой версии Премьера нет эффекта для перехода «" + T.n + "»";
      if (r3 === "p") return "err|Не нашла параметр эффекта для «" + T.n + "»";
      if (r3) return "err|" + r3;
      return "ok|Переход «" + T.n + "» готов";
    }
    if (T.tf) {                                                   // варианты на «Преобразовать»
      var ta = kkTransform(A, true), tb = kkTransform(B, true); if (!ta || !tb) return "err|Не получилось добавить «Преобразовать»";
      var SC = function (c) { return c.properties[3]; }, PS = function (c) { return c.properties[1]; };
      if (T.tf.aEnd) { kkBake(SC(ta), a0, a1, fps, function (x) { return 100 + 25 * inn(x); }); kkBake(SC(tb), b0, b1, fps, function (x) { return 180 - 80 * out(x); }); }
      else if (T.tf.dir) { var dy = T.tf.dir[1];
        kkBake(SC(ta), a0, a1, fps, function (x) { return 100 + 60 * inn(x); }); kkBake(PS(ta), a0, a1, fps, function (x) { return [0.5, 0.5 + dy * 0.3 * inn(x)]; });
        kkBake(SC(tb), b0, b1, fps, function (x) { return 160 - 60 * out(x); }); kkBake(PS(tb), b0, b1, fps, function (x) { return [0.5, 0.5 - dy * 0.3 * (1 - out(x))]; }); }
      else if (T.tf.spinDir) { var W = seq.frameSizeHorizontal, H = seq.frameSizeVertical, szA = kkSrcSize(A) || [W, H], szB = kkSrcSize(B) || [W, H];
        var cover0 = function (sz, deg) { var t = Math.abs(deg) * Math.PI / 180, c = Math.abs(Math.cos(t)), si = Math.abs(Math.sin(t)); return Math.max((sz[0] * c + sz[1] * si) / sz[0], (sz[0] * si + sz[1] * c) / sz[1]) * 102; }; var cover = function (sz, deg) { var m = 0; for (var dd = -60; dd <= 60; dd += 5) m = Math.max(m, cover0(sz, deg + dd)); return m; };
        kkBake(ta.properties[7], a0, a1, fps, function (x) { return -180 * inn(x); }); kkBake(SC(ta), a0, a1, fps, function (x) { return cover(szA, 180 * inn(x)); });
        kkBake(tb.properties[7], b0, b1, fps, function (x) { return 180 * (1 - out(x)); }); kkBake(SC(tb), b0, b1, fps, function (x) { return cover(szB, 180 * (1 - out(x))); }); }
      else if (T.tf.vertical) { ta.properties[2].setValue(false, true); tb.properties[2].setValue(false, true);
        kkBake(ta.properties[3], a0, a1, fps, function (x) { return 100 + 250 * inn(x); }); kkBake(tb.properties[3], b0, b1, fps, function (x) { return 350 - 250 * out(x); }); }
      return "ok|Переход «" + T.n + "» готов";
    }
    // варианты на эффектах: эффект нарастает к стыку на A и спадает на B
    var ca = kkAddEffect(A, KK_EFFECTS[T.fx]), cb = kkAddEffect(B, KK_EFFECTS[T.fx]);
    if (!ca || !cb) return "err|В этой версии Премьера нет эффекта для перехода «" + T.n + "»";
    var key = T.key || (T.fx === "bright" ? "bright" : T.fx === "blur" ? "blur" : T.fx === "spher" ? "spherR" : T.fx === "mosaic" ? "mosH" : null);
    var pa = kkP(ca, key), pb = kkP(cb, key); if (!pa || !pb) return "err|Не нашла параметр эффекта для «" + T.n + "»";
    var v0 = T.val[0], v1 = T.val[1], H2 = seq.frameSizeVertical, W2 = seq.frameSizeHorizontal;
    if (T.fx === "mosaic") { // пиксели: много блоков → мало блоков → много
      var pva = kkP(ca, "mosV"), pvb = kkP(cb, "mosV"), big = 200, small = 12;
      kkBake(pa, a0, a1, fps, function (x) { return Math.round(big - (big - small) * inn(x)); }); if (pva) kkBake(pva, a0, a1, fps, function (x) { return Math.round((big - (big - small) * inn(x)) * H2 / W2); });
      kkBake(pb, b0, b1, fps, function (x) { return Math.round(small + (big - small) * out(x)); }); if (pvb) kkBake(pvb, b0, b1, fps, function (x) { return Math.round((small + (big - small) * out(x)) * H2 / W2); });
    } else {
      kkBake(pa, a0, a1, fps, function (x) { return v0 + (v1 - v0) * inn(x); });
      kkBake(pb, b0, b1, fps, function (x) { return v1 + (v0 - v1) * out(x); });
    }
    if (T.also === "zoom" || T.also === "whip") { var za = kkTransform(A, true), zb = kkTransform(B, true);
      if (za && zb) { kkBake(za.properties[3], a0, a1, fps, function (x) { return 100 + 60 * inn(x); }); kkBake(zb.properties[3], b0, b1, fps, function (x) { return 160 - 60 * out(x); }); } }
    if (T.also === "jitter" || T.also === "shakeSoft") { var ja = kkTransform(A, false), jb = kkTransform(B, false), amp = T.also === "jitter" ? 0.03 : 0.012;
      if (ja && jb) { kkBake(ja.properties[1], a0, a1, fps, function (x) { return [0.5 + amp * Math.sin(x * 61) * x, 0.5]; }); kkBake(jb.properties[1], b0, b1, fps, function (x) { return [0.5 + amp * Math.sin(x * 53) * (1 - x), 0.5]; }); } }
    return "ok|Переход «" + T.n + "» готов";
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}
function kk_transList() { return kkListOut(KK_TRANS2); }

/* ---------- эффекты на клип ---------- */
/* mode: pulse (пульсирует весь клип), in (на входе), once (статично), loop (непрерывно) */
var KK_FX2 = {
  fisheye: { n: "Рыбий глаз", fx: "spher", key: "spherR", mode: "once", val: 900 }, fisheyePulse: { n: "Рыбий глаз-пульс", fx: "spher", key: "spherR", mode: "pulse", val: 800 },
  fisheyeIn: { n: "Рыбий глаз на входе", fx: "spher", key: "spherR", mode: "in", val: 1000 },
  rot3d: { n: "3D-покачивание", fx: "b3d", key: "swivel", mode: "loop", val: 18 }, tilt3d: { n: "3D-наклон", fx: "b3d", key: "tilt", mode: "loop", val: 14 },
  flip3dIn: { n: "3D-разворот на входе", fx: "b3d", key: "swivel", mode: "in", val: 90 },
  rgbPulse: { n: "RGB-пульс", fx: "rgb", key: "rgbAmt", mode: "pulse", val: 40 }, rgbStatic: { n: "RGB-разлом", fx: "rgb", key: "rgbAmt", mode: "once", val: 18 },
  twirlIn: { n: "Воронка на входе", fx: "twirl", key: "twirlA", mode: "in", val: 360 }, twirlLoop: { n: "Медленная воронка", fx: "twirl", key: "twirlA", mode: "loop", val: 40 },
  jelly: { n: "Желе (волна)", fx: "wave", key: "waveH", mode: "once", val: 12 }, dream: { n: "Сон (волна + размытие)", fx: "wave", key: "waveH", mode: "once", val: 6, plus: "blurSoft" },
  kaleido: { n: "Калейдоскоп 2×2", fx: "replicate", key: "rep", mode: "once", val: 2 }, kaleido3: { n: "Калейдоскоп 3×3", fx: "replicate", key: "rep", mode: "once", val: 3 },
  mirror: { n: "Зеркало", fx: "mirror", mode: "once" }, echo: { n: "Шлейф движения", fx: "echo", key: "echoN", mode: "once", val: 4 },
  pixelIn: { n: "Пиксели на входе", fx: "mosaic", key: "mosH", mode: "in", val: 8 }, pixelLook: { n: "Пиксель-арт", fx: "mosaic", key: "mosH", mode: "once", val: 90 },
  stop12: { n: "Через кадр (12 к/с)", fx: "post", key: "postFps", mode: "once", val: 12 },
  shake: { n: "Тряска камеры", fx: "shake", mode: "once" }, glow: { n: "Чудесное свечение", fx: "glow", mode: "once" }, leaks: { n: "Световые утечки", fx: "leaks", mode: "once" },
  glitch: { n: "Цифровой сбой", fx: "glitch", mode: "once" }, longShadow: { n: "Длинная тень (для текста)", fx: "shadow", mode: "once" },
  blurIn: { n: "Фокус на входе", fx: "blur", key: "blur", mode: "in", val: 80 }, invertFlash: { n: "Негатив-вспышка", fx: "invert", key: "invMix", mode: "flash", val: 0 }
};
/* v3: ещё 24 эффекта — своя функция (KK_FX3), c: it, sp, fps, U, W, H, seq, mo */
KK_FX2.haze = { n: "Марево", fn: "haze", g: "c", p: "wave" }; KK_FX2.glass = { n: "Стекло iOS", fn: "glass", g: "c", p: "ios" };
KK_FX2.softShadow = { n: "Мягкая тень", fn: "softShadow", g: "c", p: "shadow" }; KK_FX2.boil = { n: "Живой контур", fn: "boil", g: "c", p: "stopmo" };
KK_FX2.colorIn = { n: "Проявление цвета", fn: "colorIn", g: "c", p: "desat" }; KK_FX2.leaveYellow = { n: "Только жёлтый", fn: "leaveYellow", g: "c", p: "desat" };
KK_FX2.sketch = { n: "Скетч маркером", fn: "sketch", g: "c", p: "inv" }; KK_FX2.sign = { n: "Вывеска", fn: "sign", g: "c", p: "sway" };
KK_FX2.grain = { n: "Зерно плёнки", fn: "grain", g: "c", p: "noise" };
KK_FX2.beatFlash = { n: "Вспышки в бит", fn: "beatFlash", g: "d", p: "flash" }; KK_FX2.speedBlur = { n: "Смаз скорости", fn: "speedBlur", g: "d", p: "whip" };
KK_FX2.stutterBeat = { n: "Рваный ритм", fn: "stutterBeat", g: "d", p: "stopmo" }; KK_FX2.sticker = { n: "Стикер", fn: "sticker", g: "d", p: "shadow" };
KK_FX2.heartbeat = { n: "Сердцебиение", fn: "heartbeat", g: "d", p: "pulse" }; KK_FX2.scroll = { n: "Бегущая лента", fn: "scroll", g: "d", p: "push" };
KK_FX2.spinner = { n: "Вертушка", fn: "spinner", g: "d", p: "spin" }; KK_FX2.hopper = { n: "Попрыгунчик", fn: "hopper", g: "d", p: "hop" };
KK_FX2.coin = { n: "Монетка", fn: "coin", g: "b", p: "coin" }; KK_FX2.yellowNeon = { n: "Жёлтый неон", fn: "yellowNeon", g: "b", p: "neon" };
KK_FX2.pixelGlitch = { n: "Цифровые блоки", fn: "pixelGlitch", g: "b", p: "pixel" }; KK_FX2.melt = { n: "Плавится", fn: "melt", g: "b", p: "wave" };
KK_FX2.impact = { n: "Удар", fn: "impact", g: "b", p: "slam" }; KK_FX2.tunnel = { n: "Туннель", fn: "tunnel", g: "b", p: "through" };
KK_FX2.tvNoise = { n: "Помехи ТВ", fn: "tvNoise", g: "b", p: "noise" };
kkMeta(KK_FX2, "fisheye:d:pulse,fisheyePulse:d:pulse,fisheyeIn:d:pulse,rot3d:c:flip,tilt3d:c:board,flip3dIn:d:flip,rgbPulse:b:rgb,rgbStatic:d:rgb," +
  "twirlIn:b:spin,twirlLoop:c:spin,jelly:c:wave,dream:c:blurIn,kaleido:d:zoom,kaleido3:d:zoom,mirror:c:zoom,echo:d:trail,pixelIn:d:pixel,pixelLook:d:pixel," +
  "stop12:d:stopmo,shake:d:shake,glow:c:burn,leaks:c:burn,glitch:b:rgb,longShadow:c:shadow,blurIn:c:blurIn,invertFlash:b:inv");
function kkFxNo(key) { return "В этой версии Премьера нет эффекта «" + KK_EFFECTS[key][0] + "»"; }
var KK_FX3 = {
  haze: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.turb); if (!e) return kkFxNo("turb"); var L = c.sp.len;
    kkPs(e, "tuAmt", 10); kkPs(e, "tuSize", 70 * c.U); var ev = kkP(e, "tuEvo"); if (ev) kkBake(ev, c.sp.a, c.sp.b, Math.min(c.fps, 15), function (x) { return x * L * 150; }); },
  glass: function (c) { var b = kkAddEffect(c.it, KK_EFFECTS.blur); if (!b) return kkFxNo("blur"); kkEdgePx(b); kkPs(b, "blur", 45 * c.U);
    var br = kkAddEffect(c.it, KK_EFFECTS.bright); kkPs(br, "bright", 22); },
  softShadow: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.dshadow); if (!e) return kkFxNo("dshadow");
    kkPs(e, "dsOp", 45); kkPs(e, "dsDir", 180); kkPs(e, "dsDist", 14 * c.U); kkPs(e, "dsSoft", 55 * c.U); },
  boil: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.rough); if (!e) return kkFxNo("rough"); kkPs(e, "rgBorder", 5 * c.U);
    var ev = kkP(e, "rgEvo"); if (ev) kkSteps(ev, c.sp.a, c.sp.b, 3 / c.fps, function (x, i) { return kkHash(i + 1) * 360; }); },   // «кипящая» линия, как в рисованной анимации
  colorIn: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.procamp); if (!e) return kkFxNo("procamp");
    var s = kkP(e, "paSat"); if (s) kkBake(s, c.sp.a, c.sp.a + Math.min(1.2, c.sp.len * .8), c.fps, function (x) { return 100 * KK_EASE.inOutSine(x); }); },
  leaveYellow: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.leave); if (!e) return kkFxNo("leave");
    if (/Color Pass/.test(e.matchName)) { try { e.properties[0].setValue(28, true); e.properties[1].setValue(false, true); } catch (x) {} kkPc(e, "cpCol", "#FFAD05"); return; }
    kkPs(e, "lcAmt", 100); kkPc(e, "lcCol", "#FFAD05"); kkPs(e, "lcTol", 30); kkPs(e, "lcSoft", 12); },
  sketch: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.edges); if (!e) return kkFxNo("edges"); kkPs(e, "edInv", false); kkPs(e, "edMix", 0);
    var t = kkAddEffect(c.it, KK_EFFECTS.tint); if (t) { kkPc(t, "tBlack", "#16130C"); kkPc(t, "tWhite", "#FFFFFF"); kkPs(t, "tAmt", 100); }
    var po = kkAddEffect(c.it, KK_EFFECTS.post); kkPs(po, "postFps", 8); },
  sign: function (c) { var tr = kkTransform(c.it, false); if (!tr) return "Не получилось добавить «Преобразовать»"; var L = c.sp.len;   // качается на «гвоздике» сверху
    tr.properties[0].setValue([.5, .04], true); tr.properties[1].setValue([.5, .04], true);
    kkBake(tr.properties[7], c.sp.a, c.sp.b, Math.min(c.fps, 15), function (x) { var t = x * L; return 11 * Math.exp(-1.6 * t) * Math.cos(2 * Math.PI * t / 1.3) + 2.2 * Math.sin(2 * Math.PI * t / 2.6); }); },
  grain: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.noise); if (!e) return kkFxNo("noise"); kkPs(e, "noiseAmt", 9); kkPs(e, "noiseCol", false);
    var br = kkAddEffect(c.it, KK_EFFECTS.bright), bp = br ? kkP(br, "bright") : null; if (bp) kkSteps(bp, c.sp.a, c.sp.b, 2 / c.fps, function (x, i) { return (kkHash(i + 4) - .5) * 4; }); },
  beatFlash: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.bright); if (!e) return kkFxNo("bright"); var L = c.sp.len, p = kkP(e, "bright");
    if (p) kkBake(p, c.sp.a, c.sp.b, Math.min(c.fps, 30), function (x) { var ph = (x * L % .5) / .5; return 55 * Math.pow(1 - ph, 4); }); },
  speedBlur: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.dirblur); if (!e) return kkFxNo("dirblur"); kkPs(e, "dirang", 90); kkPs(e, "dirlen", 30 * c.U); },
  stutterBeat: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.post); if (!e) return kkFxNo("post"); var F = Math.round(c.fps), p = kkP(e, "postFps");
    if (p) kkSteps(p, c.sp.a, c.sp.b, .25, function (x, i) { return i % 2 ? F : 6; }); },
  sticker: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.stroke); if (!e) return kkFxNo("stroke") + " (он есть в Premiere Pro 2025 и новее)";
    kkPs(e, "stSize", 14 * c.U); kkPc(e, "stCol", "#FFFFFF");
    var d = kkAddEffect(c.it, KK_EFFECTS.dshadow); kkPs(d, "dsOp", 40); kkPs(d, "dsDir", 160); kkPs(d, "dsDist", 10 * c.U); kkPs(d, "dsSoft", 30 * c.U);
    var r = c.mo.properties[4]; if (!r.isTimeVarying()) r.setValue(r.getValue() - 4, true); },
  heartbeat: function (c) { var sc = c.mo.properties[1], S = kkBase(sc, c.sp.a), L = c.sp.len;   // «тук-тук» каждые 0,9 с
    kkBake(sc, c.sp.a, c.sp.b, Math.min(c.fps, 30), function (x) { var t = x * L % .9; return S * (1 + .09 * Math.exp(-Math.pow((t - .05) / .05, 2)) + .06 * Math.exp(-Math.pow((t - .25) / .06, 2))); }); },
  scroll: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.offset); if (!e) return kkFxNo("offset"); var p = kkP(e, "ofsC"); if (!p) return "Не нашла параметр «Сместить центр в»";
    kkKeysAt(p, [c.sp.a, c.sp.b], [[.5, .5], [.5 + c.sp.len * .25, .5]], false); },
  spinner: function (c) { var r = c.mo.properties[4], R = kkBase(r, c.sp.a); kkKeysAt(r, [c.sp.a, c.sp.b], [R, R + 120 * c.sp.len], false); },
  hopper: function (c) { var tr = kkTransform(c.it, false); if (!tr) return "Не получилось добавить «Преобразовать»"; var L = c.sp.len;
    try { tr.properties[2].setValue(false, true); } catch (e) {}
    var sq = function (x) { var ph = (x * L % .6) / .6, d = Math.min(ph, 1 - ph); return Math.exp(-Math.pow(d / .08, 2)); }, fr = Math.min(c.fps, 30);
    kkBake(tr.properties[1], c.sp.a, c.sp.b, fr, function (x) { return [.5, .5 - .06 * Math.abs(Math.sin(Math.PI * x * L / .6))]; });
    kkBake(tr.properties[3], c.sp.a, c.sp.b, fr, function (x) { return 100 - 12 * sq(x); }); kkBake(tr.properties[4], c.sp.a, c.sp.b, fr, function (x) { return 100 + 10 * sq(x); }); },
  coin: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.b3d); if (!e) return kkFxNo("b3d"); var p = kkP(e, "swivel"); if (p) kkKeysAt(p, [c.sp.a, c.sp.b], [0, 240 * c.sp.len], false); },
  yellowNeon: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.edges); if (!e) return kkFxNo("edges"); kkPs(e, "edInv", true); kkPs(e, "edMix", 0);
    var t = kkAddEffect(c.it, KK_EFFECTS.tint); if (t) { kkPc(t, "tBlack", "#000000"); kkPc(t, "tWhite", "#FFAD05"); kkPs(t, "tAmt", 100); }
    var b = kkAddEffect(c.it, KK_EFFECTS.bright); kkPs(b, "bright", 25); },
  pixelGlitch: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.mosaic); if (!e) return kkFxNo("mosaic"); var h = kkP(e, "mosH"), v = kkP(e, "mosV"), FW = Math.min(4000, c.W), FH = Math.min(4000, c.H);
    var b = function (i) { var r = kkHash(i * 3 + 1); return r > .82 ? 18 + Math.round(r * 30) : 0; };
    if (h) kkSteps(h, c.sp.a, c.sp.b, 2 / c.fps, function (x, i) { var k = b(i); return k || FW; });
    if (v) kkSteps(v, c.sp.a, c.sp.b, 2 / c.fps, function (x, i) { var k = b(i); return k ? Math.max(1, Math.round(k * c.H / c.W)) : FH; }); },
  melt: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.turb); if (!e) return kkFxNo("turb"); var L = c.sp.len, fr = Math.min(c.fps, 15);
    kkPs(e, "tuSize", 90 * c.U); var a = kkP(e, "tuAmt"), ev = kkP(e, "tuEvo");
    if (a) kkBake(a, c.sp.a, c.sp.b, fr, function (x) { return 110 * x * x; }); if (ev) kkBake(ev, c.sp.a, c.sp.b, fr, function (x) { return x * L * 100; }); },
  impact: function (c) { var t = kkSrcAt(c.seq, c.it, c.sp), d = Math.min(.3, c.sp.b - t), f1 = 1 / c.fps, sc = c.mo.properties[1], S = kkBase(sc, t);
    var rc = kkAddEffect(c.it, KK_EFFECTS.rgb), rp = rc ? kkP(rc, "rgbAmt") : null; if (rp) { kkCamPre(rp, t - f1, 0, c.sp.a); kkBake(rp, t, t + d, c.fps, function (x) { return 50 * (1 - KK_EASE.outCubic(x)); }); }
    var bc = kkAddEffect(c.it, KK_EFFECTS.blur), bp = bc ? kkP(bc, "blur") : null; if (bp) { kkEdgePx(bc); kkCamPre(bp, t - f1, 0, c.sp.a); kkBake(bp, t, t + d, c.fps, function (x) { return 20 * c.U * (1 - KK_EASE.outCubic(x)); }); }
    kkCamPre(sc, t - f1, S, c.sp.a); kkBake(sc, t, t + d, c.fps, function (x) { return S * (1.12 - .12 * KK_EASE.outCubic(x)); }); },
  tunnel: function (c) { var tr = kkTransform(c.it, false); if (!tr) return "Не получилось добавить «Преобразовать»";
    kkBake(tr.properties[3], c.sp.a, c.sp.b, Math.min(c.fps, 15), function (x) { return 100 + 45 * KK_EASE.inOutSine(x); });
    var e = kkAddEffect(c.it, KK_EFFECTS.echo); if (!e) return kkFxNo("echo"); kkPs(e, "echoT", -.04); kkPs(e, "echoN", 7); kkPs(e, "echoI", .38); kkPs(e, "echoD", .72); },
  tvNoise: function (c) { var e = kkAddEffect(c.it, KK_EFFECTS.noise); if (!e) return kkFxNo("noise"); var st = 2 / c.fps, p = kkP(e, "noiseAmt");
    var on = function (i) { var r = kkHash(i * 5 + 2); return r > .8 ? r : 0; };
    if (p) kkSteps(p, c.sp.a, c.sp.b, st, function (x, i) { var r = on(i); return r ? 35 + r * 40 : 0; });
    var rc = kkAddEffect(c.it, KK_EFFECTS.rgb), rp = rc ? kkP(rc, "rgbAmt") : null; if (rp) kkSteps(rp, c.sp.a, c.sp.b, st, function (x, i) { var r = on(i); return r ? 20 + r * 25 : 0; }); }
};
function kk_fx2(id) {
  try {
    var F = KK_FX2[id]; if (!F) return "err|Неизвестный эффект";
    var seq = kkSeq(); if (!seq) return "err|Открой секвенцию";
    var items = kkSel(); if (!items.length) return "err|Выдели клип";
    var fps = kkFps(seq), U = Math.min(seq.frameSizeHorizontal, seq.frameSizeVertical) / 1080, n = 0;
    for (var i = 0; i < items.length; i++) {
      var it = items[i], sp = kkSpan(it); if (!kkQeItem(it)) return "err|Не нашла клип — выдели его ещё раз";
      if (F.fn) {                                                      // эффекты v3 — своя функция
        var r3 = KK_FX3[F.fn]({ it: it, sp: sp, fps: fps, U: U, W: seq.frameSizeHorizontal, H: seq.frameSizeVertical, seq: seq, mo: kkComp(it, "AE.ADBE Motion") });
        if (r3) return "err|" + r3;
        n++; continue;
      }
      var c = kkAddEffect(it, KK_EFFECTS[F.fx]); if (!c) return "err|В этой версии Премьера нет эффекта «" + KK_EFFECTS[F.fx][0] + "»";
      n++;
      if (F.fx === "b3d" || F.fx === "shake" || F.fx === "twirl") { var mo = kkComp(it, "AE.ADBE Motion"); if (mo && !mo.properties[1].isTimeVarying()) mo.properties[1].setValue(mo.properties[1].getValue() * (F.fx === "shake" ? 1.08 : 1.18), true); } // без чёрных краёв
      if (!F.key) continue;                                            // эффекты с хорошими настройками по умолчанию
      var p = kkP(c, F.key); if (!p) continue;
      var v = F.val * ((F.key === "spherR" || F.key === "blur") ? U : 1);
      if (F.mode === "once") p.setValue(v, true);
      else if (F.mode === "in") { var d = Math.min(0.5, sp.len / 2); kkBake(p, sp.a, sp.a + d, fps, function (x) { return F.key === "mosH" ? Math.round(v + (200 - v) * KK_EASE.outCubic(x)) : v * (1 - KK_EASE.outCubic(x)); }); }
      else if (F.mode === "pulse") kkBake(p, sp.a, sp.b, Math.min(fps, 15), function (x) { var t = x * sp.len; return v * Math.pow(Math.max(0, Math.sin(t * Math.PI * 2 / 0.9)), 6); });
      else if (F.mode === "loop") kkBake(p, sp.a, sp.b, Math.min(fps, 15), function (x) { return v * Math.sin(x * sp.len * Math.PI * 2 / 3); });
      else if (F.mode === "flash") { var m = Math.min(0.3, sp.len / 3); kkBake(p, sp.a, sp.a + m, fps, function (x) { return 100 * x; }); }
      if (F.plus === "blurSoft") { var bc = kkAddEffect(it, KK_EFFECTS.blur); if (bc) kkP(bc, "blur").setValue(6 * U, true); }
    }
    return "ok|«" + F.n + "» на " + n + " клип.";
  } catch (e) { return "err|" + e.toString() + " (строка " + e.line + ")"; }
}
function kk_fxList() { return kkListOut(KK_FX2); }

/* КК · Анимация — интерфейс панели. Вызывает функции из jsx/host.jsx через CEP evalScript. */
(function () {
  var VERSION = "1.1.2";
  var cep = window.__adobe_cep__;
  function run(fn, args, cb) {
    var call = fn + "(" + (args || []).map(function (a) { return JSON.stringify(a); }).join(",") + ")";
    if (!cep) { cb && cb("err|Открой панель внутри Premiere Pro"); return; }
    cep.evalScript(call, function (r) { cb && cb(String(r || "")); });
  }
  function say(r) {
    var m = document.getElementById("msg"), p = String(r).split("|");
    m.className = p[0] === "ok" ? "ok" : "err"; m.textContent = p.slice(1).join(" ") || r;
    clearTimeout(say.t); say.t = setTimeout(function () { m.textContent = ""; }, 6000);
  }
  var dur = 0.4, side = "in", trf = 8, sub = "kk-word", subW = 0;
  var SUBS = [["kk-word", "КК · активное слово", "белый текст, сказанное слово — цветом акцента"], ["pop-word", "Поп по словам", "слова выскакивают по одному, капс"], ["word-by-word", "Слово за словом", "фраза набирается по словам"], ["karaoke", "Караоке", "цвет заливает текст по ходу речи"], ["caps-stroke", "Капс с обводкой", "крупно и жирно, как у блогеров"], ["kk-plate", "КК · плашка", "текст на цветной плашке"], ["typewriter", "Печатная машинка", "по буквам, моноширинный"], ["minimal", "Минимал", "тонкий шрифт и мягкая тень"]];
  var TRANS = [["zoom", "Зум-рывок", "zoom"], ["whipL", "Смаз влево", "slide"], ["whipR", "Смаз вправо", "slide"], ["spin", "Вращение", "pop"], ["stretch", "Растягивание", "zoom"], ["shake", "Тряска", "shake"], ["dip", "Затемнение", "blink"]];

  var per = 1.5, amt = 1;
  var LOOPS = [["sway", "Качание", "маятник туда-сюда"], ["float", "Парение", "плавно вверх-вниз"], ["pulse", "Пульс", "дышит масштабом"], ["spin", "Вращение", "бесконечный поворот"], ["blink", "Мигание", "включается и выключается"]];
  var TABS = {
    "Покадрово": function () {
      return '<div class="sec"><h3>Эффект stop-motion</h3><div class="list">' +
        '<button class="btn" data-steps="12">Через кадр (на двойках)<small>12 кадров в секунду — классика анимационных рилсов</small></button>' +
        '<button class="btn" data-steps="8">На тройках<small>8 кадров в секунду — ещё более «рукотворно»</small></button>' +
        '<button class="btn" data-boil="1">Рисованная тряска контура<small>линии «дышат», как нарисованные от руки</small></button>' +
        '<button class="btn" data-boil="2">Сильная тряска контура<small>для дудлов и мультяшного стиля</small></button></div>' +
        '<p class="note">Выдели клип, графику или вложенную секвенцию. Лучше всего — на готовую анимацию: она станет «покадровой».</p></div>';
    },
    "Циклы": function () {
      return '<div class="sec"><h3>Период</h3><div class="row"><input type="range" id="per" min="0.4" max="4" step="0.1" value="' + per + '"><b id="perv">' + per + ' с</b></div>' +
        '<h3>Сила</h3><div class="row"><input type="range" id="amt" min="0.3" max="3" step="0.1" value="' + amt + '"><b id="amtv">×' + amt + '</b></div></div>' +
        '<div class="sec"><h3>На весь клип</h3><div class="list">' + LOOPS.map(function (l) { return '<button class="btn" data-loop="' + l[0] + '">' + l[1] + '<small>' + l[2] + '</small></button>'; }).join("") + '</div></div>';
    },
    "Появление": function () {
      return '<div class="sec"><h3>Несколько объектов</h3><div class="list"><button class="btn" data-stag="1">Лесенкой<small>выдели 2+ клипа — выскочат по очереди</small></button></div></div>' +
        '<div class="sec"><h3>Движение</h3><div class="list"><button class="btn" data-jump="2">Прыжок со сжатием<small>подпрыгивает и сплющивается на земле, 2 раза</small></button>' +
        '<button class="btn" data-jump="1">Один прыжок</button></div>' +
        '<div class="grid">' + [["left", "← по дуге"], ["right", "по дуге →"], ["up", "↑ по дуге"], ["down", "↓ по дуге"]].map(function (d) { return '<button class="card" data-arc="' + d[0] + '"><span class="pv" style="--a:slide"><i></i></span>' + d[1] + '</button>'; }).join("") + '</div></div>';
    }
  };
  var GROUPS = {};
  function loadLists(n) { // при запуске Премьера ExtendScript бывает ещё не готов — пробуем ещё раз
    run("ka_lists", [], function (r) {
      if (!r || /^(err|EvalScript error)/.test(String(r))) { if ((n || 0) < 8) setTimeout(function () { run("ka_setDir", [extDir()], function () { loadLists((n || 0) + 1); }); }, 1500); return; }
      String(r).split("|").forEach(function (g) { var p = g.split(">"); GROUPS[p[0]] = { fn: p[1], items: p[2].split(",").map(function (x) { var i = x.indexOf("="); return [x.slice(0, i), x.slice(i + 1)]; }) }; });
      render();
    });
  }
  function grid(name) {
    var g = GROUPS[name]; if (!g) return "";
    return '<div class="sec"><h3>' + name + ' · ' + g.items.length + '</h3><div class="grid">' + g.items.map(function (it) {
      var pv = /spin|roll|flip|orbit|spiral|circle/.test(it[0]) ? "pop" : /fly|crop|arc|zig|wave|bounce|boomer/.test(it[0]) ? "slide" : /shake|wiggle|boil|hand|flick|stut/.test(it[0]) ? "shake" : /hop|drop|jump|rise|float|hover/.test(it[0]) ? "drop" : /blink/.test(it[0]) ? "blink" : "zoom";
      return '<button class="card" data-g="' + g.fn + '" data-id="' + it[0] + '"><span class="pv" style="--a:' + pv + '"><i></i></span>' + it[1] + '</button>'; }).join("") + '</div></div>';
  }
  if (!TABS["Пути"]) TABS["Пути"] = function () { return grid("Пути") + '<p class="note">Выдели клип: он пройдёт путь за первые 2,5 секунды. Ключи потом можно двигать вручную.</p>'; };
  var tOld = TABS["Покадрово"], cOld = TABS["Циклы"], aOld = TABS["Появление"];
  TABS["Покадрово"] = function () { return GROUPS["Покадрово"] ? grid("Покадрово") + '<p class="note">Выдели клип, графику или вложенную секвенцию. Лучше всего — на готовую анимацию: она станет «покадровой».</p>' : tOld(); };
  TABS["Циклы"] = function () { var h = cOld(); return GROUPS["Циклы"] ? h.slice(0, h.indexOf('<div class="sec"><h3>На весь клип')) + grid("Циклы") : h; };
  TABS["Появление"] = function () { return GROUPS["Появление"] ? grid("Появление") + '<p class="note">Выдели клип: он появится за первые 0,6 секунды. Для «Каскада» выдели 2+ клипа.</p>' : aOld(); };
  var cur = "Покадрово";
  function render() {
    document.getElementById("tabs").innerHTML = Object.keys(TABS).map(function (k) { return '<button class="' + (k === cur ? "on" : "") + '" data-tab="' + k + '">' + k + '</button>'; }).join("");
    document.getElementById("view").innerHTML = TABS[cur]();
    var r = document.getElementById("per"); if (r) r.oninput = function () { per = +r.value; document.getElementById("perv").textContent = per + " с"; };
    var q = document.getElementById("amt"); if (q) q.oninput = function () { amt = +q.value; document.getElementById("amtv").textContent = "×" + amt; };
  }
  document.addEventListener("click", function (ev) {
    var b = ev.target.closest("button"); if (!b) return;
    if (b.dataset.tab) { cur = b.dataset.tab; render(); return; }
    if (b.dataset.g) { var fn = b.dataset.g, id = b.dataset.id; run(fn, fn === "ka_loop2" ? [id, per, amt] : fn === "ka_in2" ? [id, 0.6] : [id], say); return; }
    if (b.dataset.steps) run("ka_steps", [+b.dataset.steps], say);
    else if (b.dataset.boil) run("ka_boil", [+b.dataset.boil], say);
    else if (b.dataset.loop) run("ka_loop", [b.dataset.loop, per, amt], say);
    else if (b.dataset.stag) run("ka_stagger", [0.12, 0.35], say);
    else if (b.dataset.jump) run("ka_jump", [220, +b.dataset.jump], say);
    else if (b.dataset.arc) run("ka_arc", [b.dataset.arc, 400], say);
  });
  /* ---------- доступ по ключу из приложения КК ---------- */
  var ID = "kk-animacia", API = "https://script.google.com/macros/s/AKfycbw2LmiS_HoOdrIQko16UGsLNQj6T1Br2BymAb2bh8_iHPxOB8QyVgbiZ0vuPcwhHCPwyQ/exec", SITE = "https://kodkreatora.bybusha.com";
  var OFFLINE_DAYS = 30;
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { return null; } }
  function api(body) { return fetch(API, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify(body) }).then(function (r) { return r.json(); }); }
  var ERR = { bad_key: "Ключ не подошёл. Скопируй его заново в приложении КК.", not_student: "Доступ только для учениц программы КОД КРЕАТОРА.", expired: "Доступ к программе закончился.", soon: "Плагин скоро откроется ученицам." };
  function loginView(msg) {
    document.getElementById("tabs").innerHTML = "";
    document.getElementById("view").innerHTML = '<div class="login"><b style="font-size:14px">Вход в плагин</b>' +
      '<span class="note">Открой приложение КК → «Полезные материалы» → «Пак режиссёра монтажа» → плагин → «Получить ключ». Скопируй ключ и вставь сюда.</span>' +
      '<input id="key" placeholder="KK-…" autocomplete="off"><button class="btn y" id="go">Войти</button>' + (msg ? '<span class="note" style="color:#ff6b5b">' + msg + '</span>' : "") + '</div>';
    document.getElementById("go").onclick = function () { var k = document.getElementById("key").value.trim(); if (k) check(k, true); };
  }
  function enter(u) { document.getElementById("who").textContent = (u.n || "") + (u.u ? " · @" + u.u : ""); render(); checkUpdate(); }
  function check(key, interactive) {
    api({ api: "plugincheck", key: key }).then(function (r) {
      if (r.ok) { ls("kk_key", key); ls("kk_ok_at", String(Date.now())); ls("kk_user", JSON.stringify(r)); sharedWrite({ key: key, at: Date.now(), user: r }); enter(r); }
      else { if (r.error !== "soon" || interactive) { ls("kk_key", null); if (r.error === "bad_key" || r.error === "not_student" || r.error === "expired") sharedClear(); } loginView(ERR[r.error] || "Не получилось войти: " + (r.error || "")); }
    }).catch(function () {
      var sh = sharedRead() || {}, at = Math.max(+ls("kk_ok_at") || 0, sh.at || 0), u = ls("kk_user") || (sh.user ? JSON.stringify(sh.user) : null);
      if (!interactive && u && Date.now() - at < OFFLINE_DAYS * 864e5) enter(JSON.parse(u)); // без интернета — 30 дней по сохранённому входу
      else loginView("Нет интернета: для первого входа он нужен.");
    });
  }

  /* ---------- файлы: свои помощники — в старых Премьерах (Node 8) нет mkdirSync({recursive}) и rmSync ---------- */
  function mkdirp(d) { var fs = require("fs"), path = require("path"); if (fs.existsSync(d)) return; mkdirp(path.dirname(d)); fs.mkdirSync(d); }
  function rmrf(d) { var fs = require("fs"), path = require("path"); if (!fs.existsSync(d)) return;
    if (fs.lstatSync(d).isDirectory()) { fs.readdirSync(d).forEach(function (n) { rmrf(path.join(d, n)); }); fs.rmdirSync(d); } else fs.unlinkSync(d); }
  function extDir() { // file:///C:/… на Windows и file:///Users/… на Mac
    var p = decodeURIComponent(String(cep.getSystemPath("extension")).replace(/^file:\/\//, ""));
    return /^\/[A-Za-z]:/.test(p) ? p.slice(1) : p;
  }
  /* общий ключ для всех плагинов КК: файл в домашней папке, его читают оба плагина */
  function sharedFile() { var path = require("path"), os = require("os"); return path.join(os.homedir(), ".kodkreatora", "plugin-key.json"); }
  function sharedRead() { try { return JSON.parse(require("fs").readFileSync(sharedFile(), "utf8")); } catch (e) { return null; } }
  function sharedWrite(o) { try { var f = sharedFile(); mkdirp(require("path").dirname(f)); require("fs").writeFileSync(f, JSON.stringify(o)); } catch (e) {} }
  function sharedClear() { try { require("fs").unlinkSync(sharedFile()); } catch (e) {} }
  /* ---------- обновления ---------- */
  function newer(a, b) { a = a.split(".").map(Number); b = b.split(".").map(Number); for (var i = 0; i < 3; i++) { if ((a[i] || 0) > (b[i] || 0)) return true; if ((a[i] || 0) < (b[i] || 0)) return false; } return false; }
  function checkUpdate() {
    fetch(SITE + "/plugin/version.json?t=" + Date.now()).then(function (r) { return r.json(); }).then(function (v) {
      var me = v[ID]; if (!me || !newer(me.v, VERSION)) return;
      var u = document.getElementById("upd"); u.hidden = false;
      u.innerHTML = '<span>Вышла версия ' + me.v + (me.notes ? ": " + me.notes : "") + '</span><button class="btn y" id="doupd" style="width:auto;padding:5px 10px">Обновить</button>';
      document.getElementById("doupd").onclick = function () { update(me); };
    }).catch(function () {});
  }
  function copyDir(src, dst) { // своё копирование: в старых Премьерах нет fs.cpSync
    var fs = require("fs"), path = require("path");
    if (!fs.existsSync(dst)) mkdirp(dst);
    fs.readdirSync(src).forEach(function (n) { var a = path.join(src, n), b = path.join(dst, n);
      if (fs.statSync(a).isDirectory()) copyDir(a, b); else fs.writeFileSync(b, fs.readFileSync(a)); });
  }
  function update(me) {
    var u = document.getElementById("upd");
    try {
      var https = require("https"), fs = require("fs"), path = require("path"), os = require("os"), cp = require("child_process");
      var dir = extDir();
      if (fs.lstatSync(dir).isSymbolicLink()) { u.innerHTML = "<span>Это версия разработчика — обновление не ставлю</span>"; return; }
      var zip = path.join(os.tmpdir(), ID + "-" + me.v + ".zip"), out = fs.createWriteStream(zip);
      u.innerHTML = "<span>Скачиваю обновление…</span>";
      var get = function (url) { https.get(url, function (res) { if (res.statusCode >= 300 && res.headers.location) return get(res.headers.location); res.pipe(out); out.on("finish", function () { out.close(unpack); }); }).on("error", function () { u.innerHTML = "<span>Не скачалось. Проверь интернет.</span>"; }); };
      var unpack = function () {
        var tmp = path.join(os.tmpdir(), ID + "-new"); try { rmrf(tmp); } catch (e) {}
        var cmd = process.platform === "win32" ? 'powershell -NoProfile -Command "Expand-Archive -Force \'' + zip + '\' \'' + tmp + '\'"' : 'ditto -x -k "' + zip + '" "' + tmp + '"';
        cp.exec(cmd, function (err) {
          if (err) { u.innerHTML = "<span>Не распаковалось: " + err.message + "</span>"; return; }
          var src = path.join(tmp, ID); if (!fs.existsSync(src)) src = tmp;
          try { copyDir(src, dir); u.innerHTML = "<span>Готово! Перезапусти Премьер, чтобы включилась версия " + me.v + "</span>"; }
          catch (e2) { u.innerHTML = "<span>Не получилось заменить файлы: " + e2.message + "</span>"; }
        });
      };
      get(me.zip);
    } catch (e) { u.innerHTML = "<span>Обновление недоступно: " + e.message + "</span>"; }
  }

  document.getElementById("ver").textContent = "v" + VERSION;
  run("kk_ping", [], function (r) { var p = r.split("|"); if (p[0] !== "ok") document.getElementById("who").textContent = "нет связи с Premiere"; });
  var saved = ls("kk_key") || (sharedRead() || {}).key; // вошла в одном плагине КК — остальные открываются сами
  if (saved) check(saved, false); else loginView();
  try { run("ka_setDir", [extDir()], function () { loadLists(); }); } catch (e) {}
})();

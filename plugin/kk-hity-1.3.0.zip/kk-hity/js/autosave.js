/* КК — автосохранение проекта: одинаковый файл во всех панелях, настройка общая (~/.kodkreatora/autosave.json).
   Перед действием плагина или по таймеру; частоту держит kk_autosave в общем движке ExtendScript, поэтому 4 открытые панели не сохраняют вчетвером. */
window.KKAuto = (function () {
  var SKIP = /^(kk_ping|kk_setDir|km_setDir|ka_setDir|kk_autosave|kk_savedAt|kk_animList|kk_fxList|kk_transList|ka_lists|kh_trlist|kk_easeCurves|kk_exportAudio|kk_fmt)$/;
  var GAP = 60, EVERY = [0, 5, 10, 15, 30], cfg = { before: true, every: 0 };
  function file() { return require("path").join(require("os").homedir(), ".kodkreatora", "autosave.json"); }
  function load() {
    try { var o = JSON.parse(require("fs").readFileSync(file(), "utf8")); cfg = { before: o.before !== false, every: EVERY.indexOf(o.every) >= 0 ? o.every : 0 }; } catch (e) {}
    return cfg;
  }
  function store() {
    try { var fs = require("fs"); fs.mkdirSync(require("path").dirname(file()), { recursive: true }); fs.writeFileSync(file(), JSON.stringify(cfg)); } catch (e) {}
  }
  function wrap(fn, call) {
    if (SKIP.test(fn)) return call;
    return "kk_pre(" + (load().before ? GAP : 0) + ");kk_post(" + call + ")";
  }
  function state(c) {
    if (c.before && c.every) return "перед действиями и каждые " + c.every + " мин";
    if (c.before) return "перед действиями";
    return c.every ? "каждые " + c.every + " мин" : "выключено";
  }
  function hhmm(ms) { var d = new Date(ms), m = d.getMinutes(); return d.getHours() + ":" + (m < 10 ? "0" : "") + m; }
  function mount(run, say) {
    var ft = document.querySelector(".ft"); if (!ft) return;
    var st = document.createElement("style");
    st.textContent = ".kas{border-top:1px solid var(--line);font-size:11px}" +
      ".kas-h{display:flex;gap:6px;align-items:center;width:100%;background:none;border:0;color:var(--muted);padding:6px 10px;font:inherit;cursor:pointer;text-align:left}" +
      ".kas-h b{color:var(--text);font-weight:500;flex:1;min-width:0}.kas-h b.off{color:var(--bad)}.kas-h i{font-style:normal;color:var(--sun)}" +
      ".kas-b{display:flex;flex-direction:column;gap:8px;padding:2px 10px 10px}.kas-b[hidden]{display:none}" +
      ".kas-b label{display:flex;gap:6px;align-items:flex-start;cursor:pointer}.kas-b input{margin:1px 0 0}" +
      ".kas-r{display:flex;flex-wrap:wrap;gap:4px;align-items:center}.kas-r button{background:var(--panel2);color:var(--muted);border:0;border-radius:4px;padding:4px 7px;font:inherit;cursor:pointer}" +
      ".kas-r button.on{background:var(--sun);color:var(--ink);font-weight:700}.kas-r span{margin-right:2px}" +
      ".kas-n{color:var(--muted);font-size:10.5px;line-height:1.35}";
    document.head.appendChild(st);
    var box = document.createElement("div"); box.className = "kas";
    box.innerHTML = '<button class="kas-h" type="button" aria-expanded="false"><span>Автосохранение:</span><b></b><i>Настроить</i></button>' +
      '<div class="kas-b" hidden><label><input type="checkbox"><span>Сохранять проект перед каждым действием плагина (не чаще раза в минуту)</span></label>' +
      '<div class="kas-r"><span>По таймеру:</span>' + EVERY.map(function (m) { return '<button type="button" data-m="' + m + '">' + (m ? m + " мин" : "выкл") + "</button>"; }).join("") + "</div>" +
      '<div class="kas-r"><button type="button" class="kas-now">Сохранить сейчас</button><span class="kas-t kas-n"></span></div>' +
      '<div class="kas-n">Сохранение записывает проект поверх файла, как обычное сохранение. Таймер работает, пока открыта панель. Копии проекта по времени делает сам Премьер: Настройки → Автосохранение.</div></div>';
    ft.parentNode.insertBefore(box, ft);
    var head = box.querySelector(".kas-h"), body = box.querySelector(".kas-b"), chk = box.querySelector("input"), tm = box.querySelector(".kas-t");
    function paint() {
      var c = load(), b = head.querySelector("b");
      b.textContent = state(c); b.className = c.before || c.every ? "" : "off"; chk.checked = c.before;
      [].forEach.call(box.querySelectorAll("[data-m]"), function (el) { el.className = +el.getAttribute("data-m") === c.every ? "on" : ""; });
    }
    function stamp() { run("kk_savedAt", [], function (r) { var n = +r; tm.textContent = n ? "Плагин сохранял в " + hhmm(n) : ""; }); }
    head.onclick = function () { body.hidden = !body.hidden; head.setAttribute("aria-expanded", String(!body.hidden)); head.querySelector("i").textContent = body.hidden ? "Настроить" : "Свернуть"; paint(); if (!body.hidden) stamp(); };
    chk.onchange = function () { load(); cfg.before = chk.checked; store(); paint(); };
    box.addEventListener("click", function (e) {
      var m = e.target.getAttribute && e.target.getAttribute("data-m"); if (m === null || m === undefined) return;
      load(); cfg.every = +m; store(); paint();
    });
    box.querySelector(".kas-now").onclick = function () {
      run("kk_autosave", [0], function (r) { var s = String(r); say(s === "ok" ? "ok|Проект сохранён" : s === "no" ? "err|Нет открытого проекта" : "err|Не получилось сохранить, сохрани вручную"); stamp(); });
    };
    setInterval(function () { var c = load(); if (c.every) run("kk_autosave", [c.every * 60 - 5], function (r) { if (r === "ok" && !body.hidden) stamp(); }); paint(); }, 30000);
    paint();
  }
  return { wrap: wrap, mount: mount };
})();

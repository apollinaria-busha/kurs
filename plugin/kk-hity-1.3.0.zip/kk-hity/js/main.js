/* КК · Adobe Хиты — интерфейс панели: луки, легендарные эффекты и спрятанные переходы Премьера в один клик. */
(function () {
  var VERSION = "1.3.0";
  var cep = window.__adobe_cep__;
  function run(fn, args, cb) {
    var call = fn + "(" + (args || []).map(function (a) { return JSON.stringify(a); }).join(",") + ")";
    if (!cep) { cb && cb("err|Открой панель внутри Premiere Pro"); return; }
    // все панели КК живут в одном движке ExtendScript Премьера и перетирают общие функции —
    // перед каждой командой подгружаем свои файлы (на верхнем уровне: $.evalFile внутри функции не создаёт глобальных функций)
    var d = JSON.stringify(extDir());
    cep.evalScript("try{$.evalFile(new File(" + d + "+\"/jsx/host.jsx\"));kk_setDir(" + d + ");$.evalFile(new File(" + d + "+\"/jsx/presets.jsx\"));$.evalFile(new File(" + d + "+\"/jsx/hity.jsx\"));}catch(e){};" + (window.KKAuto ? KKAuto.wrap(fn, call) : call), function (r) { cb && cb(String(r || "")); });
  }
  if (window.KKAuto) KKAuto.mount(run, say);
  function say(r) {
    var m = document.getElementById("msg"), p = String(r).split("|");
    m.className = p[0] === "ok" ? "ok" : "err"; m.textContent = p.slice(1).join(" ") || r;
    clearTimeout(say.t); say.t = setTimeout(function () { m.textContent = ""; }, 7000);
  }
  /* ---------- каталог хитов ---------- */
  var LOOKS = [
    ["vhs", "VHS 1997", "Кассета: смаз, RGB-подёргивания, шум", "ретро", "#3b1f4d,#ff4fa3"],
    ["film16", "Плёнка 16 мм", "Зерно, мягкий контраст, «дыхание» кадра", "кино", "#3a2a18,#d9a45b"],
    ["digicam", "Мыльница 2000-х", "Пересвет, сочный цвет, шум матрицы", "y2k", "#9af2ff,#ff8bd8"],
    ["dream", "Дримкор", "Мечтательное свечение и выход из блюра", "тренд", "#f7c6cf,#c9b8e8"],
    ["pixel", "Пиксель-арт 8-бит", "Крупные пиксели и 12 к/с", "игры", "#2a1d5c,#00e5ff"],
    ["stopmo", "Стоп-моушн", "8 к/с и покачивание кадра", "тренд", "#e8833a,#2e6e6a"],
    ["night", "Ночное видение", "Зелёный монохром и шум", "фан", "#021a05,#a6ff8f"],
    ["cctv", "Камера наблюдения", "Ч/б, рыбий глаз, 10 к/с", "фан", "#111,#777"],
    ["comic", "Комикс", "Плоские цвета и чернильный контур", "арт", "#ffe04d,#ff4f79"],
    ["paint", "Масляная живопись", "Мазки кисти поверх кадра", "арт", "#5f7a4e,#d9a45b"],
    ["duotone", "Дуотон-постер", "Два цвета вместо всех", "дизайн", "#1d1453,#ff8fb3"],
    ["neon", "Неоновый контур", "Светящиеся края силуэта", "тренд", "#08070d,#8a5cff"],
    ["acid", "Кислотный стробоскоп", "Цветные вспышки и RGB в бит", "клип", "#ff2bd6,#00ff9c"],
    ["trails", "Эхо-шлейф", "Копии тянутся за движением", "танец", "#0a84ff,#ff375f"],
    ["flashback", "Флэшбэк", "Вспышка, ч/б, зерно, виньетка", "сторителлинг", "#eee,#333"],
    ["cinema", "Кино 2.39:1", "Широкий экран и плотный контраст", "кино", "#0a0a0a,#c9a86a"],
    ["glitchHit", "Глитч-хит", "Цифровой сбой и рваные RGB-удары", "tech", "#00ff9c,#7a5cff"],
    ["wobble", "Плывущий сон", "Кадр «дышит» и плывёт", "арт", "#a7b88f,#c9b8e8"]
  ];
  var LEGENDS = [
    ["lightning", "Молния", "Легендарный эффект из старой школы", "#0b0f2a,#9fd8ff"],
    ["flare", "Блик-пролёт", "Классический блик объектива через кадр", "#1a1200,#ffad05"],
    ["flares", "Блики объектива", "Современный многослойный блик", "#160a24,#ff8bd8"],
    ["rays", "Объёмные лучи", "Свет пробивает кадр", "#1c1608,#fff1b8"],
    ["edgeGlow", "Свечение краёв", "Неоновый ореол по контуру", "#04040a,#00e5ff"],
    ["echoGlow", "Эхо-свечение", "Светящиеся копии вокруг текста", "#10061c,#b26bff"],
    ["wonder", "Чудесное свечение", "Дорогой мягкий глоу", "#191410,#f7e1b5"],
    ["bokeh", "Боке", "Киношное размытие кругами", "#0e1726,#ffb36b"],
    ["chroma", "Хром. аберрации", "Цветная кайма винтажной линзы", "#0b0b0b,#ff375f"],
    ["rough", "Рваные края", "PNG и текст «из бумаги»", "#efe6d6,#c96b4b"],
    ["stroke", "Обводка", "Контур вокруг PNG и текста", "#111,#ffffff"],
    ["longShadow", "Длинная тень", "Плоская тень моушн-дизайна", "#ff8c42,#5c2a0a"],
    ["roundCrop", "Скруглённая рамка", "Кадр-карточка с углами", "#1c1c1e,#0a84ff"],
    ["clone", "Клоны", "Копии объекта рядом", "#ff2e88,#00e5ff"],
    ["focus", "Фокус-размытие", "Киношная глубина резкости", "#0e1726,#c9a86a"],
    ["magnify", "Лупа", "Увеличенный круг на детали", "#ffffff,#3d8bff"],
    ["wiggle", "Покачивание", "Живое дрожание без ключей", "#7a5cff,#9af2ff"],
    ["squeeze", "Сжатие", "Объект сплющивается и пружинит", "#ffd60a,#ff3b30"],
    ["glint", "Блик-звёздочка", "Блеск на светах для бьюти", "#f7c6cf,#ffffff"],
    ["leaks", "Засветка", "Тёплые засветы поверх клипа", "#5b2a12,#ffb36b"],
    /* v2: ещё 30 — от спокойных к дерзким (только эффекты, которые есть в списке Премьера 26.5) */
    ["sharpCrisp", "Хрустящая резкость", "Детали как с дорогой камеры", "#101418,#d8e7f0"],
    ["timecode", "Таймкод камеры", "Бегущие цифры, как на кассете", "#1a1a1a,#ff3b30"],
    ["softShadow", "Парящая тень", "Мягкая тень под PNG и текстом", "#2a2a2e,#000000"],
    ["pearl", "Перламутр", "Пастельный перелив четырёх цветов", "#ff8bd8,#9af2ff"],
    ["watercolor", "Акварель", "Кадр из мягких мазков кисти", "#c9b8e8,#f7e1b5"],
    ["leaveColor", "Один цвет", "Всё ч/б, кроме красного", "#222222,#d62828"],
    ["recolor", "Перекрасить цвет", "Красное становится жёлтым", "#d62828,#ffad05"],
    ["duoBrand", "Фирменный дуотон", "Кадр в чёрном и жёлтом КК", "#16130c,#ffad05"],
    ["spotlight", "Луч прожектора", "Пятно света гуляет по кадру", "#050505,#ffe6b0"],
    ["softWipe", "Мягкая шторка", "Кадр проявляется по диагонали", "#1c1c1e,#ffad05"],
    ["pixelIn", "Пиксельное появление", "Кадр собирается из блоков", "#0b0b0b,#00e5ff"],
    ["perspective", "Экран в пространстве", "Кадр наклонён и покачивается", "#0e1726,#3d8bff"],
    ["card3d", "3D-карточка", "Поворот в пространстве с бликом", "#1c1c1e,#e9c46a"],
    ["mirrorWorld", "Зеркальная симметрия", "Кадр отражается пополам", "#2a1d5c,#9af2ff"],
    ["relief", "Барельеф", "Кадр выбит на металле", "#3c3a36,#bdbdbd"],
    ["sketch", "Карандашный скетч", "Только контуры, как рисунок", "#ffffff,#555555"],
    ["poster", "Шелкография", "Четыре оттенка, как постер", "#ff4f79,#ffe04d"],
    ["xerox", "Ксерокс", "Жёсткое ч/б с зерном тонера", "#000000,#ffffff"],
    ["xray", "Рентген", "Негатив в холодном синем", "#020812,#9fd8ff"],
    ["swapColors", "Цвета наоборот", "Все оттенки разворачиваются", "#ff3b30,#0a84ff"],
    ["mirage", "Мираж", "Воздух дрожит, как в жару", "#ff8c42,#ffd27a"],
    ["timeClones", "Эхо-призраки", "Копии движения отстают на шаг", "#10061c,#b26bff"],
    ["lensWarp", "Комната смеха", "Кадр выгибается туда-сюда", "#7a5cff,#ffd60a"],
    ["vrGlitch", "Цифровой сбой", "Срывы и полосы, как сломанный стрим", "#00ff9c,#7a5cff"],
    ["speedSmear", "Смаз в бит", "Рывки скорости дважды в секунду", "#0a84ff,#ffffff"],
    ["scroll", "Бесконечная лента", "Кадр прокручивается по кругу", "#00e5ff,#ff2e88"],
    ["zoomPunch", "Зум-удар", "Влёт в кадр с настоящим смазом", "#ff3b30,#ffd60a"],
    ["strobe", "Стробоскоп", "Белые вспышки в бит", "#ffffff,#111111"],
    ["fisheye", "Скейт-фишай", "Выпуклый кадр из 2000-х", "#39ff14,#111111"],
    ["melt", "Жидкий кадр", "Картинка плавится и течёт", "#ff2bd6,#00ff9c"]
  ];
  var TRS = [
    ["Морфинг", "Склейка в середине фразы становится незаметной — магия для говорящей головы", /морфинг|morph cut/i, 10],
    ["Утечки света", "Тёплая плёночная засветка между кадрами", /утечки света|light leaks/i, 20],
    ["Хроматические утечки", "Цветные кислотные засветы", /хроматическ.*утечк|chroma leaks/i, 20],
    ["Зум Мёбиуса", "Затягивающий зум в спираль", /м[её]биус|mobius/i, 20],
    ["Сферическое размытие", "Кадр уплывает в сферу", /сферическ.*размыт|spherical blur/i, 15],
    ["Лучи света", "Вспышка лучей на склейке", /лучи света|световые лучи|light rays/i, 20],
    ["Случайные блоки", "Кадр рассыпается на блоки", /случайные блоки|random blocks/i, 15],
    ["Перекрёстный зум", "Влёт в кадр через зум", /перекр.*(масштаб|зум)|cross zoom/i, 15],
    ["Вращение куба", "Классика 2000-х — кадры на гранях куба", /куб|cube spin/i, 20],
    ["Переворот", "Кадр переворачивается как карточка", /^переворот|flip over/i, 20],
    ["Отклеивание страницы", "Кадр отклеивается как стикер", /отклеив|page peel/i, 25],
    ["Перелистывание", "Как страница журнала", /перелист|переворачивание страниц|page turn/i, 25],
    ["Растворение плёнки", "Мягкое киношное растворение", /растворение пл[её]нки|film dissolve/i, 15],
    ["Брызги краски", "Ретро-переход брызгами", /брызг|paint splatter/i, 20],
    ["Жалюзи", "Винтажные полоски", /жалюзи|venetian/i, 20],
    ["Часы", "Стрелка открывает кадр", /час.*(вытес|стрелк)|clock wipe/i, 20]
  ];
  var TRLIST = null, trFrames = 15, snd = "", look = "looks";
  function thumb(cols, label) { var c = cols.split(","); return '<span class="th" style="background:linear-gradient(135deg,' + c[0] + ',' + c[1] + ')"><i>' + label + '</i></span>'; }
  function prevImg(id, cols, label) { return '<span class="th" style="background:linear-gradient(135deg,' + cols.split(",")[0] + ',' + cols.split(",")[1] + ')"><img src="prev/' + id + '.jpg" onerror="this.remove()" alt=""><i>' + label + '</i></span>'; }
  var TABS = {};
  var lookGroup = "Все", lookQ = "";
  var CAT = (window.KH_CATALOG || []).map(function (l) { return [l[0], l[1], l[2], l[3], l[4]]; });
  if (!CAT.length) CAT = LOOKS.map(function (l) { return [l[0], l[1], l[2], "Луки", l[4]]; });
  TABS["Луки"] = function () {
    var groups = ["Все"]; CAT.forEach(function (l) { if (groups.indexOf(l[3]) < 0) groups.push(l[3]); });
    var q = lookQ.toLowerCase(), list = CAT.filter(function (l) { return (lookGroup === "Все" || l[3] === lookGroup) && (!q || (l[1] + " " + l[2]).toLowerCase().indexOf(q) >= 0); });
    return '<div class="sec"><input class="srch" id="lq" placeholder="Поиск: плёнка, неон, ч/б…" value="' + lookQ.replace(/"/g, "&quot;") + '">' +
      '<div class="tabs" style="padding:0;border:0">' + groups.map(function (g) { var n = g === "Все" ? CAT.length : CAT.filter(function (l) { return l[3] === g; }).length; return '<button class="' + (g === lookGroup ? "on" : "") + '" data-lg="' + g + '">' + g + ' · ' + n + '</button>'; }).join("") + '</div>' +
      '<div class="hits">' + list.map(function (l) { return '<button class="hit" data-look="' + l[0] + '">' + prevImg(l[0], l[4], l[3]) + '<b>' + l[1] + '</b><small>' + l[2] + '</small></button>'; }).join("") + '</div>' +
      '<p class="note">Выдели клип (или несколько) и нажми лук. Лук — это сразу несколько эффектов: всё подкручивается в «Элементах управления эффектами». Отменить — Cmd/Ctrl+Z. Луки «в бит» рассчитаны на 120 BPM — две доли в секунду.</p></div>';
  };
  TABS["Эффекты"] = function () {
    return '<div class="sec"><h3>Скрытые эффекты Премьера · ' + LEGENDS.length + '</h3><div class="hits">' + LEGENDS.map(function (l) {
      return '<button class="hit" data-leg="' + l[0] + '">' + prevImg("leg-" + l[0], l[3], "легенда") + '<b>' + l[1] + '</b><small>' + l[2] + '</small></button>'; }).join("") + '</div>' +
      '<p class="note">Эффекты, которые прячутся глубоко в Премьере или пришли из старых версий. Плагин ставит их уже настроенными и с анимацией.</p></div>';
  };
  var TRS2 = [["Перекрестное растворение", "Кросс-диссолв", "Мягкая смена кадра — база", "Классика", 15], ["Монтаж морфа", "Морфинг для говорящей головы", "Склейка в середине фразы становится незаметной", "Классика", 10], ["Растворение пленки", "Киношное растворение", "Мягче обычного, как на плёнке", "Классика", 15], ["Растворение размытия", "Растворение с размытием", "Кадр уплывает в блюр и проявляется", "Классика", 15], ["Аддитивное растворение", "Светлое растворение", "Сквозь вспышку света", "Классика", 12], ["Световое затухание", "Световое затухание", "Уход в свет и обратно", "Классика", 15], ["Погружение в черный", "В чёрное", "Классическая пауза между сценами", "Классика", 15], ["Погружение в белый", "В белое", "Светлый уход — воспоминание, сон", "Классика", 15], ["Погружение в цвет", "В цвет", "Уход в любой цвет бренда", "Классика", 15], ["Линейное вытеснение", "Шторка", "Новый кадр вытесняет старый", "Классика", 15], ["Плавное вытеснение", "Мягкая шторка", "Шторка с растушёванным краем", "Классика", 15], ["Слайд", "Слайд", "Новый кадр въезжает", "Классика", 12], ["Выталкивание", "Толчок", "Новый кадр выталкивает старый", "Классика", 12], ["Разделение", "Раздвижка", "Кадр раскрывается из центра", "Классика", 15], ["Затемнение цветности", "Растворение по цвету", "Кадры смешиваются по цветам", "Классика", 15], ["Направленное размытие", "Смаз-хлыст", "Резкий смаз как у блогеров", "Динамика", 8], ["Размытие масштабирования", "Зум-блюр", "Влёт в кадр со смазом", "Динамика", 10], ["Радиальное размытие", "Радиальный смаз", "Закрутка со смазом", "Динамика", 10], ["Перекрестное масштабирование", "Перекрёстный зум", "Зум из кадра в кадр", "Динамика", 12], ["Резкое движение", "Резкий рывок", "Быстрый толчок кадра", "Динамика", 8], ["Анимация движения", "Движение", "Кадры пролетают друг за другом", "Динамика", 12], ["Пружинное движение", "Пружина", "Кадр отскакивает как на пружине", "Динамика", 14], ["Вращательное движение", "Закрутка", "Кадр улетает вращаясь", "Динамика", 12], ["Вращение", "Вращение", "Поворот на 360", "Динамика", 12], ["3D-вращение", "3D-поворот", "Кадр поворачивается в объёме", "Динамика", 15], ["Обратное 3D-вращение", "3D-поворот обратный", "Объёмный поворот в другую сторону", "Динамика", 15], ["Анимация переворота", "Переворот карточки", "Кадр переворачивается как карта", "Динамика", 15], ["Землетрясение", "Землетрясение", "Тряска на стыке — удар, бит", "Динамика", 10], ["Деформация движения", "Деформация", "Кадр гнётся в движении", "Динамика", 12], ["Растягивание", "Растяжка", "Кадр растягивается и рвётся", "Динамика", 10], ["Растянутое вытеснение", "Растянутая шторка", "Шторка со стретчем", "Динамика", 12], ["Движение блока", "Блоки", "Кадр уезжает блоками", "Динамика", 14], ["Движение складывания", "Складывание", "Кадр складывается как бумага", "Динамика", 15], ["Перетягивание", "Перетягивание", "Кадры перетягивают друг друга", "Динамика", 12], ["Панельное вытеснение", "Панели", "Кадр меняется полосами-панелями", "Динамика", 14], ["Ступенчатое вытеснение", "Ступеньки", "Ступенчатая шторка", "Динамика", 14], ["Полоса", "Полосы", "Полосы пролетают через кадр", "Динамика", 12], ["Flash", "Вспышка", "Белая вспышка на стыке", "Динамика", 8], ["Мерцание", "Мерцание", "Кадр мигает и меняется", "Динамика", 10], ["Луч", "Луч", "Луч света проходит через стык", "Динамика", 14], ["Размытие объектива", "Расфокус", "Уход в расфокус и обратно", "Динамика", 14], ["Глитч", "Глитч", "Цифровой сбой на стыке", "Дерзко", 12], ["Поврежденная VHS-кассета", "VHS-кассета", "Рваная кассета — ретро-вайб", "Дерзко", 15], ["Включение телевизора", "Включение ТВ", "Как старый телевизор щёлкает", "Дерзко", 15], ["Кинопленка", "Киноплёнка", "Плёнка проезжает через кадр", "Дерзко", 15], ["Гранж", "Гранж", "Грязные текстуры на стыке", "Дерзко", 14], ["Стекло", "Стекло", "Кадр за рифлёным стеклом", "Дерзко", 15], ["Калейдоскоп", "Калейдоскоп", "Зеркальный калейдоскоп", "Дерзко", 15], ["Зеркало", "Зеркало", "Отражения на стыке", "Дерзко", 14], ["Мозаика", "Мозаика", "Кадр рассыпается на пиксели", "Дерзко", 12], ["Искажение жидкости", "Жидкость", "Кадр плывёт как жидкость", "Дерзко", 16], ["Волна", "Волна", "Кадр уходит волной", "Дерзко", 15], ["Неоновое вытеснение", "Неон", "Неоновая линия стирает кадр", "Дерзко", 15], ["Фосфор", "Фосфор", "Светящийся фосфорный переход", "Дерзко", 14], ["Соляризация", "Соляризация", "Кислотная инверсия цветов", "Дерзко", 12], ["Хаос", "Хаос", "Кадр рассыпается хаотично", "Дерзко", 15], ["Фрагментирование", "Осколки", "Кадр бьётся на фрагменты", "Дерзко", 15], ["Растворение формы", "Растворение формой", "Кадр проявляется через фигуру", "Дерзко", 15], ["Поток фигуры", "Поток фигур", "Фигуры заливают кадр", "Дерзко", 15], ["Звездное вытеснение", "Звезда", "Новый кадр раскрывается звездой", "Дерзко", 15], ["Утечка света", "Засветка", "Тёплая плёночная засветка", "Дерзко", 16], ["Утечка цветности", "Цветная засветка", "Кислотные цветные засветы", "Дерзко", 16], ["Свечение", "Свечение", "Стык уходит в свечение", "Дерзко", 14], ["Блик", "Блик", "Блик объектива на стыке", "Дерзко", 14], ["Скольжение источника света", "Скольжение света", "Свет скользит по кадру", "Дерзко", 16], ["Листание страницы", "Страница", "Кадр перелистывается как журнал", "Дерзко", 18], ["Лассо", "Лассо", "Кадр утягивается лассо", "Дерзко", 15], ["Кадр", "Рамка", "Кадр уходит в рамку", "Дерзко", 15], ["Масштаб-е Мебиуса VR", "Зум Мёбиуса", "Затягивающая спираль", "Дерзко", 18], ["Сфер. размыт. VR", "Сферическое размытие", "Кадр уплывает в сферу", "Дерзко", 15], ["Утечки света VR", "Засветка VR", "Мягкие световые пятна", "Дерзко", 18], ["Утечки цвет-ти VR", "Цветные пятна VR", "Разноцветные засветы", "Дерзко", 18], ["Световые лучи VR", "Лучи VR", "Вспышка лучей", "Дерзко", 16], ["Случ. прямоуг. VR", "Случайные блоки VR", "Кадр рассыпается прямоугольниками", "Дерзко", 15], ["Градиент. вытесн. VR", "Градиентная шторка", "Шторка по яркости кадра", "Дерзко", 16], ["Переворачивание страницы", "Отклеивание", "Кадр отклеивается как стикер", "Дерзко", 18], ["Жалюзи", "Жалюзи", "Винтажные полоски", "Дерзко", 15], ["Диафр.-ромб", "Ромб", "Ретро-диафрагма ромбом", "Дерзко", 15], ["Вытеснение по циферблату", "Часы", "Стрелка открывает кадр", "Дерзко", 15], ["Раздвижные двери", "Двери", "Кадр раздвигается как двери", "Дерзко", 15]];
  var trGroup = "Все";
  TABS["Переходы"] = function () {
    if (!TRLIST) { run("kh_trlist", [], function (r) { var p = r.split("|"); TRLIST = p[0] === "ok" ? p.slice(1).join("|").split("\u0001").map(function (x) { return x.trim(); }) : []; if (cur === "Переходы") render(); }); return '<p class="note">Смотрю, какие переходы есть в твоём Премьере…</p>'; }
    var avail = TRS2.filter(function (t) { return TRLIST.indexOf(t[0]) >= 0; });
    var groups = ["Все", "Классика", "Динамика", "Дерзко"], list = avail.filter(function (t) { return trGroup === "Все" || t[3] === trGroup; });
    return '<div class="sec"><h3>Длительность</h3><div class="row"><input type="range" min="6" max="40" value="' + trFrames + '" id="trf"><span id="trfv">' + trFrames + ' кадров</span></div></div>' +
      '<div class="sec"><h3>Звук к переходу</h3><div class="seg">' + [["", "Без звука"], ["whoosh", "Вжух"], ["impact", "Удар"], ["glitch", "Глитч"]].map(function (s) { return '<button class="' + (snd === s[0] ? "on" : "") + '" data-snd="' + s[0] + '">' + s[1] + '</button>'; }).join("") + '</div></div>' +
      '<div class="sec"><div class="tabs" style="padding:0;border:0">' + groups.map(function (g) { var n = g === "Все" ? avail.length : avail.filter(function (t) { return t[3] === g; }).length; return '<button class="' + (g === trGroup ? "on" : "") + '" data-tg="' + g + '">' + g + ' · ' + n + '</button>'; }).join("") + '</div>' +
      '<div class="list">' + list.map(function (t) { return '<button class="btn" data-tr="' + t[0].replace(/"/g, "&quot;") + '" data-fr="' + t[4] + '"><b>' + t[1] + '</b><small>' + t[2] + '</small></button>'; }).join("") + '</div></div>' +
      '<p class="note">Поставь плейхед точно на стык двух клипов и нажми переход — он встанет серединой на склейку. Показаны только переходы, которые есть в твоей версии Премьера (в 2025–2026 их больше всего).</p>';
  };
  var AEL = [], aeGroup = "Все", aeColor = "";
  try { AEL = JSON.parse(require("fs").readFileSync(extDir() + "/mogrt/legends.json", "utf8")); } catch (e) {}
  if (AEL.length) TABS["Легенды AE"] = function () {
    var groups = ["Все"]; AEL.forEach(function (l) { if (groups.indexOf(l.group) < 0) groups.push(l.group); });
    var sw = ["", "#FFD60A", "#FFAD05", "#FF2E88", "#00E5FF", "#39FF14", "#FFFFFF", "#8A5CFF"];
    return '<div class="sec"><h3>Цвет акцента</h3><div class="sw">' + sw.map(function (c) { return '<button class="dot' + (c === aeColor ? " on" : "") + '" data-aec="' + c + '" style="background:' + (c || "linear-gradient(135deg,#444,#888)") + '" title="' + (c ? c : "как в шаблоне") + '"></button>'; }).join("") + '</div></div>' +
      '<div class="sec"><div class="tabs" style="padding:0;border:0">' + groups.map(function (g) { return '<button class="' + (g === aeGroup ? "on" : "") + '" data-aeg="' + g + '">' + g + '</button>'; }).join("") + '</div>' +
      '<div class="hits">' + AEL.filter(function (l) { return aeGroup === "Все" || l.group === aeGroup; }).map(function (l) { return '<button class="hit" data-ael="' + l.id + '"><span class="th" style="background:#1e1e22"><span class="spr6" style="background-image:url(prev/legend-' + l.id + '.png)"></span><i>' + l.group + '</i></span><b>' + l.name.replace(/ \(.*\)$/, "") + '</b><small>' + (l.name.match(/\((.*)\)$/) || ["", "After Effects"])[1] + '</small></button>'; }).join("") + '</div>' +
      '<p class="note">Легендарные эффекты After Effects, которых нет в Премьере, — упакованы в шаблоны. Нажми — встанет на плейхед; свой текст вместо «ЗАГОЛОВОК», цвет и размер меняешь сама: выдели легенду на таймлайне → «Элементы управления эффектами» → «Параметры графики» (или «Окно → Основные графические элементы»).</p></div>';
  };
  var fr6 = 0; setInterval(function () { fr6 = (fr6 + 1) % 6; var a = document.querySelectorAll(".spr6"); for (var i = 0; i < a.length; i++) a[i].style.backgroundPosition = (fr6 * 20) + "% 0"; }, 350);
  var cur = "Луки";
  /* звуки из пака (саунд-дизайн стиля «КОД КРЕАТОРА») */
  var MAN = null;
  function withSound(cb) {
    if (!snd) return cb && cb();
    var go = function () { var it = ((MAN.styles.kk || {}).sfx || []).filter(function (s) { return s.id === snd; })[0]; if (!it) return cb && cb();
      var file = cachePath("kk", "sfx/" + snd + ".wav"); download(it.files.wav, file, function (err) { if (!err) run("kh_sound", [file, -0.15], function () { cb && cb(); }); else cb && cb(); }); };
    if (MAN) return go();
    fetch("https://kodkreatora.bybusha.com/pack/manifest.json?t=" + Date.now()).then(function (r) { return r.json(); }).then(function (m) { MAN = m; go(); }).catch(function () { cb && cb(); });
  }
  function cachePath(style, rel) { var path = require("path"), os = require("os"); return path.join(os.homedir(), "Documents", "КК Наборы", style, rel); }
  function download(url, file, done) {
    var fs = require("fs"), path = require("path"), https = require("https");
    if (fs.existsSync(file) && fs.statSync(file).size > 0) return done(null);
    mkdirp(path.dirname(file)); var tmp = file + ".part";
    (function get(u, n) { https.get(u, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location && n < 6) { res.resume(); return get(res.headers.location, n + 1); }
      if (res.statusCode !== 200) { res.resume(); return done(new Error("HTTP " + res.statusCode)); }
      var out = fs.createWriteStream(tmp); res.pipe(out); out.on("finish", function () { out.close(function () { fs.renameSync(tmp, file); done(null); }); });
    }).on("error", done); })(url, 0);
  }
  function render() {
    document.getElementById("tabs").innerHTML = Object.keys(TABS).map(function (k) { return '<button class="' + (k === cur ? "on" : "") + '" data-tab="' + k + '">' + k + '</button>'; }).join("");
    document.getElementById("view").innerHTML = TABS[cur]();
    var lq = document.getElementById("lq"); if (lq) { lq.oninput = function () { lookQ = lq.value; var p = lq.selectionStart; render(); var n = document.getElementById("lq"); n.focus(); n.setSelectionRange(p, p); }; }
    var r = document.getElementById("trf"); if (r) r.oninput = function () { trFrames = +r.value; document.getElementById("trfv").textContent = trFrames + " кадров"; };
  }
  document.addEventListener("click", function (ev) {
    var b = ev.target.closest("button"); if (!b) return;
    if (b.dataset.tab) { cur = b.dataset.tab; render(); return; }
    if (b.dataset.look) { say("ok|Собираю лук…"); run("kh_look2", [b.dataset.look], say); return; }
    if (b.dataset.lg) { lookGroup = b.dataset.lg; render(); return; }
    if (b.dataset.leg) { run("kh_legend", [b.dataset.leg], say); return; }
    if (b.dataset.aeg) { aeGroup = b.dataset.aeg; render(); return; }
    if (b.dataset.aec !== undefined) { aeColor = b.dataset.aec; render(); return; }
    if (b.dataset.ael) { run("kh_aelegend", [b.dataset.ael, aeColor], say); return; }
    if (b.dataset.tg) { trGroup = b.dataset.tg; render(); return; }
    if (b.dataset.snd !== undefined) { snd = b.dataset.snd; render(); return; }
    if (b.dataset.tr) { var name = b.dataset.tr, fr = Math.round((+b.dataset.fr || 15) * trFrames / 15); withSound(function () { run("kh_tr", [name, fr], say); }); return; }
  });

  /* ---------- доступ по ключу из приложения КК ---------- */
  var ID = "kk-hity", API = "https://script.google.com/macros/s/AKfycbw2LmiS_HoOdrIQko16UGsLNQj6T1Br2BymAb2bh8_iHPxOB8QyVgbiZ0vuPcwhHCPwyQ/exec", SITE = "https://kodkreatora.bybusha.com";
  var OFFLINE_DAYS = 30;
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); if (v === null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) { return null; } }
  function api(body) { return fetch(API, { method: "POST", headers: { "Content-Type": "text/plain;charset=utf-8" }, body: JSON.stringify(body) }).then(function (r) { return r.json(); }); }
  var ERR = { bad_key: "Ключ не подошёл. Скопируй его заново в приложении КК.", not_student: "Доступ только для учениц программы КОД КРЕАТОРА.", expired: "Доступ к программе закончился.", soon: "Плагин скоро откроется ученицам." };
  function loginView(msg) {
    document.getElementById("tabs").innerHTML = "";
    document.getElementById("view").innerHTML = '<div class="login"><b style="font-size:14px">Вход в плагин</b>' +
      '<span class="note">Открой приложение КК → «Полезные материалы» → «Пак режиссёра монтажа» → плагин → «Получить ключ». Скопируй ключ и вставь сюда.</span>' +
      '<input id="key" placeholder="KK-…" autocomplete="off"><button class="btn y" id="go">Войти</button>' + (msg ? '<span class="note" style="color:#ff6b5b">' + msg + '</span>' : "") + '</div>';
    document.getElementById("go").onclick = function () { var k = document.getElementById("key").value.trim(); if (k) check(k, true); };
  }
  function enter(u) { document.getElementById("who").textContent = (u.n || "") + (u.u ? " · @" + u.u : ""); render(); checkUpdate(); }
  function check(key, interactive) {
    api({ api: "plugincheck", key: key }).then(function (r) {
      if (r.ok) { ls("kk_key", key); ls("kk_ok_at", String(Date.now())); ls("kk_user", JSON.stringify(r)); sharedWrite({ key: key, at: Date.now(), user: r }); enter(r); }
      else { if (r.error !== "soon" || interactive) { ls("kk_key", null); if (r.error === "bad_key" || r.error === "not_student" || r.error === "expired") sharedClear(); } loginView(ERR[r.error] || "Не получилось войти: " + (r.error || "")); }
    }).catch(function () {
      var sh = sharedRead() || {}, at = Math.max(+ls("kk_ok_at") || 0, sh.at || 0), u = ls("kk_user") || (sh.user ? JSON.stringify(sh.user) : null);
      if (!interactive && u && Date.now() - at < OFFLINE_DAYS * 864e5) enter(JSON.parse(u)); // без интернета — 30 дней по сохранённому входу
      else loginView("Нет интернета: для первого входа он нужен.");
    });
  }

  /* ---------- файлы: свои помощники — в старых Премьерах (Node 8) нет mkdirSync({recursive}) и rmSync ---------- */
  function mkdirp(d) { var fs = require("fs"), path = require("path"); if (fs.existsSync(d)) return; mkdirp(path.dirname(d)); fs.mkdirSync(d); }
  function rmrf(d) { var fs = require("fs"), path = require("path"); if (!fs.existsSync(d)) return;
    if (fs.lstatSync(d).isDirectory()) { fs.readdirSync(d).forEach(function (n) { rmrf(path.join(d, n)); }); fs.rmdirSync(d); } else fs.unlinkSync(d); }
  function extDir() { // file:///C:/… на Windows и file:///Users/… на Mac
    var p = decodeURIComponent(String(cep.getSystemPath("extension")).replace(/^file:\/\//, ""));
    return /^\/[A-Za-z]:/.test(p) ? p.slice(1) : p;
  }
  /* общий ключ для всех плагинов КК: файл в домашней папке, его читают оба плагина */
  function sharedFile() { var path = require("path"), os = require("os"); return path.join(os.homedir(), ".kodkreatora", "plugin-key.json"); }
  function sharedRead() { try { return JSON.parse(require("fs").readFileSync(sharedFile(), "utf8")); } catch (e) { return null; } }
  function sharedWrite(o) { try { var f = sharedFile(); mkdirp(require("path").dirname(f)); require("fs").writeFileSync(f, JSON.stringify(o)); } catch (e) {} }
  function sharedClear() { try { require("fs").unlinkSync(sharedFile()); } catch (e) {} }
  /* ---------- обновления ---------- */
  function newer(a, b) { a = a.split(".").map(Number); b = b.split(".").map(Number); for (var i = 0; i < 3; i++) { if ((a[i] || 0) > (b[i] || 0)) return true; if ((a[i] || 0) < (b[i] || 0)) return false; } return false; }
  function checkUpdate() {
    fetch(SITE + "/plugin/version.json?t=" + Date.now()).then(function (r) { return r.json(); }).then(function (v) {
      var me = v[ID]; if (!me || !newer(me.v, VERSION)) return;
      var u = document.getElementById("upd"); u.hidden = false;
      u.innerHTML = '<span>Вышла версия ' + me.v + (me.notes ? ": " + me.notes : "") + '</span><button class="btn y" id="doupd" style="width:auto;padding:5px 10px">Обновить</button>';
      document.getElementById("doupd").onclick = function () { update(me); };
    }).catch(function () {});
  }
  function copyDir(src, dst) { // своё копирование: в старых Премьерах нет fs.cpSync
    var fs = require("fs"), path = require("path");
    if (!fs.existsSync(dst)) mkdirp(dst);
    fs.readdirSync(src).forEach(function (n) { var a = path.join(src, n), b = path.join(dst, n);
      if (fs.statSync(a).isDirectory()) copyDir(a, b); else fs.writeFileSync(b, fs.readFileSync(a)); });
  }
  function update(me) {
    var u = document.getElementById("upd");
    try {
      var https = require("https"), fs = require("fs"), path = require("path"), os = require("os"), cp = require("child_process");
      var dir = extDir();
      if (fs.lstatSync(dir).isSymbolicLink()) { u.innerHTML = "<span>Это версия разработчика — обновление не ставлю</span>"; return; }
      var zip = path.join(os.tmpdir(), ID + "-" + me.v + ".zip"), out = fs.createWriteStream(zip);
      u.innerHTML = "<span>Скачиваю обновление…</span>";
      var get = function (url) { https.get(url, function (res) { if (res.statusCode >= 300 && res.headers.location) return get(res.headers.location); res.pipe(out); out.on("finish", function () { out.close(unpack); }); }).on("error", function () { u.innerHTML = "<span>Не скачалось. Проверь интернет.</span>"; }); };
      var unpack = function () {
        var tmp = path.join(os.tmpdir(), ID + "-new"); try { rmrf(tmp); } catch (e) {}
        var cmd = process.platform === "win32" ? 'powershell -NoProfile -Command "Expand-Archive -Force \'' + zip + '\' \'' + tmp + '\'"' : 'ditto -x -k "' + zip + '" "' + tmp + '"';
        cp.exec(cmd, function (err) {
          if (err) { u.innerHTML = "<span>Не распаковалось: " + err.message + "</span>"; return; }
          var src = path.join(tmp, ID); if (!fs.existsSync(src)) src = tmp;
          try { copyDir(src, dir); u.innerHTML = "<span>Готово! Перезапусти Премьер, чтобы включилась версия " + me.v + "</span>"; }
          catch (e2) { u.innerHTML = "<span>Не получилось заменить файлы: " + e2.message + "</span>"; }
        });
      };
      get(me.zip);
    } catch (e) { u.innerHTML = "<span>Обновление недоступно: " + e.message + "</span>"; }
  }

  document.getElementById("ver").textContent = "v" + VERSION;
  run("kk_ping", [], function (r) { var p = r.split("|"); if (p[0] !== "ok") document.getElementById("who").textContent = "нет связи с Premiere"; });
  var saved = ls("kk_key") || (sharedRead() || {}).key; // вошла в одном плагине КК — остальные открываются сами
  if (saved) check(saved, false); else loginView();
  try { run("kk_setDir", [extDir()]); } catch (e) {}
})();
